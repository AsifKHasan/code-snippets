
sp_addlogin hanif, hanif1, inventory
use inventory
sp_adduser hanif

grant create table to hanif
grant create index to hanif
grant create view to hanif
grant create procedure to hanif
grant create trigger to hanif
grant create rule to hanif

grant alter table to hanif

grant drop table to hanif
grant drop index to hanif
grant drop view to hanif
grant drop procedure to hanif
grant drop trigger to hanif
grant drop rule to hanif


