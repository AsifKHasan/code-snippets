--Table 01
create table unit_info
(
unit_code		int		primary key,
unit_name		varchar(5)	not null
)

--Table 02
create table supp_info 
(
loc_code		varchar(5) 	not null,
supp_code		char(3)		not null,
supp_name		varchar(40)	not null,
cont_person		varchar(40),
supp_address		varchar(50),
supp_phone		varchar(30),
supp_fax		varchar(30),
supp_email		varchar(30),
supp_remarks		text,
constraint 		pk_supp
primary key (loc_code, supp_code)
)

--Table 03
create table main_group
(
--loc_code		varchar(5)	not null,
main_code		char(3)		not null,
main_name		varchar(30) 	not null,
main_particulars 	text,
constraint 		pk_main
--primary key (loc_code, main_code)
primary key (main_code)
)

--Table 04
create table sub_group
(
--loc_code		varchar(5) 	not null,
sub_code		char(3) 	not null,
main_code		char(3) 	not null,
sub_name		varchar(30) 	not null,
sub_particulars		text,
constraint 		pk_sub
--primary key (loc_code,main_code, sub_code),
--foreign key (loc_code, main_code) references main_group (loc_code, main_code)
primary key (main_code, sub_code),
foreign key (main_code) references main_group (main_code)
)

--Table 05
create table item_info
(
--loc_code		varchar(5)	not null,
sub_code		char(3)		not null,
main_code		char(3)		not null,
item_code		int		not null,
--i_code		int		identity,
i_code			varchar(11)	not null	primary key,
item_name		varchar(100)	not null,
unit_code		int		not null,
max_level		numeric		not null,
min_level		numeric		not null,
reorder_level		numeric		not null,
item_particulars 	text,
constraint 		fk_item_sub
--foreign key (loc_code, main_code, sub_code) references sub_group (loc_code, main_code, sub_code),
foreign key (main_code, sub_code) references sub_group (main_code, sub_code),
foreign key (unit_code) references unit_info(unit_code),
--primary key (loc_code,i_code)
)

--Table 06
create table dept_info
(
loc_code		varchar(5) 	not null,
dept_code		char(3) 	not null,
dept_name		varchar(30) 	not null,
dept_head		varchar(30) 	,
dept_particulars	text,
constraint 		pk_dept
primary key (loc_code, dept_code)
)

--Table 07
create table pur_req_info
(
--pur_req_code		int		identity	primary key,
pur_req_code		int		primary key,
pur_req_name		varchar(10) 	not null
)

--Table 08
create table dept_requisition
(
req_no			int		not null,
loc_code		varchar(5)	not null,
dept_code		varchar(3)	not null,
req_date		datetime	not null,
pur_req_code		int		not null	foreign key references pur_req_info(pur_req_code),
req_particulars 	text,
entry_by		varchar(15)	not Null,
constraint pk_dept_req
primary key (req_no, loc_code, dept_code),
foreign key (loc_code, dept_code) references dept_info (loc_code, dept_code)
)

--Table 09
create table dept_requisition_detail
(
req_no 			int		not null,
loc_code 		varchar(5)	not null,
dept_code		varchar(3)	not null,
--i_code			int		not null,
i_code			varchar(11)	not null,
req_qty 		numeric		not null,
constraint pr_depr_req_deta
primary key (loc_code,i_code,req_no,dept_code),
foreign key(req_no,loc_code,dept_code) references dept_requisition(req_no,loc_code,dept_code),
--foreign key(loc_code, i_code) references item_info(loc_code, i_code),
foreign key(i_code) references item_info(i_code)
)


--Table 10
create table del_mode
(
del_code 	int 		primary key,
del_mode 	varchar(20)	not null
)

--Table 11
create table mrr_in
(
sl_no 				int		not null,
supp_code 			char(3)		not null,
supp_challan_no 		varchar(15),
supp_date 			datetime,
entry_date 			datetime,
del_code 			int 		foreign key references del_mode(del_code),
pur_del_at			varchar(30),
loc_code 			varchar(5)	not null,
trans_receipt_no 		varchar(15),
arrival_date 			datetime,
pur_req_code 			int	 	foreign key references pur_req_info(pur_req_code),
pur_order_no 			varchar(15),
pur_order_date 			datetime,
mrr_remarks 			text,
pur_by 				varchar(50),
entry_by			varchar(15)	not Null,
constraint pk_mrr
primary key (sl_no,loc_code),
foreign key(loc_code,supp_code) references supp_info(loc_code, supp_code)
)


--Table 12
create table mrr_detail
(
sl_no 			int		not null,
loc_code 		varchar(5)	not null,
--i_code			int		not null,
i_code			varchar(11)	not null,
entry_date 		datetime,
mrr_qty 		numeric		not null,
mrr_price		money 		not null,
mrr_remarks 		text,
constraint fk_mrr1
foreign key(sl_no,loc_code) references mrr_in(sl_no,loc_code),
--foreign key(loc_code, i_code) references item_info(loc_code, i_code),
foreign key(i_code) references item_info(i_code),
primary key (loc_code,i_code,sl_no)
)

--Table 13
create table issue_dept
(
req_no			int		not null,
in_no	 		int 		not null,
loc_code 		varchar(5) 	not null,
dept_code		char(3) 	not null,
issue_date 		datetime,
issue_particulars 	text,
entry_by		varchar(15) 	not null,
constraint pk_issue
primary key (in_no,loc_code, dept_code),
foreign key (loc_code, dept_code) references dept_info(loc_code, dept_code)
)

--Table 14
create table issue_dept_detail
(
in_no			int		not null,
loc_code 		varchar(5) 	not null,
--i_code			int 		not null,
dept_code		char(3) 	not null,
i_code			varchar(11) 	not null,
issue_qty 		numeric		not null,
constraint pr_issue_detail
primary key (loc_code,i_code,in_no),
foreign key(in_no,loc_code, dept_code) references issue_dept(in_no,loc_code, dept_code),
--foreign key(loc_code, i_code) references item_info(loc_code, i_code)
foreign key(i_code) references item_info(i_code)
)

--Table 15
create table issue_factory
(
in_no	 		int 		not null,
loc_code 		varchar(5) 	not null,
req_no 			varchar(15),
fac_code		varchar(5) 	not null,
issue_date 		datetime,
issue_particulars 	text,
entry_by		varchar(15) 	not null,
constraint pk_issue_factory
primary key (in_no,loc_code)
)


--Table 16
create table issue_factory_detail
(
in_no			int 		not null,
loc_code 		varchar(5) 	not null,
--i_code			int 		not null,
i_code			varchar(11)	not null,
issue_qty 		numeric		not null,
constraint fk_issue_dept_detail1
foreign key(in_no,loc_code) references issue_factory(in_no,loc_code),
--foreign key(loc_code, i_code) references item_info(loc_code, i_code),
foreign key(i_code) references item_info(i_code),
primary key (loc_code,i_code,in_no)
)

--Table 17
create table opening_balance
(
loc_code 		varchar(5) 	not null,
--i_code			int 		not null,
i_code			varchar(11)	not null,
opp_qty			numeric		not null,
opp_price		money 		not null,
opp_date		datetime 	not null,
constraint fk_opp_bal1
--foreign key(loc_code, i_code) references item_info(loc_code, i_code),
foreign key(i_code) references item_info(i_code),
primary key (loc_code,i_code)
)

--Table 18
create table factory_name
(
loc_code 		varchar(5) 	not null 	primary key,
y_n			char(1) 	not null,
factory_name		varchar(50)	not null
)

--Table 19
create table factory_info
(
factory_name		varchar(50)	not null,
factory_address		varchar(70)	not null
)

--Table 20
create table bank_inv
(
sl_no 				int		not null,
supp_code 			char(3)		not null,
supp_challan_no 		varchar(15),
supp_date 			datetime,
entry_date 			datetime,
--del_code 			int 		foreign key references del_mode(del_code),
--pur_del_at			varchar(30),
loc_code 			varchar(5)	not null,
--trans_receipt_no 		varchar(15),
--arrival_date 			datetime,
in_out			int		not null,
pur_req_code 			int	 	foreign key references pur_req_info(pur_req_code),
pur_order_no 			varchar(15)	not null,
pur_order_date 			datetime,
bank_remarks 			text,
--pur_by 				varchar(50),
entry_by			varchar(15)	not Null,
constraint pk_bank
primary key (sl_no,loc_code),
foreign key(loc_code,supp_code) references supp_info(loc_code, supp_code)
)

--Table 21
create table bank_inv_detail
(
sl_no 			int		not null,
loc_code 		varchar(5)	not null,
i_code			varchar(11)	not null,
--pur_order_no 		varchar(15)	not null,
entry_date 		datetime,
item_qty 		numeric		not null,
remain_qty 		numeric		not null,
in_out			int		not null,
item_price		money 		not null,
bank_remarks 		text,
constraint fk_bank1
foreign key(sl_no,loc_code) references bank_inv(sl_no,loc_code),
foreign key(i_code) references item_info(i_code),
primary key (loc_code,i_code,sl_no)
)

drop table bank_inv_detail
drop table bank_inv
