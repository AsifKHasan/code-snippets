--View 01
create view v_subgroup
as
select subgroupcode,subgroup.maingroupcode,subgroupname,subgroupparticular,maingroupname
from subgroup
join maingroup
on maingroup.maingroupcode=subgroup.maingroupcode

--View 02
create view v_mrr1
as
select	mrr_in.sl_no, mrr_in.supp_code, mrr_in.supp_challan_no, mrr_in.supp_date, 
	mrr_in.entry_date, mrr_in.del_code, mrr_in.pur_del_at, 
	mrr_in.loc_code, mrr_in.trans_receipt_no, mrr_in.arrival_date, 
	mrr_in.pur_req_code, mrr_in.pur_order_no, mrr_in.pur_order_date, 
	mrr_in.mrr_remarks, mrr_in.pur_by, 
	mrr_detail_item.main_code, mrr_detail_item.sub_code, mrr_detail_item.item_code, 
	mrr_detail_item.item_name, mrr_detail_item.unit_code, 
	mrr_detail_item.i_code, mrr_detail_item.mrr_qty, 
	mrr_detail_item.mrr_price, mrr_detail_item.mrr_detai_rem
from mrr_in
join
	(
	select mrr_detail.sl_no, mrr_detail.loc_code, mrr_detail.i_code, 
	item_info.main_code, item_info.sub_code, item_info.item_code, 
	item_info.item_name, item_info.unit_code, mrr_detail.mrr_qty, 
	mrr_detail.mrr_price, mrr_detail.mrr_remarks as mrr_detai_rem
	from mrr_detail
	join
	item_info
	on mrr_detail.loc_code=item_info.loc_code and mrr_detail.i_code=item_info.i_code
	)
as mrr_detail_item
on mrr_in.loc_code=mrr_detail_item.loc_code and mrr_in.sl_no=mrr_detail_item.sl_no


--View 03
create view v_mrr
as
select	mrr_in.sl_no, mrr_in.loc_code, mrr_in.entry_date, mrr_in.pur_order_no, 
	mrr_in.pur_order_date, supp_info.supp_name, mrr_in.supp_challan_no, 
	mrr_in.pur_by, mrr_in.supp_date, mrr_in.arrival_date, 
	mrr_in.trans_receipt_no, mrr_in.pur_del_at, mrr_in.mrr_remarks, 
	mrr_detail.mrr_remarks as mrr_detai_rem, mrr_in.supp_code, mrr_in.del_code, 
	mrr_in.pur_req_code, mrr_detail.i_code, mrr_detail.mrr_qty, mrr_detail.mrr_price, 
	item_info.main_code, item_info.sub_code, item_info.item_code, 
	item_info.item_name, item_info.unit_code, unit_info.unit_name, 
	pur_req_info.pur_req_name,del_mode.del_mode, Supp_address
from mrr_in, mrr_detail, item_info, supp_info, unit_info, pur_req_info, del_mode
where 	(mrr_in.loc_code=mrr_detail.loc_code and mrr_in.sl_no=mrr_detail.sl_no) and
	(mrr_detail.i_code=item_info.i_code) and
	(mrr_in.loc_code=supp_info.loc_code and mrr_in.supp_code=supp_info.supp_code) and
	(item_info.unit_code=unit_info.unit_code) and
	(pur_req_info.pur_req_code=mrr_in.pur_req_code) and
	(del_mode.del_code=mrr_in.del_code)


select * from v_mrr

select * from mrr_in

drop view v_mrr

