DISK INIT 
NAME 		= 'inventory_device',
PHYSNAME 	= 'D:\Mssql\Data\Inventory.dat',
VDEVNO 		= 255,
SIZE 		= 8192,
VSTART 		= 0

DISK INIT 
NAME 		= 'invlog_device',
PHYSNAME 	= 'D:\Mssql\Data\Invlog.dat',
VDEVNO 		= 254,
SIZE 		= 4096,
VSTART 		= 0
