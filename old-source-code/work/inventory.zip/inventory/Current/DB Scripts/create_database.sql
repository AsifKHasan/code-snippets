create database inventory
on inventory_device
log on invlog_device
