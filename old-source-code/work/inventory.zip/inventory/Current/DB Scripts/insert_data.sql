insert into unit_info (unit_code, unit_name) values(1, 'KGS.')
insert into unit_info (unit_code, unit_name) values(2, 'LBS.')
insert into unit_info (unit_code, unit_name) values(3, 'PCS.')


insert main_group values ('001','Chemical','Chemical Type')
insert main_group values ('002','Electrical','Electrical Type')
insert main_group values ('003','Mechanical','Mechanical Type')

insert sub_group values ('001','001','Hydrogen per oxide','Used for reagent')
insert sub_group values ('003','001','Nitrogen per oxide','Used for reagent')
insert sub_group values ('002','001','Oxigen','Used for Sholdering')

--			sub_code,main_code,item_code,i_code,item_name,unit_code,max_level,min_level,reorder_level,item_particulars
--delete from item_info

insert into item_info values('001', '001', 1, '0010011', 'Item111', 1, 130.5, 100, 20, 'Used for Sholdering')
insert into item_info values('001', '001', 2, '0010012', 'Item112', 2, 150.3, 110, 30, 'Used for Nothing')


insert into factory_name (loc_code,y_n,factory_name) values('SNIL','N','Sonali Newsprint Industried Ltd.')

insert into pur_req_info (pur_req_code, pur_req_name) values(1, 'CASH')

insert into del_mode (del_code, del_mode) values(1, "CARGO")

insert into dept_info 
	(loc_code,dept_code,dept_name,dept_head,dept_particulars)
	values('SNIL','001','Mechanical','Hanif','Deal with Mechanical Items')

--insert into dept_requisition 
--	(req_no, loc_code, dept_code, req_date, pur_req_code, req_particulars)
--	values(1, 'SNIL','001','06/19/2000',1,'Cash Purchase')

insert into opening_balance 
	(loc_code, i_code,opp_qty,opp_price,opp_date)
	values('SNIL', '0010011',100.6,15.5,'01/07/2000')

insert into supp_info 
(loc_code, supp_code,supp_name,cont_person,supp_address,supp_phone,supp_fax,supp_email,supp_remarks) 
values('SNIL', '001','Spectrum','Naved','Panthapath','9122222','912222','spectrum@bangla.net','Supplier 01')

insert factory_info values('Shahjalal Newsprint Induatries Ltd.', 'Meghnaghat, Sonargaon, Narayangamnj')
