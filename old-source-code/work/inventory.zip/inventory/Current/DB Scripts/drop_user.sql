use inventory
sp_dropalias hanif
sp_dropuser hanif
sp_droplogin hanif
