// Dialog.h : main header file for the DIALOG application
//

#if !defined(AFX_DIALOG_H__FBB088FD_80CC_11D2_A9DB_00A024C905B6__INCLUDED_)
#define AFX_DIALOG_H__FBB088FD_80CC_11D2_A9DB_00A024C905B6__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

#define NUM_COLUMNS 10
#define ROW_HEIGHT 700
//#define INDEX_HEIGHT 2000
//#define INDEX_WIDTH	100


/////////////////////////////////////////////////////////////////////////////
// CDialogApp:
// See Dialog.cpp for the implementation of this class
//
#define	ID_DISABLE					0
#define	ID_ACTIVE					1
#define	ID_INPROCESS				2
#define	ID_PRODUCED_INC				3
#define	ID_PRODUCED_COM				4
#define	ID_BATCH_NOT_AVAILABLE		5

#define	COLOR_BACK_INACTIVE				0x00404040
#define	COLOR_FORE_INACTIVE				0x00ffffff

#define	COLOR_BACK_DISABLED				0x00808080
#define	COLOR_FORE_DISABLED				0x00ffffff

#define	COLOR_BACK_NOBATCH				0x00b0b0b0
#define	COLOR_FORE_NOBATCH				0x00000000

#define	COLOR_CELL_BACK					0x00f0f0f0
#define	COLOR_CELL_FORE					0x00000000

#define	COLOR_CELL_BACK_PRODUCED_INC	RGB(255, 150, 150)
#define	COLOR_CELL_FORE_PRODUCED_INC	0x00000000

#define	COLOR_CELL_BACK_PRODUCED_COM	RGB(200, 255, 200)
#define	COLOR_CELL_FORE_PRODUCED_COM	0x00000000

#define	COLOR_CELL_BACK_INPROCESS		RGB(0, 206, 255)
#define	COLOR_CELL_FORE_INPROCESS		0x00000000

class CDialogApp : public CWinApp
{
public:
	CDialogApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDialogApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CDialogApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DIALOG_H__FBB088FD_80CC_11D2_A9DB_00A024C905B6__INCLUDED_)
