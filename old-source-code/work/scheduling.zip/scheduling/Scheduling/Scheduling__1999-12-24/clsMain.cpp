// clsMain.cpp : implementation file
//

#include "stdafx.h"
#include "Scheduling.h"
#include "clsMain.h"
#include "clsCell.h"
#include "ScheduleSet.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

extern enum Codes;

/////////////////////////////////////////////////////////////////////////////
// clsMain


clsMain::clsMain()
{
	OrderCount		= 0;
	MCount			= 0;
	m_Connected		= FALSE;
	m_LoadProcessed	= FALSE;
	m_nBatch		= 0;

	ordercolors[0].red		= 0;
	ordercolors[0].green	= 0;
	ordercolors[0].blue		= 0;

	ordercolors[1].red		= 64;
	ordercolors[1].green	= 64;
	ordercolors[1].blue		= 64;

	ordercolors[2].red		= 128;
	ordercolors[2].green	= 128;
	ordercolors[2].blue		= 128;

	ordercolors[3].red		= 192;
	ordercolors[3].green	= 192;
	ordercolors[3].blue		= 192;

	ordercolors[4].red		= 255;
	ordercolors[4].green	= 0;
	ordercolors[4].blue		= 0;

	ordercolors[5].red		= 192;
	ordercolors[5].green	= 0;
	ordercolors[5].blue		= 0;

	ordercolors[6].red		= 128;
	ordercolors[6].green	= 0;
	ordercolors[6].blue		= 0;

	ordercolors[7].red		= 64;
	ordercolors[7].green	= 0;
	ordercolors[7].blue		= 0;

	ordercolors[8].red		= 0;
	ordercolors[8].green	= 240;
	ordercolors[8].blue		= 64;

	ordercolors[9].red		= 0;
	ordercolors[9].green	= 192;
	ordercolors[9].blue		= 0;

	ordercolors[10].red		= 0;
	ordercolors[10].green	= 128;
	ordercolors[10].blue		= 0;

	ordercolors[11].red		= 0;
	ordercolors[11].green	= 64;
	ordercolors[11].blue		= 0;

	ordercolors[12].red		= 0;
	ordercolors[12].green	= 0;
	ordercolors[12].blue	= 255;

	ordercolors[13].red		= 0;
	ordercolors[13].green	= 0;	
	ordercolors[13].blue	= 192;

	ordercolors[14].red		= 0;
	ordercolors[14].green	= 0;	
	ordercolors[14].blue	= 128;
	
	ordercolors[15].red		= 0;
	ordercolors[15].green	= 0;	
	ordercolors[15].blue	= 64;
	
	ordercolors[16].red		= 255;
	ordercolors[16].green	= 192;
	ordercolors[16].blue		= 0;

	ordercolors[17].red		= 255;
	ordercolors[17].green	= 128;
	ordercolors[17].blue		= 0;

	ordercolors[18].red		= 255;
	ordercolors[18].green	= 64;
	ordercolors[18].blue		= 0;

	ordercolors[19].red		= 192;
	ordercolors[19].green	= 192;
	ordercolors[19].blue		= 0;

	ordercolors[20].red		= 192;
	ordercolors[20].green	= 128;
	ordercolors[20].blue		= 0;

	ordercolors[21].red		= 192;
	ordercolors[21].green	= 64;
	ordercolors[21].blue		= 0;

	ordercolors[22].red		= 128;
	ordercolors[22].green	= 192;
	ordercolors[22].blue		= 0;

	ordercolors[23].red		= 128;
	ordercolors[23].green	= 128;
	ordercolors[23].blue	= 0;

	ordercolors[24].red		= 128;
	ordercolors[24].green	= 64;
	ordercolors[24].blue	= 0;

	ordercolors[25].red		= 64;
	ordercolors[25].green	= 192;	
	ordercolors[25].blue	= 0;

	ordercolors[26].red		= 64;
	ordercolors[26].green	= 128;	
	ordercolors[26].blue	= 0;
	
	ordercolors[27].red		= 64;
	ordercolors[27].green	= 64;	
	ordercolors[27].blue	= 0;

	ordercolors[28].red		= 255;
	ordercolors[28].green	= 0;
	ordercolors[28].blue		= 255;

	ordercolors[29].red		= 255;
	ordercolors[29].green	= 0;
	ordercolors[29].blue		= 192;

	ordercolors[30].red		= 255;
	ordercolors[30].green	= 0;
	ordercolors[30].blue		= 128;

	ordercolors[31].red		= 255;
	ordercolors[31].green	= 0;
	ordercolors[31].blue		= 64;

	ordercolors[32].red		= 192;
	ordercolors[32].green	= 0;
	ordercolors[32].blue		= 255;

	ordercolors[33].red		= 192;
	ordercolors[33].green	= 0;
	ordercolors[33].blue		= 192;

	ordercolors[34].red		= 192;
	ordercolors[34].green	= 0;
	ordercolors[34].blue		= 128;

	ordercolors[35].red		= 192;
	ordercolors[35].green	= 0;
	ordercolors[35].blue		= 64;

	ordercolors[36].red		= 128;
	ordercolors[36].green	= 0;
	ordercolors[36].blue		= 255;

	ordercolors[37].red		= 128;
	ordercolors[37].green	= 0;
	ordercolors[37].blue		= 192;

	ordercolors[38].red		= 128;
	ordercolors[38].green	= 0;
	ordercolors[38].blue	= 128;

	ordercolors[39].red		= 128;
	ordercolors[39].green	= 0;
	ordercolors[39].blue	= 64;

	ordercolors[40].red		= 64;
	ordercolors[40].green	= 0;
	ordercolors[40].blue	= 255;

	ordercolors[41].red		= 64;
	ordercolors[41].green	= 0;
	ordercolors[41].blue	= 192;	

	ordercolors[42].red		= 64;
	ordercolors[42].green	= 0;
	ordercolors[42].blue	= 128;	
	
	ordercolors[43].red		= 64;
	ordercolors[43].green	= 0;
	ordercolors[43].blue	= 64;	

	ordercolors[44].red	= 0;
	ordercolors[44].green		= 192;
	ordercolors[44].blue		= 192;

	ordercolors[45].red	= 0;
	ordercolors[45].green		= 192;
	ordercolors[45].blue		= 128;

	ordercolors[46].red	= 0;
	ordercolors[46].green		= 192;
	ordercolors[46].blue		= 64;

	ordercolors[47].red	= 0;
	ordercolors[47].green		= 128;
	ordercolors[47].blue		= 255;

	ordercolors[48].red	= 0;
	ordercolors[48].green		= 128;
	ordercolors[48].blue		= 192;

	ordercolors[49].red	= 0;
	ordercolors[49].green		= 128;
	ordercolors[49].blue	= 128;

	ordercolors[50].red	= 0;
	ordercolors[50].green		= 128;
	ordercolors[50].blue	= 64;

	ordercolors[51].red	= 0;
	ordercolors[51].green		= 64;
	ordercolors[51].blue	= 255;

	ordercolors[52].red	= 0;
	ordercolors[52].green		= 64;
	ordercolors[52].blue	= 192;	

	ordercolors[53].red	= 0;
	ordercolors[53].green		= 64;
	ordercolors[53].blue	= 128;	
	
	ordercolors[54].red	= 0;
	ordercolors[54].green		= 64;
	ordercolors[54].blue	= 64;	
}

clsMain::~clsMain()
{
	OrderArray.RemoveAll();
	IndexArray.RemoveAll();
	MachineArray.RemoveAll();
	table.RemoveAll();
}

clsMain::Connect(int pDays)
{
		
	if (!m_Database.Open( _T("Schedule"), FALSE, FALSE, _T("ODBC;"), FALSE))
	{		
		cmsg.raise_Error(SCH_ERR_CONNECT_FAILED);
		m_Connected	= TRUE;
	}	
	m_Connected	= TRUE;
	TotalDays = pDays;
	return m_Connected;
}


clsMain::LoadOrder()
{
	COrderSet		m_OrderSet(&m_Database);			
	
	OrderCount	= 0;
	clsOrder tempOrder;
	
	// remove all previous orders
	OrderArray.RemoveAll();

	m_OrderSet.m_strSort = "deliverydate";
	if(!m_LoadProcessed)
	{
		m_OrderSet.m_strFilter = "dyecomplete = 0";
	}
	if (!m_OrderSet.Open())
	{		
		cmsg.raise_Error(SCH_ERR_ORDER_LOAD_FAILED);
		return FALSE;
	}		
	m_OrderSet.MoveFirst();
	m_first_date = m_OrderSet.m_deliverydate;
	while ( !m_OrderSet.IsEOF( ) )
	{
		tempOrder.m_wo_id			= m_OrderSet.m_wo_id;
		tempOrder.m_shade			= m_OrderSet.m_shade;		
		tempOrder.m_quantity		= m_OrderSet.m_quantity;
		tempOrder.m_deliverydate	= m_OrderSet.m_deliverydate;		
		tempOrder.m_count_name		= m_OrderSet.m_count_name;
		tempOrder.m_yarn_type		= m_OrderSet.m_yarn_type.Left(12);
		tempOrder.m_workorder_no	= m_OrderSet.m_workorder_no;
		tempOrder.m_leftover		= m_OrderSet.m_left_over;		
		tempOrder.m_scamt			= m_OrderSet.m_scamt;		
		tempOrder.m_client_name		= m_OrderSet.m_client_name.Left(20);		
		tempOrder.m_client_id		= m_OrderSet.m_client_id;		
		tempOrder.m_dyecomplete		= m_OrderSet.m_dyecomplete;		
		tempOrder.orderColor		= (COLORREF)RGB(ordercolors[m_OrderSet.m_client_id%55].red, ordercolors[m_OrderSet.m_client_id%55].green, ordercolors[m_OrderSet.m_client_id%55].blue);
		OrderArray.Add(tempOrder);
		OrderCount++;			
		m_OrderSet.MoveNext();					
	}	
	return TRUE;
}

clsMain::LoadSelOrder()
{
	CSelOrderset	m_SelOrderSet(&m_Database);			
	clsSelOrder		tempOrder;
	
	SelOrderCount	= 0;
	
	// remove all previous orders
	SelOrderArray.RemoveAll();

	//m_SelOrderSet.m_strSort = "m_wo_id";
	if (!m_SelOrderSet.Open())
	{		
		cmsg.raise_Error(SCH_ERR_ORDER_LOAD_FAILED);
		return FALSE;
	}		
	while( !m_SelOrderSet.IsEOF( ) )
	{
		m_SelOrderSet.MoveNext();					
		tempOrder.m_wo_id			= m_SelOrderSet.m_wo_id;
		tempOrder.m_sel_group		= m_SelOrderSet.m_sel_group;		
		SelOrderArray.Add(tempOrder);
		SelOrderCount++;			
	}	
	return TRUE;
}

clsMain::LoadMachine()
{
	CMachinesSet	m_MachineSet(&m_Database);	
	clsMachine tempMachine;
	
	MachineArray.RemoveAll();
	MCount	= 0;

	m_MachineSet.m_strSort = "capacity DESC";
	if (!m_MachineSet.Open())
	{
		cmsg.raise_Error(SCH_ERR_MACHINE_LOAD_FAILED);
		return FALSE;
	}

	m_MachineSet.MoveFirst();
	while ( !m_MachineSet.IsEOF( ) )
	{
		tempMachine.m_batchcount	= m_MachineSet.m_batchcount;
		if(tempMachine.m_batchcount > m_nBatch)
		{
			m_nBatch = tempMachine.m_batchcount;
		}
		tempMachine.m_capacity		= m_MachineSet.m_capacity;
		tempMachine.m_liquor		= m_MachineSet.m_liquor;
		tempMachine.m_machine_id	= m_MachineSet.m_machine_id;
		tempMachine.m_machine_name	= m_MachineSet.m_machine_name;
		tempMachine.m_maxcapacity	= m_MachineSet.m_maxcapacity;
		tempMachine.m_mincapacity	= m_MachineSet.m_mincapacity;
		tempMachine.m_specification	= m_MachineSet.m_specification;
		tempMachine.m_status		= m_MachineSet.m_status;
		tempMachine.m_enabled		= m_MachineSet.m_enabled;
		MachineArray.Add(tempMachine);

		MCount++;
		m_MachineSet.MoveNext();
	}	

	return TRUE;		
}


CString   clsMain::GetMachineName(long index)
{
	return MachineArray[index].m_machine_name;
}

long clsMain::GetMachineCount()
{
	return MCount;
}

double clsMain::GetMachineCapacity(long index)
{
		return MachineArray[index].m_capacity;

}

BOOL clsMain::Schedule(long index, CTime pStartDate, int pDays, double pAmount)
{
	int		SplitCount, RunningCount;
	int		TotalRow = pDays * m_nBatch;

	double  total, Quantity;
	int		i, j, PrevRow, PrevCol, row, col, BackTrack;
	int		tmprow, tmpcol;
	BOOL	Quit, Return, Solved ;		
		
	//initializaton
	total =  Quantity = pAmount;
	//total = Total; 
	row				= 0; 
	col				= 0;	
	PrevRow			= -1; 
	PrevCol			= -1;
	BackTrack		= FALSE;	
	Quit			= FALSE;
	Return			= FALSE;
	SplitCount		= 32000;  //arbitary large value
	RunningCount	= 0;
	Solved			= FALSE;
		
	while (!Quit)
	{	
		if (BackTrack)
		{
			row = PrevRow;
			col = PrevCol;
			BackTrack = FALSE;
			if(table[row * MCount + col].m_amount == MachineArray[col].m_capacity && !Return)
			{
				//allocating maximum capacity 
				total -= MachineArray[col].m_maxcapacity - MachineArray[col].m_capacity; //maximum load
				table[row * MCount + col].m_amount = MachineArray[col].m_maxcapacity;
				PrevRow = row;
				PrevCol = col;					
			}
			else if(table[row * MCount + col].m_amount == MachineArray[col].m_maxcapacity && !Return)
			{
				//allocating minimum capacity 
				total += MachineArray[col].m_maxcapacity - MachineArray[col].m_mincapacity; 
				table[row * MCount + col].m_amount = MachineArray[col].m_mincapacity;
				PrevRow = row;
				PrevCol = col;
				
			}
			else 
			{
				//backtracking
				RunningCount--;
				Return = FALSE;
				total += table[row * MCount + col].m_amount;
				PrevRow = table[row * MCount + col].prevrow;
				PrevCol = table[row * MCount + col].prevcol;
				table[row * MCount + col].MakeEmpty();
				if (total == Quantity )
				{
					Quit = TRUE;	//end of backtracking
				}
				else
				{			
					//backtrack
					BackTrack = TRUE;					
				}
			}
		}
		else
		{				
			row =0;
			while (total >= MachineArray[col].m_mincapacity && !BackTrack)
			{					
				if (table[row * MCount + col].m_empty && table[row * MCount + col].m_active == ID_ACTIVE
					&&	MachineArray[col].m_enabled)
				{					
					RunningCount++;
					table[row * MCount + col].m_empty = FALSE;
					table[row * MCount + col].prevrow = PrevRow;
					table[row * MCount + col].prevcol = PrevCol;
					PrevRow = row;
					PrevCol = col;  //current column
					if (total >= MachineArray[col].m_mincapacity &&
						total <= MachineArray[col].m_maxcapacity )
					{	
						table[row * MCount + col].m_amount = total;
						total =0; 
						if (SplitCount > RunningCount)
						{
							//discard previous solutin set							
							IndexArray.RemoveAll();
							SplitCount = RunningCount;
							AddIndexRow(SplitCount);							
							Solved = TRUE;
						}
						
						tmprow = row; 
						tmpcol = col;
						j =0;    
						while (tmprow >= 0 && tmpcol >= 0)
						{
							IndexArray[j].m_amount = table[tmprow * MCount + tmpcol].m_amount;
							IndexArray[j].row = tmprow;
							IndexArray[j].col = tmpcol;
							tmprow = table[IndexArray[j].row * MCount + IndexArray[j].col].prevrow;
							tmpcol = table[IndexArray[j].row * MCount + IndexArray[j].col].prevcol;
							j++;
						}						
						// set for backtrack
						BackTrack = TRUE;
						Return = TRUE;						
					}										
					else
					{
						//normal allocation								
						total -= MachineArray[col].m_capacity; 
						table[row * MCount + col].m_amount = MachineArray[col].m_capacity;				
						
						if (RunningCount >= SplitCount -1 )
						{
							//no better solution
							BackTrack = TRUE;
							Return = TRUE;
						}
			
					}
				}   // check neighboring machine
				else
				{
					if (col < (MCount - 1) && MachineArray[col].m_status == MachineArray[col + 1].m_status )
					{
						col = col + 1;
					}
					else if (row >= TotalRow - 1)
					{
						Quit = TRUE;
						break; //get out of the inner while loop
					}
					else
					{
						row++;
						while (col > 0 && MachineArray[col].m_status == MachineArray[col - 1].m_status )
						{
							col--;
						}
					}						
				}
			} //end of while loop
				
			if (total > 0 && !BackTrack) 
			{
				while (col < MCount && total < MachineArray[col].m_mincapacity)
				{
					col++;
				}
				if (col == MCount )
				{
					if (PrevRow < 0 || PrevCol < 0)
					{
						Quit = TRUE; //getting out of the main while loop
					}
					else
					{
						//go back to the previous allocation
						BackTrack = TRUE;
						row = PrevRow;
						col = PrevCol;							
					}
				}
			}
		}   

	}		//end of while loop		

	if (Solved)
	{
		//Saving solution in database		
		for(i=0; i < SplitCount; i++ )
		{
			int l_dateCount = IndexArray[i].row / m_nBatch;
			CTimeSpan l_date(l_dateCount, 0, 0, 0);

			table[IndexArray[i].row * MCount + IndexArray[i].col].m_amount = IndexArray[i].m_amount;
			table[IndexArray[i].row * MCount + IndexArray[i].col].m_date = pStartDate + l_date;
			table[IndexArray[i].row * MCount + IndexArray[i].col].m_batchid = IndexArray[i].row % m_nBatch;
			table[IndexArray[i].row * MCount + IndexArray[i].col].m_machineid = IndexArray[i].col;

			InitialiseTable(IndexArray[i].row, IndexArray[i].col, index);
			OrderArray[index].m_leftover -= IndexArray[i].m_amount;
			UpdateDatabase(IndexArray[i].row, IndexArray[i].col, IDD_ADD, TRUE, index);
		}
	}	

	OrderArray[index].m_scamt = OrderArray[index].m_leftover;

	IndexArray.RemoveAll();	
	if (!Solved)
	{
		cmsg.raise_Error(SCH_ERR_NO_OPTIMAL_SOLUTION);
	}
	return Solved;
}

void clsSolution::MakeEmpty()
{
	row = -1;
	col = -1;
	m_amount = 0;
	return ;
}


void clsMain::AddIndexRow(int Count)
{	
	clsSolution tmpSoln;
	tmpSoln.MakeEmpty();
	for(int i=0; i < Count; i++)
	{
		IndexArray.Add(tmpSoln);
	}
	return;
}


int clsMain::GetOrderCount()
{
	return OrderCount;
}

int clsMain::GetSelOrderCount()
{
	return SelOrderCount;
}

void clsMain::LoadSchedule(CTime pStartDate, int pDays)
{
	CDScheduleSet	m_DScheduleSet(&m_Database);
	clsCell			EmptyCell;
	long			Index;
	CTimeSpan		DateDiff;

	table.RemoveAll();

	EmptyCell.MakeEmpty();
	if(table.GetSize())
	{
		table.RemoveAll();
	}
	
	long IndexCount = pDays * m_nBatch * MCount;
	//table.SetSize( Index, -1);
	for (long i=0; i < IndexCount; i++)
	{
		table.Add(EmptyCell);
	}
	//parameterize filtering
	m_DScheduleSet.m_strFilter = "date >= ?";
	m_DScheduleSet.m_DateParam = pStartDate;

	if (!m_DScheduleSet.Open())
	{
		cmsg.raise_Error(SCH_ERR_SOLUTION_LOAD_FAILED);
		return;
	}
	
	if (!m_DScheduleSet.IsBOF())
	{
		m_DScheduleSet.MoveFirst();
	}
	while ( !m_DScheduleSet.IsEOF() )
	{
		DateDiff = m_DScheduleSet.m_date - pStartDate;
		int diff = DateDiff.GetDays();
		if (diff < pDays)
		{
			Index =  (diff * m_nBatch + m_DScheduleSet.m_batchid ) * MCount + m_DScheduleSet.m_machineid;
			table[Index].m_count_name	= m_DScheduleSet.m_count_name;
			table[Index].m_yarn_type	= m_DScheduleSet.m_yarn_type.Left(12);
			table[Index].m_shade		= m_DScheduleSet.m_shade;
			table[Index].m_workorder_no = m_DScheduleSet.m_workorder_no;
			table[Index].m_wo_id		= m_DScheduleSet.m_wo_id;
			table[Index].m_amount		= m_DScheduleSet.m_amount;
			table[Index].m_date			= m_DScheduleSet.m_date;
			table[Index].m_batchid		= m_DScheduleSet.m_batchid;
			table[Index].m_machineid	= m_DScheduleSet.m_machineid;
			table[Index].m_client_name	= m_DScheduleSet.m_client_name.Left(20);
			table[Index].m_client_id	= m_DScheduleSet.m_client_id;
			table[Index].m_active		= m_DScheduleSet.m_active;
			table[Index].m_empty		= FALSE;

			table[Index].m_starthour	= m_DScheduleSet.m_starthour;
			table[Index].m_startminute	= m_DScheduleSet.m_startminute;
			table[Index].m_endhour		= m_DScheduleSet.m_endhour;
			table[Index].m_endminute	= m_DScheduleSet.m_endminute;
			table[Index].m_comment		= m_DScheduleSet.m_comment;

			if(table[Index].m_amount)
			{
				table[Index].m_scheduleColor = (COLORREF)RGB(ordercolors[m_DScheduleSet.m_client_id%55].red, ordercolors[m_DScheduleSet.m_client_id%55].green, ordercolors[m_DScheduleSet.m_client_id%55].blue);
			}
		}
		m_DScheduleSet.MoveNext();
	}	
	m_DScheduleSet.Close();
	
//	extra batches that are not available for any machine will be disabled by using
//	m_active = 4

	for(i = 0; i < TotalDays * m_nBatch; i++)
		for(int j = 0; j < MCount; j++)
			if ((i % m_nBatch) >= MachineArray[j].m_batchcount)
			{
				table[i * MCount + j].m_active = ID_BATCH_NOT_AVAILABLE;
			}

}



double clsMain::GetTableAmount(int row, int col)
{
	return table[row * MCount + col].m_amount;
}

int clsMain::SetTableAmount(int row, int col, double pAmount)
{
	table[row * MCount + col].m_amount = pAmount;
	return 1;
}

int clsMain::SetTableRemark(int row, int col, CString& remark)
{
	table[row * MCount + col].m_comment = remark;
	return 1;
}

int clsMain::GridMouseUp(int row, int col, long DragItemIndex, CTime pDate, int pDays, int flag)
{
	double	l_amount, l_leftover;
	int		Index;

	if (flag == 0) 
	{
		Index = DragItemIndex;
	}
	else
	{
		Index	= o_array[DragItemIndex];
	}
	
	double	NewAmount	= OrderArray[Index].m_leftover;

	if (GetTableStatus(row, col) != 1 || !MachineArray[col].m_enabled)
	{
		return FALSE;
	}

	if (NewAmount == 0)
	{
		cmsg.raise_Error(SCH_ERR_LEFTOVER_SMALL);
		return FALSE;
	}

	if( table[row * MCount + col].m_empty && NewAmount>0)
	{			
		if (NewAmount >= MachineArray[col].m_mincapacity &&
			NewAmount <= MachineArray[col].m_maxcapacity )
		{
			l_amount =  NewAmount;			
			l_leftover = OrderArray[Index].m_leftover - NewAmount;			
		}
		else if(NewAmount >= MachineArray[col].m_capacity)
		{
			l_amount= MachineArray[col].m_capacity;
			l_leftover = OrderArray[Index].m_leftover - MachineArray[col].m_capacity;
		}		
		else
		{
			cmsg.raise_Error(SCH_ERR_LEFTOVER_SMALL);
			return FALSE;
		}			
		
	}

	OrderArray[Index].m_leftover = l_leftover;

	int l_dateCount = row / m_nBatch;
	CTimeSpan l_date(l_dateCount, 0, 0, 0);

	table[row * MCount + col].m_amount = l_amount;
	
	table[row * MCount + col].m_date = pDate + l_date;
	table[row * MCount + col].m_batchid = row % m_nBatch;
	table[row * MCount + col].m_machineid = col;
	
/*	table[row * MCount + col].m_active = ID_ACTIVE;
	table[row * MCount + col].m_wo_id = OrderArray[DragItemIndex].m_wo_id;
	table[row * MCount + col].m_client_name = OrderArray[DragItemIndex].m_client_name;
	table[row * MCount + col].m_count_name = OrderArray[DragItemIndex].m_count_name;
	table[row * MCount + col].m_workorder_no = OrderArray[DragItemIndex].m_workorder_no;
	table[row * MCount + col].m_shade = OrderArray[DragItemIndex].m_shade;
	table[row * MCount + col].m_yarn_type = OrderArray[DragItemIndex].m_yarn_type;
	table[row * MCount + col].m_empty = FALSE;
	table[row * MCount + col].m_scheduleColor = (COLORREF)RGB(ordercolors[OrderArray[DragItemIndex].m_client_id%55].red, ordercolors[OrderArray[DragItemIndex].m_client_id%55].green, ordercolors[OrderArray[DragItemIndex].m_client_id%55].blue);
*/
	InitialiseTable(row, col, Index);
	//update table and orderarray
	UpdateDatabase(row, col, IDD_ADD, TRUE, Index);
	
	
	return TRUE;	
}


int clsMain::EditAmount(int row, int col, long OrderIndex, double NewAmount, BOOL f_mode)
{		
	
	double l_leftover = OrderArray[OrderIndex].m_leftover;
	double TableAmount  =  table[row * MCount + col].m_amount;
	
	if (NewAmount >= MachineArray[col].m_mincapacity &&	NewAmount <= MachineArray[col].m_maxcapacity )
	{		
		if (NewAmount < TableAmount)
		{
			l_leftover = OrderArray[OrderIndex].m_leftover + TableAmount - NewAmount;
		}
		else if (NewAmount > TableAmount)
		{
			if ((NewAmount - TableAmount) <= OrderArray[OrderIndex].m_leftover)
			{
				l_leftover = OrderArray[OrderIndex].m_leftover + TableAmount - NewAmount;	
			}
			else
			{
				if(!f_mode)
				{
					cmsg.raise_Error(SCH_ERR_QTY_EXCEED);
					return FALSE;
				}
				else
				{
					l_leftover = OrderArray[OrderIndex].m_leftover + TableAmount - NewAmount;	
				}
			}
		}
		else
		{
			return FALSE;
		}
	}
	else
	{		
		cmsg.raise_Error(SCH_ERR_RANGE_EXCEED);
		return FALSE;
	}	
	
	OrderArray[OrderIndex].m_leftover	= l_leftover;
	OrderArray[OrderIndex].m_scamt		= l_leftover;
	table[row * MCount + col].m_amount = NewAmount;

	UpdateDatabase(row, col, IDD_EDIT, TRUE, OrderIndex);

	return TRUE;
}

int clsMain::Delete(int row, int col)
{
	// checking for emptiness
	if (table[row * MCount + col].m_empty || table[row * MCount + col].m_active != ID_ACTIVE)
	{
		return FALSE;
	}
	if (GetTableStatus(row, col) == ID_INPROCESS)
	{
		cmsg.raise_Error(SCH_ERR_DELETE_INP);
		return FALSE;
	}
	else if(GetTableStatus(row, col) == ID_PRODUCED_INC || GetTableStatus(row, col) == ID_PRODUCED_COM)
	{
		cmsg.raise_Error(SCH_ERR_DELETE_PRO);
		return FALSE;
	}

	long OrderIndex = FindOrderIndex(row, col);
	if( OrderIndex == -1)
	{
		cmsg.raise_Error(SCH_ERR_ORDER_MISS);
		return FALSE;
	}

	OrderArray[OrderIndex].m_leftover += table[ row * MCount + col].m_amount;
	OrderArray[OrderIndex].m_scamt = OrderArray[OrderIndex].m_leftover;
	UpdateDatabase(row, col, IDD_DELETE, TRUE, OrderIndex);
	table[row * MCount + col].MakeEmpty();

	return TRUE;
}

clsOrder clsMain::GetOrder(long OrderIndex)
{
	return OrderArray[OrderIndex];
}

double clsMain::GetOrderLeftAmount(long Index)
{
	return OrderArray[Index].m_leftover;
}

double clsMain::GetOrderScAmount(long Index)
{
	return OrderArray[Index].m_scamt;
}

void clsMain::SetOrderScAmount(long Index, double sc_amt)
{
	OrderArray[Index].m_scamt = sc_amt;
}

CString clsMain::GetWorkOrderNo(long Index)
{
	return OrderArray[Index].m_workorder_no;
}

long clsMain::GetSelOrderNo(long Index)
{
	return SelOrderArray[Index].m_wo_id;
}

CString clsMain::GetWorkOrderShade(long Index)
{
	return OrderArray[Index].m_shade;
}

BOOL clsMain::IsTableCellEmpty(int row, int col)
{
	return table[row * MCount + col].m_empty;
}

long clsMain::FindOrderIndex(int row, int col)
{
/* this function uses the wo_id pointed by table(row,col) to find 
the order index from order array */

	long wo_id = table[row * MCount + col].m_wo_id;

	for(int i = 0; i < OrderCount; i++)
	{
		if (OrderArray[i].m_wo_id == wo_id)
		{
			return i;
		}
	}
	return -1;
}

clsCell clsMain::GetTableCell(int row, int col)
{
	return table[row * MCount + col];
}


BOOL clsMain::DisableCell(int row, int col, CTime pDate)
{	
	if (table[row * MCount + col].m_empty)
	{
	    
		int			l_dateCount = row / m_nBatch;
		CTimeSpan	l_date(l_dateCount, 0, 0, 0);

		table[row * MCount + col].m_date = pDate + l_date;
		table[row * MCount + col].m_batchid = row % m_nBatch;
		table[row * MCount + col].m_machineid = col;
		table[row * MCount + col].MakeDisable();
		UpdateDatabase(row, col, IDD_ADD, FALSE, -1);
	}
	else
	{
		long OrderIndex = FindOrderIndex(row, col);
		if( OrderIndex == -1)
		{
			cmsg.raise_Error(SCH_ERR_ORDER_MISS);
			return FALSE;
		}		
		OrderArray[OrderIndex].m_leftover += table[ row * MCount + col].m_amount;
		OrderArray[OrderIndex].m_scamt = OrderArray[OrderIndex].m_leftover;
		table[row * MCount + col].MakeDisable();	//disabling the curr batch
		UpdateDatabase(row, col, IDD_EDIT, TRUE, OrderIndex);
	}

	return TRUE;
}


BOOL clsMain::UpdateDatabase(int row, int col, int UpdateType, BOOL OUpdate, long OrderIndex)
{
	char strFilter[100];

	if ( !m_Database.BeginTrans())        
	{
		return FALSE;
    }
	CScheduleSet m_ScheduleSet(&m_Database);
	sprintf(strFilter, "date= ? AND batchid=%d AND machineid=%d", table[row * MCount + col].m_batchid, table[row * MCount + col].m_machineid);
	
	//assigning  value to the parameter
	m_ScheduleSet.m_DateParam = table[row * MCount + col].m_date;
    m_ScheduleSet.m_strFilter = strFilter;
    if ( !m_ScheduleSet.Open(CRecordset::dynaset) )        
	{
		return FALSE;
	}

	if (OUpdate)
	{
		COrder_Stat m_OrderSet(&m_Database);
		sprintf(strFilter, "wo_id = %d", OrderArray[OrderIndex].m_wo_id);
		m_OrderSet.m_strFilter = strFilter;
		
		if ( !m_OrderSet.Open(CRecordset::dynaset))        
			return FALSE;

		TRY
		{
			m_OrderSet.Edit();			
			m_OrderSet.m_left_over	= OrderArray[OrderIndex].m_leftover;
			m_OrderSet.m_scamt		= OrderArray[OrderIndex].m_scamt;
			m_OrderSet.Update();
		}

		CATCH_ALL(e)    
		{
			cmsg.raise_Error(SCH_ERR_DATABASE);
			m_Database.Rollback();
			return FALSE;    
		}    
		END_CATCH_ALL
		m_OrderSet.Close();
	}

	if (UpdateType == IDD_DELETE)
	{
		TRY
		{
			m_ScheduleSet.Delete();			
			m_Database.CommitTrans();
		}

		CATCH_ALL(e)    
		{
			cmsg.raise_Error(SCH_ERR_DATABASE);
			m_Database.Rollback();
			return FALSE;    
		}    
		END_CATCH_ALL
	}
	else if (UpdateType == IDD_EDIT)
	{
		TRY
		{
			m_ScheduleSet.Edit();

			m_ScheduleSet.m_active = table[row * MCount + col].m_active;
			m_ScheduleSet.m_amount = table[row * MCount + col].m_amount;
			m_ScheduleSet.m_wo_id = table[row * MCount + col].m_wo_id;

			m_ScheduleSet.m_starthour	= table[row * MCount + col].m_starthour;
			m_ScheduleSet.m_startminute	= table[row * MCount + col].m_startminute;
			m_ScheduleSet.m_endhour		= table[row * MCount + col].m_endhour;
			m_ScheduleSet.m_endminute	= table[row * MCount + col].m_endminute;
			m_ScheduleSet.m_comment		= table[row * MCount + col].m_comment;

			m_ScheduleSet.Update();
			m_Database.CommitTrans();
		}

		CATCH_ALL(e)    
		{
			cmsg.raise_Error(SCH_ERR_DATABASE);
			m_Database.Rollback();
			return FALSE;    
		}    
		END_CATCH_ALL
	}
	else if (UpdateType == IDD_ADD)
	{
		TRY
		{
			m_ScheduleSet.AddNew();

			m_ScheduleSet.m_date = table[row * MCount + col].m_date;
			m_ScheduleSet.m_active = table[row * MCount + col].m_active;
			m_ScheduleSet.m_amount = table[row * MCount + col].m_amount;
			m_ScheduleSet.m_wo_id = table[row * MCount + col].m_wo_id;
			m_ScheduleSet.m_machineid = table[row * MCount + col].m_machineid;
			m_ScheduleSet.m_batchid = table[row * MCount + col].m_batchid;

			m_ScheduleSet.m_starthour	= table[row * MCount + col].m_starthour;
			m_ScheduleSet.m_startminute	= table[row * MCount + col].m_startminute;
			m_ScheduleSet.m_endhour		= table[row * MCount + col].m_endhour;
			m_ScheduleSet.m_endminute	= table[row * MCount + col].m_endminute;
			m_ScheduleSet.m_comment		= table[row * MCount + col].m_comment;

			m_ScheduleSet.Update();
				
			m_Database.CommitTrans();
		}

		CATCH_ALL(e)    
		{
			cmsg.raise_Error(SCH_ERR_ROLLBACK);
			m_Database.Rollback( );        
			return FALSE;
		}    
		END_CATCH_ALL
 	}
	m_ScheduleSet.Close( );
	
	return TRUE;
}


void clsMain::TempDisableCell(int row, int col)
{
	table[row * MCount + col ].m_empty = FALSE;
}

void clsMain::EnableTempDisableCell(int row, int col)
{
	table[row * MCount + col ].m_empty = TRUE;
}

BOOL clsMain::IsTableCellActive(int row, int col)
{
	return table[row * MCount + col].m_active;
}

BOOL clsMain::EnableCell(int row, int col)
{
	UpdateDatabase(row, col, IDD_DELETE, FALSE, -1);
	table[row * MCount + col].MakeEmpty();
	
	return TRUE;
}

BOOL clsMain::DropOneDate(CTime pDate, int col, int DropType)
{
	// Droptype FALSE means based on every machine, TRUE means based on single machine

	char strFilter[300];	
	CTimeSpan OneDay(1, 0, 0, 0);

    if ( !m_Database.BeginTrans( ) )        
	{
		return FALSE;
	}
	CScheduleSet m_ScheduleSet(&m_Database);

	if (DropType)
		sprintf(strFilter, "date >= ? AND machineid = %d", col);
	else
		sprintf(strFilter, "date >= ? ");

	m_ScheduleSet.m_strSort = "date DESC";

	//assigning  value to the parameter
	m_ScheduleSet.m_DateParam = pDate;
	
    m_ScheduleSet.m_strFilter = strFilter;
    if ( !m_ScheduleSet.Open(CRecordset::dynaset) )        
	{
		return FALSE;
	}
	m_ScheduleSet.MoveFirst();
	
	while ( !m_ScheduleSet.IsEOF( ) )
	{
		if (m_ScheduleSet.m_active != ID_ACTIVE )
		{
				m_ScheduleSet.MoveNext();
				continue;		//no update, go to next record
		}

		TRY
		{
			m_ScheduleSet.Edit();			
			m_ScheduleSet.m_date += OneDay;
			m_ScheduleSet.Update();
		}

		CATCH_ALL(e)    
		{
			cmsg.raise_Error(SCH_ERR_DATABASE);
			m_Database.Rollback( );        
			return FALSE;
		}    
		END_CATCH_ALL
		m_ScheduleSet.MoveNext();
	}
	
	m_Database.CommitTrans();

	m_ScheduleSet.Close();    
	
	return TRUE;
}

BOOL clsMain::DropOneBatch(CTime pStartDate, int row, int col, BOOL DropType)
{
	// Droptype FALSE means based on every machine, TRUE means based on single machine

	char strFilter[300];	
	int	batch = row % m_nBatch;
	int l_dateCount = row / m_nBatch;
	CTimeSpan l_date(l_dateCount, 0, 0, 0);
	CTime CurrDate = pStartDate + l_date;

    if ( !m_Database.BeginTrans())        
	{
		return FALSE;
	}
	CScheduleSet m_ScheduleSet(&m_Database);
	if (DropType)
		sprintf(strFilter, "date >= ? AND machineid = %d", col);
	else
		sprintf(strFilter, "date >= ? ");

	m_ScheduleSet.m_strSort = "date DESC, batchid DESC";

	//assigning  value to the parameter
	m_ScheduleSet.m_DateParam = CurrDate;
	
    m_ScheduleSet.m_strFilter = strFilter;
    if ( !m_ScheduleSet.Open(CRecordset::dynaset) )        
	{
		return FALSE;
	}
	m_ScheduleSet.MoveFirst();
	
	while ( !m_ScheduleSet.IsEOF( ) )
	{
		if ((m_ScheduleSet.m_date == CurrDate && m_ScheduleSet.m_batchid < batch) 
				|| m_ScheduleSet.m_active != ID_ACTIVE )
		{
				m_ScheduleSet.MoveNext();
				continue;		//no update, go to next record
		}

		l_date = m_ScheduleSet.m_date - pStartDate;
		int CurrRow = l_date.GetDays() * m_nBatch + m_ScheduleSet.m_batchid;

		for(;;)
		{
			CurrRow++;
			if ((CurrRow % m_nBatch) < MachineArray[m_ScheduleSet.m_machineid].m_batchcount)
			{
				int l_dateCount = CurrRow / m_nBatch;
				CTimeSpan Days(l_dateCount, 0, 0, 0);

				TRY
				{
					m_ScheduleSet.Edit();			
					m_ScheduleSet.m_date = pStartDate + Days;
					m_ScheduleSet.m_batchid = CurrRow % m_nBatch;
					m_ScheduleSet.Update();
				}

				CATCH_ALL(e)    
				{
					cmsg.raise_Error(SCH_ERR_DATABASE);
					m_Database.Rollback( );        
					return FALSE;
				}    
				END_CATCH_ALL
					
				break; //getting out of the for loop
			}
		}
		m_ScheduleSet.MoveNext();
	}
	
	m_Database.CommitTrans();
	m_ScheduleSet.Close();   
	
	return TRUE;
}


CTime clsMain::GetMaxDate()
{
	CTime NullDate(1980, 1, 1, 0, 0, 0, 0);
	
	CScheduleSet m_ScheduleSet(&m_Database);
		
	m_ScheduleSet.m_strSort = "date DESC";
    if ( !m_ScheduleSet.Open(CRecordset::dynaset))
	{
		return 	m_ScheduleSet.m_date;
	}
	if (m_ScheduleSet.IsEOF())
	{
		return NullDate;
	}
	m_ScheduleSet.MoveFirst();	

	return 	m_ScheduleSet.m_date;
}

BOOL clsMain::MachineEnabled(int col)
{
	return MachineArray[col].m_enabled;
}

BOOL clsMain::DisableMachine(int col)
{
    char strFilter[300];

	if ( !m_Database.BeginTrans())        
	{
		return FALSE;
	}
	sprintf(strFilter, "machine_id = %d", MachineArray[col].m_machine_id);

	CMachinesSet m_MachineSet(&m_Database);
	m_MachineSet.m_strFilter = strFilter;

	if ( !m_MachineSet.Open(CRecordset::dynaset))
	{
		return FALSE;
	}
	TRY
	{
		m_MachineSet.Edit();		
		m_MachineSet.m_enabled = FALSE;
		m_MachineSet.Update();
		
		m_Database.CommitTrans();
	}

	CATCH_ALL(e)    
	{
		cmsg.raise_Error(SCH_ERR_DATABASE);
		m_Database.Rollback( );        
		return FALSE;
	}    
	END_CATCH_ALL
    
	m_MachineSet.Close();
	MachineArray[col].m_enabled = FALSE;

	return TRUE;
}

BOOL clsMain::EnableMachine(int col)
{
	char strFilter[300];

	if ( !m_Database.BeginTrans())        
	{
		return FALSE;
	}
	sprintf(strFilter, "machine_id = %d", MachineArray[col].m_machine_id);

	CMachinesSet m_MachineSet(&m_Database);
	m_MachineSet.m_strFilter = strFilter;

	if ( !m_MachineSet.Open(CRecordset::dynaset))
	{
		return FALSE;
	}
	TRY
	{
		m_MachineSet.Edit();		
		m_MachineSet.m_enabled = TRUE;
		m_MachineSet.Update();
		
		m_Database.CommitTrans();
	}

	CATCH_ALL(e)    
	{
		cmsg.raise_Error(SCH_ERR_DATABASE);
		m_Database.Rollback( );        
		return FALSE;
	}    
	END_CATCH_ALL
    
	m_MachineSet.Close();
	MachineArray[col].m_enabled = TRUE;

	return TRUE;
}

BOOL clsMain::CellDragDrop(int SrcRow, int SrcCol, int DesRow, int DesCol, CTime pDate, int pDays)
{
	if (MachineArray[SrcCol].m_capacity < MachineArray[DesCol].m_capacity || !table[DesRow * MCount + DesCol].m_active || !MachineArray[DesCol].m_enabled)
	{
		return FALSE;
	}

	if ( table[DesRow * MCount + DesCol].m_empty )
	{
		long SrcOrderIndex = FindOrderIndex(SrcRow, SrcCol);
		if( SrcOrderIndex == -1)
		{
			cmsg.raise_Error(SCH_ERR_ORDER_MISS);
			return FALSE;
		}
		Delete(SrcRow, SrcCol);
		GridMouseUp(DesRow, DesCol, SrcOrderIndex, pDate, pDays, 0);
	}
	else
	{
		long	DesOrderIndex = FindOrderIndex(DesRow, DesCol);
		if( DesOrderIndex == -1)
		{
			cmsg.raise_Error(SCH_ERR_ORDER_MISS);
			return FALSE;
		}
		long	SrcOrderIndex = FindOrderIndex(SrcRow, SrcCol);
		if( SrcOrderIndex == -1)
		{
			cmsg.raise_Error(SCH_ERR_ORDER_MISS);
			return FALSE;
		}
	
		Delete(SrcRow, SrcCol);
		Delete(DesRow, DesCol);
		GridMouseUp(DesRow, DesCol, SrcOrderIndex, pDate, pDays, 0);
		GridMouseUp(SrcRow, SrcCol, DesOrderIndex, pDate, pDays, 0);
	}
	return TRUE;
}

BOOL clsMain::Unschedule(long Index, int pDays)
{
	CString	orderNo;
	int		i, j;
	int		OrderIndex = o_array[Index];

	orderNo = "\r\nOrder: ";
	orderNo += GetWorkOrderNo(OrderIndex);
	orderNo += " and Shade: ";
	orderNo += GetWorkOrderShade(OrderIndex);
	if(cmsg.raise_Error(SCH_ERR_UNSCHEDULE, orderNo) != IDYES)
	{
		return FALSE;
	}

	if (OrderArray[OrderIndex].m_leftover == OrderArray[OrderIndex].m_quantity)
	{
		return FALSE;
	}
	for(i=0; i < pDays * m_nBatch; i++)
	{
		for(j=0; j < MCount; j++)
		{
			if (table[i*MCount + j].m_wo_id == OrderArray[OrderIndex].m_wo_id)
			{
				Delete(i, j);
			}
		}
	}
	return TRUE;
}

BOOL clsMain::IsConnected()
{
	return m_Connected;
}

int clsMain::GetTableStatus(int row, int col)
{
	return table[row * MCount + col].m_active;
}

void clsMain::SetTableStatus(int row, int col, int stat, CTime pDate, int starthour, int startminute, int endhour, int endminute, BOOL f_mode)
{
	int		i, j;
	int		old_stat = table[row * MCount + col].m_active;

	//old and new states are equal. do nothing
	if( old_stat == stat)
	{
//		if( stat == ID_PRODUCED)
//		{
			table[row * MCount + col].m_starthour	= starthour;
			table[row * MCount + col].m_startminute	= startminute;
			table[row * MCount + col].m_endhour		= endhour;
			table[row * MCount + col].m_endminute	= endminute;
			//UpdateDatabase(row, col, IDD_EDIT, FALSE, -1);
//		}
		return;
	}

	// the state was scheduled before hand
	if( old_stat == ID_ACTIVE )
	{
		// new state is processed. unacceptable
		if( stat == ID_PRODUCED_INC || stat == ID_PRODUCED_COM )
		{
			cmsg.raise_Error(SCH_ERR_NO_TRANSITION1);
			return;
		}
		// new state is in process. ask confirmation
		else
		{
			if(cmsg.raise_Error(SCH_ERR_SCH_TO_INP) == IDYES)
			{
				table[row * MCount + col].m_active = stat;				
				table[row * MCount + col].m_starthour	= starthour;
				table[row * MCount + col].m_startminute	= startminute;
				table[row * MCount + col].m_endhour		= endhour;
				table[row * MCount + col].m_endminute	= endminute;
				//UpdateDatabase(row, col, IDD_EDIT, FALSE, -1);
			}
			else
			{
				return;
			}
		}
	}
	// the state was in-process before hand
	else if( old_stat == ID_INPROCESS )
	{
		// new state is processed. ask confirmation
		if( stat == ID_PRODUCED_INC || stat == ID_PRODUCED_COM )
		{
			if(cmsg.raise_Error(SCH_ERR_INP_TO_PRO) == IDYES)
			{
				table[row * MCount + col].m_active = stat;				
				table[row * MCount + col].m_starthour	= starthour;
				table[row * MCount + col].m_startminute	= startminute;
				table[row * MCount + col].m_endhour		= endhour;
				table[row * MCount + col].m_endminute	= endminute;
				//UpdateDatabase(row, col, IDD_EDIT, FALSE, -1);
			}
			else
			{
				return;
			}
		}
		// new state is in process. ask confirmation
		else
		{
			if(cmsg.raise_Error(SCH_ERR_INP_TO_SCH) == IDYES)
			{
				table[row * MCount + col].m_active = stat;				
				table[row * MCount + col].m_starthour	= starthour;
				table[row * MCount + col].m_startminute	= startminute;
				table[row * MCount + col].m_endhour		= endhour;
				table[row * MCount + col].m_endminute	= endminute;
				//UpdateDatabase(row, col, IDD_EDIT, FALSE, -1);
			}
			else
			{
				return;
			}
		}
	}
	// the state was procesed before hand
	if( old_stat == ID_PRODUCED_INC || old_stat == ID_PRODUCED_COM )
	{
		// new state is processed. unacceptable
		if( stat == ID_ACTIVE )
		{
			cmsg.raise_Error(SCH_ERR_NO_TRANSITION2);
			return;
		}
		// new state is in process. ask confirmation
		else if( stat == ID_INPROCESS )
		{
			if(cmsg.raise_Error(SCH_ERR_PRO_TO_INP) == IDYES)
			{
				// set corresponding order as not dye complete
				int		index	= FindOrderIndex(row, col);

				SetWorkorderStatus(index, 0);
				table[row * MCount + col].m_active = stat;
				table[row * MCount + col].m_starthour	= starthour;
				table[row * MCount + col].m_startminute	= startminute;
				table[row * MCount + col].m_endhour		= endhour;
				table[row * MCount + col].m_endminute	= endminute;
				//UpdateDatabase(row, col, IDD_EDIT, FALSE, -1);
			}
			else
			{
				return;
			}
		}
		else
		{
			int		index	= FindOrderIndex(row, col);

			SetWorkorderStatus(index, 0);
			table[row * MCount + col].m_active = stat;
			table[row * MCount + col].m_starthour	= starthour;
			table[row * MCount + col].m_startminute	= startminute;
			table[row * MCount + col].m_endhour		= endhour;
			table[row * MCount + col].m_endminute	= endminute;
		}
	}

	// check whether there is any pending schedule in previos days
	if (stat >= ID_INPROCESS)
	{
		int RowsTobeChecked = row - (row % m_nBatch);

		for(i=0; i < RowsTobeChecked; i++ )
		{
			for(j=0; j< MCount; j++)
			{
				if (!table[i*MCount + j].m_empty && (table[i*MCount + j].m_active == ID_ACTIVE || table[i*MCount + j].m_active == ID_INPROCESS))
				{
					if(!f_mode)
					{
						cmsg.raise_Error(SCH_ERR_PREV_UNPROCESSED);
						table[row * MCount + col].m_active = old_stat;				
						table[row * MCount + col].m_starthour	= starthour;
						table[row * MCount + col].m_startminute	= startminute;
						table[row * MCount + col].m_endhour		= endhour;
						table[row * MCount + col].m_endminute	= endminute;
						UpdateDatabase(row, col, IDD_EDIT, FALSE, -1);
						return;
					}
				}
			}
		}
		//rows checked successflly, now making the unused cells in previous days unavailable
		
/*		for(i=0; i < RowsTobeChecked; i++ )
		{
			for(j=0; j<MCount; j++)
			{
				if (table[i*MCount + j].m_empty)
				{
					DisableCell(i, j, pDate);
				}
			}
		}
*/
	}

	UpdateDatabase(row, col, IDD_EDIT, FALSE, -1);
}

CTime clsMain::GetStartDate()
{
	CTime NullDate(1980, 1, 1, 0, 0, 0, 0);
	
	CScheduleSet m_ScheduleSet(&m_Database);
		
	m_ScheduleSet.m_strSort = "date ASC";
	m_ScheduleSet.m_strFilter = "active = 2 or active = 1";
    if ( !m_ScheduleSet.Open(CRecordset::dynaset))
	{
		return NullDate;
	}
	if (!m_ScheduleSet.IsEOF())
	{
		NullDate = m_ScheduleSet.m_date;
	}
	m_ScheduleSet.Close();

	return NullDate;
}

void clsMain::SetOrderStatus(int index, int Status, BOOL force)
{
	CString		orderNo;
	CTime		dt(1980, 1, 1, 0, 0, 0, 0);
	
	orderNo = "\r\nOrder: ";
	orderNo += GetWorkOrderNo(index);
	orderNo += " and Shade: ";
	orderNo += GetWorkOrderShade(index);
	if( GetWorkorderStatus(index) == Status)
	{
		cmsg.raise_Error(SCH_ERR_ORDER_COMPLETED, orderNo);
		return;
	}

	// check whether all schedules for the order are processed
	// and there is no left-over amount

	if( force == TRUE)
	{
		SetWorkorderStatus(index, Status);
	}
	else
	{
		if(GetOrderLeftAmount(index) != 0.0)
		{
			cmsg.raise_Error(SCH_ERR_ORDER_NO_LEFT, orderNo);
			return;
		}
	
		char			strFilter[100];
		CScheduleSet	m_ScheduleSet(&m_Database);

		sprintf(strFilter, "date > ? and wo_id = %d and active <> 3", OrderArray[index].m_wo_id);
		m_ScheduleSet.m_strFilter = strFilter;
		m_ScheduleSet.m_DateParam = dt;
		if( !m_ScheduleSet.Open(CRecordset::dynaset))
		{
			return;
		}
		if(m_ScheduleSet.GetRecordCount() > 0)
		{
			m_ScheduleSet.Close();
			cmsg.raise_Error(SCH_ERR_ORDER_SCH_UNP, orderNo);
			return;
		}

		// finally set the order status
		m_ScheduleSet.Close();
		SetWorkorderStatus(index, Status);
	}

	return;
}

int clsMain::GetWorkorderStatus(long index)
{
	return OrderArray[index].m_dyecomplete;
}

void clsMain::SetWorkorderStatus(long index, int Status)
{
	int		old_Status;

	old_Status = OrderArray[index].m_dyecomplete;
	OrderArray[index].m_dyecomplete = Status;
	if(!UpdateOrder(index, IDD_EDIT))
	{
		OrderArray[index].m_dyecomplete = old_Status;
	}
}

void clsMain::SetLoadProcessed(BOOL bVal)
{
	m_LoadProcessed = bVal;
}

int clsMain::GetnBatch()
{
	return m_nBatch;
}


BOOL clsMain::UpdateSelOrder(long OrderIndex, int UpdateType)
{
	char strFilter[100];

	if ( !m_Database.BeginTrans())        
	{
		return FALSE;
    }

	long wo_id	= OrderArray[OrderIndex].m_wo_id;
    CSelOrderset m_SelOrderSet(&m_Database);	

	sprintf(strFilter, "wo_id = %ld", wo_id);
    m_SelOrderSet.m_strFilter = strFilter;

    if ( !m_SelOrderSet.Open(CRecordset::dynaset))        
	{
		return FALSE;
	}
	
	if (UpdateType == IDD_ADD)
	{
		TRY
		{
			m_SelOrderSet.AddNew();
			
			m_SelOrderSet.m_wo_id		= wo_id;			
			m_SelOrderSet.m_sel_group	= "a";
			m_SelOrderSet.Update();

			m_Database.CommitTrans();
		}

		CATCH_ALL(e)    
		{
			cmsg.raise_Error(SCH_ERR_DATABASE);
			m_Database.Rollback();
			return FALSE;    
		}    
		END_CATCH_ALL

		clsSelOrder	tmpSelOrder;

		tmpSelOrder.m_wo_id		= wo_id;
		tmpSelOrder.m_sel_group	= "a";
		SelOrderArray.Add(tmpSelOrder);
		SelOrderCount++;
	}
	else if(UpdateType == IDD_DELETE)
	{
		TRY
		{
			m_SelOrderSet.Delete();
			//m_SelOrderSet.Update();
			m_Database.CommitTrans();
		}

		CATCH_ALL(e)    
		{
			cmsg.raise_Error(SCH_ERR_DATABASE);
			m_Database.Rollback();
			return FALSE;    
		}    
		END_CATCH_ALL

		int		i;
		
		for( i = 0 ; i < SelOrderCount ; i++)
		{
			if(SelOrderArray[i].m_wo_id == wo_id)
			{
				SelOrderArray.RemoveAt(i, 1);
				SelOrderCount--;
				continue;
			}
		}
	}
		
	m_SelOrderSet.Close();

	return TRUE;
}

BOOL clsMain::UpdateOrder(long OrderIndex, int UpdateType)
{
	char strFilter[100];

	if ( !m_Database.BeginTrans())        
	{
		return FALSE;
    }
    COrder_Stat m_OrderSet(&m_Database);	

	sprintf(strFilter, "wo_id = %d", OrderArray[OrderIndex].m_wo_id);
    m_OrderSet.m_strFilter = strFilter;

    if ( !m_OrderSet.Open(CRecordset::dynaset))        
	{
		return FALSE;
	}
	
	if (UpdateType == IDD_EDIT)
	{
		TRY
		{
			m_OrderSet.Edit();
			
			m_OrderSet.m_left_over		= OrderArray[OrderIndex].m_leftover;			
			m_OrderSet.m_dyecomplete	= OrderArray[OrderIndex].m_dyecomplete;
			m_OrderSet.m_scamt			= OrderArray[OrderIndex].m_scamt;
			m_OrderSet.Update();

			m_Database.CommitTrans();
		}

		CATCH_ALL(e)    
		{
			cmsg.raise_Error(SCH_ERR_DATABASE);
			m_Database.Rollback();
			return FALSE;    
		}    
		END_CATCH_ALL
	}
	m_OrderSet.Close();

	return TRUE;
}

BOOL clsMain::AdjustOrders()
{
	CString strCmd1 = "INSERT INTO Order_Stat(wo_id, left_over, status, dyecomplete, sc_amt) SELECT Insertable_Orders.wo_id, Insertable_Orders.quantity, 0, 0, Insertable_Orders.quantity FROM Insertable_Orders";
	CString strCmd2 = "DELETE from Schedule WHERE wo_id IN (SELECT wo_id FROM Order_Stat WHERE dyecomplete=254)";
	CString strCmd3 = "DELETE FROM Order_Stat WHERE dyecomplete=254";
	TRY
	{
		m_Database.ExecuteSQL(strCmd1);
		m_Database.ExecuteSQL(strCmd2);
		m_Database.ExecuteSQL(strCmd3);
	}		

	CATCH(CDBException, e)
	{
		AfxMessageBox( e->m_strError,MB_ICONEXCLAMATION );
        return FALSE;        
	}
	END_CATCH



	if ( !m_Database.BeginTrans())        
	{
		return FALSE;
    }
	
	COrderSet m_OrderSet(&m_Database);
	m_OrderSet.m_strFilter = "dyecomplete = 255";  //changed order
    if ( !m_OrderSet.Open(CRecordset::dynaset))        
		return FALSE;

	CScheduleSet m_ScheduleSet(&m_Database);
	BOOL	FirstTime = TRUE;
	while(!m_OrderSet.IsEOF())
	{
		char	SchFilter[100];
		sprintf(SchFilter, "wo_id = %d", m_OrderSet.m_wo_id);
		m_ScheduleSet.m_strFilter = SchFilter;
		if (FirstTime)
		{
			m_ScheduleSet.Open(CRecordset::dynaset);
			FirstTime = FALSE;
		}
		else
			m_ScheduleSet.Requery();
		
		double DeletedAmount = 0;
		while (!m_ScheduleSet.IsEOF())
		{
			if (m_ScheduleSet.m_active == ID_ACTIVE)
			{
				DeletedAmount	+= m_ScheduleSet.m_amount;
				m_ScheduleSet.Delete();				
			}
			m_ScheduleSet.MoveNext();
		}
				
		TRY
		{
			m_OrderSet.Edit();
			m_OrderSet.m_left_over	+= DeletedAmount;
			m_OrderSet.m_dyecomplete = 0;
			m_OrderSet.Update();
		}

		CATCH_ALL(e)    
		{
			cmsg.raise_Error(SCH_ERR_DATABASE);
			m_Database.Rollback();
			return FALSE;    
		}    
		END_CATCH_ALL

		m_OrderSet.MoveNext();
	}
	
	if ( !m_Database.CommitTrans())
		return FALSE;

	m_OrderSet.Close();	
	m_ScheduleSet.Close();

	return TRUE;	
}

void clsMain::GetTableTime(int row, int col, int* shour, int* smin, int* ehour, int* emin)
{
	*shour	= table[row * MCount + col].m_starthour;
	*smin	= table[row * MCount + col].m_startminute;
	*ehour	= table[row * MCount + col].m_endhour;
	*emin	= table[row * MCount + col].m_endminute;
}

void clsMain::InitialiseTable(int row, int col, long OrderIndex)
{
	table[row * MCount + col].m_active = ID_ACTIVE;
	table[row * MCount + col].m_wo_id = OrderArray[OrderIndex].m_wo_id;
	table[row * MCount + col].m_client_name = OrderArray[OrderIndex].m_client_name;
	table[row * MCount + col].m_count_name = OrderArray[OrderIndex].m_count_name;
	table[row * MCount + col].m_workorder_no = OrderArray[OrderIndex].m_workorder_no;
	table[row * MCount + col].m_shade = OrderArray[OrderIndex].m_shade;
	table[row * MCount + col].m_yarn_type = OrderArray[OrderIndex].m_yarn_type;
	table[row * MCount + col].m_empty = FALSE;
	table[row * MCount + col].m_scheduleColor = (COLORREF)RGB(ordercolors[OrderArray[OrderIndex].m_client_id%55].red, ordercolors[OrderArray[OrderIndex].m_client_id%55].green, ordercolors[OrderArray[OrderIndex].m_client_id%55].blue);
}

CString clsMain::GetOrderClient(long Index)
{
	return OrderArray[Index].m_client_name;
}

CString clsMain::GetWorkOrderCount(long Index)
{
	return OrderArray[Index].m_count_name;
}
