// DialogDlg.cpp : implementation file
//

#include <commctrl.h>
#include "stdafx.h"
#include "Scheduling.h"
#include "SchedulingDlg.h"
#include "clsCell.h"
#include "AmountDlg.h"
#include "RemarkDlg.h"
#include "DateAmtDlg.h"
#include "font.h"
#include <stdio.h>


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

enum parts
{
	ID_PART_STARTER,
	ID_PART_MESSAGE,
	ID_PART_SEP1,
	ID_PART_DATE
};

static int partswidth[] =
{
	5, 600, 605, 795
};

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDialogDlg dialog

CDialogDlg::CDialogDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CDialogDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDialogDlg)	
	m_NoOfDays = 50;
	m_client = _T("");
	m_shade = _T("");
	m_order = _T("");
	m_count = _T("");
	m_ddate = COleDateTime(1970, 1, 1, 0, 0, 0);
	m_filled_order = 0;
	MaxQuantity = 3000;
	m_AutoSchedule = FALSE;
	m_Confirm = TRUE;
	m_Forcemode = FALSE;
	m_Selgroup = TRUE;
	m_Calshow = FALSE;
	m_Keepselection = FALSE;
	m_LoadProcessed = FALSE;
	m_SearchMode = FALSE;
	m_ListInitialized = FALSE;
	m_changed = FALSE;
	m_spinbuddy = 0;
	m_ExcelStarted = FALSE;
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	
	// initialization 
}

void CDialogDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDialogDlg)
	DDX_Control(pDX, IDC_APPLY, m_apply);
	DDX_Control(pDX, IDC_SPINDDATE, m_spinddate);
	DDX_Control(pDX, IDC_LIST1, m_ListCtrl);
	DDX_Control(pDX, IDC_MSFLEXGRID1, m_gOutput);	
	DDX_Text(pDX, IDC_NOOFDAYS, m_NoOfDays);
	DDV_MinMaxInt(pDX, m_NoOfDays, 1, 50);
	DDX_Text(pDX, IDC_CLIENT, m_client);
	DDX_Text(pDX, IDC_SHADE, m_shade);
	DDX_Text(pDX, IDC_ORDER, m_order);
	DDX_Text(pDX, IDC_COUNT, m_count);
	DDX_Text(pDX, IDC_DDATE, m_ddate);
	DDX_Text(pDX, IDC_SPINBUDDY, m_spinbuddy);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CDialogDlg, CDialog)
	//{{AFX_MSG_MAP(CDialogDlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_CONNECT, OnConnect)	
	ON_BN_CLICKED(IDC_SCHEDULE, OnSchedule)	
	ON_COMMAND(ID_EDIT, OnEdit)
	ON_COMMAND(ID_DELETE, OnDelete)
	ON_WM_CONTEXTMENU()
	ON_NOTIFY(LVN_BEGINDRAG, IDC_LIST1, OnBegindragList1)
	ON_BN_CLICKED(IDC_LOADSCHEDULE, OnLoadschedule)
	ON_COMMAND(ID_DELETEBATCH, OnDeletebatch)
	ON_COMMAND(ID_DROPONEDATE, OnDroponedate)
	ON_COMMAND(ID_DISABLECURRCELL, OnDisablebatch)
	ON_COMMAND(ID_ENABLECURRCELL, OnEnablecurrcell)
	ON_COMMAND(ID_DELETE_ALL, OnDeleteAll)
	ON_COMMAND(ID_DISABLE_MACHINE, OnDisableMachine)
	ON_COMMAND(ID_DROPONEBATCH, OnDroponebatch)
	ON_COMMAND(ID_ENABLE_MACHINE, OnEnableMachine)
	ON_COMMAND(IDC_AUTOMATIC, OnAutomatic)
	ON_COMMAND(IDC_CONFIRM, OnConfirm)
	ON_COMMAND(ID_SCHEDULE_SCHEDULE, OnPopupSchedule)
	ON_COMMAND(ID_SCHEDULE_UNSCHEDULE, OnPopupUnschedule)
	ON_COMMAND(IDC_CALSHOW, OnCalshow)
	ON_COMMAND(IDS_ABOUTBOX, OnAboutbox)
	ON_WM_MOUSEMOVE()
	ON_COMMAND(ID_COMPLETE, OnComplete)
	ON_COMMAND(IDC_LOADPROCESSED, OnLoadprocessed)
	ON_COMMAND(ID_DROPONEBATCH_BYMACHINE, OnDroponebatchBymachine)
	ON_COMMAND(ID_DROPONEDATE_BYMACHINE, OnDroponedateBymachine)
	ON_COMMAND(IDC_SEARCHMODE, OnSearchmode)
	ON_EN_CHANGE(IDC_CLIENT, OnChangeClient)
	ON_EN_CHANGE(IDC_SHADE, OnChangeShade)
	ON_EN_KILLFOCUS(IDC_CLIENT, OnKillfocusClient)
	ON_EN_KILLFOCUS(IDC_SHADE, OnKillfocusShade)
	ON_NOTIFY(HDN_ITEMCLICK, IDC_LIST1, OnItemclickList1)
	ON_COMMAND(ID_REMARK, OnRemark)
	ON_EN_KILLFOCUS(IDC_ORDER, OnKillfocusOrder)
	ON_COMMAND(IDC_FORCEMODE, OnForcemode)
	ON_EN_KILLFOCUS(IDC_COUNT, OnKillfocusCount)
	ON_COMMAND(ID_FINDSCHEDULE, OnFindschedule)
	ON_COMMAND(ID_FINDNEXT, OnFindnext)
	ON_COMMAND(ID_FINDPREV, OnFindprev)
	ON_COMMAND(ID_FINDORDER, OnFindorder)
	ON_COMMAND(IDC_SAVESEARCH, OnSavesearch)
	ON_COMMAND(IDC_SEARCHSAVED, OnSearchsaved)
	ON_EN_CHANGE(IDC_SPINBUDDY, OnChangeSpinbuddy)
	ON_BN_CLICKED(IDC_APPLY, OnApply)
	ON_COMMAND(IDC_DELETESEARCH, OnDeletesearch)
	ON_WM_VSCROLL()
	ON_COMMAND(IDC_SELECTGROUP, OnSelectgroup)
	ON_COMMAND(ID_ADDTOSELECTION, OnAddtoselection)
	ON_COMMAND(ID_REMOVEFROMSELECTION, OnRemovefromselection)
	ON_COMMAND(IDC_CONNECT, OnConnect)
	ON_COMMAND(IDC_LOADSCHEDULE, OnLoadschedule)
	ON_COMMAND(IDC_PRINTSCHEDULE, OnPrintschedule)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDialogDlg message handlers

BOOL CDialogDlg::OnInitDialog()
{
	CDialog::OnInitDialog();
	this->MoveWindow(0, 0, SCR_SIZE_X, SCR_SIZE_Y);
	SendMessage(WM_SYSCOMMAND, SC_MAXIMIZE, 0);

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	CRect	cr(SBAR_LFT_X, SBAR_TOP_Y, SBAR_RGT_X, SBAR_BOT_Y);
	if (!m_wndStatusBarCtrl.Create(WS_CHILD | WS_VISIBLE | CCS_BOTTOM, cr, this, AFX_IDW_STATUS_BAR ) )
	{
		TRACE0("Failed to create status bar\n");
		return -1;      // fail to create
	}

	m_wndStatusBarCtrl.SetParts(4, partswidth);

	m_wndStatusBarCtrl.SetText(_T(""),		ID_PART_STARTER, SBT_NOBORDERS);
	m_wndStatusBarCtrl.SetText(_T("Ready"), ID_PART_MESSAGE, 0);
	m_wndStatusBarCtrl.SetText(_T(""),		ID_PART_SEP1, SBT_NOBORDERS);
	m_wndStatusBarCtrl.SetText(_T(""),		ID_PART_DATE, 0);
	
	HWND	hwndLV;
	DWORD	dwStyle;

	hwndLV = m_ListCtrl.GetSafeHwnd();

	dwStyle = GetWindowLong(hwndLV, GWL_STYLE);  

	//dwStyle |= LVS_ICON | LVS_REPORT;
	dwStyle |= LVS_REPORT;

    SetWindowLong(hwndLV, GWL_STYLE, dwStyle); 
	m_SmallImageList = NULL;
	m_StateImageList = NULL;


	CRect		rc(CAL1_LFT_X, CAL1_TOP_Y, CAL1_RGT_X, CAL1_BOT_Y);
	COleFont	cf;

	m_Calendar.Create(NULL, !WS_VISIBLE, rc, this, IDC_CALENDAR, NULL, FALSE, NULL);
	m_Calendar.SetShowTitle(FALSE);
	m_Calendar.SetDayLength(0);

	cf	= m_Calendar.GetDayFont();

	m_Calendar.SetDayFont(cf.m_lpDispatch);
	m_Calendar.SetGridFont(cf.m_lpDispatch);

	CRect		lp1(LIST1_LFT_X, LIST1_TOP_Y, LIST1_RGT_X, LIST1_BOT_Y);
	CWnd*		cwlist = GetDlgItem(IDC_LIST1);

	cwlist->MoveWindow(&lp1, TRUE);

	CWnd*		cwgrid = GetDlgItem(IDC_MSFLEXGRID1);

	CRect		lp2(GRID1_LFT_X, GRID1_TOP_Y, GRID1_RGT_X, GRID1_BOT_Y);

	cwgrid->MoveWindow(&lp2, TRUE);

	CTime	CurrDate = CTime::GetCurrentTime();
	SetDate(CurrDate);

	DragStart = FALSE;
	CellDragStart	= FALSE;
	ValidDrag = FALSE;

	(GetDlgItem(IDC_SCLIENT))->GetWindowRect(&search_cr[0]);
	(GetDlgItem(IDC_CLIENT))->GetWindowRect(&search_cr[1]);
	(GetDlgItem(IDC_SORDER))->GetWindowRect(&search_cr[2]);
	(GetDlgItem(IDC_ORDER))->GetWindowRect(&search_cr[3]);
	(GetDlgItem(IDC_SSHADE))->GetWindowRect(&search_cr[4]);
	(GetDlgItem(IDC_SHADE))->GetWindowRect(&search_cr[5]);
	(GetDlgItem(IDC_SCOUNT))->GetWindowRect(&search_cr[6]);
	(GetDlgItem(IDC_COUNT))->GetWindowRect(&search_cr[7]);
	(GetDlgItem(IDC_SDDATE))->GetWindowRect(&search_cr[8]);
	(GetDlgItem(IDC_DDATE))->GetWindowRect(&search_cr[9]);
	(GetDlgItem(IDC_SPINDDATE))->GetWindowRect(&search_cr[10]);
	(GetDlgItem(IDC_APPLY))->GetWindowRect(&search_cr[11]);

	m_spinddate.SetBase(10);
	m_spinddate.SetRange(0, 365);
	m_spinddate.SetPos(0);
	m_spinddate.SetBuddy(GetDlgItem(IDC_SPINBUDDY));


	OnConnect();
	OnSearchmode();
	//SendDlgItemMessage(IDC_LIST1, WM_KEYDOWN, VK_DOWN, 0);
	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CDialogDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);

		CRect rect;
		GetClientRect(&rect);
		
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CPaintDC	dc(this); // device context for painting
		CPen*		cp1 = dc.GetCurrentPen();
		CPen		cp2(PS_SOLID, 1, 0x00e0e0e0);

		dc.MoveTo( 5, 0);
		dc.LineTo( 795, 0);
		dc.SelectObject((CPen*)&cp2);
		dc.MoveTo( 5, 1);
		dc.LineTo( 795, 1);
		dc.SelectObject((CPen*)cp1);

		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
// the minimized window.
HCURSOR CDialogDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CDialogDlg::OnCancel() 
{
	if( m_SmallImageList) delete m_SmallImageList;
	CDialog::OnCancel();
}

BOOL CDialogDlg::OnConnect() 
{
	CMenu*	menu;

	UpdateData(TRUE);

	if (!MainObject.Connect(m_NoOfDays))
	{
		return FALSE;	
	}

	menu = CWnd::GetMenu();
	{
		menu->EnableMenuItem(IDC_CONNECT,MF_GRAYED);
	}

	OnLoadschedule();
	
	if (m_AutoSchedule)
	{
		AutoSchedule();
	}

	return TRUE;
}

void CDialogDlg::InitiateGrid(CTime p_StartDate )
{
	if(!MainObject.IsConnected())
	{
		return;
	}

	int		nMCount = MainObject.GetMachineCount();

	// initializing different parameter
	LockWindowUpdate();
	UpdateData(TRUE);

	// Do Grid related works
	m_gOutput.SetCols(1);
	m_gOutput.SetRows(1);

	m_gOutput.SetWordWrap(TRUE);
	m_gOutput.SetRowHeight(0, ROW_HEIGHT);
	m_gOutput.SetCols( nMCount+ 1);
	m_gOutput.SetRows(m_NoOfDays * MainObject.GetnBatch() + 1);
	m_gOutput.SetCellAlignment(3);

	m_gOutput.SetRow(0);  // selecting Heading
	
	int		sign, digit, i, j;
	for(i = 0; i < nMCount; i++ )
	{
		char	*strCapacity;

		m_gOutput.SetCol(i+1);
		strCapacity = _fcvt(MainObject.GetMachineCapacity(i), 0, &digit, &sign);
		m_gOutput.SetText((LPCTSTR)(MainObject.GetMachineName(i)+ " - " + strCapacity + "(kg)"));
	}

	m_gOutput.SetCol(0); //selecting leftmost column	 

	for(i = 0; i < m_NoOfDays; i++ )
	{
		CTimeSpan Days(i, 0, 0, 0);
		CTime  CurrDate = p_StartDate + Days;
		CString	str = CurrDate.Format("%B\n%d, %Y\n");
		str += "Batch ";

		int		j;
		for(j = 0; j < MainObject.GetnBatch(); j++)
		{			
			char	strIndex[5];

			m_gOutput.SetRow( i * MainObject.GetnBatch() + j + 1);
			sprintf( strIndex, "%d", j+1);			
			m_gOutput.SetText((LPCTSTR)(str + strIndex));
		}
	}
	
//	start modification done by ahasan 06/04/1999
//	change font to arial narrow so that rows and columns take less space

	m_gOutput.SetColWidth(0, 900);
	m_gOutput.SetColAlignment(0, 0);
	m_gOutput.SetRowHeight(0, 300);

	for(i = 1; i <= nMCount; i++ )
	{
		m_gOutput.SetColWidth(i, 1600);
		m_gOutput.SetColAlignment(i, 3);
	}
	for(i = 1; i < m_NoOfDays * MainObject.GetnBatch() + 1; i++ )
	{
		m_gOutput.SetRowHeight(i, 1000);
	}
//	end modification done by ahasan 06/04/1999

//	start modification done by ahasan 06/04/1999
//	change backfround colors of columns 
	for(i = 1; i < m_NoOfDays * MainObject.GetnBatch() + 1; i++ )
	{
		for(j = 1; j <= nMCount; j++ )
		{
			m_gOutput.SetCol(j);
			m_gOutput.SetRow(i);
			//m_gOutput.SetCellBackColor((long)0xffffc0 + (j * 4));
			m_gOutput.SetCellBackColor(COLOR_CELL_BACK);
		}
	}
	
//	end modification done by ahasan 06/04/1999

	m_gOutput.SetAllowBigSelection(0);

	UnlockWindowUpdate();
}

void CDialogDlg::OnSchedule() 
{
	if(!MainObject.IsConnected())
	{
		return;
	}

	long	index ;
	BOOL	NeedRefresh;
	BOOL	NeedLoad;
	CString status, orderNo;
	int		o_index;

	NeedLoad	= FALSE;
	index = m_ListCtrl.GetNextItem( -1, LVNI_SELECTED );
	NeedRefresh = (index >=0 ? TRUE : FALSE);
	while (	index >= 0)
	{
		o_index = MainObject.o_array[index];
		if (MainObject.GetOrderLeftAmount(o_index) == 0)
		{
			orderNo = "Order: ";
			orderNo += MainObject.GetWorkOrderNo(o_index);
			MainObject.cmsg.raise_Error(SCH_ERR_ORDER_SCHEDULED, orderNo);
		}
		else
		{
			UpdateData(TRUE);
			
			double  LeftOver = MainObject.GetOrderLeftAmount(o_index);
			CTime	ct		 = GetDate();
			CString	otext;

			CPropertySheet		sheet(_T("Properties"));
			CDateAmtDlg			dlg;
			
			otext	=  _T("Work Order Number - ");
			otext	+= MainObject.GetWorkOrderNo(o_index);
			otext	+= "\r\n";
			otext	+= _T("Client Name       - ");
			otext	+= MainObject.GetOrderClient(o_index);
			otext	+= "\r\n";
			otext	+= _T("Count             - ");
			otext	+= MainObject.GetWorkOrderCount(o_index);
			otext	+= "\r\n";
			otext	+= _T("Shade             - ");
			otext	+= MainObject.GetWorkOrderShade(o_index);

			dlg.m_order		= otext;
			dlg.m_amount	= LeftOver;
			dlg.m_date.SetDate(ct.GetYear(), ct.GetMonth(), ct.GetDay());

			sheet.AddPage( &dlg );
			if (sheet.DoModal() != IDOK)
			{
				return;
			}
			
			if(dlg.m_amount < 0 )
			{
				return;
			}
			if( dlg.m_amount > LeftOver )
			{
				if(!m_Forcemode)
				{
					MainObject.cmsg.raise_Error(SCH_ERR_QTY_EXCEED);
					return;
				}
				else
				{
					LeftOver	= dlg.m_amount;
				}
			}
			else
			{
				LeftOver	= dlg.m_amount;
			}
			
			CTime	ct1 = CTime(dlg.m_date.GetYear(), dlg.m_date.GetMonth(), dlg.m_date.GetDay(), 0, 0, 0);
			
			long	sum1	= ct1.GetYear() * 10000 + ct1.GetMonth() * 100 + ct1.GetDay();
			long	sum		= ct.GetYear() * 10000 + ct.GetMonth() * 100 + ct.GetDay();

			if( sum1 <= sum )
			{
				ct1	= ct;
			}
			else
			{
				NeedLoad = TRUE;
			}

			int			n_days;
			CTimeSpan	cts = ct1 - ct;

			n_days	= m_NoOfDays - cts.GetDays();

			while (LeftOver - MaxQuantity > 0)
			{
				LeftOver -= MaxQuantity;
				MainObject.Schedule(o_index, ct1, n_days, MaxQuantity);
			}
			CWaitCursor	cw;

			MainObject.Schedule(o_index, ct1, n_days, LeftOver);
			
			PrintLeftOver(o_index);			
		}
		index = m_ListCtrl.GetNextItem( index, LVNI_SELECTED );
	}
	if( NeedLoad )
	{
		MainObject.LoadSchedule(GetDate(), m_NoOfDays);
	}
	if (NeedRefresh)
	{
		RefreshGrid(-1, -1);
	}
}

void CDialogDlg::FillOrderList()
{	
	if(!MainObject.IsConnected())
	{
		return;
	}

	if(!m_ListInitialized)
	{
		CString ColumnLabel[NUM_COLUMNS] = {_T("Order"),	_T("Client Name"),	_T("Quantity"),	_T("Yarn"),	_T("Count"),	_T("Shade"),	_T("Delivery Date"),	_T("Status"),	_T("Left") };
		int		ColumnWidth[NUM_COLUMNS] = { 110,			150,				55,				80,		50,				120,			75,						75,				55};
		int		ColumnStyle[NUM_COLUMNS] = {LVCFMT_LEFT,	LVCFMT_LEFT,		LVCFMT_RIGHT,	LVCFMT_LEFT, LVCFMT_LEFT,	LVCFMT_LEFT,	LVCFMT_LEFT,			LVCFMT_LEFT,	LVCFMT_RIGHT};
		CBitmap	cb;
		BOOL	b;
		long	ij;

		cb.LoadBitmap(IDB_SMALLICON);
		if( m_SmallImageList) 
		{
			delete m_SmallImageList;
		}
		m_SmallImageList = new CImageList();

		// b = m_SmallImageList->Create(IDB_BITMAP2, 16, 1, RGB(255, 255, 255));
		b = m_SmallImageList->Create( 16, 15, ILC_COLOR8, 55, 0 );
		m_SmallImageList->Add(&cb, RGB(255, 255, 255));

		m_ListCtrl.SetImageList(m_SmallImageList, LVSIL_SMALL);
		
		if( m_StateImageList)
		{
			delete m_StateImageList;
		}
		m_StateImageList = new CImageList();

		b = m_StateImageList->Create(IDB_STATEICON, 16, 1, RGB(255, 255, 255));
		m_ListCtrl.SetImageList(m_SmallImageList, LVSIL_STATE);

		// insert columns

		LockWindowUpdate();

		LV_COLUMN	lvc;

		lvc.mask = LVCF_FMT | LVCF_WIDTH | LVCF_TEXT | LVCF_SUBITEM;
		
		for(ij = 0; ij< NUM_COLUMNS; ij++)
		{
			lvc.cx = ColumnWidth[ij];
			lvc.fmt = ColumnStyle[ij];
			lvc.iSubItem = ij;
			lvc.pszText = (LPTSTR)(LPCTSTR)ColumnLabel[ij];
			m_ListCtrl.InsertColumn(ij, &lvc);
		}

		UnlockWindowUpdate();
		m_ListInitialized = TRUE;
	}

	// insert items
	char	str[25];

	m_ListCtrl.DeleteAllItems();

	LV_ITEM		lvi;
	int			cnt = MainObject.GetOrderCount();
	int			i;

	int j = 0;

	MainObject.o_array.RemoveAll();
	for(i = 0; i < cnt; i++)
	{
		// see if the order obeys search condition
		if(!IsOrderUnderSearch(i, m_Keepselection))
		{
			continue;
		}
		if(!IsOrderUnderSel(i))
		{
			continue;
		}
		lvi.mask = LVIF_STATE | LVIF_TEXT | LVIF_IMAGE;
		lvi.iItem = j;
		MainObject.o_array.InsertAt(j, i);
		//lvi.iItem = i;
		lvi.iSubItem = 0;
		lvi.pszText = (LPTSTR)(LPCTSTR)MainObject.GetWorkOrderNo(i);

		clsOrder	tmpOrder = MainObject.GetOrder(i);
		lvi.iImage =  tmpOrder.m_client_id % 55;
		//lvi.iImage = i;
		lvi.stateMask = LVIS_STATEIMAGEMASK;
		lvi.state = INDEXTOSTATEIMAGEMASK(0);
		lvi.lParam = i;
		m_ListCtrl.InsertItem(&lvi);		
		j++;
	}
// set item text for additional columns
	
	j = 0;

	for(i = 0; i< MainObject.GetOrderCount(); i++)
	{
		if(!IsOrderUnderSearch(i, m_Keepselection))
		{
			continue;
		}
		if(!IsOrderUnderSel(i))
		{
			continue;
		}
		clsOrder CurrOrder = MainObject.GetOrder(i);
		
		m_ListCtrl.SetItemText(j,1, (LPTSTR)(LPCTSTR)CurrOrder.m_client_name);
		sprintf(str, "%.02f", CurrOrder.m_quantity);
		m_ListCtrl.SetItemText(j,2, (LPTSTR)str);
		m_ListCtrl.SetItemText(j,3, (LPTSTR)(LPCTSTR)CurrOrder.m_yarn_type);
		m_ListCtrl.SetItemText(j,4, (LPTSTR)(LPCTSTR)CurrOrder.m_count_name);
		m_ListCtrl.SetItemText(j,5, (LPTSTR)(LPCTSTR)CurrOrder.m_shade);

		m_ListCtrl.SetItemText(j,6, (LPTSTR)(LPCTSTR)CurrOrder.m_deliverydate.Format("%d-%m-%Y"));
		
		if (CurrOrder.m_leftover == 0 )
		{
			m_ListCtrl.SetItemText(j,7, "Scheduled");
		}
		else if (CurrOrder.m_leftover == CurrOrder.m_quantity)
		{
			m_ListCtrl.SetItemText(j,7, "Unscheduled");
		}
		else
		{
			m_ListCtrl.SetItemText(j,7, "Partial");
		}
		sprintf(str, "%.02f", CurrOrder.m_leftover);
		m_ListCtrl.SetItemText(j,8, str);
		j++;
	}
	UnlockWindowUpdate();
	m_filled_order = j;


	sprintf(str, "Order Count = %5d", MainObject.o_array.GetSize()); 

	m_wndStatusBarCtrl.SetText(str, ID_PART_MESSAGE, 0);
	SendDlgItemMessage(IDC_LIST1, WM_KEYDOWN, VK_DOWN, 0);
}


void CDialogDlg::OnEdit() 
{
	
	if(!MainObject.IsConnected())
	{
		return;
	}

	int		row			= m_gOutput.GetRow() - 1;
	int		col			= m_gOutput.GetCol() - 1;
	long	i			= MainObject.FindOrderIndex(row, col);
	double	TableAmount = MainObject.GetTableAmount(row, col);
	int		stat		= MainObject.GetTableStatus(row, col);

	if( i == -1)
	{
		MainObject.cmsg.raise_Error(SCH_ERR_ORDER_MISS);
		return;
	}
	CPropertySheet		sheet(_T("Properties"));
	CAmountDlg			dlg;

	dlg.m_amount = TableAmount;
	dlg.m_sval = stat - 1;
	
//	if(stat == ID_PRODUCED)
//	{
		MainObject.GetTableTime(row, col,	&dlg.m_editstarthour, 
											&dlg.m_editstartmin, 
											&dlg.m_editendhour, 
											&dlg.m_editendmin );
//	}
	
	sheet.AddPage( &dlg );
	if (sheet.DoModal() != IDOK || dlg.m_cancel == TRUE)
	{
		return;
	}

	MainObject.SetTableStatus(row, col, dlg.m_sval + 1, GetDate(),
											dlg.m_editstarthour, 
											dlg.m_editstartmin, 
											dlg.m_editendhour, 
											dlg.m_editendmin, m_Forcemode );

	if (MainObject.EditAmount(row, col, i, dlg.m_amount, m_Forcemode))
	{
		PrintLeftOver(i);		

		UpdateData(TRUE);
		if (m_AutoSchedule)
		{
			AutoSchedule();
		}
	}
	RefreshGrid(row, col);
}



void CDialogDlg::OnDelete() 
{
	if(!MainObject.IsConnected())
	{
		return;
	}

	int		row = m_gOutput.GetRow() - 1;
	int		col = m_gOutput.GetCol() - 1;	

	if (MainObject.IsTableCellEmpty(row, col))
	{
		return;
	}
	if(MainObject.cmsg.raise_Error(SCH_ERR_DELETE_CELL) != IDYES)
	{
		return;
	}
	
	long	i	= MainObject.FindOrderIndex(row, col);
	if( i == -1)
	{
		MainObject.cmsg.raise_Error(SCH_ERR_ORDER_MISS);
		return;
	}

	if(MainObject.Delete(row, col))
	{
		RefreshGrid(row, col);
		PrintLeftOver(i);
		
		MainObject.TempDisableCell(row, col);

		UpdateData(TRUE);
		if (m_AutoSchedule)
		{
			AutoSchedule();
		}
		MainObject.EnableTempDisableCell(row, col);
	}
}

void CDialogDlg::OnContextMenu(CWnd* pWnd, CPoint point) 
{
	if(!MainObject.IsConnected())
	{
		return;
	}

	int		row = m_gOutput.GetMouseRow() - 1;
	int		col = m_gOutput.GetMouseCol() - 1;

	m_gOutput.SetRow(row + 1);
	m_gOutput.SetCol(col + 1);
	
	CWnd*	FlexWnd = CWnd::GetDlgItem(IDC_MSFLEXGRID1);
	
	CWnd*	ListCtlWnd = CWnd::GetDlgItem(IDC_LIST1);

	if (pWnd == ListCtlWnd )
	{
//		change it so that menu is shown only when one or more item is selected

		int		count = m_ListCtrl.GetSelectedCount();

		if( !count )
		{
			return;
		}

		CMenu menu;
		if (menu.LoadMenu(ID_POPUP_SCHEDULE))
		{
			CMenu* pPopup = menu.GetSubMenu(0);
			ASSERT(pPopup != NULL);
			// route commands through main window
			if( m_Selgroup )
			{
				menu.EnableMenuItem(ID_ADDTOSELECTION,MF_GRAYED);
			}
			else
			{
				menu.EnableMenuItem(ID_REMOVEFROMSELECTION,MF_GRAYED);
			}
			pPopup->TrackPopupMenu(TPM_RIGHTBUTTON | TPM_LEFTALIGN, point.x, point.y, AfxGetMainWnd()); 
		}
	}
	else if( pWnd == FlexWnd)
	{
		if (row >= 0 && col == -1)
		{
			CMenu menu;

			if (menu.LoadMenu(ID_POPUP_ROW_MENU))
			{
				CMenu* pPopup = menu.GetSubMenu(0);
				ASSERT(pPopup != NULL);
				// route commands through main window
				pPopup->TrackPopupMenu(TPM_RIGHTBUTTON | TPM_LEFTALIGN, point.x, point.y, AfxGetMainWnd()); 
			}	
		}
		else if (row == -1 && col == -1)
		{
			CMenu menu;

			if (menu.LoadMenu(ID_POPUP_DELETEALL))
			{
				CMenu* pPopup = menu.GetSubMenu(0);
				ASSERT(pPopup != NULL);
				// route commands through main window
				pPopup->TrackPopupMenu(TPM_RIGHTBUTTON | TPM_LEFTALIGN, point.x, point.y, AfxGetMainWnd()); 
			}		
		}

		else if (row == -1 && col >= 0)
		{
			CMenu menu;

			if (menu.LoadMenu(ID_POPUP_COL_MENU))
			{
				CMenu* pPopup = menu.GetSubMenu(0);
				ASSERT(pPopup != NULL);

				if (MainObject.MachineEnabled(col))
				{
					menu.EnableMenuItem(ID_ENABLE_MACHINE,MF_GRAYED);
				}				
				else 
				{
					menu.EnableMenuItem(ID_DISABLE_MACHINE,MF_GRAYED);
				}
				
				if (!IsMachineDisablable(row, col))
				{
					menu.EnableMenuItem(ID_DISABLE_MACHINE,MF_GRAYED);
				}

				// route commands through main window
				pPopup->TrackPopupMenu(TPM_RIGHTBUTTON | TPM_LEFTALIGN, point.x, point.y, AfxGetMainWnd());
			}	
		}
		else if ( row >= 0 && col >= 0)
		{
			CMenu menu;

			if (menu.LoadMenu(ID_POPUP_MENU))
			{
				CMenu* pPopup = menu.GetSubMenu(0);

				ASSERT(pPopup != NULL);
				
				if (MainObject.IsTableCellEmpty(row, col) || !MainObject.IsTableCellActive(row, col))
				{
					//menu.EnableMenuItem(ID_REMARK, MF_GRAYED);
					menu.EnableMenuItem(ID_EDIT, MF_GRAYED);
					menu.EnableMenuItem(ID_DELETE, MF_GRAYED);
				}

				if (MainObject.IsTableCellActive(row, col))
				{
					menu.EnableMenuItem(ID_REMARK, MF_GRAYED);
					menu.EnableMenuItem(ID_ENABLECURRCELL,MF_GRAYED);
				}
				
				if (MainObject.GetTableStatus(row, col) != 1)  //1 for active
				{
					menu.EnableMenuItem(ID_DISABLECURRCELL,MF_GRAYED);
				}

				if (!MainObject.MachineEnabled(col))
				{
					menu.EnableMenuItem(ID_ENABLECURRCELL,MF_GRAYED);
					menu.EnableMenuItem(ID_DISABLECURRCELL,MF_GRAYED);
				}

				// route commands through main window
				pPopup->TrackPopupMenu(TPM_RIGHTBUTTON | TPM_LEFTALIGN, point.x, point.y, AfxGetMainWnd());
			}	
		}
	}
}

void CDialogDlg::RefreshGrid(int row, int col)
{
	if(!MainObject.IsConnected())
	{
		return;
	}

	char	strText[200];
	int		MCount = MainObject.GetMachineCount();
	int		i, j;

	LockWindowUpdate();	
	if (row < 0 && col <0  )  //total grid
	{		
		for(i = 0; i < m_NoOfDays * MainObject.GetnBatch() ; i++)
		{
			for(j = 0; j < MCount; j++)
			{	
				clsCell		tmpCell = MainObject.GetTableCell(i, j);

				m_gOutput.SetRow(i+1);
				m_gOutput.SetCol(j+1);
				if (tmpCell.m_amount)
				{
					sprintf(strText, "%s %s\r\n%s\r\n%s (%.02f)\r\n%s",  tmpCell.m_count_name, tmpCell.m_yarn_type, tmpCell.m_shade.Left(20), tmpCell.m_workorder_no, tmpCell.m_amount, tmpCell.m_client_name);
					m_gOutput.SetCellForeColor((unsigned long)tmpCell.m_scheduleColor);
				}
				else 
				{
					sprintf(strText, (LPCTSTR)tmpCell.m_comment);
				}
				m_gOutput.SetText(strText);
		
				if (!tmpCell.m_active)
				{
					m_gOutput.SetCellBackColor(COLOR_BACK_INACTIVE);
					m_gOutput.SetCellForeColor(COLOR_FORE_INACTIVE);
				}
				else if (!MainObject.MachineEnabled(j))
				{
					m_gOutput.SetCellBackColor(COLOR_BACK_DISABLED);
					m_gOutput.SetCellForeColor(COLOR_FORE_DISABLED);
				}
				else
				{
					//m_gOutput.SetCellBackColor((long)0xffffc0 + ((j+1) * 4));
					m_gOutput.SetCellBackColor(COLOR_CELL_BACK);
					//m_gOutput.SetCellForeColor(COLOR_CELL_FORE);
					if(tmpCell.m_active == ID_INPROCESS)
					{
						m_gOutput.SetCellBackColor(COLOR_CELL_BACK_INPROCESS);
						m_gOutput.SetCellForeColor(COLOR_CELL_FORE_INPROCESS);
						//m_gOutput.SetCellFontItalic(TRUE);
						//m_gOutput.SetCellFontBold(TRUE);
					}
					else if(tmpCell.m_active == ID_PRODUCED_INC)
					{
						m_gOutput.SetCellBackColor(COLOR_CELL_BACK_PRODUCED_INC);
						m_gOutput.SetCellForeColor(COLOR_CELL_FORE_PRODUCED_INC);
						//m_gOutput.SetCellFontItalic(TRUE);
						//m_gOutput.SetCellFontBold(TRUE);
					}
					else if(tmpCell.m_active == ID_PRODUCED_COM)
					{
						m_gOutput.SetCellBackColor(COLOR_CELL_BACK_PRODUCED_COM);
						m_gOutput.SetCellForeColor(COLOR_CELL_FORE_PRODUCED_COM);
						//m_gOutput.SetCellFontItalic(TRUE);
						//m_gOutput.SetCellFontBold(TRUE);
					}
					else if(tmpCell.m_active == ID_ACTIVE)
					{
						m_gOutput.SetCellFontItalic(FALSE);
						//m_gOutput.SetCellFontBold(FALSE);
					}
					else if(tmpCell.m_active == ID_BATCH_NOT_AVAILABLE)
					{
						m_gOutput.SetCellBackColor(COLOR_BACK_NOBATCH);
						m_gOutput.SetCellForeColor(COLOR_FORE_NOBATCH);
					}
				}
			}
		}
	}
	else if (row >=0 && col >=0)	//only a cell identified by row,col
	{
		clsCell		tmpCell = MainObject.GetTableCell(row, col);

		if (tmpCell.m_amount)
		{
			sprintf(strText, "%s %s\r\n%-20s\r\n%s (%.02f)\r\n%s",  tmpCell.m_count_name, tmpCell.m_yarn_type, tmpCell.m_shade.Left(20), tmpCell.m_workorder_no, tmpCell.m_amount, tmpCell.m_client_name);
		}
		else 
		{
			if (tmpCell.m_active == ID_DISABLE)
			{
				sprintf(strText, tmpCell.m_comment);
			}
			else
			{
				sprintf(strText, "");
			}
		}
		m_gOutput.SetRow(row + 1);
		m_gOutput.SetCol(col + 1);
		m_gOutput.SetText(strText);
		m_gOutput.SetCellForeColor((unsigned long)tmpCell.m_scheduleColor);
		
		if (!tmpCell.m_active)
		{
			m_gOutput.SetCellBackColor(COLOR_BACK_INACTIVE);
			m_gOutput.SetCellForeColor(COLOR_FORE_INACTIVE);
		}
		else if (!MainObject.MachineEnabled(col))
		{
			m_gOutput.SetCellBackColor(COLOR_BACK_DISABLED);
			m_gOutput.SetCellForeColor(COLOR_FORE_DISABLED);
		}
		else
		{
			//m_gOutput.SetCellBackColor((long)0xffffc0 + ((col+1) * 4));
			m_gOutput.SetCellBackColor(COLOR_CELL_BACK);
			//m_gOutput.SetCellForeColor(COLOR_CELL_FORE);
			if(tmpCell.m_active == ID_INPROCESS)
			{
				m_gOutput.SetCellBackColor(COLOR_CELL_BACK_INPROCESS);
				m_gOutput.SetCellForeColor(COLOR_CELL_FORE_INPROCESS);
				//m_gOutput.SetCellFontItalic(TRUE);
				//m_gOutput.SetCellFontBold(TRUE);
			}
			else if(tmpCell.m_active == ID_PRODUCED_INC)
			{
				m_gOutput.SetCellBackColor(COLOR_CELL_BACK_PRODUCED_INC);
				m_gOutput.SetCellForeColor(COLOR_CELL_FORE_PRODUCED_INC);
				//m_gOutput.SetCellFontItalic(TRUE);
				//m_gOutput.SetCellFontBold(TRUE);
			}
			else if(tmpCell.m_active == ID_PRODUCED_COM)
			{
				m_gOutput.SetCellBackColor(COLOR_CELL_BACK_PRODUCED_COM);
				m_gOutput.SetCellForeColor(COLOR_CELL_FORE_PRODUCED_COM);
				//m_gOutput.SetCellFontItalic(TRUE);
				//m_gOutput.SetCellFontBold(TRUE);
			}
			else if(tmpCell.m_active == ID_ACTIVE)
			{
				m_gOutput.SetCellFontItalic(FALSE);
				m_gOutput.SetCellFontBold(FALSE);
			}
			else if(tmpCell.m_active == ID_BATCH_NOT_AVAILABLE)
			{
				m_gOutput.SetCellBackColor(COLOR_BACK_NOBATCH);						
				m_gOutput.SetCellForeColor(COLOR_FORE_NOBATCH);						
			}
		}
	}
	UnlockWindowUpdate();	
	return;
}

void CDialogDlg::PrintLeftOver(int Index)
{

	// Index is the array index of the order table
	// o_Index is the list index of the order in display

	if(!MainObject.IsConnected())
	{
		return;
	}

	clsOrder	tempOrder = MainObject.GetOrder(Index);
	char		str[20];
	int			i, o_Index = -1;

	for( i = 0 ; i < m_filled_order ; i++)
	{
		if( MainObject.o_array[i] == Index)
		{
			o_Index = i;
			break;
		}
	}

	if( o_Index == -1)
	{
		return;
	}

	if (tempOrder.m_quantity == tempOrder.m_leftover)	
	{
		m_ListCtrl.SetItemText(o_Index, 7, "Unscheduled");		
	}
	else if (tempOrder.m_leftover > 0)
	{
		m_ListCtrl.SetItemText(o_Index, 7, "Partial");		
	}
	else
	{
		m_ListCtrl.SetItemText(o_Index, 7, "Scheduled");
	}

	sprintf(str, "%.02f", tempOrder.m_leftover);
	m_ListCtrl.SetItemText(o_Index, 8, str);
}



BEGIN_EVENTSINK_MAP(CDialogDlg, CDialog)
    //{{AFX_EVENTSINK_MAP(CDialogDlg)
	ON_EVENT(CDialogDlg, IDC_MSFLEXGRID1, -607 /* MouseUp */, OnMouseUpMsflexgrid1, VTS_I2 VTS_I2 VTS_I4 VTS_I4)
	ON_EVENT(CDialogDlg, IDC_MSFLEXGRID1, 69 /* SelChange */, OnSelChangeMsflexgrid1, VTS_NONE)
	ON_EVENT(CDialogDlg, IDC_MSFLEXGRID1, 1550 /* OLEStartDrag */, OnOLEStartDragMsflexgrid1, VTS_PDISPATCH VTS_PI4)
	ON_EVENT(CDialogDlg, IDC_MSFLEXGRID1, -606 /* MouseMove */, OnMouseMoveMsflexgrid1, VTS_I2 VTS_I2 VTS_I4 VTS_I4)
	ON_EVENT(CDialogDlg, IDC_MSFLEXGRID1, -601 /* DblClick */, OnDblClickMsflexgrid1, VTS_NONE)
	//}}AFX_EVENTSINK_MAP
END_EVENTSINK_MAP()

void CDialogDlg::OnMouseUpMsflexgrid1(short Button, short Shift, long x, long y) 
{
	if(!MainObject.IsConnected())
	{
		return;
	}
	UpdateData(TRUE);

	int		row = m_gOutput.GetMouseRow() - 1;
	int		col = m_gOutput.GetMouseCol() - 1;
	
	if (CellDragStart && !(row == DragRow && col == DragCol) && row>=0 && col>=0 &&
		MainObject.GetTableStatus(row, col) <2 )
	{
			long SrcOrderIndex = MainObject.FindOrderIndex(DragRow, DragCol);
			if( SrcOrderIndex == -1)
			{
				MainObject.cmsg.raise_Error(SCH_ERR_ORDER_MISS);
				return;
			}
			
			if (MainObject.CellDragDrop(DragRow, DragCol, row, col, GetDate(), m_NoOfDays))
			{				
				PrintLeftOver(SrcOrderIndex);
				if (!MainObject.IsTableCellEmpty(DragRow, DragCol))
				{
					long DesOrderIndex = MainObject.FindOrderIndex(DragRow, DragCol);
					if( DesOrderIndex == -1)
					{
						MainObject.cmsg.raise_Error(SCH_ERR_ORDER_MISS);
						return;
					}
					PrintLeftOver(DesOrderIndex);
				}
				RefreshGrid(DragRow, DragCol);
				RefreshGrid(row, col);
			}
		
	}

	if (DragStart && row>=0 && col>=0 )
	{
		if (MainObject.GridMouseUp(row, col, DragItemIndex, GetDate(), m_NoOfDays, 1))
		{
			RefreshGrid(row, col);
			PrintLeftOver(DragItemIndex);
		}
	}
	DragStart = FALSE;
	CellDragStart = FALSE;
	ValidDrag = FALSE;
}

void CDialogDlg::OnBegindragList1(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_LISTVIEW*	pNMListView = (NM_LISTVIEW*)pNMHDR;

	// TODO: Add your control notification handler code 	
	DragItemIndex = m_ListCtrl.GetNextItem( -1, LVNI_SELECTED );
	DragStart = TRUE;
	if(DragStart)
	{
		SetCursor(OnQueryDragIcon());
	}
	*pResult = 0;
}


void CDialogDlg::OnLoadschedule() 
{
	if(!MainObject.IsConnected())
	{
		return;
	}

	CWaitCursor		wait;

	if(!m_Forcemode)
	{
		SetStartDate();
	}
	AdjustDate();

	CTime			m_StartDate = GetDate();
	
	// add a function to adjust order status
	MainObject.AdjustOrders();
	MainObject.LoadOrder();
	MainObject.LoadSelOrder();
	MainObject.LoadMachine();		
	FillOrderList();
	InitiateGrid(m_StartDate);
	MainObject.LoadSchedule(m_StartDate, m_NoOfDays);
	RefreshGrid(-1, -1);
}

// for getting date from calendar Control
CTime CDialogDlg::GetDate()
{
	int		Month, Day, Year;

	Year	= m_Calendar.GetYear();
	Month	= m_Calendar.GetMonth();
	Day		= m_Calendar.GetDay();

	CTime	StartDate(Year, Month, Day, 0, 0, 0);
	CString	s = StartDate.Format( "%A, %B %d, %Y" );

	m_wndStatusBarCtrl.SetText(s, ID_PART_DATE, 0);
	
	return	StartDate;
}

void CDialogDlg::OnDeletebatch() 
{
	if(!MainObject.IsConnected())
	{
		return;
	}

	if(MainObject.cmsg.raise_Error(SCH_ERR_DELETE_BATCH) != IDYES)
	{
		return;
	}

	int		row		= m_gOutput.GetRow() -1 ;
	int		col		= m_gOutput.GetCol() - 1;	
	int		MCount	= MainObject.GetMachineCount();
	int		i;

	for(i = 0; i < MCount; i++)
	{
		long	OrderIndex = MainObject.FindOrderIndex(row, i);
		/*if( OrderIndex == -1)
		{
			MainObject.cmsg.raise_Error(SCH_ERR_ORDER_MISS);
			return;
		}*/

		if (MainObject.Delete(row, i))
		{			
			PrintLeftOver(OrderIndex);
			RefreshGrid(row, i);
		}
	}
	
	UpdateData(TRUE);
	if (m_AutoSchedule)
	{
		AutoSchedule();
	}

}

void CDialogDlg::OnDroponedate() 
{
	if(!MainObject.IsConnected())
	{
		return;
	}

	int		row		= m_gOutput.GetRow() -1 ;
	int		col		= m_gOutput.GetCol() - 1;
	
	int l_dateCount = row / MainObject.GetnBatch();
	CTimeSpan l_date(l_dateCount, 0, 0, 0);
	
	CTime StartDate  = GetDate();
	StartDate += l_date;

	MainObject.DropOneDate(StartDate, -1, FALSE);
	MainObject.LoadSchedule(GetDate(), m_NoOfDays);

	UpdateData(TRUE);
	if (m_AutoSchedule)
	{
		AutoSchedule();
	}
	RefreshGrid(-1, -1);

}


void CDialogDlg::OnDisablebatch() 
{
	if(!MainObject.IsConnected())
	{
		return;
	}

	int		row		= m_gOutput.GetRow() -1 ;
	int		col		= m_gOutput.GetCol() - 1;
	
	if (!MainObject.IsTableCellEmpty(row, col))
	{
		long OrderIndex = MainObject.FindOrderIndex(row, col);
		if( OrderIndex == -1)
		{
			MainObject.cmsg.raise_Error(SCH_ERR_ORDER_MISS);
			return;
		}
		if (MainObject.DisableCell(row, col, GetDate()))
		{
			//chage background 
			RefreshGrid(row, col);
			PrintLeftOver(OrderIndex);
		}		
	}
	else
	{
		if (MainObject.DisableCell(row, col, GetDate()))
		{
			RefreshGrid(row, col);
		}

	}

	UpdateData(TRUE);
	if (m_AutoSchedule)
	{
		AutoSchedule();
	}
}

void CDialogDlg::AutoSchedule()
{
	if(!MainObject.IsConnected())
	{
		return;
	}

	//long OrderCount = MainObject.GetOrderCount();	
	CTime	StartDate = GetDate();
	int		o_index;

	for(long index = 0; index < m_filled_order; index++)
	{
		o_index = MainObject.o_array[index];

		double  LeftOver = MainObject.GetOrderLeftAmount(o_index);

		if (LeftOver > 0)
		{			
			while (LeftOver - MaxQuantity > 0)
			{
				LeftOver -= MaxQuantity;
				MainObject.Schedule(o_index, GetDate(), m_NoOfDays, MaxQuantity);				
			}
			MainObject.Schedule(o_index, GetDate(), m_NoOfDays, LeftOver);
			PrintLeftOver(o_index);
		}
	}
	RefreshGrid(-1, -1);
}

void CDialogDlg::OnEnablecurrcell() 
{
	if(!MainObject.IsConnected())
	{
		return;
	}

	int		row		= m_gOutput.GetRow() -1 ;
	int		col		= m_gOutput.GetCol() - 1;

	if (MainObject.EnableCell(row, col))
	{
		RefreshGrid(row, col);		
	}		

	UpdateData(TRUE);
	if (m_AutoSchedule)
	{
		AutoSchedule();
	}

}

void CDialogDlg::OnDeleteAll() 
{
	if(!MainObject.IsConnected())
	{
		return;
	}

	int MCount = MainObject.GetMachineCount();

	int i, j;
	
	for(i = 0; i < m_NoOfDays * MainObject.GetnBatch(); i++)
	{
		for (j=0; j < MCount; j++)
		{
			if (!MainObject.IsTableCellEmpty(i, j))
			{
				long OrderIndex = MainObject.FindOrderIndex(i, j);
				if( OrderIndex == -1)
				{
					MainObject.cmsg.raise_Error(SCH_ERR_ORDER_MISS);
					return;
				}
				if(MainObject.Delete(i, j))
				{				
					PrintLeftOver(OrderIndex);
				}
			}
		}	
	}
	RefreshGrid(-1, -1);
}

void CDialogDlg::OnDisableMachine() 
{
	if(!MainObject.IsConnected())
	{
		return;
	}

	int		col		= m_gOutput.GetCol() - 1;
	
	for(int i = 0; i < m_NoOfDays * MainObject.GetnBatch(); i++)
	{
		long OrderIndex = MainObject.FindOrderIndex(i, col);
		if( OrderIndex > -1)
		{
			if (MainObject.Delete(i, col))
			{
				PrintLeftOver(OrderIndex);
			}
		}
	}
	
	MainObject.DisableMachine(col);

	RefreshGrid(-1, -1);

	UpdateData(TRUE);
	if (m_AutoSchedule)
	{
		AutoSchedule();
	}
}

void CDialogDlg::OnDroponebatch() 
{
	if(!MainObject.IsConnected())
	{
		return;
	}
	CTime	m_StartDate		= GetDate();
	int		row		= m_gOutput.GetRow() -1 ;	
	
	MainObject.DropOneBatch(m_StartDate, row, -1, FALSE);
	MainObject.LoadSchedule(m_StartDate, m_NoOfDays);

	UpdateData(TRUE);
	if (m_AutoSchedule)
	{
		AutoSchedule();
	}
	
	RefreshGrid(-1, -1);
}

void CDialogDlg::AdjustDate()
{
	UpdateData(TRUE);

	CTime	MaxDate = MainObject.GetMaxDate();
	CTime	StartDate = GetDate();
	if (MaxDate > StartDate)
	{
		CTimeSpan	DaysRequired = MaxDate - StartDate;

		int date = DaysRequired.GetDays();
		if (m_NoOfDays < date )
		{
			m_NoOfDays = date  + 1;
			UpdateData(FALSE);
		}
	}
}

void CDialogDlg::OnEnableMachine() 
{
	if(!MainObject.IsConnected())
	{
		return;
	}

	int		col		= m_gOutput.GetCol() - 1;

	MainObject.EnableMachine(col);
	
	RefreshGrid(-1, -1);

	UpdateData(TRUE);
	if (m_AutoSchedule)
	{
		AutoSchedule();
	}

}

void CDialogDlg::OnSelChangeMsflexgrid1() 
{
	if(!MainObject.IsConnected())
	{
		return;
	}

	long	srow = m_gOutput.GetRow();
	long	scol = m_gOutput.GetCol();
	
	long	erow = m_gOutput.GetRowSel();
	long	ecol = m_gOutput.GetColSel();

	int		MaxRow, MinRow, MinCol, MaxCol;

	if((srow == erow) && (ecol == scol))
	{
		return;
	}
	if(erow == 0 || ecol == 0)
	{
		return;
	}
	if (srow > erow)
	{
		MaxRow = srow;
		MinRow = erow;
	}
	else
	{
		MaxRow = erow;
		MinRow = srow;
	}

	if (scol > ecol)
	{
		MaxCol = scol;
		MinCol = ecol;
	}
	else
	{
		MaxCol = ecol;
		MinCol = scol;
	}

	for( long i = MinRow; i <= MaxRow ; i++)
	{
		for( long j = MinCol; j <= MaxCol ; j++)
		{
			m_gOutput.SetCol(j);
			m_gOutput.SetRow(i);
			
			if (MainObject.GetTableStatus(i-1, j-1) == 1)
			{
				//m_gOutput.SetCellBackColor((long)0xffffc0 + (j * 4));
				m_gOutput.SetCellBackColor(COLOR_CELL_BACK);
			}			
			else if(MainObject.GetTableStatus(i-1, j-1) == 3)
			{
				m_gOutput.SetCellBackColor(0x00ff00ff);
			}
			else if(MainObject.GetTableStatus(i-1, j-1) == 2)
			{
				m_gOutput.SetCellBackColor(0x00ff0000);
			}			
			else if(MainObject.GetTableStatus(i-1, j-1) == ID_BATCH_NOT_AVAILABLE)
			{
				m_gOutput.SetCellBackColor(COLOR_BACK_NOBATCH);
			}
			

			if (!MainObject.MachineEnabled(j-1))
			{
					m_gOutput.SetCellBackColor((COLORREF)RGB(MainObject.ordercolors[2].red, MainObject.ordercolors[2].green, MainObject.ordercolors[2].blue));
			}
		}
	}
	
	m_gOutput.SetCol(ecol);
	m_gOutput.SetRow(erow);
	
	if(!CellDragStart && !MainObject.IsTableCellEmpty(srow-1, scol-1)
		&& MainObject.IsTableCellActive(srow-1, scol-1) && !ValidDrag &&
		MainObject.GetTableStatus(srow-1, scol-1) < 2)
	{
		DragRow	= srow - 1;
		DragCol	= scol - 1;	
		CellDragStart = TRUE;
	}	
	
	ValidDrag = TRUE;

}

void CDialogDlg::OnAutomatic() 
{
	CMenu*	menu;

	menu = CWnd::GetMenu();

	if(m_AutoSchedule)
	{
		menu->CheckMenuItem(IDC_AUTOMATIC,MF_UNCHECKED);
		m_AutoSchedule = FALSE;
	}
	else
	{
		menu->CheckMenuItem(IDC_AUTOMATIC,MF_CHECKED);
		m_AutoSchedule = TRUE;
	}
}

void CDialogDlg::OnConfirm() 
{
	// TODO: Add your command handler code here
	CMenu*	menu;

	menu = CWnd::GetMenu();

	if(m_Confirm)
	{
		menu->CheckMenuItem(IDC_CONFIRM,MF_UNCHECKED);
		m_Confirm = FALSE;
		MainObject.cmsg.SetConfirmation(m_Confirm);
	}
	else
	{
		menu->CheckMenuItem(IDC_CONFIRM,MF_CHECKED);
		m_Confirm = TRUE;
		MainObject.cmsg.SetConfirmation(m_Confirm);
	}
}

BOOL CDialogDlg::GetConfirmation()
{
	return m_Confirm;
}

void CDialogDlg::OnPopupSchedule() 
{
	if(!MainObject.IsConnected())
	{
		return;
	}
	OnSchedule();	
}

void CDialogDlg::OnPopupUnschedule() 
{
	if(!MainObject.IsConnected())
	{
		return;
	}

	long	index;
	int		o_Index;

	index = m_ListCtrl.GetNextItem( -1, LVNI_SELECTED );
	while (	index >= 0)
	{
		o_Index = MainObject.o_array[index];

		if ( MainObject.Unschedule(index, m_NoOfDays))
		{			
			PrintLeftOver(o_Index);
		}
		index = m_ListCtrl.GetNextItem( index, LVNI_SELECTED );
	}	
	RefreshGrid(-1, -1);
}

void CDialogDlg::OnCalshow() 
{
	// TODO: Add your command handler code here
	CMenu*		menu;
	CWnd*		cwcal  = CWnd::GetDlgItem(IDC_CALENDAR);
	CWnd*		cwlist = GetDlgItem(IDC_LIST1);

	menu = CWnd::GetMenu();

	if(m_Calshow)
	{
		if(m_SearchMode)
		{
			CRect		lp(LIST3_LFT_X, LIST3_TOP_Y, LIST3_RGT_X, LIST3_BOT_Y);

			cwlist->MoveWindow(&lp, TRUE);
			CRect		lps[12];
			for( int i = 0; i < 12 ; i++)
			{
				lps[i] = search_cr[i];
				lps[i].top = 5;
				lps[i].bottom = 25;
			}
			(GetDlgItem(IDC_SCLIENT))->MoveWindow(&lps[0]);
			(GetDlgItem(IDC_CLIENT))->MoveWindow(&lps[1]);
			(GetDlgItem(IDC_SORDER))->MoveWindow(&lps[2]);
			(GetDlgItem(IDC_ORDER))->MoveWindow(&lps[3]);
			(GetDlgItem(IDC_SSHADE))->MoveWindow(&lps[4]);
			(GetDlgItem(IDC_SHADE))->MoveWindow(&lps[5]);
			(GetDlgItem(IDC_SCOUNT))->MoveWindow(&lps[6]);
			(GetDlgItem(IDC_COUNT))->MoveWindow(&lps[7]);
			(GetDlgItem(IDC_SDDATE))->MoveWindow(&lps[8]);
			(GetDlgItem(IDC_DDATE))->MoveWindow(&lps[9]);
			(GetDlgItem(IDC_SPINDDATE))->MoveWindow(&lps[10]);
			(GetDlgItem(IDC_APPLY))->MoveWindow(&lps[11]);
		}
		else
		{
			CRect		lp(LIST1_LFT_X, LIST1_TOP_Y, LIST1_RGT_X, LIST1_BOT_Y);

			cwlist->MoveWindow(&lp, TRUE);

		}
		menu->CheckMenuItem(IDC_CALSHOW,MF_UNCHECKED);
		m_Calshow = FALSE;
		cwcal->ShowWindow(SW_HIDE);	
	}
	else
	{
		if(m_SearchMode)
		{
			CRect		lp(LIST4_LFT_X, LIST4_TOP_Y, LIST4_RGT_X, LIST4_BOT_Y);

			cwlist->MoveWindow(&lp, TRUE);
			CRect		lps[12];
			for( int i = 0; i < 12 ; i++)
			{
				lps[i] = search_cr[i];
				lps[i].left += SEARCH_SHIFT;
				lps[i].right += SEARCH_SHIFT;
				lps[i].top = 5;
				lps[i].bottom = 25;
			}
			(GetDlgItem(IDC_APPLY))->MoveWindow(&lps[11]);
			(GetDlgItem(IDC_SPINDDATE))->MoveWindow(&lps[10]);
			(GetDlgItem(IDC_DDATE))->MoveWindow(&lps[9]);
			(GetDlgItem(IDC_SDDATE))->MoveWindow(&lps[8]);
			(GetDlgItem(IDC_COUNT))->MoveWindow(&lps[7]);
			(GetDlgItem(IDC_SCOUNT))->MoveWindow(&lps[6]);
			(GetDlgItem(IDC_SHADE))->MoveWindow(&lps[5]);
			(GetDlgItem(IDC_SSHADE))->MoveWindow(&lps[4]);
			(GetDlgItem(IDC_ORDER))->MoveWindow(&lps[3]);
			(GetDlgItem(IDC_SORDER))->MoveWindow(&lps[2]);
			(GetDlgItem(IDC_CLIENT))->MoveWindow(&lps[1]);
			(GetDlgItem(IDC_SCLIENT))->MoveWindow(&lps[0]);
		}
		else
		{
			CRect		lp(LIST2_LFT_X, LIST2_TOP_Y, LIST2_RGT_X, LIST2_BOT_Y);

			cwlist->MoveWindow(&lp, TRUE);

		}

		menu->CheckMenuItem(IDC_CALSHOW,MF_CHECKED);
		m_Calshow = TRUE;
		cwcal->ShowWindow(SW_SHOW);
	}
}

void CDialogDlg::SetDate(CTime ct)
{
	m_Calendar.SetYear(ct.GetYear());
	m_Calendar.SetMonth(ct.GetMonth());
	m_Calendar.SetDay(ct.GetDay());
	CString		s = ct.Format( "%A, %B %d, %Y" );
	m_wndStatusBarCtrl.SetText(s, ID_PART_DATE, 0);
}

void CDialogDlg::OnAboutbox() 
{
	// TODO: Add your command handler code here
	CAboutDlg dlgAbout;
	dlgAbout.DoModal();
}

void CDialogDlg::OnOLEStartDragMsflexgrid1(LPDISPATCH FAR* Data, long FAR* AllowedEffects) 
{
	// TODO: Add your control notification handler code here
	return;	
}

void CDialogDlg::OnMouseMoveMsflexgrid1(short Button, short Shift, long x, long y) 
{
	// TODO: Add your control notification handler code here
	if(CellDragStart)
	{
//		crsr = GetCursor();
		SetCursor(OnQueryDragIcon());
	}
}

void CDialogDlg::OnMouseMove(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	if(DragStart)
	{
//		crsr = GetCursor();
		SetCursor(OnQueryDragIcon());
	}
	
	CDialog::OnMouseMove(nFlags, point);
}

BOOL CDialogDlg::IsMachineDisablable(int row, int col)
{
	for(int i = 0; i < m_NoOfDays * MainObject.GetnBatch(); i++)
	{
		if (MainObject.GetTableStatus(i, col) == 2 || MainObject.GetTableStatus(i, col) == 3)
		{
			return FALSE;
		}
	}
	return TRUE;
}


void CDialogDlg::SetStartDate()
{
	CTime	sDate = MainObject.GetStartDate();

	if(sDate.GetYear() != 1980)
	{
		SetDate(sDate);
	}
}

void CDialogDlg::OnComplete() 
{
	// TODO: Add your command handler code here
	if(!MainObject.IsConnected())
	{
		return;
	}

	long	index;
	
	index = m_ListCtrl.GetNextItem(-1, LVNI_SELECTED);
	while (	index >= 0)
	{
		MainObject.SetOrderStatus(index, 1, m_Forcemode);
		index = m_ListCtrl.GetNextItem( index, LVNI_SELECTED );
	}	
}

void CDialogDlg::OnLoadprocessed() 
{
	// TODO: Add your command handler code here
	CMenu*	menu;

	menu = CWnd::GetMenu();

	if(m_LoadProcessed)
	{
		menu->CheckMenuItem(IDC_LOADPROCESSED, MF_UNCHECKED);
		m_LoadProcessed = FALSE;
		MainObject.SetLoadProcessed(m_LoadProcessed);
	}
	else
	{
		menu->CheckMenuItem(IDC_LOADPROCESSED, MF_CHECKED);
		m_LoadProcessed = TRUE;
		MainObject.SetLoadProcessed(m_LoadProcessed);
	}
	
}

void CDialogDlg::OnDroponebatchBymachine() 
{
	if(!MainObject.IsConnected())
	{
		return;
	}

	int		row		= m_gOutput.GetRow() -1 ;
	int		col		= m_gOutput.GetCol() -1 ;

	CTime m_StartDate	=	GetDate();
	MainObject.DropOneBatch(m_StartDate, row, col, TRUE);
	MainObject.LoadSchedule(m_StartDate, m_NoOfDays);

	UpdateData(TRUE);
	if (m_AutoSchedule)
	{
		AutoSchedule();
	}

	RefreshGrid(-1, -1);
	
}

void CDialogDlg::OnDroponedateBymachine() 
{
	if(!MainObject.IsConnected())
	{
		return;
	}

	int		row		= m_gOutput.GetRow() -1 ;
	int		col		= m_gOutput.GetCol() - 1;
	
	int l_dateCount = row / MainObject.GetnBatch();
	CTimeSpan l_date(l_dateCount, 0, 0, 0);
	
	CTime StartDate  = GetDate();
	StartDate += l_date;

	MainObject.DropOneDate(StartDate, col, TRUE);
	MainObject.LoadSchedule(GetDate(), m_NoOfDays);

	UpdateData(TRUE);
	if (m_AutoSchedule)
	{
		AutoSchedule();
	}
	RefreshGrid(-1, -1);

}

void CDialogDlg::OnSearchmode() 
{
	// TODO: Add your command handler code here
	CMenu*	menu;
	CWnd*		cwlist = GetDlgItem(IDC_LIST1);

	menu = CWnd::GetMenu();

	if(m_SearchMode)
	{
		if(m_Calshow)
		{
			CRect		lp(LIST2_LFT_X, LIST2_TOP_Y, LIST2_RGT_X, LIST2_BOT_Y);

			cwlist->MoveWindow(&lp, TRUE);
		}
		else
		{
			CRect		lp(LIST1_LFT_X, LIST1_TOP_Y, LIST1_RGT_X, LIST1_BOT_Y);

			cwlist->MoveWindow(&lp, TRUE);
		}
		menu->CheckMenuItem(IDC_SEARCHMODE, MF_UNCHECKED);
		m_SearchMode = FALSE;
		m_changed = FALSE;
		(GetDlgItem(IDC_SCLIENT))->ShowWindow(SW_HIDE);
		(GetDlgItem(IDC_CLIENT))->ShowWindow(SW_HIDE);
		(GetDlgItem(IDC_SORDER))->ShowWindow(SW_HIDE);
		(GetDlgItem(IDC_ORDER))->ShowWindow(SW_HIDE);
		(GetDlgItem(IDC_SSHADE))->ShowWindow(SW_HIDE);
		(GetDlgItem(IDC_SHADE))->ShowWindow(SW_HIDE);
		(GetDlgItem(IDC_SCOUNT))->ShowWindow(SW_HIDE);
		(GetDlgItem(IDC_COUNT))->ShowWindow(SW_HIDE);
		(GetDlgItem(IDC_SDDATE))->ShowWindow(SW_HIDE);
		(GetDlgItem(IDC_DDATE))->ShowWindow(SW_HIDE);
		(GetDlgItem(IDC_SPINDDATE))->ShowWindow(SW_HIDE);
		(GetDlgItem(IDC_APPLY))->ShowWindow(SW_HIDE);
	}
	else
	{
		if(m_Calshow)
		{
			CRect		lp(LIST4_LFT_X, LIST4_TOP_Y, LIST4_RGT_X, LIST4_BOT_Y);

			cwlist->MoveWindow(&lp, TRUE);

			CRect		lps[12];
			for( int i = 0; i < 12 ; i++)
			{
				lps[i] = search_cr[i];
				lps[i].left += SEARCH_SHIFT;
				lps[i].right += SEARCH_SHIFT;
				lps[i].top = 5;
				lps[i].bottom = 25;
			}
			(GetDlgItem(IDC_SCLIENT))->MoveWindow(&lps[0]);
			(GetDlgItem(IDC_CLIENT))->MoveWindow(&lps[1]);
			(GetDlgItem(IDC_SORDER))->MoveWindow(&lps[2]);
			(GetDlgItem(IDC_ORDER))->MoveWindow(&lps[3]);
			(GetDlgItem(IDC_SSHADE))->MoveWindow(&lps[4]);
			(GetDlgItem(IDC_SHADE))->MoveWindow(&lps[5]);
			(GetDlgItem(IDC_SCOUNT))->MoveWindow(&lps[6]);
			(GetDlgItem(IDC_COUNT))->MoveWindow(&lps[7]);
			(GetDlgItem(IDC_SDDATE))->MoveWindow(&lps[8]);
			(GetDlgItem(IDC_DDATE))->MoveWindow(&lps[9]);
			(GetDlgItem(IDC_SPINDDATE))->MoveWindow(&lps[10]);
			(GetDlgItem(IDC_APPLY))->MoveWindow(&lps[11]);
		}
		else
		{
			CRect		lp(LIST3_LFT_X, LIST3_TOP_Y, LIST3_RGT_X, LIST3_BOT_Y);

			cwlist->MoveWindow(&lp, TRUE);
			CRect		lps[12];
			for( int i = 0; i < 12 ; i++)
			{
				lps[i] = search_cr[i];
				lps[i].top = 5;
				lps[i].bottom = 25;
			}
			(GetDlgItem(IDC_SCLIENT))->MoveWindow(&lps[0]);
			(GetDlgItem(IDC_CLIENT))->MoveWindow(&lps[1]);
			(GetDlgItem(IDC_SORDER))->MoveWindow(&lps[2]);
			(GetDlgItem(IDC_ORDER))->MoveWindow(&lps[3]);
			(GetDlgItem(IDC_SSHADE))->MoveWindow(&lps[4]);
			(GetDlgItem(IDC_SHADE))->MoveWindow(&lps[5]);
			(GetDlgItem(IDC_SCOUNT))->MoveWindow(&lps[6]);
			(GetDlgItem(IDC_COUNT))->MoveWindow(&lps[7]);
			(GetDlgItem(IDC_SDDATE))->MoveWindow(&lps[8]);
			(GetDlgItem(IDC_DDATE))->MoveWindow(&lps[9]);
			(GetDlgItem(IDC_SPINDDATE))->MoveWindow(&lps[10]);
			(GetDlgItem(IDC_APPLY))->MoveWindow(&lps[11]);
		}

		menu->CheckMenuItem(IDC_SEARCHMODE, MF_CHECKED);
		m_SearchMode = TRUE;
		(GetDlgItem(IDC_SCLIENT))->ShowWindow(SW_SHOW);
		(GetDlgItem(IDC_CLIENT))->ShowWindow(SW_SHOW);
		(GetDlgItem(IDC_SORDER))->ShowWindow(SW_SHOW);
		(GetDlgItem(IDC_ORDER))->ShowWindow(SW_SHOW);
		(GetDlgItem(IDC_SSHADE))->ShowWindow(SW_SHOW);
		(GetDlgItem(IDC_SHADE))->ShowWindow(SW_SHOW);
		(GetDlgItem(IDC_SCOUNT))->ShowWindow(SW_SHOW);
		(GetDlgItem(IDC_COUNT))->ShowWindow(SW_SHOW);
		(GetDlgItem(IDC_SDDATE))->ShowWindow(SW_SHOW);
		(GetDlgItem(IDC_DDATE))->ShowWindow(SW_SHOW);
		(GetDlgItem(IDC_SPINDDATE))->ShowWindow(SW_SHOW);
		(GetDlgItem(IDC_APPLY))->ShowWindow(SW_SHOW);
	}
}

BOOL CDialogDlg::IsOrderUnderSel(int oc)
{
	if(!m_Selgroup)
	{
		return TRUE;
	}
	
	clsOrder	ord		= MainObject.GetOrder(oc);
	long		wo_id	= ord.m_wo_id;
	int			i;

	for( i = 0 ; i < MainObject.GetSelOrderCount() ; i++)
	{
		if( wo_id == MainObject.GetSelOrderNo(i))
		{
			return TRUE;
		}
	}
	return FALSE;
}

BOOL CDialogDlg::IsOrderUnderSearch(int oc)
{
	if(!m_SearchMode)
	{
		return TRUE;
	}
	clsOrder	ord		= MainObject.GetOrder(oc);
	CString		cname	= ord.m_client_name;
	CString		sname	= ord.m_shade;
	CString		worder	= ord.m_workorder_no;
	CString		count	= ord.m_count_name;
	CTime		ddate	= ord.m_deliverydate;

	cname = cname.Left(m_client.GetLength());
	sname = sname.Left(m_shade.GetLength());
	worder = worder.Left(m_order.GetLength());
	count = count.Left(m_count.GetLength());

	if( !m_order.IsEmpty() && worder.CompareNoCase((LPCTSTR)m_order) != 0)
	{
		return FALSE;
	}
	if( !m_shade.IsEmpty() && sname.CompareNoCase((LPCTSTR)m_shade) != 0)
	{
		return FALSE;
	}
	if( !m_client.IsEmpty() && cname.CompareNoCase((LPCTSTR)m_client) != 0)
	{
			return FALSE;
	}
	if( !m_count.IsEmpty() && count.CompareNoCase((LPCTSTR)m_count) != 0)
	{
		return FALSE;
	}
	if( m_ddate.GetYear() == 1970)
	{
		return TRUE;
	}
	else
	{
		if( m_ddate.GetDay()	!= ddate.GetDay()	||
			m_ddate.GetMonth()	!= ddate.GetMonth() ||
			m_ddate.GetYear()	!= ddate.GetYear())
		{
			return FALSE;
		}
		else
		{
			return TRUE;
		}
	}

	return TRUE;
}

BOOL CDialogDlg::IsOrderUnderSearch(int oc, BOOL mode)
{
	if(!m_SearchMode)
	{
		return TRUE;
	}
	if(mode == FALSE)
	{
		return IsOrderUnderSearch(oc);
	}
	
	clsOrder	ord		= MainObject.GetOrder(oc);
	CString		cname	= ord.m_client_name;
	CString		sname	= ord.m_shade;
	CString		worder	= ord.m_workorder_no;
	CString		count	= ord.m_count_name;
	CTime		ddate	= ord.m_deliverydate;

	int	i;

	for(i = 0 ; i < SArray.GetSize() ; i++)
	{
		cname	= cname.Left(SArray[i].m_client.GetLength());
		sname	= sname.Left(SArray[i].m_shade.GetLength());
		worder	= worder.Left(SArray[i].m_order.GetLength());
		count	= count.Left(SArray[i].m_count.GetLength());

		if( !SArray[i].m_order.IsEmpty() && worder.CompareNoCase((LPCTSTR)SArray[i].m_order) != 0)
		{
			continue;
			//return FALSE;
		}
		if( !SArray[i].m_shade.IsEmpty() && sname.CompareNoCase((LPCTSTR)SArray[i].m_shade) != 0)
		{
			continue;
			//return FALSE;
		}
		if( !SArray[i].m_client.IsEmpty() && cname.CompareNoCase((LPCTSTR)SArray[i].m_client) != 0)
		{
			continue;
			//return FALSE;
		}
		if( !SArray[i].m_count.IsEmpty() && count.CompareNoCase((LPCTSTR)SArray[i].m_count) != 0)
		{
			continue;
			//return FALSE;
		}
		if( SArray[i].m_ddate.GetYear() == 1970)
		{
			return TRUE;
		}
		else
		{
			if( SArray[i].m_ddate.GetDay()	!= ddate.GetDay() ||
				SArray[i].m_ddate.GetMonth() != ddate.GetMonth() ||
				SArray[i].m_ddate.GetYear() != ddate.GetYear())
			{
				continue;
				//return FALSE;
			}
			else
			{
				return TRUE;
			}
		}
	}
	return IsOrderUnderSearch(oc);
}

void CDialogDlg::OnChangeClient() 
{
	// TODO: If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CDialog::OnInitDialog()
	// function to send the EM_SETEVENTMASK message to the control
	// with the ENM_CHANGE flag ORed into the lParam mask.
	
	// TODO: Add your control notification handler code here
	//FillOrderList();
}

void CDialogDlg::OnChangeShade() 
{
	// TODO: If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CDialog::OnInitDialog()
	// function to send the EM_SETEVENTMASK message to the control
	// with the ENM_CHANGE flag ORed into the lParam mask.
	
	// TODO: Add your control notification handler code here
	//FillOrderList();
}

void CDialogDlg::OnItemclickList1(NMHDR* pNMHDR, LRESULT* pResult) 
{
	HD_NOTIFY *phdn = (HD_NOTIFY *) pNMHDR;
	// TODO: Add your control notification handler code here
	switch(phdn->iItem)
	{
		case 0:
		{
			MessageBox("a");
			break;
		}
		case 1:
		{
			MessageBox("b");
			break;
		}
		case 2:
		{
			MessageBox("c");
			break;
		}
		case 3:
		{
			MessageBox("d");
			break;
		}
		case 4:
		{
			MessageBox("e");
			break;
		}
		default:
		{
			break;
		}
	}
	*pResult = 0;
}


void CDialogDlg::OnDblClickMsflexgrid1() 
{
	// TODO: Add your control notification handler code here
	if(!MainObject.IsConnected())
	{
		return;
	}

	int		row			= m_gOutput.GetMouseRow() - 1;
	int		col			= m_gOutput.GetMouseCol() - 1;

	if ( row >= 0 && col >= 0)
	{
		clsCell		tmpCell = MainObject.GetTableCell(row, col);
		if (MainObject.IsTableCellActive(row, col))
		{
			if(tmpCell.m_amount)
			{
				OnEdit();
			}
		}
		else
		{
			OnRemark();
		}
	}
}


void CDialogDlg::OnRemark() 
{
	
	if(!MainObject.IsConnected())
	{
		return;
	}

	CPropertySheet		sheet(_T("Properties"));
	CRemarkDlg			dlg;

	int		row			= m_gOutput.GetRow() - 1;
	int		col			= m_gOutput.GetCol() - 1;

	clsCell		tmpCell = MainObject.GetTableCell(row, col);

	dlg.m_remark = tmpCell.m_comment;

	sheet.AddPage( &dlg );
	if (sheet.DoModal() != IDOK)
	{
		return;
	}

	if(dlg.m_remark != tmpCell.m_comment)
	{
		MainObject.SetTableRemark(row, col, dlg.m_remark);
		MainObject.UpdateDatabase(row, col, IDD_EDIT, FALSE, -1);
		RefreshGrid(row, col);
	}
}

void CDialogDlg::OnForcemode() 
{
	// TODO: Add your command handler code here
	CMenu*	menu;

	menu = CWnd::GetMenu();

	if(m_Forcemode)
	{
		menu->CheckMenuItem(IDC_FORCEMODE,MF_UNCHECKED);
		m_Forcemode = FALSE;
	}
	else
	{
		menu->CheckMenuItem(IDC_FORCEMODE,MF_CHECKED);
		m_Forcemode = TRUE;
	}
}

void CDialogDlg::OnSelectgroup() 
{
	CMenu*	menu;

	menu = CWnd::GetMenu();

	if(m_Selgroup)
	{
		menu->CheckMenuItem(IDC_SELECTGROUP,MF_UNCHECKED);
		m_Selgroup = FALSE;
	}
	else
	{
		menu->CheckMenuItem(IDC_SELECTGROUP,MF_CHECKED);
		m_Selgroup = TRUE;
	}
	FillOrderList();
}

BOOL CDialogDlg::CstrToTime(CString& m_strdate, CTime& ct)
{
	int	year;
	int	month;
	int	day;

	if(m_strdate.IsEmpty())
	{
		return FALSE;
	}
	day		= atoi(m_strdate.Mid(0, 2));
	month	= atoi(m_strdate.Mid(3, 2));
	year	= atoi(m_strdate.Mid(6, 4));

	CTime	ctemp = CTime(year, month, day, 0, 0, 0);

	ct	= ctemp;
	return TRUE;
}

void CDialogDlg::OnFindschedule() 
{
	// TODO: Add your command handler code here
	if(!MainObject.IsConnected())
	{
		return;
	}

	long	index ;
	long	o_index;
	int		i, j;

	index	= m_ListCtrl.GetNextItem( -1, LVNI_SELECTED );
	o_index = MainObject.o_array[index];
	clsOrder	co = MainObject.GetOrder(o_index);

	for(i = 0; i < m_NoOfDays * MainObject.GetnBatch() ; i++)
	{
		for(j = 0; j < MainObject.GetMachineCount(); j++)
		{	
			clsCell		tmpCell = MainObject.GetTableCell(i, j);

			if( tmpCell.m_wo_id == co.m_wo_id )
			{
				m_gOutput.SetLeftCol(j+1);
				m_gOutput.SetTopRow(i+1);
				m_gOutput.SetRow(i+1);
				m_gOutput.SetCol(j+1);
				m_gOutput.SetFocus();
				return;
			}
		}
	}
	return;
}

void CDialogDlg::OnFindnext() 
{
	if(!MainObject.IsConnected())
	{
		return;
	}

	int		row = m_gOutput.GetRow() - 1;
	int		col = m_gOutput.GetCol() - 1;	

	if (MainObject.IsTableCellEmpty(row, col))
	{
		return;
	}
	
	long		o_index	= MainObject.FindOrderIndex(row, col);
	clsOrder	co = MainObject.GetOrder(o_index);
	int			i, j;
	
	for(j = col + 1; j < MainObject.GetMachineCount(); j++)
	{	
		clsCell		tmpCell = MainObject.GetTableCell(row, j);
			
		if( tmpCell.m_wo_id == co.m_wo_id )
		{
			m_gOutput.SetLeftCol(j+1);
			m_gOutput.SetTopRow(row+1);
			m_gOutput.SetRow(row+1);
			m_gOutput.SetCol(j+1);
			m_gOutput.SetFocus();

			return;
		}
	}

	for(i = row + 1 ; i < m_NoOfDays * MainObject.GetnBatch() ; i++)
	{
		for(j = 0; j < MainObject.GetMachineCount(); j++)
		{	
			clsCell		tmpCell = MainObject.GetTableCell(i, j);

			if( tmpCell.m_wo_id == co.m_wo_id )
			{
				m_gOutput.SetLeftCol(j+1);
				m_gOutput.SetTopRow(i+1);
				m_gOutput.SetRow(i+1);
				m_gOutput.SetCol(j+1);
				m_gOutput.SetFocus();
				return;
			}
		}
	}
	return;
}

void CDialogDlg::OnFindprev() 
{
	if(!MainObject.IsConnected())
	{
		return;
	}

	int		row = m_gOutput.GetRow() - 1;
	int		col = m_gOutput.GetCol() - 1;	

	if (MainObject.IsTableCellEmpty(row, col))
	{
		return;
	}
	
	long		o_index	= MainObject.FindOrderIndex(row, col);
	clsOrder	co = MainObject.GetOrder(o_index);
	int			i, j;
	
	for(j = col - 1; j >= 0 ; j--)
	{	
		clsCell		tmpCell = MainObject.GetTableCell(row, j);
			
		if( tmpCell.m_wo_id == co.m_wo_id )
		{
			m_gOutput.SetLeftCol(j+1);
			m_gOutput.SetTopRow(row+1);
			m_gOutput.SetRow(row+1);
			m_gOutput.SetCol(j+1);
			m_gOutput.SetFocus();

			return;
		}
	}

	for(i = row - 1 ; i >= 0 ; i--)
	{
		for(j = MainObject.GetMachineCount() - 1; j >= 0 ; j--)
		{	
			clsCell		tmpCell = MainObject.GetTableCell(i, j);

			if( tmpCell.m_wo_id == co.m_wo_id )
			{
				m_gOutput.SetLeftCol(j+1);
				m_gOutput.SetTopRow(i+1);
				m_gOutput.SetRow(i+1);
				m_gOutput.SetCol(j+1);
				m_gOutput.SetFocus();
				return;
			}
		}
	}
	return;
}

void CDialogDlg::OnFindorder() 
{
	if(!MainObject.IsConnected())
	{
		return;
	}

	int		row = m_gOutput.GetRow() - 1;
	int		col = m_gOutput.GetCol() - 1;	
	int	i;
	
	if (MainObject.IsTableCellEmpty(row, col))
	{
		return;
	}
	
	long	o_index	= MainObject.FindOrderIndex(row, col);
	clsCell	cc		= MainObject.GetTableCell(row, col);
	long	wo_id	= cc.m_wo_id;

	BOOL		flag = FALSE;
	
	for( i = 0 ; i < m_filled_order ; i++ )
	{
		clsOrder	co1 = MainObject.GetOrder(MainObject.o_array[i]);
		if( co1.m_wo_id == wo_id)
		{
			flag = TRUE;
			break;
		}
	}
	if(!flag)
	{
		return;
	}

	int	fc	= m_ListCtrl.GetNextItem( -1, LVNI_FOCUSED);

	flag = FALSE;
	for(i = 0 ; i < m_filled_order ; i++)
	{
		if(o_index == MainObject.o_array[i])
		{
			flag = TRUE;
			break;
		}
	}

	if(!flag)
	{
		return;
	}
	
	o_index	= i;

	LockWindowUpdate();	
	CWaitCursor	cw;
	m_ListCtrl.SetFocus();
	if( fc > o_index)
	{
		for( i = 0 ; i < fc - o_index; i++)
		{
			SendDlgItemMessage(IDC_LIST1, WM_KEYDOWN, VK_UP, 0);
		}
	}
	else if(fc < o_index)
	{
		for( i = 0 ; i < o_index - fc ; i++)
		{
			SendDlgItemMessage(IDC_LIST1, WM_KEYDOWN, VK_DOWN, 0);
		}
	}
	UnlockWindowUpdate();		
}

void CDialogDlg::OnSavesearch() 
{
	if(!m_SearchMode)
	{
		return;
	}

	SearchStruct	ss;
	
	ss.m_client	= m_client;
	ss.m_count	= m_count;
	ss.m_ddate	= m_ddate;
	ss.m_order	= m_order;
	ss.m_shade	= m_shade;

	SArray.Add(ss);
	m_changed = TRUE;
}

void CDialogDlg::OnDeletesearch() 
{
	SArray.RemoveAll();
	m_changed = TRUE;
}

void CDialogDlg::OnSearchsaved() 
{
	CMenu*	menu;

	menu = CWnd::GetMenu();

	if(m_Forcemode)
	{
		menu->CheckMenuItem(IDC_SEARCHSAVED,MF_UNCHECKED);
		m_Keepselection = FALSE;
	}
	else
	{
		menu->CheckMenuItem(IDC_SEARCHSAVED,MF_CHECKED);
		m_Keepselection = TRUE;
	}
}

void CDialogDlg::OnChangeSpinbuddy() 
{
	// TODO: If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CDialog::OnInitDialog()
	// function to send the EM_SETEVENTMASK message to the control
	// with the ENM_CHANGE flag ORed into the lParam mask.
	
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);
	COleDateTimeSpan	cts;
	CTime	ct = MainObject.m_first_date;
	
	o_ddate = m_ddate;

	if(m_spinbuddy == 0)
	{
		m_ddate.SetDate(1970, 1, 1);
	}
	else
	{
		cts = COleDateTimeSpan(m_spinbuddy - 1, 0, 0, 0);
		m_ddate.SetDate( ct.GetYear(), ct.GetMonth(), ct.GetDay());
		m_ddate	+= cts;
	}
	if(m_ddate != o_ddate)
	{
		m_changed = TRUE;
	}
	UpdateData(FALSE);
}

void CDialogDlg::OnApply() 
{
	// See whether changes are needed
	if(m_changed)
	{
		FillOrderList();
		m_changed = FALSE;		
	}
}


void CDialogDlg::OnKillfocusClient() 
{
	UpdateData(TRUE);
	if(o_client.CompareNoCase((LPCTSTR)m_client) != 0)
	{
		m_changed = TRUE;
		o_client = m_client;
	}
}

void CDialogDlg::OnKillfocusShade() 
{
	UpdateData(TRUE);
	if(o_shade.CompareNoCase((LPCTSTR)m_shade) != 0)
	{
		m_changed = TRUE;
		o_shade = m_shade;
	}
}

void CDialogDlg::OnKillfocusOrder() 
{
	UpdateData(TRUE);
	if(o_order.CompareNoCase((LPCTSTR)m_order) != 0)
	{
		m_changed = TRUE;
		o_order = m_order;
	}
}

void CDialogDlg::OnKillfocusCount() 
{
	UpdateData(TRUE);
	if(o_count.CompareNoCase((LPCTSTR)m_count) != 0)
	{
		m_changed = TRUE;
		o_count = m_count;
	}
}

void CDialogDlg::OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar) 
{
	// TODO: Add your message handler code here and/or call default
	MessageBox("Here I Am");
	CDialog::OnVScroll(nSBCode, nPos, pScrollBar);
}


void CDialogDlg::OnAddtoselection() 
{
	if(!MainObject.IsConnected())
	{
		return;
	}

	if(m_Selgroup)	// we are in selected group remove
	{
		return;
	}

	BOOL	changed = FALSE;
	long	index;
	int		o_Index;

	index = m_ListCtrl.GetNextItem( -1, LVNI_SELECTED );
	while (	index >= 0)
	{
		o_Index = MainObject.o_array[index];

		changed = MainObject.UpdateSelOrder(o_Index, IDD_ADD);
		index = m_ListCtrl.GetNextItem( index, LVNI_SELECTED );
	}	
	if(changed)
	{
		//FillOrderList();
	}
}

void CDialogDlg::OnRemovefromselection() 
{
	if(!MainObject.IsConnected())
	{
		return;
	}

	if(!m_Selgroup)	
	{
		return;
	}

	BOOL	changed = FALSE;
	long	index;
	int		o_Index;

	index = m_ListCtrl.GetNextItem( -1, LVNI_SELECTED );
	while (	index >= 0)
	{
		o_Index = MainObject.o_array[index];

		changed = MainObject.UpdateSelOrder(o_Index, IDD_DELETE);
		index = m_ListCtrl.GetNextItem( index, LVNI_SELECTED );
	}	
	if(changed)
	{
		FillOrderList();
	}
}

BOOL CDialogDlg::OpenExcel()
{
	if(!m_ExcelStarted)
	{
		if(!m_Excel.CreateDispatch("Excel.Application"))
		{
			MessageBox("Could not run Excel");
			return FALSE;
		}
		m_ExcelStarted = TRUE;
		m_Excel.m_bAutoRelease = TRUE;
	}
	return TRUE;
}

BOOL CDialogDlg::CloseExcel()
{
	if(m_ExcelStarted)
	{
		//m_Excel.Quit();
		m_Excel.ReleaseDispatch();
		m_ExcelStarted = FALSE;
	}
	return m_ExcelStarted;
}

void CDialogDlg::OnPrintschedule() 
{
	COleVariant	covOptional((long)DISP_E_PARAMNOTFOUND, VT_ERROR);
	COleVariant	covTrue((short)TRUE);
	COleVariant	covFalse((short)FALSE);

	static char szFilter[] = "Excel Worksheet Files (*.xls)||";
	CString		fext	= "xls";
	CString		fname	= "Schedules";
	CString		fpath;
	CFileDialog	*cf	= new CFileDialog(	FALSE, 
										(LPCTSTR)fext,
										(LPCTSTR)fname,
										OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT, 
										szFilter, 
										this );

	if(cf->DoModal() != IDOK )
	{
		return;
	}

	fname = cf->GetPathName();
	if( fname.IsEmpty())
	{
		return;
	}

	if(OpenExcel())
	{
		m_Excel.SetVisible(TRUE);
		//MessageBox("Excel is running");
	}
	m_WorkBooks	= m_Excel.GetWorkbooks();
	m_WorkBook	= m_WorkBooks.Add(covOptional);

	m_WorkSheets	= m_WorkBook.GetSheets();
	m_WorkSheet		= m_WorkSheets.GetItem(COleVariant((short)1));
	//m_WorkSheet.SetName("Schedule");

	FillExcelSheet();

	//m_WorkBook.SaveCopyAs(COleVariant(fname));
	m_WorkBook.SaveAs(	COleVariant(fname), COleVariant((short)43),
						covOptional, covOptional, covOptional, covOptional, 
						1l, covOptional, covOptional, covOptional,  
						covOptional);

	//m_WorkBooks.ReleaseDispatch();
	//m_Excel.SaveWorkspace(COleVariant(fname));
	//m_WorkBook.Save();
	//m_WorkBook.Close(covTrue, COleVariant(fname), covOptional);
	//m_WorkBooks.Close();
	CloseExcel();
}

void CDialogDlg::FillExcelSheet()
{
	COleSafeArray	sa;
	DWORD			dim[2];
	int				i, j;
	VARIANT			v;
	long			index[2];
	CString			cs;
	CString			cs1;
	

	// fill machine names
	dim[0] = 1;
	dim[1] = MainObject.GetMachineCount();
	sa.Create(VT_BSTR, 2, dim);

	VariantInit(&v);
	for(j = 0; j < MainObject.GetMachineCount(); j++)
	{	
		cs   = MainObject.MachineArray[j].m_machine_name;
		cs	+= "\n(";
		sprintf((LPTSTR)(LPCTSTR)cs1, "Capacity - %5.2lf Kgs)", MainObject.MachineArray[j].m_capacity);
		cs	+= cs1;

		index[0] = 0;
		index[1] = j;
		v = COleVariant(cs);
		v.vt = VT_BSTR;
		sa.PutElement(index, v.bstrVal);
	}
	VariantClear(&v);
	m_range	= m_WorkSheet.GetRange(COleVariant("B1"), COleVariant("N1"));
	//m_range	= m_WorkSheet.GetRange(COleVariant("B1"), COleVariant("B1"));
	//m_range = m_range.GetResize(COleVariant((short)1), COleVariant((short)MainObject.GetMachineCount()));
	m_range.SetValue(COleVariant(sa));
	sa.Detach();


	// fill cells
/*	dim[0] = m_NoOfDays * MainObject.GetnBatch();
	dim[1] = MainObject.GetMachineCount();
	sa.Create(VT_BSTR, 2, dim);

	cs.Empty();
	cs1.Empty();
	VariantInit(&v);
	for(i = 0; i < m_NoOfDays * MainObject.GetnBatch() ; i++)
	{
		for(j = 0; j < MainObject.GetMachineCount(); j++)
		{	
			//clsCell		tmpCell = MainObject.GetTableCell(i, j);

			m_gOutput.SetRow(i+1);
			m_gOutput.SetCol(j+1);
			cs = m_gOutput.GetText();

			index[0] = i;
			index[1] = j;
			v = COleVariant(cs);
			v.vt = VT_BSTR;
			sa.PutElement(index, v.bstrVal);
		}
	}
	VariantClear(&v);
	m_range	= m_WorkSheet.GetRange(COleVariant("B2"), COleVariant("B2"));
	m_range = m_range.GetResize(COleVariant((short)i), COleVariant((short)j));
	m_range.SetValue(COleVariant(sa));
	sa.Detach();
*/
}