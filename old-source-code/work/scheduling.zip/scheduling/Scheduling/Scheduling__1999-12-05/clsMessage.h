// clsMessage.h: interface for the clsMessage class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_CLSMESSAGE_H__62757502_F163_11D2_818D_00C0DFEC3C16__INCLUDED_)
#define AFX_CLSMESSAGE_H__62757502_F163_11D2_818D_00C0DFEC3C16__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000


enum	Codes
{		SCH_ERR_NO_MSG					= 0,
		SCH_ERR_CONNECT_FAILED			= 100,
		SCH_ERR_ORDER_LOAD_FAILED		= 101,
		SCH_ERR_MACHINE_LOAD_FAILED		= 102,
		SCH_ERR_SOLUTION_LOAD_FAILED	= 103,
		SCH_ERR_NO_OPTIMAL_SOLUTION		= 500,
		SCH_ERR_ROLLBACK				= 1000,
		SCH_ERR_DATABASE				= 1001,
		SCH_ERR_LEFTOVER_SMALL			= 1100,
		SCH_ERR_QTY_EXCEED				= 1101,
		SCH_ERR_RANGE_EXCEED			= 1102,
		SCH_ERR_ORDER_SCHEDULED			= 1103,
		SCH_ERR_DELETE_CELL				= 1500,
		SCH_ERR_DELETE_BATCH			= 1501,
		SCH_ERR_UNSCHEDULE				= 1505,
		SCH_ERR_NO_TRANSITION1			= 1600,
		SCH_ERR_NO_TRANSITION2			= 1601,
		SCH_ERR_SCH_TO_INP				= 1602,
		SCH_ERR_INP_TO_SCH				= 1603,
		SCH_ERR_INP_TO_PRO				= 1604,
		SCH_ERR_PRO_TO_INP				= 1605,
		SCH_ERR_DELETE_INP				= 1700,
		SCH_ERR_DELETE_PRO				= 1701,
		SCH_ERR_ORDER_MISS				= 1800,
		SCH_ERR_ORDER_COMPLETED			= 1801,
		SCH_ERR_PREV_UNPROCESSED		= 1900,
		SCH_ERR_ORDER_NO_LEFT			= 2000,
		SCH_ERR_ORDER_SCH_UNP			= 2001
};

typedef struct
{
	int			err_Number;
	char		err_String[100];
	BOOL		err_Maskable;
	int			err_Format;
}EMSG;


class clsMessage  
{
public:
	void SetConfirmation(BOOL bVal);
	int raise_Error(int e_num);
	int raise_Error(int e_num, CString cs);
	clsMessage();
	virtual ~clsMessage();

protected:
	BOOL	m_Confirm;
	int		find_Error(int e_num);
	static	EMSG	err_Messages[];
};

#endif // !defined(AFX_CLSMESSAGE_H__62757502_F163_11D2_818D_00C0DFEC3C16__INCLUDED_)
