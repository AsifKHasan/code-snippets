// OrderSet.cpp : implementation file
//

#include "stdafx.h"
#include "Scheduling.h"
#include "OrderSet.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// COrderSet

IMPLEMENT_DYNAMIC(COrderSet, CRecordset)

COrderSet::COrderSet(CDatabase* pdb)
	: CRecordset(pdb)
{
	//{{AFX_FIELD_INIT(COrderSet)
	m_quantity = 0.0;
	m_shade = _T("");
	m_count_name = _T("");
	m_workorder_no = _T("");
	m_yarn_type = _T("");
	m_left_over = 0.0;
	m_wo_id = 0;
	m_client_name = _T("");
	m_status = 0;
	m_dyecomplete = 0;
	m_client_id = 0;
	m_nFields = 12;
	//}}AFX_FIELD_INIT
	m_nDefaultType = dynaset;
}


CString COrderSet::GetDefaultConnect()
{
	return _T("");
}

CString COrderSet::GetDefaultSQL()
{
	return _T("[GrossOrder]");
}

void COrderSet::DoFieldExchange(CFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(COrderSet)
	pFX->SetFieldType(CFieldExchange::outputColumn);
	RFX_Date(pFX, _T("[deliverydate]"), m_deliverydate);
	RFX_Double(pFX, _T("[quantity]"), m_quantity);
	RFX_Text(pFX, _T("[shade]"), m_shade);
	RFX_Text(pFX, _T("[count_name]"), m_count_name);
	RFX_Text(pFX, _T("[workorder_no]"), m_workorder_no);
	RFX_Text(pFX, _T("[yarn_type]"), m_yarn_type);
	RFX_Double(pFX, _T("[left_over]"), m_left_over);
	RFX_Long(pFX, _T("[wo_id]"), m_wo_id);
	RFX_Text(pFX, _T("[client_name]"), m_client_name);
	RFX_Byte(pFX, _T("[status]"), m_status);
	RFX_Byte(pFX, _T("[dyecomplete]"), m_dyecomplete);
	RFX_Int(pFX, _T("[client_id]"), m_client_id);
	//}}AFX_FIELD_MAP
}

/////////////////////////////////////////////////////////////////////////////
// COrderSet diagnostics

#ifdef _DEBUG
void COrderSet::AssertValid() const
{
	CRecordset::AssertValid();
}

void COrderSet::Dump(CDumpContext& dc) const
{
	CRecordset::Dump(dc);
}
#endif //_DEBUG
