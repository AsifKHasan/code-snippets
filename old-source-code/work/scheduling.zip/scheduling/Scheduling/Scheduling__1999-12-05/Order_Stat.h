#if !defined(AFX_ORDER_STAT_H__1B3F5A73_069E_11D3_81C2_00C0DFEC3C16__INCLUDED_)
#define AFX_ORDER_STAT_H__1B3F5A73_069E_11D3_81C2_00C0DFEC3C16__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// Order_Stat.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// COrder_Stat recordset

class COrder_Stat : public CRecordset
{
public:
	COrder_Stat(CDatabase* pDatabase = NULL);
	DECLARE_DYNAMIC(COrder_Stat)

// Field/Param Data
	//{{AFX_FIELD(COrder_Stat, CRecordset)
	long	m_wo_id;
	BYTE	m_status;
	double	m_left_over;
	BYTE	m_dyecomplete;
	//}}AFX_FIELD


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(COrder_Stat)
	public:
	virtual CString GetDefaultConnect();    // Default connection string
	virtual CString GetDefaultSQL();    // Default SQL for Recordset
	virtual void DoFieldExchange(CFieldExchange* pFX);  // RFX support
	//}}AFX_VIRTUAL

// Implementation
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ORDER_STAT_H__1B3F5A73_069E_11D3_81C2_00C0DFEC3C16__INCLUDED_)
