// Order_Stat.cpp : implementation file
//

#include "stdafx.h"
#include "scheduling.h"
#include "Order_Stat.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// COrder_Stat

IMPLEMENT_DYNAMIC(COrder_Stat, CRecordset)

COrder_Stat::COrder_Stat(CDatabase* pdb)
	: CRecordset(pdb)
{
	//{{AFX_FIELD_INIT(COrder_Stat)
	m_wo_id = 0;
	m_status = 0;
	m_left_over = 0.0;
	m_dyecomplete = 0;
	m_nFields = 4;
	//}}AFX_FIELD_INIT
	m_nDefaultType = dynaset;
}


CString COrder_Stat::GetDefaultConnect()
{
	return _T("ODBC;DSN=Schedule");
}

CString COrder_Stat::GetDefaultSQL()
{
	return _T("[Order_Stat]");
}

void COrder_Stat::DoFieldExchange(CFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(COrder_Stat)
	pFX->SetFieldType(CFieldExchange::outputColumn);
	RFX_Long(pFX, _T("[wo_id]"), m_wo_id);
	RFX_Byte(pFX, _T("[status]"), m_status);
	RFX_Double(pFX, _T("[left_over]"), m_left_over);
	RFX_Byte(pFX, _T("[dyecomplete]"), m_dyecomplete);
	//}}AFX_FIELD_MAP
}

/////////////////////////////////////////////////////////////////////////////
// COrder_Stat diagnostics

#ifdef _DEBUG
void COrder_Stat::AssertValid() const
{
	CRecordset::AssertValid();
}

void COrder_Stat::Dump(CDumpContext& dc) const
{
	CRecordset::Dump(dc);
}
#endif //_DEBUG
