// clsOrder.cpp : implementation file
//

#include "stdafx.h"
#include "Scheduling.h"
#include "clsOrder.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// clsOrder

clsOrder::clsOrder()
{
	m_leftover = 0;
}

clsOrder::~clsOrder()
{
}


//BEGIN_MESSAGE_MAP(clsOrder, CWnd)
	//{{AFX_MSG_MAP(clsOrder)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
//END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// clsOrder message handlers
