#if !defined(AFX_CLSORDER_H__FBB08908_80CC_11D2_A9DB_00A024C905B6__INCLUDED_)
#define AFX_CLSORDER_H__FBB08908_80CC_11D2_A9DB_00A024C905B6__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// clsOrder.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// clsOrder window

class clsOrder
{
// Construction
public:
	clsOrder();

// Attributes
public:

	COLORREF	orderColor;
	CString		m_shade;		
	CString		m_count_name;
	CString		m_workorder_no;
	CString		m_yarn_type;
	CString		m_client_name;
	CTime		m_deliverydate;
	double		m_quantity;
	double		m_leftover;
	long		m_wo_id;
	BYTE		m_dyecomplete;
	int			m_client_id;

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(clsOrder)
	//}}AFX_VIRTUAL

// Implementation
public:
	
	virtual ~clsOrder();

	// Generated message map functions
protected:
//	{{AFX_MSG(clsOrder)
		// NOTE - the ClassWizard will add and remove member functions here.
//	}}AFX_MSG
//	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CLSORDER_H__FBB08908_80CC_11D2_A9DB_00A024C905B6__INCLUDED_)
