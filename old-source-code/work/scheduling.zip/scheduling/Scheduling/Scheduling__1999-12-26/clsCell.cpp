// clsCell.cpp : implementation file
//

#include "stdafx.h"
#include "Scheduling.h"
#include "clsCell.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// clsCell

clsCell::clsCell()
{
	m_active = ID_ACTIVE;
}

clsCell::~clsCell()
{
}


//BEGIN_MESSAGE_MAP(clsCell, CWnd)
	//{{AFX_MSG_MAP(clsCell)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
//END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// clsCell message handlers

BOOL clsCell::MakeEmpty()
{
	m_wo_id			= 0;	
	m_workorder_no.Empty();	
	m_count_name.Empty();	
	m_client_name.Empty();
	m_yarn_type.Empty();
	m_shade.Empty();
	m_empty			= TRUE;
	m_active		= ID_ACTIVE;
	m_amount		= 0;
	m_scheduleColor = 0;
	prevrow			= -1;
	prevcol			= -1;	
	m_starthour		= 0;
	m_startminute	= 0;
	m_endhour		= 0;
	m_endminute		= 0;

	return  TRUE;
}

BOOL clsCell::MakeDisable()
{
	m_amount  = 0;
	m_active = ID_DISABLE;
	m_wo_id =0;
	return TRUE;
}
