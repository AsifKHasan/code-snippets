// ScheduleSet.cpp : implementation file
//

#include "stdafx.h"
#include "Scheduling.h"
#include "ScheduleSet.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CScheduleSet

IMPLEMENT_DYNAMIC(CScheduleSet, CRecordset)

CScheduleSet::CScheduleSet(CDatabase* pdb)
	: CRecordset(pdb)
{
	//{{AFX_FIELD_INIT(CScheduleSet)
	m_batchid = 0;
	m_machineid = 0;
	m_amount = 0.0;
	m_wo_id = 0;
	m_active = 0;
	m_endhour = 0;
	m_endminute = 0;
	m_starthour = 0;
	m_startminute = 0;
	m_comment = _T("");
	m_nFields = 11;
	//}}AFX_FIELD_INIT
	m_nParams = 1;
	m_nDefaultType = dynaset;
}


CString CScheduleSet::GetDefaultConnect()
{
	return _T("");
}

CString CScheduleSet::GetDefaultSQL()
{
	return _T("[Schedule]");
}

void CScheduleSet::DoFieldExchange(CFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(CScheduleSet)
	pFX->SetFieldType(CFieldExchange::outputColumn);
	RFX_Date(pFX, _T("[date]"), m_date);
	RFX_Int(pFX, _T("[batchid]"), m_batchid);
	RFX_Int(pFX, _T("[machineid]"), m_machineid);
	RFX_Double(pFX, _T("[amount]"), m_amount);
	RFX_Long(pFX, _T("[wo_id]"), m_wo_id);
	RFX_Byte(pFX, _T("[Active]"), m_active);
	RFX_Int(pFX, _T("[endhour]"), m_endhour);
	RFX_Int(pFX, _T("[endminute]"), m_endminute);
	RFX_Int(pFX, _T("[starthour]"), m_starthour);
	RFX_Int(pFX, _T("[startminute]"), m_startminute);
	RFX_Text(pFX, _T("[comment]"), m_comment);
	//}}AFX_FIELD_MAP
	pFX->SetFieldType( CFieldExchange::param );
	RFX_Date(pFX, _T("[date]"), m_DateParam);
}

/////////////////////////////////////////////////////////////////////////////
// CScheduleSet diagnostics

#ifdef _DEBUG
void CScheduleSet::AssertValid() const
{
	CRecordset::AssertValid();
}

void CScheduleSet::Dump(CDumpContext& dc) const
{
	CRecordset::Dump(dc);
}
#endif //_DEBUG
