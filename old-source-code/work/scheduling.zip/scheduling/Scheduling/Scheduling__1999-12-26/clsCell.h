#if !defined(AFX_CLSCELL_H__0C0DEAA0_8714_11D2_A9DB_00A024C905B6__INCLUDED_)
#define AFX_CLSCELL_H__0C0DEAA0_8714_11D2_A9DB_00A024C905B6__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// clsCell.h : header file
//


#include "clsOrder.h"


class  clsSolution
{
public :
	int		row;
	int		col;
	double	m_amount;
public:
	void	MakeEmpty();	
};

/////////////////////////////////////////////////////////////////////////////
// clsCell window

class clsCell
{
// Construction
public:
	clsCell();

// Attributes
public:
	COLORREF		m_scheduleColor;
	CString			m_workorder_no;
	CString			m_count_name;
	CString			m_yarn_type;
	CString			m_shade;
	CString			m_client_name;
	int				m_client_id;
	CTime			m_date;
	BYTE			m_empty;
	BYTE			m_active;
	double			m_amount;
	long			m_wo_id;
	int				prevrow;
	int				prevcol;
	int				m_starthour;
	int				m_startminute;
	int				m_endhour;
	int				m_endminute;
	CString			m_comment;



// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(clsCell)
	//}}AFX_VIRTUAL

// Implementation
public:
	BOOL	MakeDisable();
	int		m_machineid;
	int		m_batchid;	
	BOOL	MakeEmpty();
	virtual ~clsCell();

	// Generated message map functions
protected:	
	//{{AFX_MSG(clsCell)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG
	//DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CLSCELL_H__0C0DEAA0_8714_11D2_A9DB_00A024C905B6__INCLUDED_)
