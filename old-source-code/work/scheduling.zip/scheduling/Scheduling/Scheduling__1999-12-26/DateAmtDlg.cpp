// DateAmtDlg.cpp : implementation file
//

#include "stdafx.h"
#include "scheduling.h"
#include "DateAmtDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDateAmtDlg property page

IMPLEMENT_DYNCREATE(CDateAmtDlg, CPropertyPage)

CDateAmtDlg::CDateAmtDlg() : CPropertyPage(CDateAmtDlg::IDD)
{
	//{{AFX_DATA_INIT(CDateAmtDlg)
	m_amount = 0.0;
	m_date = time_t(0);
	m_order = _T("");
	m_spinbuddy = 0;
	//}}AFX_DATA_INIT
}

CDateAmtDlg::~CDateAmtDlg()
{
}

void CDateAmtDlg::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDateAmtDlg)
	DDX_Control(pDX, IDC_SPINDATE, m_spindate);
	DDX_Text(pDX, IDC_AMOUNT, m_amount);
	DDX_Text(pDX, IDC_DATE, m_date);
	DDX_Text(pDX, IDC_ORDER, m_order);
	DDX_Text(pDX, IDC_SPINBUDDY, m_spinbuddy);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDateAmtDlg, CPropertyPage)
	//{{AFX_MSG_MAP(CDateAmtDlg)
	ON_NOTIFY(UDN_DELTAPOS, IDC_SPINDATE, OnDeltaposSpindate)
	ON_EN_CHANGE(IDC_SPINBUDDY, OnChangeSpinbuddy)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDateAmtDlg message handlers

void CDateAmtDlg::OnDeltaposSpindate(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_UPDOWN* pNMUpDown = (NM_UPDOWN*)pNMHDR;
	// TODO: Add your control notification handler code here
	//MessageBox("Here I Am");
	*pResult = 0;
}

BOOL CDateAmtDlg::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();
	
	m_date_start	= m_date;

	m_spindate.SetBase(10);
	m_spindate.SetRange(0, 20);
	m_spindate.SetPos(0);
	m_spindate.SetBuddy(GetDlgItem(IDC_SPINBUDDY));

	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CDateAmtDlg::OnChangeSpinbuddy() 
{
	// TODO: If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CPropertyPage::OnInitDialog()
	// function to send the EM_SETEVENTMASK message to the control
	// with the ENM_CHANGE flag ORed into the lParam mask.
	
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);
	COleDateTimeSpan	cts = COleDateTimeSpan(m_spinbuddy, 0, 0, 0);

	m_date = m_date_start + cts;
	UpdateData(FALSE);
}
