// clsMachine.cpp : implementation file
//

#include "stdafx.h"
#include "Scheduling.h"
#include "clsMachine.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// clsMachine

clsMachine::clsMachine()
{
}

clsMachine::~clsMachine()
{
}


//BEGIN_MESSAGE_MAP(clsMachine, CWnd)
	//{{AFX_MSG_MAP(clsMachine)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
//END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// clsMachine message handlers
