// clsMessage.cpp: implementation of the clsMessage class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Scheduling.h"
#include "clsMessage.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
EMSG	clsMessage::err_Messages[] = 
{
	{	
		SCH_ERR_NO_MSG,	
		"No Error Messsage Defined for This Error. ",
		FALSE,
		MB_OK
	},
	{	
		SCH_ERR_CONNECT_FAILED,	
		"Database Connection Failed. ", 
		FALSE,
		MB_OK
	},
	{	
		SCH_ERR_ORDER_LOAD_FAILED,	
		"Retrieval of Orders Failed. ", 
		FALSE,
		MB_OK
	},
	{	
		SCH_ERR_MACHINE_LOAD_FAILED,	
		"Retrieval of Machine Spec Failed. ", 
		FALSE,
		MB_OK
	},
	{	
		SCH_ERR_SOLUTION_LOAD_FAILED,	
		"Retrieval of Saved Solutions Failed. ", 
		FALSE,
		MB_OK
	},
	{
		SCH_ERR_NO_OPTIMAL_SOLUTION,
		"No Optimal Solution Was Found. ", 
		TRUE,
		MB_OK
	},
	{
		SCH_ERR_ROLLBACK,
		"Rollback.....", 
		FALSE,
		MB_OK
	},
	{
		SCH_ERR_DATABASE,
		"Database Update Failed", 
		FALSE,
		MB_OK
	},
	{
		SCH_ERR_LEFTOVER_SMALL,
		"Left Over Amount Is Too Small to Schedule In This Machine.", 
		FALSE,
		MB_OK
	},
	{
		SCH_ERR_QTY_EXCEED,
		"Sorry, Amount Specified Excceeds Order Quantity. Try Force Mode.", 
		FALSE,
		MB_OK
	},
	{
		SCH_ERR_RANGE_EXCEED,
		"Sorry, Amount Has Exceeded Machine Range. ", 
		FALSE,
		MB_OK
	},
	{
		SCH_ERR_ORDER_SCHEDULED,
		"The Order Has Already Been Scheduled. Try Force Mode to Schedule in Excess.", 
		TRUE,
		MB_OK
	},
	{
		SCH_ERR_DELETE_CELL,
		"Are You Sure to Delete The Schedule? ", 
		TRUE,
		MB_YESNO
	},
	{
		SCH_ERR_DELETE_BATCH,
		"Are You Sure to Delete The Batch? ", 
		TRUE,
		MB_YESNO
	},
	{
		SCH_ERR_UNSCHEDULE,
		"Are You Sure to Delete All The Schedules For This Order? ", 
		TRUE,
		MB_YESNO
	},
	{
		SCH_ERR_NO_TRANSITION1,
		"It Is Not Possible to Mark a Schedule Processed Directly. ", 
		FALSE,
		MB_OK
	},
	{
		SCH_ERR_NO_TRANSITION2,
		"It Is Not Possible to Mark a Schedule Scheduled After It Is Processed Directly. ",
		FALSE,
		MB_OK
	},
	{
		SCH_ERR_SCH_TO_INP,
		"You Are Marking a Schedule In Process. Are You Sure? ", 
		TRUE,
		MB_YESNO
	},
	{
		SCH_ERR_INP_TO_SCH,
		"You Are Marking a Previously In Process Schedule To Be Scheduled. Are You Sure? ", 
		TRUE,
		MB_YESNO
	},
	{
		SCH_ERR_INP_TO_PRO,
		"You Are Marking an In Process Schedule To Be Processed. Are You Sure? ", 
		TRUE,
		MB_YESNO
	},
	{
		SCH_ERR_PRO_TO_INP,
		"You Are Marking a Previously Processed Schedule To Be In Process. Are You Sure? ", 
		TRUE,
		MB_YESNO
	},
	{
		SCH_ERR_DELETE_INP,
		"You Can Not Delete a Schedule When It Is In Process. ", 
		TRUE,
		MB_OK
	},
	{
		SCH_ERR_DELETE_PRO,
		"You Can Not Delete a Schedule When It Is Processed. ", 
		TRUE,
		MB_OK
	},
	{
		SCH_ERR_ORDER_MISS,
		"Corresponding Order Was Not Found. The Order May Have Been Processed. ", 
		TRUE,
		MB_OK
	},
	{
		SCH_ERR_ORDER_COMPLETED,
		"This Order Has Already Been Dye Completed. ", 
		TRUE,
		MB_OK
	},
	{
		SCH_ERR_PREV_UNPROCESSED,
		"There Are Unprocessed Schedules in Any Earlier Day. Try Force Mode.", 
		FALSE,
		MB_OK
	},
	{
		SCH_ERR_ORDER_NO_LEFT,
		"There Are Left Over Amount Remaining for This Order. You Can Not Change The Status. ", 
		FALSE,
		MB_OK
	},
	{
		SCH_ERR_ORDER_SCH_UNP,
		"There Are Unprocessed Schedules for This Order. You Can Not Change The Status. ", 
		FALSE,
		MB_OK
	}
};

clsMessage::clsMessage()
{

}

clsMessage::~clsMessage()
{

}

int clsMessage::raise_Error(int e_num)
{
	int		index;
	CString	str;

	index	= find_Error(e_num);
	str		= err_Messages[index].err_String;
	if( (err_Messages[index].err_Maskable == TRUE) &&
		(m_Confirm == FALSE))
	{
		if(err_Messages[index].err_Format == MB_YESNO)
		{
			return IDYES;
		}
		else
		{
			return MB_OK;
		}
	}
	else
	{
		if(err_Messages[index].err_Format == MB_YESNO)
		{
			return AfxMessageBox(str, MB_YESNO);
		}
		else
		{
			return AfxMessageBox(str);
		}
	}
}

int clsMessage::raise_Error(int e_num, CString cs)
{
	int		index;
	CString	str;

	index	= find_Error(e_num);
	str		= err_Messages[index].err_String;
	if(!cs.IsEmpty())
	{
		str	+= cs;
	}
	if( (err_Messages[index].err_Maskable == TRUE) &&
		(m_Confirm == FALSE))
	{
		if(err_Messages[index].err_Format == MB_YESNO)
		{
			return IDYES;
		}
		else
		{
			return MB_OK;
		}
	}	
	else
	{
		if(err_Messages[index].err_Format == MB_YESNO)
		{
			return AfxMessageBox(str, MB_YESNO);
		}
		else
		{
			return AfxMessageBox(str);
		}
	}
}

int clsMessage::find_Error(int e_num)
{
	int		index;

	for( index = 1; ; index++)
	{
		if( err_Messages[index].err_Number == e_num)
		{
			return index;
		}
		else if(err_Messages[index].err_Number > e_num)
		{
			return	0; 
		}
	}
}

void clsMessage::SetConfirmation(BOOL bVal)
{
	m_Confirm = bVal;
}
