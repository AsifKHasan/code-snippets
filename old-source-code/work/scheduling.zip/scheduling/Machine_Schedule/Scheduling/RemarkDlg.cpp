// RemarkDlg.cpp : implementation file
//

#include "stdafx.h"
#include "scheduling.h"
#include "RemarkDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CRemarkDlg property page

IMPLEMENT_DYNCREATE(CRemarkDlg, CPropertyPage)

CRemarkDlg::CRemarkDlg() : CPropertyPage(CRemarkDlg::IDD)
{
	//{{AFX_DATA_INIT(CRemarkDlg)
	m_remark = _T("");
	//}}AFX_DATA_INIT
}

CRemarkDlg::~CRemarkDlg()
{
}

void CRemarkDlg::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CRemarkDlg)
	DDX_Text(pDX, IDC_REMARK, m_remark);
	DDV_MaxChars(pDX, m_remark, 100);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CRemarkDlg, CPropertyPage)
	//{{AFX_MSG_MAP(CRemarkDlg)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CRemarkDlg message handlers
