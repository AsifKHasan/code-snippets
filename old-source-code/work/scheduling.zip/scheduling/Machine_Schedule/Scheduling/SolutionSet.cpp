// SolutionSet.cpp: implementation of the CSolutionSet class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Scheduling.h"
#include "SolutionSet.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CSolutionSet::CSolutionSet()
{
	m_cursol = -1;
}

CSolutionSet::CSolutionSet(CSolutionSet& css)
{
	m_amount  = css.m_amount;
	m_cursol  = -1;
}

CSolutionSet::~CSolutionSet()
{

}

CSolutionSet &CSolutionSet::operator=( CSolutionSet &css )
{
	m_amount	= css.m_amount;
	m_cursol	= css.m_cursol;

    return *this;  
}

int CSolutionSet::AddSolution()
{
	CSolution	cs;

	if(m_cursol != -1)
	{
		cs = m_solution[m_cursol];
	}
	m_solution.Add(cs);
	m_cursol++;

	return 1;
}

int CSolutionSet::DelSolution()
{
	int	to_del = m_solution.GetSize();

	if(to_del > 0 )
	{
		m_solution.RemoveAt(to_del - 1);
		m_cursol--;
	}

	return 1;
}

BOOL CSolutionSet::IsSimilar(int index)
{
	int		i;

	for( i = 0 ; i < index ; i++)
	{
		if(m_solution[i] == m_solution[index])
		{
			return TRUE;
		}
	}
	return FALSE;
}

BOOL CSolutionSet::AdjustSubset(int index)
{
	if(index <= 0 || index > m_cursol)
	{
		return FALSE;
	}

	int		minpair, to_keep, i, j;
	BOOL	adjustable = FALSE;

	for( i = 0 ; i < index ; i++)
	{
		if(m_solution[i].m_pair.GetSize() > m_solution[index].m_pair.GetSize())
		{
			minpair = m_solution[index].m_pair.GetSize();
			to_keep = index;
		}
		else
		{
			minpair = m_solution[i].m_pair.GetSize();
			to_keep = i;
		}
		
		for(j = 0 ; j < minpair ; j++)
		{
			if(m_solution[i].m_pair[j].m_mid != m_solution[index].m_pair[j].m_mid)
			{
				adjustable = FALSE;
				break;
			}
			else
			{
				adjustable = TRUE;
			}
		}

		if(adjustable == TRUE)
		{
			if( i != to_keep)
			{
				m_solution[i] = m_solution[to_keep];
			}
			break;
		}
	}
	return adjustable;
}

int CSolutionSet::MergeSolution(CSolutionSet &css)
{
	int			i, j, index, step1, step2;
	CSolution	cs;

	if(m_solution.GetSize() == 0)
	{
		for(i = 0; i < css.m_solution.GetSize() ; i++)
		{
			index = i;
			m_solution.SetAtGrow(index, css.m_solution[i]);
		}
	}
	else
	{
		step1	= m_solution.GetSize();
		step2	= css.m_solution.GetSize();

		for(i = 0; i < step1 ; i++)
		{
			for(j = 0; j < step2 ; j++)
			{
				index = i * step2 + j;
				//cs	= cs1 + 
				//int len = cs.m_pair.GetSize();
				m_solution.SetAtGrow(index, m_solution[i]);
			}
		}

		for(i = 0; i < step1 ; i++)
		{
			for(j = 0; j < step2 ; j++)
			{
				index = i * step2 + j;

				int len = m_solution[index].m_pair.GetSize();
				len = css.m_solution[j].m_pair.GetSize();

				cs = m_solution[index] + css.m_solution[j];
				len = cs.m_pair.GetSize();

				m_solution[index] = cs;
				
				len = m_solution[index].m_pair.GetSize();
			}
		}
	}
	return 1;
}

double CSolutionSet::AmountMismatch(int sid)
{
	double	samount = 0.0;
	int		i;

	for(i = 0 ; i < m_solution[sid].m_pair.GetSize() ; i++)
	{
		samount += m_solution[sid].m_pair[i].m_amount;
	}
	return (samount - m_amount);
}

int CSolutionSet::GetSolutionCount()
{
	return m_solution.GetSize();
}
