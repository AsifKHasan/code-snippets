#if !defined(AFX_CLSMAIN_H__44D5EF42_8327_11D2_A9DB_00A024C905B6__INCLUDED_)
#define AFX_CLSMAIN_H__44D5EF42_8327_11D2_A9DB_00A024C905B6__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// clsMain.h : header file
//

#define WM_MESSAGE_TO_DLG		WM_USER+1

#define WM_REFRESH_GRID			100
#define WM_REFRESH_SBAR			101

#define IDD_ADD		1
#define IDD_EDIT	2
#define IDD_DELETE	3


#include <afxtempl.h>
#include <afxcmn.h>
#include "OrderSet.h"
#include "MachinesSet.h"
#include "UniqueFID.h"
#include "DyelineSet.h"
#include "clsOrder.h"
#include "clsSelOrder.h"
#include "clsCell.h"
#include "DScheduleSet.h"
#include "SelOrderSet.h"
#include "Order_Stat.h"
#include "clsMachine.h"
#include "clsMessage.h"
#include "AllowRange.h"
#include "SolutionSet.h"
#include "ChangedCells.h"


/////////////////////////////////////////////////////////////////////////////
// clsMain window

typedef struct
{
	int		red;
	int		green;
	int		blue;
}	RGBColors;


class clsMain
{
// Construction
public:
//	friend	class					CDateAmtDlg;
	clsMain();
	clsMessage								cmsg;
	CArray<int, int>						o_array;
	CArray<int, int>						m_tempallowed;
	long									MCount;
	CTime									m_first_date;
	CArray< clsMachine, clsMachine>			MachineArray;
	CChangedCells							m_changedcells;

protected:
	CArray<clsCell, clsCell>				table;	
	CArray<clsOrder, clsOrder>				OrderArray;
	CArray<clsSelOrder, clsSelOrder>		SelOrderArray;
	CArray<clsSolution, clsSolution>		IndexArray;
	CDatabase								m_Database;
	long									OrderCount;	
	long									SelOrderCount;	
	int										m_nBatch;

	int										m_curset;
	CArray<CAllowRange,CAllowRange>			m_allowrange;
	CArray<CSolutionSet, CSolutionSet>		m_solutionset;
	CSolutionSet							m_finalsolution;

public:		
	double GetMachineIncrement(int mid);
	int			InMachineRange(int mid, double amount);
	long		m_mswitch;
	long		m_curply;
	int			GetOrderFirstMachine(long oindex);
	int			GetOrderNextMachine(long oindex, int mid);
	int			GetOrderLastMachine(long oindex);
	int			AddOrderAllowRangeMachine(long oindex, int mid);
	int			GetOrderAllowRangeMachine(long oindex, int index);
	int			GetOrderAllowRangeSize(long oindex);
	int			EmptyOrderAllowRange(long oindex);
	BOOL		IsMachineInOrderRange(int mid, long oindex);
	int			SetOrderAllowRange(long oindex);
	double		GetOrderQuantity(long oindex);
	int			SetOrderLeftover(long oindex, double leftover);
	int			UnionSolutions();
	long		GetChangedCellSize();
	int			ShowChangedCells();
	int			InitChangedCells();
	int			GetRowsInSolution(int* n_firstrow, int* n_lastrow);
	int			GetMachineInSolution(long solid, int* n_machines, double* avg_batches);
	double		WeighSolution(long solid);
	double		GetMachineMinCapacity(int mid);
	double		GetMachineMaxCapacity(int mid);
	
	int			AddSolutionSet(long oindex);
	int			Distribute(long oindex, double amount, int mid, int level, double thold, int count);
	int			Allocate(long oindex, double amount, int mid, int level, double thold);
	void		Compute(long oindex);

	int			GetSolutionCount();
	BOOL		DiscardSolution();
	BOOL		SaveSolution();

	BOOL		FindFreeCell(int mid, int srow, int erow, int* row, int* col);
	int			GetStartRow(CTime ct);
	int			ApplySolution(int sid);
	void		ResetSolutionSet();
	BOOL		IsMachineInRange(int mid, int range);
	int			GetAllowRange(double amount);
	int			InitAllowRanges();
	void		NotifyDialog(UINT msg);
	
	BOOL		SetCellRefresh(int row, int col, BOOL mode);
	BOOL		CellRefresh(int row, int col);
	CString		GetOrderClient(long index);
	void		InitialiseTable(int row, int col, double amt, long OrderIndex);
	void		GetTableTime(int row, int col, int* shour, int* smin, int* ehour, int* emin);
	BOOL		AdjustOrders();
	BOOL		UpdateOrder(long OrderIndex, int UpdateType);
	BOOL		UpdateSelOrder(long OrderIndex, int UpdateType);
	int			GetnBatch(void);	
	void		SetLoadProcessed(BOOL bVal);
	void		SetWorkorderStatus(long index, int Status);
	int			GetWorkorderStatus(long index);
	int			SetOrderMaxsol(long oindex, int maxsol);
	int			GetOrderMaxsol(long oindex);
	CTime		GetStartDate();

	BOOL		m_savepending;
	HWND		m_hWndDlg;
	CString		m_logmessage;
	CTime		m_StartDate;
	RGBColors	ordercolors[55];
	BOOL		m_Connected;
	BOOL		m_LoadProcessed;

	virtual		~clsMain();

	virtual		BOOL Connect(int pDays);	
	BOOL		IsConnected();
	BOOL		IsTableCellActive(int row, int col);
	BOOL		IsTableCellEmpty(int row, int col);
	BOOL		UpdateDatabase(int row, int col, int UpdateType, BOOL OrderUpdate, long OrderIndex);
	BOOL		EnableMachine(int col);
	BOOL		DisableMachine(int col);
	BOOL		MachineEnabled(int col);
	BOOL		EnableCell(int row, int col);
	void		EnableTempDisableCell(int row, int col);
	void		TempDisableCell(int row, int col);
	BOOL		DisableCell(int row, int col, CTime pDate);
	clsCell		GetTableCell(int row, int col);
	BOOL		CellDragDrop(int SrcRow, int SrcCol, int DesRow, int DesCol, CTime pDate, int pDays);

	clsOrder	GetOrder(long OrderIndex);
	CString		GetWorkOrderNo(long Index);
	long		GetWorkOrderID(long Index);
	CString		GetWorkOrderShade(long Index);
	CString		GetWorkOrderCount(long Index);
	CString		GetWorkOrderType(long Index);
	CTime		GetOrderScheduleTime(long Index);
	int			GetWorkOrderCountID(long Index);
	int			GetWorkOrderYarnID(long Index);
	int			GetOrderCount();
	long		GetSelOrderNo(long index);
	int			GetSelOrderCount();
	CTime		GetMaxDate();
	double		GetTableAmount(int row, int col);
	double		GetOrderLeftover(long Index);
	double		GetOrderScamount(long Index);
	int			SetOrderScamount(long Index, double scamount);

	double		GetMachineCapacity(int mid);
	double		GetMachineLiquor(int mid);
	long		GetMachineCount();	
	CString		GetMachineName(int mid);
	int			GetMachineIndex(int midx);
	int			GetMachineStatus(int mid);

	int			GetTableStatus(int row, int col);
	void		SetTableStatus(int row, int col, int stat, CTime pDate, int starthour, int startminute, int endhour, int endminute, BOOL f_mode);
	void		SetOrderStatus(int index, int Status, BOOL force);
	int			SetOrderScheduleTime(long Index, CTime ct);

	BOOL		DropOneBatch(CTime pStartDate, int row, int col, BOOL DropType);
	BOOL		DropOneDate(CTime pDate, int col, int DropType);
	int			Delete(int row, int col, BOOL rdl);

	BOOL		Unschedule(long OrderIndex, int pdays);
	BOOL		Schedule(long index);

	BOOL		LoadOrder();
	BOOL		LoadSelOrder();
	BOOL		LoadMachine();
	void		LoadSchedule(CTime pStartDate, int pDays);

	long		FindOrderIndex(int row, int col);
	int			EditAmount(int row, int col, long OrderIndex, double NewAmount, BOOL f_mode);

	// flag 0 indicates that the index is the orderarray order index and 1 means it is the list index
	int			GridMouseUp(int row, int col, long DragItemIndex, CTime pDate, int pDays, int flag);

	int			SetTableAmount(int row, int col, double pAmount);
	int			SetTableRemark(int row, int col, CString& remark);
	void		SetConfirmation(BOOL bVal);
	long		GetUnique_Dyeline_ID();
	CString		GetNumBatches(long wo_id, int machine_id, CTime mdate, int mbatch);
	int			ProcessDyeline(int row, int col);
	int			RemoveDyeline(int row, int col, BOOL ud);
	long		GetDyelineID(int row, int col);
	int			AdjustDyeline(int row, int col, long dyeline_id);
	CString		GetDyeingShift(int sh, int sm, int eh, int em);
	BOOL		PopulateDyelineHeads(long dyeline_id);


protected:
	//{{AFX_MSG(clsMain)
	void AddIndexRow(int Count);
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG
//	DECLARE_MESSAGE_MAP()
private:
	int TotalDays;
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CLSMAIN_H__44D5EF42_8327_11D2_A9DB_00A024C905B6__INCLUDED_)
