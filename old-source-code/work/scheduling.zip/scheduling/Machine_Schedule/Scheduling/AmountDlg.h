#if !defined(AFX_AMOUNTDLG_H__17147AC2_9D23_11D2_8C57_BA8901510729__INCLUDED_)
#define AFX_AMOUNTDLG_H__17147AC2_9D23_11D2_8C57_BA8901510729__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// AmountDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CAmountDlg dialog

class CAmountDlg : public CPropertyPage
{
	DECLARE_DYNCREATE(CAmountDlg)

// Construction
public:
	CAmountDlg();
	~CAmountDlg();

// Dialog Data
	//{{AFX_DATA(CAmountDlg)
	enum { IDD = IDD_ADD_EDIT };
	CSpinButtonCtrl	m_spinendmin;
	CSpinButtonCtrl	m_spinstartmin;
	CSpinButtonCtrl	m_spinendhour;
	CSpinButtonCtrl	m_spinstarthour;
	double	m_amount;
	int		m_stat;
	int		m_sval;
	int		m_editstarthour;
	int		m_editendhour;
	int		m_editstartmin;
	int		m_editendmin;
	BOOL	m_cancel;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CAmountDlg)
	public:
	virtual int DoModal();
	virtual void OnOK();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CAmountDlg)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_AMOUNTDLG_H__17147AC2_9D23_11D2_8C57_BA8901510729__INCLUDED_)
