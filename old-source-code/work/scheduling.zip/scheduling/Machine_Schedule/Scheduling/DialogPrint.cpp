// DialogPrint.cpp : implementation file
//

#include "stdafx.h"
#include "scheduling.h"
#include "DialogPrint.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDialogPrint dialog


CDialogPrint::CDialogPrint(CWnd* pParent /*=NULL*/)
	: CDialog(CDialogPrint::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDialogPrint)
	m_sto = _T("");
	m_dfrom = time_t(0);
	m_dto = time_t(0);
	m_tobuddy = 0;
	m_frombuddy = 0;
	//}}AFX_DATA_INIT
}


void CDialogPrint::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDialogPrint)
	DDX_Control(pDX, IDC_SPINFROM, m_spinfrom);
	DDX_Control(pDX, IDC_SPINTO, m_spinto);
	DDX_Text(pDX, IDC_STO, m_sto);
	DDX_Text(pDX, IDC_DFROM, m_dfrom);
	DDX_Text(pDX, IDC_DTO, m_dto);
	DDX_Text(pDX, IDC_TOBUDDY, m_tobuddy);
	DDX_Text(pDX, IDC_FROMBUDDY, m_frombuddy);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDialogPrint, CDialog)
	//{{AFX_MSG_MAP(CDialogPrint)
	ON_EN_CHANGE(IDC_FROMBUDDY, OnChangeFrombuddy)
	ON_EN_CHANGE(IDC_TOBUDDY, OnChangeTobuddy)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDialogPrint message handlers

BOOL CDialogPrint::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	m_spinfrom.SetBase(10);
	m_spinfrom.SetRange(0, 20);
	m_spinfrom.SetPos(0);
	m_spinfrom.SetBuddy(GetDlgItem(IDC_FROMBUDDY));
	
	m_spinto.SetBase(10);
	m_spinto.SetRange(0, 20);
	m_spinto.SetPos(0);
	m_spinto.SetBuddy(GetDlgItem(IDC_TOBUDDY));

	o_dfrom	= m_dfrom;
	o_dto	= m_dto;

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CDialogPrint::OnChangeFrombuddy() 
{
	// TODO: If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CDialog::OnInitDialog()
	// function to send the EM_SETEVENTMASK message to the control
	// with the ENM_CHANGE flag ORed into the lParam mask.
	
	// TODO: Add your control notification handler code here
	COleDateTimeSpan	cts;

	UpdateData(TRUE);

	cts = COleDateTimeSpan(m_frombuddy, 0, 0, 0);
	m_dfrom.SetDate( o_dfrom.GetYear(), o_dfrom.GetMonth(), o_dfrom.GetDay());
	m_dfrom	+= cts;

	UpdateData(FALSE);
}

void CDialogPrint::OnChangeTobuddy() 
{
	// TODO: If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CDialog::OnInitDialog()
	// function to send the EM_SETEVENTMASK message to the control
	// with the ENM_CHANGE flag ORed into the lParam mask.
	
	// TODO: Add your control notification handler code here
	COleDateTimeSpan	cts;

	UpdateData(TRUE);

	cts = COleDateTimeSpan(m_tobuddy, 0, 0, 0);
	m_dto.SetDate( o_dto.GetYear(), o_dto.GetMonth(), o_dto.GetDay());
	m_dto	+= cts;

	UpdateData(FALSE);
}
