// Solution.cpp: implementation of the CSolution class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Scheduling.h"
#include "Solution.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CSolution::CSolution()
{
	m_curpair = -1;
}

CSolution::CSolution(CSolution& cs)
{
	int		i;
	CPair	cp;

	m_sid		= cs.m_sid + 1;
	m_curpair	= cs.m_curpair;

	for( i = 0 ; i < cs.m_pair.GetSize() ; i++)
	{
		cp = cs.m_pair[i];
		m_pair.Add(cp);
	}

}

CSolution::~CSolution()
{

}

CSolution &CSolution::operator=( CSolution &cs )
{
	CPair	cp;
	int		i;

    m_sid		= cs.m_sid;
    m_curpair	= cs.m_curpair;
	m_pair.RemoveAll();

	for( i = 0 ; i < cs.m_pair.GetSize() ; i++)
	{
		cp = cs.m_pair[i];
		m_pair.Add(cp);
	}

    return *this;  
}

CSolution &CSolution::operator+( CSolution &cs )
{
	CPair	cp;
	int		i;
	int		rpos = 0;

	for(i = 0 ; i < cs.m_pair.GetSize() ; i++)
	{
		rpos = MergePair(rpos, cs.m_pair[i]);
	}

    return *this;  
}

BOOL CSolution::operator==( CSolution &cs )
{
	BOOL	similar = TRUE;

	if( m_pair.GetSize() != cs.m_pair.GetSize())
	{
		return FALSE;
	}

	int		i;

	for( i = 0 ; i < cs.m_pair.GetSize() ; i++)
	{
		if(m_pair[i].m_mid != cs.m_pair[i].m_mid)
		{
			similar = FALSE;
			break;
		}
	}
    return similar;  
}

int CSolution::AddPair(int index, CPair cp)
{
	int		i;

	for(i = m_pair.GetSize() - 1 ; i <= index ; i++)
	{
		m_pair.Add(CPair());
	}
	m_pair.SetAt(index, cp);

	for(i = index + 1 ; i < m_pair.GetSize() ; i++)
	{
		m_pair.RemoveAt(i);
	}
	m_curpair = index;
	return -1;
}

int CSolution::MergePair(int startp, CPair cp)
{
	int		position = m_pair.GetSize();
	int		i;
	int		m1, m2;

	// find the position to insert
	for( i = startp ; i < position ; i++)
	{
		m1 = m_pair[i].m_mid;
		m2 = cp.m_mid;
		if(m_pair[i].m_mid > cp.m_mid)
		{
			position = i;
			break;
		}
	}
	
	// insert at the position
	m_pair.Add(cp);
	for( i = m_pair.GetSize() - 1 ; i > position ; i--)
	{
		m_pair[i] = m_pair[i-1];
	}
	m_pair[position] = cp;
	return position;
}

int CSolution::GetMachineStat(int *n_machines, double *std_dev)
{
	CArray<int, int>	mlist;
	CArray<int, int>	mnum;
	int		i, cmachine, tcount, count;

	if((tcount = m_pair.GetSize()) == 0)
	{
		*n_machines = 0;
		*std_dev	= 0.0;
		return -1;
	}

	cmachine	= m_pair[0].m_mid;
	count		= 1;
	for(i = 1 ; i < tcount ; i++)
	{
		if(m_pair[i].m_mid != cmachine)
		{
			mlist.Add(cmachine);
			mnum.Add(count);
			cmachine = m_pair[i].m_mid;
			count = 1;
		}
		else
		{
			count++;
		}
	}
	mlist.Add(cmachine);
	mnum.Add(count);

	*n_machines = mlist.GetSize();

	double mean = 0;

	for(i = 0 ; i < *n_machines ; i++)
	{
		mean += mnum[i];
	}

	mean = mean / *n_machines;

	double sqr = 0;

	for( i = 0 ; i < *n_machines ; i++)
	{
		sqr += ((mnum[i] - mean) * (mnum[i] - mean));
	}

	*std_dev = sqr / *n_machines;
	return 1;
}
