#if !defined(AFX_DATEAMTDLG_H__84590F80_9FE6_11D3_9BAD_00C0DFEC3C16__INCLUDED_)
#define AFX_DATEAMTDLG_H__84590F80_9FE6_11D3_9BAD_00C0DFEC3C16__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// DateAmtDlg.h : header file
//

//#include "ListColumn.h"
#include <afxtempl.h>
#include "MachineList.h"	// Added by ClassView

/////////////////////////////////////////////////////////////////////////////
// CDateAmtDlg dialog

#define	M_CHECKED		1
#define	M_UNCHECKED		0

//class clsMain;

class CDateAmtDlg : public CPropertyPage
{
	DECLARE_DYNCREATE(CDateAmtDlg)

// Construction
public:
	int AddNewMachine(CString machine, BOOL selected);
	CDateAmtDlg();
	~CDateAmtDlg();
	CArray<CMachineList, CMachineList>	m_maclist;
// Dialog Data
	//{{AFX_DATA(CDateAmtDlg)
	enum { IDD = IDD_DATEAMT };
	CCheckListBox	m_clist;
	CSpinButtonCtrl	m_spindate;
	double	m_amount;
	COleDateTime	m_date;
	COleDateTime	m_date_start;
	CString	m_order;
	int		m_spinbuddy;
	UINT	m_maxsol;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CDateAmtDlg)
	public:
	virtual void OnOK();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CDateAmtDlg)
	afx_msg void OnDeltaposSpindate(NMHDR* pNMHDR, LRESULT* pResult);
	virtual BOOL OnInitDialog();
	afx_msg void OnChangeSpinbuddy();
	afx_msg void OnSelect();
	afx_msg void OnUnselect();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DATEAMTDLG_H__84590F80_9FE6_11D3_9BAD_00C0DFEC3C16__INCLUDED_)
