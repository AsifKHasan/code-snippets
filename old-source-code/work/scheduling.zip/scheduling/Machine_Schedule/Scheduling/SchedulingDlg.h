// DialogDlg.h : header file
//
//{{AFX_INCLUDES()
#include "msflexgrid.h"
#include "calendar.h"
#include "excel8.h"
//}}AFX_INCLUDES

#if !defined(AFX_DIALOGDLG_H__FBB088FF_80CC_11D2_A9DB_00A024C905B6__INCLUDED_)
#define AFX_DIALOGDLG_H__FBB088FF_80CC_11D2_A9DB_00A024C905B6__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000


#include "clsMain.h"

/////////////////////////////////////////////////////////////////////////////
// CDialogDlg dialog


#define	SCR_SIZE_X		800
#define	SCR_SIZE_Y		600

#define	SBAR_TOP_Y		  0
#define	SBAR_BOT_Y		 15
#define	SBAR_LFT_X		  5
#define	SBAR_RGT_X		795

#define	CAL1_TOP_Y		  5
#define	CAL1_BOT_Y		179
#define	CAL1_LFT_X		  5
#define	CAL1_RGT_X		199

#define	LIST1_TOP_Y		  5
#define	LIST1_BOT_Y		179
#define	LIST1_LFT_X		  5
#define	LIST1_RGT_X		795

#define	LIST2_TOP_Y		  5
#define	LIST2_BOT_Y		179
#define	LIST2_LFT_X		200
#define	LIST2_RGT_X		795

#define	LIST3_TOP_Y		 30
#define	LIST3_BOT_Y		179
#define	LIST3_LFT_X		  5
#define	LIST3_RGT_X		795

#define	LIST4_TOP_Y		 30
#define	LIST4_BOT_Y		179
#define	LIST4_LFT_X		200
#define	LIST4_RGT_X		795

#define	GRID1_TOP_Y		181
#define	GRID1_BOT_Y		518
#define	GRID1_LFT_X		  5
#define	GRID1_RGT_X		795

#define SEARCH_SHIFT	195

typedef struct
{
	CString	m_client;
	CString	m_count;
	COleDateTime	m_ddate;
	CString	m_order;
	CString	m_shade;
}	SearchStruct;

class CDialogDlg : public CDialog
{

protected:
	double	MaxQuantity;
	long	m_editindex;

public :

	// Excel Specific
	_Application	m_Excel;
	_Workbook		m_WorkBook;
	_Worksheet		m_WorkSheet;
	Workbooks		m_WorkBooks;
	Worksheets		m_WorkSheets;
	Font			m_font;
	Range			m_range;
	Border			m_Border;
	Interior		m_Interior;

	CArray<SearchStruct, SearchStruct>	SArray;
	clsMain		MainObject;
	CImageList*	m_SmallImageList;
	CImageList*	m_StateImageList;
	CStatusBarCtrl  m_wndStatusBarCtrl;
	BOOL		DragStart;
	BOOL		CellDragStart;
	BOOL		ValidDrag;
	BOOL		m_AutoSchedule;
	BOOL		m_Confirm;
	BOOL		m_Forcemode;
	BOOL		m_Datemode;
	BOOL		m_Selgroup;
	BOOL		m_Keepselection;
	BOOL		m_Calshow;
	BOOL		m_LoadProcessed;
	BOOL		m_SearchMode;
	BOOL		m_ListInitialized;
	BOOL		m_changed;
	BOOL		m_ExcelStarted;
	CRect		search_cr[12];
	int			DragRow;
	int			DragCol;
	long		DragItemIndex;
	CString		o_client;
	CString		o_order;
	CString		o_shade;
	CString		o_count;
	CTime		m_saveddate;
	int			m_filled_order;
public:
	int		RefreshOrderList();
	int		CreateCellGrid();
	int		CreateCalendar();
	int		CreateOrderList();
	int		CreateStatusBar();
	void	ProcessNotification(UINT msg);
	int		ShowDateAmtDialog(int o_index);
	BOOL	BrowseSolution();
	void	FillExcelSheet(COleDateTime d_from, COleDateTime d_to);
	BOOL	CloseExcel();
	BOOL	OpenExcel();
	void	SetDate(CTime ct);
	BOOL	GetConfirmation();
	
	CDialogDlg(CWnd* pParent = NULL);	// standard constructor
	
// Dialog Dat
	//{{AFX_DATA(CDialogDlg)
	enum { IDD = IDD_DIALOG_DIALOG };
	CButton	m_apply;
	CSpinButtonCtrl	m_spinddate;
	CListCtrl	m_ListCtrl;
	CMSFlexGrid	m_gOutput;	
	int			m_NoOfDays;
	CCalendar	m_Calendar;
	CString	m_client;
	CString	m_shade;
	CString	m_order;
	CString	m_count;
	COleDateTime	m_ddate;
	COleDateTime	o_ddate;
	int		m_spinbuddy;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDialogDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	BOOL	IsOrderUnderSel(int oc);
	BOOL	IsOrderUnderSearch(int oc);
	BOOL	IsOrderUnderSearch(int oc, BOOL mode);
	void	SetStartDate();
	BOOL	IsMachineDisablable(int row, int col);
	HCURSOR crsr;
	void	InitiateGrid(CTime p_StartDate );
	void	AdjustDate();
	void	AutoSchedule();
	void	PrintLeftOver(int Index);
	void	RefreshGrid(int row, int col);
	void	FillOrderList();
	CTime	GetDate();	
	BOOL	CstrToTime(CString& m_strdate, CTime& ct);
	HICON	m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CDialogDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	virtual void OnCancel();
	afx_msg BOOL OnConnect();
	afx_msg void OnSchedule();	
	afx_msg void OnEdit();
	afx_msg void OnDelete();
	afx_msg void OnContextMenu(CWnd* pWnd, CPoint point);
	afx_msg void OnMouseUpMsflexgrid1(short Button, short Shift, long x, long y);
	afx_msg void OnBegindragList1(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnLoadschedule();
	afx_msg void OnDeletebatch();
	afx_msg void OnDroponedate();
	afx_msg void OnDisablebatch();
	afx_msg void OnEnablecurrcell();
	afx_msg void OnDeleteAll();
	afx_msg void OnDisableMachine();
	afx_msg void OnDroponebatch();
	afx_msg void OnEnableMachine();
	afx_msg void OnSelChangeMsflexgrid1();
	afx_msg void OnAutomatic();
	afx_msg void OnConfirm();
	afx_msg void OnPopupSchedule();
	afx_msg void OnPopupUnschedule();
	afx_msg void OnCalshow();
	afx_msg void OnAboutbox();
	afx_msg void OnOLEStartDragMsflexgrid1(LPDISPATCH FAR* Data, long FAR* AllowedEffects);
	afx_msg void OnMouseMoveMsflexgrid1(short Button, short Shift, long x, long y);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnComplete();
	afx_msg void OnLoadprocessed();
	afx_msg void OnDroponebatchBymachine();
	afx_msg void OnDroponedateBymachine();
	afx_msg void OnSearchmode();
	afx_msg void OnChangeClient();
	afx_msg void OnChangeShade();
	afx_msg void OnKillfocusClient();
	afx_msg void OnKillfocusShade();
	afx_msg void OnDblClickMsflexgrid1();
	afx_msg void OnRemark();
	afx_msg void OnKillfocusOrder();
	afx_msg void OnForcemode();
	afx_msg void OnKillfocusCount();
	afx_msg void OnFindschedule();
	afx_msg void OnFindnext();
	afx_msg void OnFindprev();
	afx_msg void OnFindorder();
	afx_msg void OnSavesearch();
	afx_msg void OnSearchsaved();
	afx_msg void OnChangeSpinbuddy();
	afx_msg void OnApply();
	afx_msg void OnDeletesearch();
	afx_msg void OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	afx_msg void OnSelectgroup();
	afx_msg void OnAddtoselection();
	afx_msg void OnRemovefromselection();
	afx_msg void OnPrintschedule();
	afx_msg void OnDblclkList1(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnGendline();
	afx_msg void OnDeldyeline();
	afx_msg void OnSetfocusDdate();
	DECLARE_EVENTSINK_MAP()
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DIALOGDLG_H__FBB088FF_80CC_11D2_A9DB_00A024C905B6__INCLUDED_)
