#if !defined(AFX_SCHEDULESET_H__644B6D42_CCD9_11D2_A9DC_00A024C905B6__INCLUDED_)
#define AFX_SCHEDULESET_H__644B6D42_CCD9_11D2_A9DC_00A024C905B6__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// ScheduleSet.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CScheduleSet recordset

class CScheduleSet : public CRecordset
{
public:
	CScheduleSet(CDatabase* pDatabase = NULL);
	DECLARE_DYNAMIC(CScheduleSet)

// Field/Param Data
	//{{AFX_FIELD(CScheduleSet, CRecordset)
	CTime	m_date;
	int		m_batchid;
	int		m_machineid;
	double	m_amount;
	long	m_wo_id;
	BYTE	m_active;
	int		m_endhour;
	int		m_endminute;
	int		m_starthour;
	int		m_startminute;
	CString	m_comment;
	long	m_dyeline_id;
	CString	m_ownlink;
	//}}AFX_FIELD
	CTime m_DateParam;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CScheduleSet)
	public:
	virtual CString GetDefaultConnect();    // Default connection string
	virtual CString GetDefaultSQL();    // Default SQL for Recordset
	virtual void DoFieldExchange(CFieldExchange* pFX);  // RFX support
	//}}AFX_VIRTUAL

// Implementation
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SCHEDULESET_H__644B6D42_CCD9_11D2_A9DC_00A024C905B6__INCLUDED_)
