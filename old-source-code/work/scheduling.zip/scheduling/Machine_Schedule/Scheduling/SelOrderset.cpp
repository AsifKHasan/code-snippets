// SelOrderset.cpp : implementation file
//

#include "stdafx.h"
#include "scheduling.h"
#include "SelOrderset.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSelOrderset

IMPLEMENT_DYNAMIC(CSelOrderset, CRecordset)

CSelOrderset::CSelOrderset(CDatabase* pdb)
	: CRecordset(pdb)
{
	//{{AFX_FIELD_INIT(CSelOrderset)
	m_wo_id = 0;
	m_sel_group = _T("");
	m_nFields = 2;
	//}}AFX_FIELD_INIT
	m_nDefaultType = snapshot;
}


CString CSelOrderset::GetDefaultConnect()
{
	return _T("ODBC;DSN=Schedule");
}

CString CSelOrderset::GetDefaultSQL()
{
	return _T("[Order_Sel]");
}

void CSelOrderset::DoFieldExchange(CFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(CSelOrderset)
	pFX->SetFieldType(CFieldExchange::outputColumn);
	RFX_Long(pFX, _T("[wo_id]"), m_wo_id);
	RFX_Text(pFX, _T("[sel_group]"), m_sel_group);
	//}}AFX_FIELD_MAP
}

/////////////////////////////////////////////////////////////////////////////
// CSelOrderset diagnostics

#ifdef _DEBUG
void CSelOrderset::AssertValid() const
{
	CRecordset::AssertValid();
}

void CSelOrderset::Dump(CDumpContext& dc) const
{
	CRecordset::Dump(dc);
}
#endif //_DEBUG
