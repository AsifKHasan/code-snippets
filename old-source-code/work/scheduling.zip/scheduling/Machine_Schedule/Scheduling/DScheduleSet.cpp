// DScheduleSet.cpp : implementation file
//

#include "stdafx.h"
#include "Scheduling.h"
#include "DScheduleSet.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDScheduleSet

IMPLEMENT_DYNAMIC(CDScheduleSet, CRecordset)

CDScheduleSet::CDScheduleSet(CDatabase* pdb)
	: CRecordset(pdb)
{
	//{{AFX_FIELD_INIT(CDScheduleSet)
	m_amount = 0.0;
	m_batchid = 0;
	m_client_name = _T("");
	m_count_name = _T("");
	m_machineid = 0;
	m_shade = _T("");
	m_wo_id = 0;
	m_workorder_no = _T("");
	m_yarn_type = _T("");
	m_active = 0;
	m_endhour = 0;
	m_endminute = 0;
	m_starthour = 0;
	m_startminute = 0;
	m_client_id = 0;
	m_comment = _T("");
	m_dyeline_id = 0;
	m_ownlink = _T("");
	m_nFields = 19;
	//}}AFX_FIELD_INIT
	m_nDefaultType = dynaset;
	m_nParams = 1;
}


CString CDScheduleSet::GetDefaultConnect()
{
	return _T("");
}

CString CDScheduleSet::GetDefaultSQL()
{
	return _T("[DSchedule]");
}

void CDScheduleSet::DoFieldExchange(CFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(CDScheduleSet)
	pFX->SetFieldType(CFieldExchange::outputColumn);
	RFX_Double(pFX, _T("[amount]"), m_amount);
	RFX_Int(pFX, _T("[batchid]"), m_batchid);
	RFX_Text(pFX, _T("[client_name]"), m_client_name);
	RFX_Text(pFX, _T("[count_name]"), m_count_name);
	RFX_Date(pFX, _T("[date]"), m_date);
	RFX_Int(pFX, _T("[machineid]"), m_machineid);
	RFX_Text(pFX, _T("[shade]"), m_shade);
	RFX_Long(pFX, _T("[wo_id]"), m_wo_id);
	RFX_Text(pFX, _T("[workorder_no]"), m_workorder_no);
	RFX_Text(pFX, _T("[yarn_type]"), m_yarn_type);
	RFX_Byte(pFX, _T("[Active]"), m_active);
	RFX_Int(pFX, _T("[endhour]"), m_endhour);
	RFX_Int(pFX, _T("[endminute]"), m_endminute);
	RFX_Int(pFX, _T("[starthour]"), m_starthour);
	RFX_Int(pFX, _T("[startminute]"), m_startminute);
	RFX_Int(pFX, _T("[client_id]"), m_client_id);
	RFX_Text(pFX, _T("[comment]"), m_comment);
	RFX_Long(pFX, _T("[dyeline_id]"), m_dyeline_id);
	RFX_Text(pFX, _T("[ownlink]"), m_ownlink);
	//}}AFX_FIELD_MAP
	pFX->SetFieldType(CFieldExchange::param);
	RFX_Date(pFX, _T("[Date]"), m_DateParam);
}

/////////////////////////////////////////////////////////////////////////////
// CDScheduleSet diagnostics

#ifdef _DEBUG
void CDScheduleSet::AssertValid() const
{
	CRecordset::AssertValid();
}

void CDScheduleSet::Dump(CDumpContext& dc) const
{
	CRecordset::Dump(dc);
}
#endif //_DEBUG
