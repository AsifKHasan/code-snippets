// clsOrder.cpp : implementation file
//

#include "stdafx.h"
#include "Scheduling.h"
#include "clsOrder.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// clsOrder

clsOrder::clsOrder()
{
	m_leftover	= 0;
	m_scamount	= 0;
	m_maxsol	= 5;
	m_scdate	= CTime::GetCurrentTime();
}

clsOrder::clsOrder(clsOrder& co)
{
	*this = co;
}

clsOrder::~clsOrder()
{
}


clsOrder& clsOrder::operator=( clsOrder &co )
{
	orderColor			= co.orderColor;
	m_shade				= co.m_shade;		
	m_count_name		= co.m_count_name;
	m_workorder_no		= co.m_workorder_no;
	m_yarn_type			= co.m_yarn_type;
	m_client_name		= co.m_client_name;
	m_deliverydate		= co.m_deliverydate;
	m_quantity			= co.m_quantity;
	m_leftover			= co.m_leftover;
	m_scamount			= co.m_scamount;
	m_wo_id				= co.m_wo_id;
	m_dyecomplete		= co.m_dyecomplete;
	m_client_id			= co.m_client_id;
	m_count_id			= co.m_count_id;
	m_workorder_type	= co.m_workorder_type;
	m_yarn_type_id		= co.m_yarn_type_id;
	m_allowed.Copy(co.m_allowed);

	return *this;
}

//BEGIN_MESSAGE_MAP(clsOrder, CWnd)
	//{{AFX_MSG_MAP(clsOrder)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
//END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// clsOrder message handlers

double clsOrder::GetLeftover()
{
	return m_leftover;
}

int clsOrder::SetLeftover(double leftover)
{
	m_leftover = leftover;
	return 1;
}

double clsOrder::GetScamount()
{
	return m_scamount;
}

int clsOrder::SetScamount(double scamount)
{
	m_scamount = scamount;
	return 1;
}

int clsOrder::GetMaxsol()
{
	if(m_maxsol > 0 )
	{
		return m_maxsol;
	}
	else
	{
		return 5;
	}
}

int clsOrder::SetMaxsol(int maxsol)
{
	if(maxsol > 0)
	{
		m_maxsol = maxsol;
	}
	else
	{
		m_maxsol = 5;
	}
	return 1;
}

double clsOrder::GetQuantity()
{
	return m_quantity;
}

int clsOrder::EmptyAllowRange()
{
	m_allowed.RemoveAll();
	return 1;
}

int clsOrder::GetAllowRangeSize()
{
	return m_allowed.GetSize();
}

int clsOrder::GetAllowRangeMachine(int index)
{
	if(index < m_allowed.GetSize())
	{
		return m_allowed[index];
	}
	else
	{
		return -1;
	}
}

int clsOrder::AddAllowRangeMachine(int mid)
{
	int		i;
	BOOL	found;

	found = FALSE;
	for(i = 0 ; i < m_allowed.GetSize() ; i++)
	{
		if(m_allowed[i] == mid)
		{
			found = TRUE;
			break;
		}
	}
	if(found == FALSE)
	{
		m_allowed.Add(mid);
	}
	return 1;
}

int clsOrder::GetFirstMachine()
{
	if(m_allowed.GetSize() == 0)
	{
		return -1;
	}
	return m_allowed[0];
}

int clsOrder::GetNextMachine(int mid)
{
	int		i;

	for(i = 0 ; i < m_allowed.GetSize() - 1 ; i++)
	{
		if(m_allowed[i] == mid)
		{
			return m_allowed[i+1];
		}
	}
	return -1;
}

int clsOrder::GetLastMachine()
{
	if(m_allowed.GetSize() == 0)
	{
		return -1;
	}
	return m_allowed[m_allowed.GetSize() - 1];
}
