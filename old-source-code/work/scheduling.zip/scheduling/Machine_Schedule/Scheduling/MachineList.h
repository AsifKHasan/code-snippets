// MachineList.h: interface for the CMachineList class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MACHINELIST_H__372196FD_92D9_11D4_B788_080000000579__INCLUDED_)
#define AFX_MACHINELIST_H__372196FD_92D9_11D4_B788_080000000579__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CMachineList  
{
public:
	BOOL	m_selected;
	CString	m_machinename;
	CMachineList();
	virtual ~CMachineList();

};

#endif // !defined(AFX_MACHINELIST_H__372196FD_92D9_11D4_B788_080000000579__INCLUDED_)
