// clsSelOrder.h: interface for the clsSelOrder class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_CLSSELORDER_H__2856FB21_A51D_11D3_9BAD_00C0DFEC3C16__INCLUDED_)
#define AFX_CLSSELORDER_H__2856FB21_A51D_11D3_9BAD_00C0DFEC3C16__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

class clsSelOrder  
{
public:
	CString m_sel_group;
	long m_wo_id;
	clsSelOrder();
	virtual ~clsSelOrder();

};

#endif // !defined(AFX_CLSSELORDER_H__2856FB21_A51D_11D3_9BAD_00C0DFEC3C16__INCLUDED_)
