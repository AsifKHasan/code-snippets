// Cell.cpp: implementation of the CCell class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "scheduling.h"
#include "Cell.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CCell::CCell()
{

}

CCell::CCell(int row, int col, long oindex, double amount)
{
	m_row = row;
	m_col = col;
	m_oindex = oindex;
	m_amount = amount;
}

CCell::~CCell()
{

}
