// MachinesSet.cpp : implementation file
//

#include "stdafx.h"
#include "Scheduling.h"
#include "MachinesSet.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMachinesSet

IMPLEMENT_DYNAMIC(CMachinesSet, CRecordset)

CMachinesSet::CMachinesSet(CDatabase* pdb)
	: CRecordset(pdb)
{
	//{{AFX_FIELD_INIT(CMachinesSet)
	m_batchcount = 0;
	m_capacity = 0.0;
	m_liquor = 0.0;
	m_machine_id = 0;
	m_machine_name = _T("");
	m_maxcapacity = 0.0;
	m_mincapacity = 0.0;
	m_specification = _T("");
	m_status = 0;
	m_enabled = 0;
	m_nFields = 10;
	//}}AFX_FIELD_INIT
	m_nDefaultType = snapshot;
}


CString CMachinesSet::GetDefaultConnect()
{
	return _T("");
}

CString CMachinesSet::GetDefaultSQL()
{
	return _T("[machines]");
}

void CMachinesSet::DoFieldExchange(CFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(CMachinesSet)
	pFX->SetFieldType(CFieldExchange::outputColumn);
	RFX_Int(pFX, _T("[batchcount]"), m_batchcount);
	RFX_Double(pFX, _T("[capacity]"), m_capacity);
	RFX_Double(pFX, _T("[liquor]"), m_liquor);
	RFX_Byte(pFX, _T("[machine_id]"), m_machine_id);
	RFX_Text(pFX, _T("[machine_name]"), m_machine_name);
	RFX_Double(pFX, _T("[maxcapacity]"), m_maxcapacity);
	RFX_Double(pFX, _T("[mincapacity]"), m_mincapacity);
	RFX_Text(pFX, _T("[specification]"), m_specification);
	RFX_Int(pFX, _T("[status]"), m_status);
	RFX_Byte(pFX, _T("[enabled]"), m_enabled);
	//}}AFX_FIELD_MAP
}

/////////////////////////////////////////////////////////////////////////////
// CMachinesSet diagnostics

#ifdef _DEBUG
void CMachinesSet::AssertValid() const
{
	CRecordset::AssertValid();
}

void CMachinesSet::Dump(CDumpContext& dc) const
{
	CRecordset::Dump(dc);
}
#endif //_DEBUG
