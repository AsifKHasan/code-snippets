// Pair.h: interface for the CPair class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_PAIR_H__782FD57B_8BAB_11D4_B781_080000000579__INCLUDED_)
#define AFX_PAIR_H__782FD57B_8BAB_11D4_B781_080000000579__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CPair  
{
public:
	long m_oindex;
	double m_amount;
	int m_mid;
	CPair();
	CPair(long oindex, int mid, double amount);
	virtual ~CPair();

	CPair &operator=( CPair & );  
};

#endif // !defined(AFX_PAIR_H__782FD57B_8BAB_11D4_B781_080000000579__INCLUDED_)
