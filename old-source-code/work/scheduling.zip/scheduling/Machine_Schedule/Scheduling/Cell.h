// Cell.h: interface for the CCell class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_CELL_H__DE05FAF7_9452_11D4_B788_080000000579__INCLUDED_)
#define AFX_CELL_H__DE05FAF7_9452_11D4_B788_080000000579__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CCell  
{
public:
	double	m_amount;
	long	m_oindex;
	int		m_col;
	int		m_row;
	CCell();
	CCell(int row, int col, long oindex, double amount);
	virtual ~CCell();

};

#endif // !defined(AFX_CELL_H__DE05FAF7_9452_11D4_B788_080000000579__INCLUDED_)
