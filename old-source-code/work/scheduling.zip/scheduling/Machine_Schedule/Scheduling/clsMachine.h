#if !defined(AFX_CLSMACHINE_H__C2285184_8198_11D2_A9DB_00A024C905B6__INCLUDED_)
#define AFX_CLSMACHINE_H__C2285184_8198_11D2_A9DB_00A024C905B6__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// clsMachine.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// clsMachine window

class clsMachine 
{
// Construction
public:
	clsMachine();

// Attributes
public:
	int			m_batchcount;
	double		m_capacity;
	double		m_liquor;
	BYTE		m_machine_id;
	CString		m_machine_name;	
	double		m_maxcapacity;
	double		m_mincapacity;
	CString		m_specification;
	int			m_status;
	BOOL		m_enabled;

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(clsMachine)
	//}}AFX_VIRTUAL

// Implementation
public:
	double GetIncrement();
	double	GetCapacity();
	double	GetMinCapacity();
	double	GetMaxCapacity();
	double	GetLiquor();

	int		GetIndex();
	CString GetName();
	int		GetStatus();

	BOOL	IsEnabled();
	int		InRange(double amount);

	double	m_incr;
	virtual ~clsMachine();

	// Generated message map functions
protected:
	//{{AFX_MSG(clsMachine)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG
//	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CLSMACHINE_H__C2285184_8198_11D2_A9DB_00A024C905B6__INCLUDED_)
