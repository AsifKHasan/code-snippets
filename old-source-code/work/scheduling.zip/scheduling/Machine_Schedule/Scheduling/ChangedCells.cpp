// ChangedCells.cpp: implementation of the CChangedCells class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "scheduling.h"
#include "ChangedCells.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CChangedCells::CChangedCells()
{
	m_applied = TRUE;
}

CChangedCells::~CChangedCells()
{
	m_olist.RemoveAll();
	m_cells.RemoveAll();
}

int CChangedCells::AddCell(int row, int col, long oindex, double amount)
{
	BOOL	found;
	int		i;

	found = FALSE;
	if(oindex != -1)
	{
		for(i = 0 ; i < m_olist.GetSize() ; i++)
		{
			if(m_olist[i] == oindex)
			{
				found = TRUE;
				break;
			}
		}
		if(found == FALSE)
		{
			m_olist.Add(oindex);
		}
	}
	for( i = 0 ; i < m_cells.GetSize() ; i++)
	{
		if(m_cells[i].m_row == row && m_cells[i].m_col == col)
		{
			m_cells[i].m_oindex = oindex;
			m_cells[i].m_amount	= amount;
			m_applied = FALSE;
			return 1;
		}
	}
	m_cells.Add(CCell(row, col, oindex, amount));
	m_applied = FALSE;
	return 1;
}

int CChangedCells::Init()
{
	m_olist.RemoveAll();
	m_cells.RemoveAll();
	m_applied = TRUE;
	return 1;
}
