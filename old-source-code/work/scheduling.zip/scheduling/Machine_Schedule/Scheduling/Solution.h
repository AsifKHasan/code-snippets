// Solution.h: interface for the CSolution class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SOLUTION_H__782FD57C_8BAB_11D4_B781_080000000579__INCLUDED_)
#define AFX_SOLUTION_H__782FD57C_8BAB_11D4_B781_080000000579__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <afxtempl.h>
#include "Pair.h"

class CSolution  
{
public:
	int GetMachineStat(int *n_machines, double *avg_batch);
	int MergePair(int startp, CPair cp);
	int AddPair(int index, CPair cp);
	int m_curpair;
	int		m_sid;
	CArray	<CPair,CPair> m_pair;
	CSolution();
	CSolution(CSolution& cs);
	virtual ~CSolution();

	CSolution &operator=( CSolution & );  
	CSolution &operator+( CSolution & );
	BOOL	  operator==( CSolution & );  
};

#endif // !defined(AFX_SOLUTION_H__782FD57C_8BAB_11D4_B781_080000000579__INCLUDED_)
