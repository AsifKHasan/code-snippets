// clsMachine.cpp : implementation file
//

#include "stdafx.h"
#include "Scheduling.h"
#include "clsMachine.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// clsMachine

clsMachine::clsMachine()
{
	m_incr		= 1.0;
}

clsMachine::~clsMachine()
{
}


//BEGIN_MESSAGE_MAP(clsMachine, CWnd)
	//{{AFX_MSG_MAP(clsMachine)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
//END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// clsMachine message handlers

int clsMachine::InRange(double amount)
{
	if(amount < m_mincapacity)
	{
		return RANGE_BELOW;
	}
	else if(amount > m_maxcapacity)
	{
		return RANGE_ABOVE;
	}
	else
	{
		return RANGE_IN;
	}
}

double clsMachine::GetMaxCapacity()
{
	return m_maxcapacity;
}

double clsMachine::GetMinCapacity()
{
	return m_mincapacity;
}

double clsMachine::GetCapacity()
{
	return m_capacity;
}

int clsMachine::GetIndex()
{
	return m_machine_id;
}

CString clsMachine::GetName()
{
	return m_machine_name;
}

int clsMachine::GetStatus()
{
	return m_status;
}

double clsMachine::GetLiquor()
{
	return m_liquor;
}

BOOL clsMachine::IsEnabled()
{
	return m_enabled;
}

double clsMachine::GetIncrement()
{
	return m_incr;
}
