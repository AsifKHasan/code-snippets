#if !defined(AFX_ORDERSET_H__FBB08907_80CC_11D2_A9DB_00A024C905B6__INCLUDED_)
#define AFX_ORDERSET_H__FBB08907_80CC_11D2_A9DB_00A024C905B6__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// OrderSet.h : header file
//

#include  <afxdb.h>
/////////////////////////////////////////////////////////////////////////////
// COrderSet recordset

class COrderSet : public CRecordset
{
public:
	COrderSet(CDatabase* pDatabase = NULL);
	DECLARE_DYNAMIC(COrderSet)

// Field/Param Data
	//{{AFX_FIELD(COrderSet, CRecordset)
	CTime	m_deliverydate;
	double	m_quantity;
	CString	m_shade;
	CString	m_count_name;
	CString	m_workorder_no;
	CString	m_yarn_type;
	double	m_left_over;
	long	m_wo_id;
	CString	m_client_name;
	BYTE	m_status;
	BYTE	m_dyecomplete;
	int		m_client_id;
	double	m_scamount;
	int		m_count_id;
	CString	m_workorder_type;
	int		m_yarn_type_id;
	//}}AFX_FIELD


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(COrderSet)
	public:
	virtual CString GetDefaultConnect();    // Default connection string
	virtual CString GetDefaultSQL();    // Default SQL for Recordset
	virtual void DoFieldExchange(CFieldExchange* pFX);  // RFX support
	//}}AFX_VIRTUAL

// Implementation
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ORDERSET_H__FBB08907_80CC_11D2_A9DB_00A024C905B6__INCLUDED_)
