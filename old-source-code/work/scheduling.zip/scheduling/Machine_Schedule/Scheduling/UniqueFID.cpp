// UniqueFID.cpp : implementation file
//

#include "stdafx.h"
#include "scheduling.h"
#include "UniqueFID.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CUniqueFID

IMPLEMENT_DYNAMIC(CUniqueFID, CRecordset)

CUniqueFID::CUniqueFID(CDatabase* pdb)
	: CRecordset(pdb)
{
	//{{AFX_FIELD_INIT(CUniqueFID)
	m_id = 0;
	m_table_name = _T("");
	m_original_table = _T("");
	m_field_name = _T("");
	m_unique_id = 0;
	m_nFields = 5;
	//}}AFX_FIELD_INIT
	m_nDefaultType = snapshot;
}


CString CUniqueFID::GetDefaultConnect()
{
	return _T("ODBC;DSN=Schedule");
}

CString CUniqueFID::GetDefaultSQL()
{
	return _T("[QUFID]");
}

void CUniqueFID::DoFieldExchange(CFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(CUniqueFID)
	pFX->SetFieldType(CFieldExchange::outputColumn);
	RFX_Long(pFX, _T("[id]"), m_id);
	RFX_Text(pFX, _T("[table_name]"), m_table_name);
	RFX_Text(pFX, _T("[original_table]"), m_original_table);
	RFX_Text(pFX, _T("[field_name]"), m_field_name);
	RFX_Long(pFX, _T("[unique_id]"), m_unique_id);
	//}}AFX_FIELD_MAP
}

/////////////////////////////////////////////////////////////////////////////
// CUniqueFID diagnostics

#ifdef _DEBUG
void CUniqueFID::AssertValid() const
{
	CRecordset::AssertValid();
}

void CUniqueFID::Dump(CDumpContext& dc) const
{
	CRecordset::Dump(dc);
}
#endif //_DEBUG
