#if !defined(AFX_MACHINESSET_H__C2285185_8198_11D2_A9DB_00A024C905B6__INCLUDED_)
#define AFX_MACHINESSET_H__C2285185_8198_11D2_A9DB_00A024C905B6__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// MachinesSet.h : header file
//



/////////////////////////////////////////////////////////////////////////////
// CMachinesSet recordset

class CMachinesSet : public CRecordset
{
public:
	CMachinesSet(CDatabase* pDatabase = NULL);
	DECLARE_DYNAMIC(CMachinesSet)

// Field/Param Data
	//{{AFX_FIELD(CMachinesSet, CRecordset)
	int		m_batchcount;
	double	m_capacity;
	double	m_liquor;
	BYTE	m_machine_id;
	CString	m_machine_name;
	double	m_maxcapacity;
	double	m_mincapacity;
	CString	m_specification;
	int		m_status;
	BYTE	m_enabled;
	//}}AFX_FIELD


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMachinesSet)
	public:
	virtual CString GetDefaultConnect();    // Default connection string
	virtual CString GetDefaultSQL();    // Default SQL for Recordset
	virtual void DoFieldExchange(CFieldExchange* pFX);  // RFX support
	//}}AFX_VIRTUAL

// Implementation
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MACHINESSET_H__C2285185_8198_11D2_A9DB_00A024C905B6__INCLUDED_)
