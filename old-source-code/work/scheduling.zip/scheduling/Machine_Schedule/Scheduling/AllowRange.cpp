// AllowRange.cpp: implementation of the CAllowRange class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Scheduling.h"
#include "AllowRange.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CAllowRange::CAllowRange(double lbound, double ubound)
{
	m_lbound = lbound;
	m_ubound = ubound;
	m_allowed.RemoveAll();
}

CAllowRange::CAllowRange(CAllowRange &car)
{
	m_lbound = car.m_lbound;
	m_ubound = car.m_ubound;
	
	m_allowed.RemoveAll();
	m_allowed.Append(car.m_allowed);
}

CAllowRange::CAllowRange()
{

}

CAllowRange::~CAllowRange()
{

}

CAllowRange& CAllowRange::operator=( CAllowRange &car )
{
	m_lbound = car.m_lbound;
	m_ubound = car.m_ubound;
	
	m_allowed.RemoveAll();
	m_allowed.Append(car.m_allowed);
	return *this;
}
