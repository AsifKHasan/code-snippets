// DyelineSet.cpp : implementation file
//

#include "stdafx.h"
#include "scheduling.h"
#include "DyelineSet.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDyelineSet

IMPLEMENT_DYNAMIC(CDyelineSet, CRecordset)

CDyelineSet::CDyelineSet(CDatabase* pdb)
	: CRecordset(pdb)
{
	//{{AFX_FIELD_INIT(CDyelineSet)
	m_dyeline_id = 0;
	m_dyeline_number = 0;
	m_client_id = 0;
	m_workorder_ref = 0;
	m_labdip_master_id = 0;
	m_labdip_id = 0;
	m_color = _T("");
	m_count = 0;
	m_yarn_type = 0;
	m_machine_id = 0;
	m_liquor = 0.0;
	m_weight = 0.0;
	m_batch_no = _T("");
	m_packages = 0.0;
	m_dyeing_program = 0;
	m_yarn_stock_flag = FALSE;
	m_finished_weight = 0.0;
	m_dyeing_shift = _T("");
	m_dyeline_comments = _T("");
	m_complete = FALSE;
	m_parentlink = 0;
	m_recount = 0;
	m_ownlink = _T("");
	m_nFields = 27;
	//}}AFX_FIELD_INIT
	m_nDefaultType = snapshot;
}


CString CDyelineSet::GetDefaultConnect()
{
	return _T("ODBC;DSN=Schedule");
}

CString CDyelineSet::GetDefaultSQL()
{
	return _T("[Qdyeline]");
}

void CDyelineSet::DoFieldExchange(CFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(CDyelineSet)
	pFX->SetFieldType(CFieldExchange::outputColumn);
	RFX_Long(pFX, _T("[dyeline_id]"), m_dyeline_id);
	RFX_Long(pFX, _T("[dyeline_number]"), m_dyeline_number);
	RFX_Int(pFX, _T("[client_id]"), m_client_id);
	RFX_Long(pFX, _T("[workorder_ref]"), m_workorder_ref);
	RFX_Long(pFX, _T("[labdip_master_id]"), m_labdip_master_id);
	RFX_Long(pFX, _T("[labdip_id]"), m_labdip_id);
	RFX_Date(pFX, _T("[dyeline_date]"), m_dyeline_date);
	RFX_Text(pFX, _T("[color]"), m_color);
	RFX_Int(pFX, _T("[count]"), m_count);
	RFX_Int(pFX, _T("[yarn_type]"), m_yarn_type);
	RFX_Byte(pFX, _T("[machine_id]"), m_machine_id);
	RFX_Double(pFX, _T("[liquor]"), m_liquor);
	RFX_Double(pFX, _T("[weight]"), m_weight);
	RFX_Text(pFX, _T("[batch_no]"), m_batch_no);
	RFX_Double(pFX, _T("[packages]"), m_packages);
	RFX_Int(pFX, _T("[dyeing_program]"), m_dyeing_program);
	RFX_Date(pFX, _T("[start_time]"), m_start_time);
	RFX_Date(pFX, _T("[end_time]"), m_end_time);
	RFX_Bool(pFX, _T("[yarn_stock_flag]"), m_yarn_stock_flag);
	RFX_Double(pFX, _T("[finished_weight]"), m_finished_weight);
	RFX_Text(pFX, _T("[dyeing_shift]"), m_dyeing_shift);
	RFX_Date(pFX, _T("[prod_date]"), m_prod_date);
	RFX_Text(pFX, _T("[dyeline_comments]"), m_dyeline_comments);
	RFX_Bool(pFX, _T("[complete]"), m_complete);
	RFX_Long(pFX, _T("[parentlink]"), m_parentlink);
	RFX_Byte(pFX, _T("[recount]"), m_recount);
	RFX_Text(pFX, _T("[ownlink]"), m_ownlink);
	//}}AFX_FIELD_MAP
}

/////////////////////////////////////////////////////////////////////////////
// CDyelineSet diagnostics

#ifdef _DEBUG
void CDyelineSet::AssertValid() const
{
	CRecordset::AssertValid();
}

void CDyelineSet::Dump(CDumpContext& dc) const
{
	CRecordset::Dump(dc);
}
#endif //_DEBUG
