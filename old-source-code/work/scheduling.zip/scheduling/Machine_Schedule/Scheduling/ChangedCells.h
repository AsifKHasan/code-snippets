// ChangedCells.h: interface for the CChangedCells class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_CHANGEDCELLS_H__DE05FAF3_9452_11D4_B788_080000000579__INCLUDED_)
#define AFX_CHANGEDCELLS_H__DE05FAF3_9452_11D4_B788_080000000579__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <afxtempl.h>
#include "Cell.h"

class CChangedCells  
{
public:
	int Init();
	int AddCell(int row, int col, long oindex, double amount);
	CArray<CCell, CCell>	m_cells;
	CArray<long, long>	m_olist;
	BOOL	m_applied;
	CChangedCells();
	virtual ~CChangedCells();
};

#endif // !defined(AFX_CHANGEDCELLS_H__DE05FAF3_9452_11D4_B788_080000000579__INCLUDED_)
