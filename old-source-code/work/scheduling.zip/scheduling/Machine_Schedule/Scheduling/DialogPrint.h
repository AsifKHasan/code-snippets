#if !defined(AFX_DIALOGPRINT_H__764484E0_BA23_11D3_9BAE_00C0DFEC3C16__INCLUDED_)
#define AFX_DIALOGPRINT_H__764484E0_BA23_11D3_9BAE_00C0DFEC3C16__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// DialogPrint.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDialogPrint dialog

class CDialogPrint : public CDialog
{
// Construction
public:
	CDialogPrint(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CDialogPrint)
	enum { IDD = IDD_SPRINT };
	CSpinButtonCtrl	m_spinfrom;
	CSpinButtonCtrl	m_spinto;
	CString	m_sto;
	COleDateTime	m_dfrom;
	COleDateTime	m_dto;
	COleDateTime	o_dfrom;
	COleDateTime	o_dto;
	int		m_tobuddy;
	int		m_frombuddy;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDialogPrint)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDialogPrint)
	virtual BOOL OnInitDialog();
	afx_msg void OnChangeFrombuddy();
	afx_msg void OnChangeTobuddy();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DIALOGPRINT_H__764484E0_BA23_11D3_9BAE_00C0DFEC3C16__INCLUDED_)
