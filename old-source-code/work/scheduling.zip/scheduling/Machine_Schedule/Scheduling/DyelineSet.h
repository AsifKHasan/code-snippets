#if !defined(AFX_DYELINESET_H__0D99BBE9_799C_11D4_B76D_080000000579__INCLUDED_)
#define AFX_DYELINESET_H__0D99BBE9_799C_11D4_B76D_080000000579__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DyelineSet.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDyelineSet recordset

class CDyelineSet : public CRecordset
{
public:
	CDyelineSet(CDatabase* pDatabase = NULL);
	DECLARE_DYNAMIC(CDyelineSet)

// Field/Param Data
	//{{AFX_FIELD(CDyelineSet, CRecordset)
	long	m_dyeline_id;
	long	m_dyeline_number;
	int		m_client_id;
	long	m_workorder_ref;
	long	m_labdip_master_id;
	long	m_labdip_id;
	CTime	m_dyeline_date;
	CString	m_color;
	int		m_count;
	int		m_yarn_type;
	BYTE	m_machine_id;
	double	m_liquor;
	double	m_weight;
	CString	m_batch_no;
	double	m_packages;
	int		m_dyeing_program;
	CTime	m_start_time;
	CTime	m_end_time;
	BOOL	m_yarn_stock_flag;
	double	m_finished_weight;
	CString	m_dyeing_shift;
	CTime	m_prod_date;
	CString	m_dyeline_comments;
	BOOL	m_complete;
	long	m_parentlink;
	BYTE	m_recount;
	CString	m_ownlink;
	//}}AFX_FIELD


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDyelineSet)
	public:
	virtual CString GetDefaultConnect();    // Default connection string
	virtual CString GetDefaultSQL();    // Default SQL for Recordset
	virtual void DoFieldExchange(CFieldExchange* pFX);  // RFX support
	//}}AFX_VIRTUAL

// Implementation
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DYELINESET_H__0D99BBE9_799C_11D4_B76D_080000000579__INCLUDED_)
