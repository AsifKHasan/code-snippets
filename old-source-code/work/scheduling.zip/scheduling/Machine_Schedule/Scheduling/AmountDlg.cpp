// AmountDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Scheduling.h"
#include "AmountDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAmountDlg property page

IMPLEMENT_DYNCREATE(CAmountDlg, CPropertyPage)

CAmountDlg::CAmountDlg() : CPropertyPage(CAmountDlg::IDD)
{
	//{{AFX_DATA_INIT(CAmountDlg)
	m_amount = 0.0;
	m_sval = -1;
	m_editstarthour = 0;
	m_editendhour = 0;
	m_editstartmin = 0;
	m_editendmin = 0;
	//}}AFX_DATA_INIT
}

CAmountDlg::~CAmountDlg()
{
}

void CAmountDlg::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAmountDlg)
	DDX_Control(pDX, IDC_SPINENDMIN, m_spinendmin);
	DDX_Control(pDX, IDC_SPINSTARTMIN, m_spinstartmin);
	DDX_Control(pDX, IDC_SPINENDHOUR, m_spinendhour);
	DDX_Control(pDX, IDC_SPINSTARTHOUR, m_spinstarthour);
	DDX_Text(pDX, IDC_AMOUNT, m_amount);
	DDX_Radio(pDX, IDC_SCHEDULED, m_sval);
	DDX_Text(pDX, IDC_EDITSTARTHOUR, m_editstarthour);
	DDX_Text(pDX, IDC_EDITENDHOUR, m_editendhour);
	DDX_Text(pDX, IDC_EDITSTARTMIN, m_editstartmin);
	DDX_Text(pDX, IDC_EDITENDMIN, m_editendmin);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CAmountDlg, CPropertyPage)
	//{{AFX_MSG_MAP(CAmountDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CAmountDlg message handlers

BOOL CAmountDlg::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();	

	m_spinstarthour.SetBase(10);
	m_spinstarthour.SetRange(0, 23);
	m_spinstarthour.SetPos(0);
	m_spinstarthour.SetBuddy(GetDlgItem(IDC_EDITSTARTHOUR));
	
	m_spinendhour.SetBase(10);
	m_spinendhour.SetRange(0, 23);
	m_spinendhour.SetPos(0);
	m_spinendhour.SetBuddy(GetDlgItem(IDC_EDITENDHOUR));

	m_spinstartmin.SetBase(10);
	m_spinstartmin.SetRange(0, 59);
	m_spinstartmin.SetPos(0);
	m_spinstartmin.SetBuddy(GetDlgItem(IDC_EDITSTARTMIN));

	m_spinendmin.SetBase(10);
	m_spinendmin.SetRange(0, 59);
	m_spinendmin.SetPos(0);
	m_spinendmin.SetBuddy(GetDlgItem(IDC_EDITENDMIN));

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

int CAmountDlg::DoModal() 
{
	return CPropertyPage::DoModal();
}



void CAmountDlg::OnOK() 
{
	// TODO: Add your specialized code here and/or call the base class
	if(m_sval == 1)
	{
		if( m_editstarthour == 0 && m_editstartmin == 0)
		{
			MessageBox("In-process schedules must have definite starting hour and starting minute");
			m_cancel = TRUE;
		}
	}
	else if(m_sval == 2)
	{
		if( m_editendhour == 0 && m_editendmin == 0)
		{
			MessageBox("Incomplete schedules orders must have definite ending hour and ending minute");
			m_cancel = TRUE;
		}
	}
	else if(m_sval == 3)
	{
		if( m_editendhour == 0 && m_editendmin == 0)
		{
			MessageBox("Complete schedules must have definite ending hour and ending minute");
			m_cancel = TRUE;
		}
	}

	CPropertyPage::OnOK();
}
