// AllowRange.h: interface for the CAllowRange class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ALLOWRANGE_H__3CE7E39F_8F82_11D4_B786_080000000579__INCLUDED_)
#define AFX_ALLOWRANGE_H__3CE7E39F_8F82_11D4_B786_080000000579__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <afxtempl.h>

class CAllowRange  
{
public:
	double m_ubound;
	double m_lbound;
	CArray<int, int> m_allowed;
	CAllowRange();
	CAllowRange(CAllowRange &car);
	CAllowRange(double lbound, double ubound);
	virtual ~CAllowRange();
	CAllowRange& CAllowRange::operator=(CAllowRange &car );


};

#endif // !defined(AFX_ALLOWRANGE_H__3CE7E39F_8F82_11D4_B786_080000000579__INCLUDED_)
