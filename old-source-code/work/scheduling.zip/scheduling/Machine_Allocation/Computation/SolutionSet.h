// SolutionSet.h: interface for the CSolutionSet class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SOLUTIONSET_H__782FD57F_8BAB_11D4_B781_080000000579__INCLUDED_)
#define AFX_SOLUTIONSET_H__782FD57F_8BAB_11D4_B781_080000000579__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Solution.h"

class CSolutionSet  
{
public:
	int GetLastMachine();
	int GetNextMachine(int mid);
	int GetFirstMachine();
	BOOL	AdjustSubset(int index);
	BOOL	IsSimilar(int index);
	int		AddSolution();
	int		DelSolution();
	int		m_cursol;
	double	m_amount;
	CArray<CSolution, CSolution>	m_solution;
	CArray<int, int>	m_mallowed;

	CSolutionSet();
	CSolutionSet(CSolutionSet &css);
	virtual ~CSolutionSet();

	CSolutionSet &operator=( CSolutionSet & );  

};

#endif // !defined(AFX_SOLUTIONSET_H__782FD57F_8BAB_11D4_B781_080000000579__INCLUDED_)
