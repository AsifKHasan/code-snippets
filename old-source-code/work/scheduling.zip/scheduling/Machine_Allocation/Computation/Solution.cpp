// Solution.cpp: implementation of the CSolution class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Computation.h"
#include "Solution.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CSolution::CSolution()
{
	m_curpair = -1;
}

CSolution::CSolution(CSolution& cs)
{
	int		i;
	CPair	cp;

	m_sid		= cs.m_sid + 1;
	m_curpair	= cs.m_curpair;

	for( i = 0 ; i < cs.m_pair.GetSize() ; i++)
	{
		cp = cs.m_pair[i];
		m_pair.Add(cp);
	}

}

CSolution::~CSolution()
{

}

CSolution &CSolution::operator=( CSolution &cs )
{
	CPair	cp;
	int		i;

    m_sid	= cs.m_sid;

	for( i = 0 ; i < cs.m_pair.GetSize() ; i++)
	{
		cp = cs.m_pair[i];
		m_pair.Add(cp);
	}

    return *this;  
}

BOOL CSolution::operator==( CSolution &cs )
{
	BOOL	similar = TRUE;

	if( m_pair.GetSize() != cs.m_pair.GetSize())
	{
		return FALSE;
	}

	int		i;

	for( i = 0 ; i < cs.m_pair.GetSize() ; i++)
	{
		if(m_pair[i].m_mid != cs.m_pair[i].m_mid)
		{
			similar = FALSE;
			break;
		}
	}



    return similar;  
}

int CSolution::AddPair(int index, CPair cp)
{
	int		i;

	for(i = m_pair.GetSize() - 1 ; i <= index ; i++)
	{
		m_pair.Add(CPair());
	}
	m_pair.SetAt(index, cp);

	for(i = index + 1 ; i < m_pair.GetSize() ; i++)
	{
		m_pair.RemoveAt(i);
	}
	m_curpair = index;
	return -1;
}
