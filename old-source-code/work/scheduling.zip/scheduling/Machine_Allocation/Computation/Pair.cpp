// Pair.cpp: implementation of the CPair class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Computation.h"
#include "Pair.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CPair::CPair()
{

}

CPair::CPair(int mid, double amount)
{
	m_amount	= amount;
	m_mid		= mid;
}

CPair::~CPair()
{

}

CPair &CPair::operator=( CPair &cp )
{
    m_amount	= cp.m_amount;
    m_mid		= cp.m_mid;

    return *this;  
}
