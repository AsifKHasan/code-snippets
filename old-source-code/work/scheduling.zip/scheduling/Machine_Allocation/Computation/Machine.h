// Machine.h: interface for the CMachine class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MACHINE_H__1407CC66_8A27_11D4_B77F_080000000579__INCLUDED_)
#define AFX_MACHINE_H__1407CC66_8A27_11D4_B77F_080000000579__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CMachine  
{
public:
	int m_accept;
	int		m_status;
	double	m_incr;
	double	m_optc;
	double	m_maxc;
	double	m_minc;
	int		m_mid;
	CMachine();
	CMachine(int mid, double optc, double minc, double maxc, int status);
	virtual ~CMachine();

};

#endif // !defined(AFX_MACHINE_H__1407CC66_8A27_11D4_B77F_080000000579__INCLUDED_)
