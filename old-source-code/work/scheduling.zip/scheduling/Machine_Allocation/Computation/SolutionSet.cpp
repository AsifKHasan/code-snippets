// SolutionSet.cpp: implementation of the CSolutionSet class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Computation.h"
#include "SolutionSet.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CSolutionSet::CSolutionSet()
{
	m_cursol = -1;
}

CSolutionSet::CSolutionSet(CSolutionSet& css)
{
	int		i;

	m_amount  = css.m_amount;
	m_cursol  = -1;
	m_mallowed.RemoveAll();
	for( i = 0 ; i < css.m_mallowed.GetSize() ; i++)
	{
		m_mallowed.Add(css.m_mallowed[i]);
	}
	//m_mallowed.Append(css.m_mallowed);
}

CSolutionSet::~CSolutionSet()
{

}

CSolutionSet &CSolutionSet::operator=( CSolutionSet &css )
{
	int		i;

	m_amount	= css.m_amount;
	m_cursol	= css.m_cursol;

	m_mallowed.RemoveAll();
	for( i = 0 ; i < css.m_mallowed.GetSize() ; i++)
	{
		m_mallowed.Add(css.m_mallowed[i]);
	}

	for( i = 0 ; i < css.m_solution.GetSize() ; i++)
	{
		m_solution[i] = css.m_solution[i];
	}

    return *this;  
}

int CSolutionSet::AddSolution()
{
	CSolution	cs;

	if(m_cursol != -1)
	{
		cs = m_solution[m_cursol];
	}
	m_solution.Add(cs);
	m_cursol++;

	return 1;
}

int CSolutionSet::DelSolution()
{
	int	to_del = m_solution.GetSize();

	if(to_del > 0 )
	{
		m_solution.RemoveAt(to_del - 1);
		m_cursol--;
	}

	return 1;
}

BOOL CSolutionSet::IsSimilar(int index)
{
	int		i;

	for( i = 0 ; i < index ; i++)
	{
		if(m_solution[i] == m_solution[index])
		{
			return TRUE;
		}
	}
	return FALSE;
}

BOOL CSolutionSet::AdjustSubset(int index)
{
	if(index <= 0 || index > m_cursol)
	{
		return FALSE;
	}

	int		minpair, to_keep, i, j;
	BOOL	adjustable = FALSE;

	for( i = 0 ; i < index ; i++)
	{
		if(m_solution[i].m_pair.GetSize() > m_solution[index].m_pair.GetSize())
		{
			minpair = m_solution[index].m_pair.GetSize();
			to_keep = index;
		}
		else
		{
			minpair = m_solution[i].m_pair.GetSize();
			to_keep = i;
		}
		
		for(j = 0 ; j < minpair ; j++)
		{
			if(m_solution[i].m_pair[j].m_mid != m_solution[index].m_pair[j].m_mid)
			{
				adjustable = FALSE;
				break;
			}
			else
			{
				adjustable = TRUE;
			}
		}

		if(adjustable == TRUE)
		{
			if( i != to_keep)
			{
				m_solution[i] = m_solution[to_keep];
			}
			break;
		}
	}
	return adjustable;
}

int CSolutionSet::GetFirstMachine()
{
	if(m_mallowed.GetSize() == 0)
	{
		return -1;
	}
	return m_mallowed[0];
}

int CSolutionSet::GetNextMachine(int mid)
{
	int		i;

	for(i = 0 ; i < m_mallowed.GetSize() - 1 ; i++)
	{
		if(m_mallowed[i] == mid)
		{
			return m_mallowed[i+1];
		}
	}
	return -1;
}

int CSolutionSet::GetLastMachine()
{
	if(m_mallowed.GetSize() == 0)
	{
		return -1;
	}
	return m_mallowed[m_mallowed.GetSize() - 1];
}
