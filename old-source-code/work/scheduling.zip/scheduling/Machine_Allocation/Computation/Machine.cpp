// Machine.cpp: implementation of the CMachine class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Computation.h"
#include "Machine.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CMachine::CMachine()
{
	m_accept = 1;
}

CMachine::CMachine(int mid, double optc, double minc, double maxc, int status)
{
	m_mid	= mid;
	m_optc	= optc;
	m_minc	= minc;
	m_maxc	= maxc;
	m_status = status;
	m_accept = 1;
}

CMachine::~CMachine()
{

}
