// Mainobject.h: interface for the CMainobject class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MAINOBJECT_H__1407CC67_8A27_11D4_B77F_080000000579__INCLUDED_)
#define AFX_MAINOBJECT_H__1407CC67_8A27_11D4_B77F_080000000579__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <afxtempl.h>
#include "Machine.h"
#include "AllowRange.h"
#include "SolutionSet.h"

class CMainobject  
{
public:
	void	PrintResult(int index);
	int		GetMachineCount();
	int		AddSolutionSet(double amount);
	int		Distribute(double amount, int mid, int level);
	void	Compute(double amount);
	CMainobject();
	virtual ~CMainobject();

	int		m_curset;
	CArray	<CMachine,CMachine> m_marray;
	CArray	<CAllowRange,CAllowRange> m_allowrange;
	CArray	<CSolutionSet, CSolutionSet>	m_solutionset;
};

#endif // !defined(AFX_MAINOBJECT_H__1407CC67_8A27_11D4_B77F_080000000579__INCLUDED_)
