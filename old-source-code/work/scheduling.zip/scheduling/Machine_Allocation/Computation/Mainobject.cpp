// Mainobject.cpp: implementation of the CMainobject class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include <iostream.h>
#include <iomanip.h>
#include "Computation.h"
#include "Mainobject.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CMainobject::CMainobject()
{
	int		i, j;

	m_curset = -1;

	m_marray.Add(CMachine(12, 440, 400, 450, 11));	//  0
	m_marray.Add(CMachine(11, 320, 300, 330, 10));	//  1
	m_marray.Add(CMachine( 9, 250, 240, 260,  9));	//  2
	m_marray.Add(CMachine( 8, 250, 240, 260,  9));	//  3
	m_marray.Add(CMachine( 7, 250, 240, 260,  9));	//  4
	m_marray.Add(CMachine(10, 210, 200, 220,  8));	//  5
	m_marray.Add(CMachine( 6, 125, 120, 130,  7));	//  6
	m_marray.Add(CMachine( 5, 125, 120, 130,  7));	//  7
	m_marray.Add(CMachine( 4,  50,  45,  55,  6));	//  8
	m_marray.Add(CMachine( 3,  50,  45,  55,  6));	//  9
	m_marray.Add(CMachine( 2,  12,   8,  16,  5));	// 10
	m_marray.Add(CMachine( 1,  12,   8,  16,  5));	// 11
	m_marray.Add(CMachine(13,   4,   2,   6,  4));	// 12

	for( i = 0 ; i < GetMachineCount() ; i++)
	{
		if(m_marray[i].m_optc > 75.0)
		{
			m_marray[i].m_incr = 5.00;
		}
		else
		{
			m_marray[i].m_incr = 1.00;
		}
	}

	for( i = 0 ; i < GetMachineCount() ; i++)
	{
		for(j = i + 1 ; j < GetMachineCount() ; j++)
		{
			if(m_marray[j].m_status == m_marray[i].m_status)
			{
				m_marray[j].m_accept = 0;
			}
		}
	}

	//CAllowRange		arange;

	m_allowrange.RemoveAll();

	m_allowrange.Add( CAllowRange(400, 3000));
	m_allowrange[0].m_allowed.Add(0);
	m_allowrange[0].m_allowed.Add(1);
	m_allowrange[0].m_allowed.Add(2);
	m_allowrange[0].m_allowed.Add(5);
	//m_allowrange[0].m_allowed.Add(6);

	m_allowrange.Add( CAllowRange(300, 400));
	m_allowrange[1].m_allowed.Add(1);
	m_allowrange[1].m_allowed.Add(2);
	m_allowrange[1].m_allowed.Add(5);
	m_allowrange[1].m_allowed.Add(6);
	m_allowrange[1].m_allowed.Add(8);

	m_allowrange.Add( CAllowRange(240, 300));
	m_allowrange[2].m_allowed.Add(2);
	m_allowrange[2].m_allowed.Add(5);
	m_allowrange[2].m_allowed.Add(6);
	m_allowrange[2].m_allowed.Add(8);
	m_allowrange[2].m_allowed.Add(10);

	m_allowrange.Add( CAllowRange(200, 240));
	m_allowrange[3].m_allowed.Add(5);
	m_allowrange[3].m_allowed.Add(6);
	m_allowrange[3].m_allowed.Add(8);
	m_allowrange[3].m_allowed.Add(10);

	m_allowrange.Add( CAllowRange(125, 200));
	m_allowrange[4].m_allowed.Add(6);
	m_allowrange[4].m_allowed.Add(8);
	m_allowrange[4].m_allowed.Add(10);

	m_allowrange.Add( CAllowRange(45, 125));
	m_allowrange[5].m_allowed.Add(8);
	m_allowrange[5].m_allowed.Add(10);

	m_allowrange.Add(CAllowRange(2, 45));
	m_allowrange[6].m_allowed.Add(10);
	m_allowrange[6].m_allowed.Add(12);
}

CMainobject::~CMainobject()
{
	m_marray.RemoveAll();
}

int CMainobject::GetMachineCount()
{
	return m_marray.GetSize();
}

int CMainobject::AddSolutionSet(double amount)
{
	int				i, j, k;
	BOOL			found = FALSE;
	
	CSolutionSet	css;

	for( i = 0 ; i < m_allowrange.GetSize() ; i++)
	{
		if(amount >= m_allowrange[i].m_lbound && amount <= m_allowrange[i].m_ubound)
		{
			css.m_mallowed.RemoveAll();
			k = m_allowrange[i].m_allowed.GetSize();
			for( j = 0 ; j < k ; j++)
			{
				css.m_mallowed.Add(m_allowrange[i].m_allowed[j]);
			}
			found = TRUE;
			break;
		}
	}
	if(found == FALSE)
	{
		return -1;
	}

	css.m_amount = amount;

	m_curset++;

	m_solutionset.Add(css);

	if(m_solutionset[m_curset].m_cursol == -1)
	{
		m_solutionset[m_curset].AddSolution();
	}

	return 1;
}

void CMainobject::Compute(double amount)
{
	int			i, smachine, fmachine, cmachine;

	if(AddSolutionSet(amount) == -1)
	{
		return;
	}

	if((smachine = m_solutionset[m_curset].GetFirstMachine()) == -1)
	{
		return;
	}
	if((fmachine = m_solutionset[m_curset].GetLastMachine()) == -1)
	{
		return;
	}

	cmachine = smachine;
	while(cmachine <= fmachine)
	{
		if(Distribute(amount, cmachine, 0) == -1)
		{
			//cout << "no solution starting with machine " << cmachine << endl;
			//cin.ignore();
		}
		else
		{
			//cout << "solution starting with machine " << cmachine << endl;
			//cin.ignore();
		}

		if((cmachine = m_solutionset[m_curset].GetNextMachine(cmachine)) == -1)
		{
			break;
		}
		//PrintResult(0);
		//cin.ignore();
	}
	m_solutionset[m_curset].DelSolution();

	for( i = 0 ; i < m_solutionset.GetSize() ; i++)
	{
		PrintResult(i);
	}
}

int CMainobject::Distribute(double amount, int mid, int level)
{
	int			p = 0, q = 0, r = 0;
	int			nmid;
	double		m_amt = amount;

	if(m_marray[mid].m_accept == 0)
	{
		nmid = m_solutionset[m_curset].GetNextMachine(mid);
		if(nmid == - 1)
		{
			return -1;
		}
		else
		{
			return Distribute(m_amt, nmid, level);
		}
	}

	if( amount <= 0)
	{
		if(m_solutionset[m_curset].IsSimilar(m_solutionset[m_curset].m_cursol))
		{
			m_solutionset[m_curset].DelSolution();
			m_solutionset[m_curset].AddSolution();
			return 1;
		}
		else if(m_solutionset[m_curset].AdjustSubset(m_solutionset[m_curset].m_cursol))
		{
			m_solutionset[m_curset].DelSolution();
			m_solutionset[m_curset].AddSolution();
			return 1;
		}
		else
		{
			m_solutionset[m_curset].AddSolution();
			return 1;
		}
	}
//	else if( m_amt >= m_marray[mid].m_minc && m_amt <= m_marray[mid].m_maxc)
	else if( m_amt >= m_marray[mid].m_minc)
//	else if( m_amt <= m_marray[mid].m_maxc)
	{
		m_amt = (m_amt > m_marray[mid].m_maxc) ? m_marray[mid].m_maxc: m_amt;
		while( m_amt >= m_marray[mid].m_minc && m_amt <= amount)
		{
			CPair	cp(mid, m_amt);

			int	cur = m_solutionset[m_curset].m_cursol;

			m_solutionset[m_curset].m_solution[cur].AddPair(level, cp);

			if(Distribute(amount - m_amt, mid, level + 1) == -1)
			{
				m_amt = m_amt - m_marray[mid].m_incr;
			}
			else
			{
				return 1;
			}
			//m_amt = m_amt + m_marray[mid].m_incr;
		}
		return -1;
	}
	else
	{
		nmid = m_solutionset[m_curset].GetNextMachine(mid);
		if(nmid == - 1)
		{
			return -1;
		}
		else
		{
			return Distribute(m_amt, nmid, level);	
		}
	}
	
	return 1;
}

void CMainobject::PrintResult(int index)
{
	int		i, j;
	int		solutions;

	if( index >= m_solutionset.GetSize())
	{
		return;
	}

	if((solutions = m_solutionset[index].m_solution.GetSize()) == 0)
	{
		cout << endl << "No Solutions for amount " << setw(4) <<m_solutionset[index].m_amount << endl;
	}
	else
	{
		cout << endl << "Solutions for amount " << setw(4) <<m_solutionset[index].m_amount << endl;
		cout << "--------------------------------" << endl;
		for( i = 0 ; i < m_solutionset[index].m_solution.GetSize() ; i++)
		{
			//cout << endl << "Seqn       Machine        Amount" << endl;
			//cout << "--------------------------------" << endl;
			cout << setw(4) << i << "  ";
			for( j = 0 ; j < m_solutionset[index].m_solution[i].m_pair.GetSize() ; j++)
			{
				cout << "(" << setw(2) << m_solutionset[index].m_solution[i].m_pair[j].m_mid << ",";
				cout << setw(5) << m_solutionset[index].m_solution[i].m_pair[j].m_amount << ") ";
			}
			cout << endl;
		}
	}
}

