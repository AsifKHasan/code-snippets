-- 
-- NAME		: cre_user.sql
-- LOCA		: $ATTNLOGGER_SRCE/01__user/
-- AUTH		: KAH, 2004/09/05
-- TEXT		: for creating AttnLogger user
-- PLAT		: MySQL
-- NOTE		: 
-- 


GRANT ALL PRIVILEGES ON *.* TO AttnLogger@localhost IDENTIFIED BY 'AttnLogger' WITH GRANT OPTION;
GRANT ALL PRIVILEGES ON *.* TO AttnLogger@'%' 		IDENTIFIED BY 'AttnLogger' WITH GRANT OPTION;
