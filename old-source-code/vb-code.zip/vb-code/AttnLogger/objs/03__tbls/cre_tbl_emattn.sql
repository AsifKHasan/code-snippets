--
-- NAME	: 	cre_tbl_emattn.sql
-- LOCA	: 	$ATTNLOGGER_SRCE/03__tbls/
-- AUTH	: 	KAH, 2004/09/05
-- ABBR	: 	EMployee ATTeNdence
-- TEXT	: 
-- NOTE	: 
-- COLS		emattn_text	attendance id (of attendee)
-- 		  	emattn_date	attendance date
-- 		  	emattn_stat	attendance processing status
--						'N' means attendance was not processed
--						'Y' means attendance was processed
-- 

create table	x_emattn
(
emattn_text		varchar(16)		not null,
emattn_date		datetime		not null,
emattn_stat		varchar(1)		not null,
constraint		pk_emattn		primary key	(emattn_text, emattn_date)
);
