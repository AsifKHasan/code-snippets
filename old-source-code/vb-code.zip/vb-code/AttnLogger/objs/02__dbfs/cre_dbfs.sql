-- 
-- NAME		: cre_dbfs.sql
-- LOCA		: $ATTNLOGGER_SRCE/02__dbfs/
-- AUTH		: KAH, 2004/09/05
-- TEXT		: database for eBRTA data
-- NOTE		: 
-- 

create database AttnLogger;
