
-- Inventory Checkout (IC) after a specific date

SELECT 		ISSREC.ITEMNUM, Sum(ISSREC.QTY) AS 'consumption'
FROM 		mp2h.dbo.ISSREC ISSREC
WHERE 		ISSREC.FROMWAREHOUSEID	= 'AES-Haripur'	and
		ISSREC.ISSUEDATE	> ? 		And 
		ISSREC.ISSUEDATE	<= getdate() 	AND 
		ISSREC.TRANSTYPE	= 'IC'
GROUP BY 	ISSREC.ITEMNUM
HAVING		Sum(ISSREC.QTY)		<> 0



-- Current Stock (CS)

SELECT 		invy.ITEMNUM, round(Sum(stock.qtyonhand),2) AS 'QtyOnHand'
FROM 		mp2h.dbo.invy invy, mp2h.dbo.stock stock
WHERE 		stock.warehouseid	= 'AES-Haripur'	and
		invy.ITEMNUM 		= stock.ITEMNUM	and
		stock.qtyonhand 	is not null
GROUP BY 	invy.ITEMNUM
HAVING		Sum(stock.qtyonhand)	> 0
ORDER BY 	invy.ITEMNUM



-- Inventory Return (IR) after a specific date

SELECT 		ISSREC.ITEMNUM, Sum(ISSREC.QTY) AS 'consumption'
FROM 		mp2h.dbo.ISSREC ISSREC
WHERE 		ISSREC.FROMWAREHOUSEID	= 'AES-Haripur'	and
		ISSREC.ISSUEDATE	> ? 		And 
		ISSREC.ISSUEDATE	<= getdate() 	AND 
		ISSREC.TRANSTYPE	= 'IR'
GROUP BY 	ISSREC.ITEMNUM
HAVING		Sum(ISSREC.QTY)		<> 0



-- Stock Adjustment (SA) after a specific date

SELECT 		ISSREC.ITEMNUM, Sum(ISSREC.QTY) AS 'consumption'
FROM 		mp2h.dbo.ISSREC ISSREC
WHERE 		ISSREC.FROMWAREHOUSEID	= 'AES-Haripur'	and
		ISSREC.ISSUEDATE	> ? 		And 
		ISSREC.ISSUEDATE	<= getdate() 	AND 
		ISSREC.TRANSTYPE	= 'SA'
GROUP BY 	ISSREC.ITEMNUM
HAVING		Sum(ISSREC.QTY)		<> 0


-- Purchase (PR) after a specific date

SELECT 		ISSREC.ITEMNUM, Sum(ISSREC.QTY) AS 'consumption'
FROM 		mp2h.dbo.ISSREC ISSREC
WHERE 		ISSREC.FROMWAREHOUSEID	= 'AES-Haripur'	and
		ISSREC.ISSUEDATE	> ? 		And 
		ISSREC.ISSUEDATE	<= getdate() 	AND 
		ISSREC.TRANSTYPE	= 'PR'
GROUP BY 	ISSREC.ITEMNUM
HAVING		Sum(ISSREC.QTY)		<> 0


-- Purchase Return (RV) after a specific date

SELECT 		ISSREC.ITEMNUM, Sum(ISSREC.QTY) AS 'consumption'
FROM 		mp2h.dbo.ISSREC ISSREC
WHERE 		ISSREC.FROMWAREHOUSEID	= 'AES-Haripur'	and
		ISSREC.ISSUEDATE	> ? 		And 
		ISSREC.ISSUEDATE	<= getdate() 	AND 
		ISSREC.TRANSTYPE	= 'RV'
GROUP BY 	ISSREC.ITEMNUM
HAVING		Sum(ISSREC.QTY)		<> 0


-- SD = CS - IC + IR + SA - PR + RV


select		invy.ITEMNUM, Sum(qtyonhand)
from		(
SELECT 		invy.ITEMNUM, round(Sum(stock.qtyonhand),2) AS 'QtyOnHand'
FROM 		mp2h.dbo.invy invy, mp2h.dbo.stock stock
WHERE 		stock.warehouseid	= 'AES-Haripur'	and
		invy.ITEMNUM 		= stock.ITEMNUM	and
		stock.qtyonhand 	is not null
GROUP BY 	invy.ITEMNUM
HAVING		Sum(stock.qtyonhand)	> 0
ORDER BY 	invy.ITEMNUM
union
SELECT 		ISSREC.ITEMNUM, Sum(ISSREC.QTY) * -1 AS 'consumption'
FROM 		mp2h.dbo.ISSREC ISSREC
WHERE 		ISSREC.FROMWAREHOUSEID	= 'AES-Haripur'	and
		ISSREC.ISSUEDATE	> ? 		And 
		ISSREC.ISSUEDATE	<= getdate() 	AND 
		ISSREC.TRANSTYPE	= 'IC'
GROUP BY 	ISSREC.ITEMNUM
HAVING		Sum(ISSREC.QTY)		<> 0
union
SELECT 		ISSREC.ITEMNUM, Sum(ISSREC.QTY) AS 'consumption'
FROM 		mp2h.dbo.ISSREC ISSREC
WHERE 		ISSREC.FROMWAREHOUSEID	= 'AES-Haripur'	and
		ISSREC.ISSUEDATE	> ? 		And 
		ISSREC.ISSUEDATE	<= getdate() 	AND 
		ISSREC.TRANSTYPE	= 'IR'
GROUP BY 	ISSREC.ITEMNUM
HAVING		Sum(ISSREC.QTY)		<> 0
union
SELECT 		ISSREC.ITEMNUM, Sum(ISSREC.QTY) AS 'consumption'
FROM 		mp2h.dbo.ISSREC ISSREC
WHERE 		ISSREC.FROMWAREHOUSEID	= 'AES-Haripur'	and
		ISSREC.ISSUEDATE	> ? 		And 
		ISSREC.ISSUEDATE	<= getdate() 	AND 
		ISSREC.TRANSTYPE	= 'SA'
GROUP BY 	ISSREC.ITEMNUM
HAVING		Sum(ISSREC.QTY)		<> 0
union
SELECT 		ISSREC.ITEMNUM, Sum(ISSREC.QTY) * -1 AS 'consumption'
FROM 		mp2h.dbo.ISSREC ISSREC
WHERE 		ISSREC.FROMWAREHOUSEID	= 'AES-Haripur'	and
		ISSREC.ISSUEDATE	> ? 		And 
		ISSREC.ISSUEDATE	<= getdate() 	AND 
		ISSREC.TRANSTYPE	= 'PR'
GROUP BY 	ISSREC.ITEMNUM
HAVING		Sum(ISSREC.QTY)		<> 0
union
SELECT 		ISSREC.ITEMNUM, Sum(ISSREC.QTY) AS 'consumption'
FROM 		mp2h.dbo.ISSREC ISSREC
WHERE 		ISSREC.FROMWAREHOUSEID	= 'AES-Haripur'	and
		ISSREC.ISSUEDATE	> ? 		And 
		ISSREC.ISSUEDATE	<= getdate() 	AND 
		ISSREC.TRANSTYPE	= 'RV'
GROUP BY 	ISSREC.ITEMNUM
HAVING		Sum(ISSREC.QTY)		<> 0
)
group by	ISSREC.ITEMNUM
