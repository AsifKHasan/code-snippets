create view	sv_tranbycc
			(
			costcenter,
			itemnum,
			description,
			qty,
			avgcost,
			consumption
			)
as
(
select 		costcenter, 
			itemnum, 
			description,
			sum(qty), 
			sum(consumption)/sum(qty), 
			sum(consumption)
from 		sv_invytrancc
where 		issuedate >= 'STDT' 	and 
			issuedate <= 'ENDT'
group by 	costcenter, 
			itemnum, 
			description
having 		(sum(qty) <> 0)
)
