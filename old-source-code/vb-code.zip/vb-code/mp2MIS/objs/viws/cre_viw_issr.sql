/*
-- NAME		cre_viw_issr.sql
-- LOCA		$SPECTRUM\Projects\mp2MIS\objs\viws\
-- AUTH		MEH, 2004/01/28
-- APPL		mp2MIS
-- ABBR		ISSUE RECEIVE 
-- TEXT		Issue and Receive view
-- NOTE		
-- DPND		ISSREC
*/


execute
(
'if exists	(
			select 	name 
			from 	sysobjects 
			where 	type like ''v'' and name like ''sv_issr''
			) 
drop view sv_issr'
)

go


create view	sv_issr	
			(
			serialnum,
			itemnum,
			itemtype,
			invytype,
			description,
			issuedate,
			issuetime,
			transtype,
			qty,
			avgunitcost,
			reason,
			qtyonhand,
			mp2unitcost,
			mp2basecost,
			unitname,
			chargeto,
			numchargedto
			)
as
select		t.serialnum,
			t.itemnum,
			t.itemtype,
			i.itemtype,
			case 	t.itemnum
				when '-' then t.description
				else i.description
			end,
			t.issuedate,
			t.issuetime,
			t.transtype,
			case 	t.transtype
				when 'IC' then t.qty * -1
				when 'RV' then t.qty * -1
				else t.qty
			end,
			t.avgunitcost,
			t.reason,
			i.qtyonhand,
			i.mp2unitcost,
			i.mp2basecost,
			i.unitname,
			t.chargeto,
			t.numchargedto
from		issrec		t
			left outer join 
						sv_invy		i
						on			i.itemnum			= t.itemnum
where		t.fromwarehouseid 	= 'AES-Meghnaghat'

go
