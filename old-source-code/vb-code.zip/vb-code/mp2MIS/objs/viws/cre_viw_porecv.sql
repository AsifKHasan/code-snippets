/*
-- NAME		cre_viw_porecv.sql
-- LOCA		$SPECTRUM\Projects\mp2MIS\objs\viws\
-- AUTH		MEH, 2004/01/27
-- APPL		mp2MIS
-- ABBR		Inventory
-- TEXT		view to get PO receipt information
-- NOTE		
-- DPND		POHEADER, ISSREC
*/

execute
(
'if exists	(
			select 	name 
			from 	sysobjects 
			where 	type like ''v'' and name like ''sv_porecv''
			) 
drop view sv_porecv'
)

go

create view sv_porecv
			(
			ponum,
			releasenum,
			potype,
			status,
			orderdate,
			vendorbranchid,
			itemtotal,
			total,
			received,
			returned,
			stockrecv,
			paid
			)
as
(
select		po.ponum,
			po.releasenum,
			po.potype,
			po.status,
			po.orderdate,
			po.vendorbranchid,
			po.subtotal,
			po.subtotal + isnull(po.totalshippingcharge, 0) + isnull(po.misccharge, 0),
			isnull(pr.received, 0) * (1 + (isnull(po.totalshippingcharge, 0) + isnull(po.misccharge, 0)) / (po.subtotal)),
			isnull(rv.returned, 0) * (1 + (isnull(po.totalshippingcharge, 0) + isnull(po.misccharge, 0)) / (po.subtotal)),
			isnull(sr.stockrecv, 0) * (1 + (isnull(po.totalshippingcharge, 0) + isnull(po.misccharge, 0)) / (po.subtotal)),
			isnull(py.paid, 0)
from		poheader		po
			right join		(
							select		issr.ponum								ponum,
										issr.releasenum							releasenum,
										sum(issr.avgunitcost * issr.qty)		received
							from		issrec									issr
							where		issr.transtype		= 'PR'				and
										issr.issuedate 		between 'STDT' and 'ENDT'
							group by	issr.ponum, issr.releasenum
							)			pr
							on			pr.ponum			= po.ponum			and
										pr.releasenum		= po.releasenum
			left outer join	(
							select		issr.ponum								ponum,
										issr.releasenum							releasenum,
										sum(issr.avgunitcost * issr.qty)		stockrecv
							from		issrec									issr
							where		issr.transtype		= 'PR'				and
										issr.chargeto		= 'Stock'			and
										issr.issuedate 		between 'STDT' and 'ENDT'
							group by	issr.ponum, issr.releasenum
							)			sr
							on			sr.ponum			= po.ponum			and
										sr.releasenum		= po.releasenum
			left outer join	(
							select		issr.ponum								ponum,
										issr.releasenum							releasenum,
										sum(issr.avgunitcost * issr.qty * -1)	returned
							from		issrec									issr
							where		issr.transtype		= 'RV'				and
										issr.issuedate 		between 'STDT' and 'ENDT'
							group by	issr.ponum, issr.releasenum
							)			rv
							on			rv.ponum			= po.ponum			and
										rv.releasenum		= po.releasenum
			left outer join	(
							select		popy.popy_pohd							ponum,
										popy.popy_rlnm							releasenum,
										sum(popy.popy_cost / popy.popy_crat)	paid
							from		st_popy									popy
							group by	popy.popy_pohd, popy.popy_rlnm
							)			py
							on			py.ponum			= po.ponum			and
										py.releasenum		= po.releasenum
where		po.purchasingcenterid	= 'SITE'
)

go
