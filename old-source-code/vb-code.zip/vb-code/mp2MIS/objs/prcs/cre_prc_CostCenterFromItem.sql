drop function CostcenterFromItem

go


create function CostcenterFromItem
	(
	@p_item_in		varchar(25)
	)
	returns 	varchar(15)
as
begin

	declare @v_costcenter			varchar(15)
	
	select	top 1
			@v_costcenter				= costcenter
	from	invy
	where	@p_item_in	= itemnum

	return @v_costcenter

end

go
