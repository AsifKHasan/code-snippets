drop function CostcenterFromWO

go


create function CostcenterFromWO
	(
	@p_wonum_in			varchar(10),
	@p_itemnum_in		varchar(25)
	)
	returns 	varchar(15)
as
begin
	declare @v_costcenter	varchar(15)
	declare @v_ityp			varchar(6)
	declare @v_dept			varchar(10)
	declare @v_psys			varchar(20)
	declare @v_eqnum		varchar(30)
	

	/*
		GET THE EQUIPMENT FROM WOEQLIST WITH COSTCTR, LOCATION ETC
	*/
	select 	top 1
			@v_eqnum			= eqnum,
			@v_costcenter		= costcenter
	from 	woeqlist 
	where 	wonum 				= @p_wonum_in
	
	/*
		SEE IF THE WO HAS A COSTCENTER WHICH IS NOT TIED UP WITH ANY DEPT THEN RETURN IT
	*/
	if not @v_costcenter is null
	begin
		select	top 1
				@v_dept				= dept
		from	st_deptcc
		where	costcenter			= @v_costcenter

		if @v_dept is null
		begin
			goto exitline
		end
	end



	if @v_eqnum = '-'
	/*
		LOCATION BASED, GET COSTCENTER FROM LOCATION
	*/
	begin
		goto exitline
	end
	else
	/*
		EQUIPMENT BASED, GET DEPT AND PARENTSYS
	*/
	begin
		select	@v_dept			= dept,
				@v_psys			= ud5
		from	equip
		where	@v_eqnum		= eqnum
		
		/*
			IF ITEM IS '-' THEN SERVICE ELSE GET ITEMTYPE 
		*/
		if @p_itemnum_in = '-'
		begin
			/*
				SERVICE, GET FROM DEPTCC 
			*/
			select	@v_costcenter		= costcenter
			from	st_deptcc
			where	@v_dept				= dept			and
					psys				is null			and
					ityp				is null
		end
		else
		begin
			/*
				ITEM BASED, GET ITEMTYPE, GET FROM DEPTCC 
			*/
			select	@v_ityp				= type
			from	invy
			where	@p_itemnum_in		= itemnum

			select	@v_costcenter		= costcenter
			from	st_deptcc
			where	@v_dept				= dept			and
					@v_psys				= psys			and
					@v_ityp				= ityp

			if 	@v_costcenter is null 
			begin
				select	@v_costcenter	= costcenter
				from	st_deptcc
				where	@v_dept			= dept			and
						@v_ityp			= ityp
			end
		end
		

		goto exitline
	end

	return @v_costcenter

exitline:
	return @v_costcenter
end

go
