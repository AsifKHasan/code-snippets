drop function DeptFromCostcenter

go


create function DeptFromCostcenter
	(
	@p_costcenter_in		varchar(15)
	)
	returns 	varchar(10)
as
begin

	declare @v_dept			varchar(10)
	
	select	top 1
			@v_dept				= dept
	from	st_deptcc
	where	@p_costcenter_in	= costcenter

	return @v_dept

end

go
