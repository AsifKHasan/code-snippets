drop function CostcenterFromEQ

go


create function CostcenterFromEQ
	(
	@p_eqnum_in			varchar(10),
	@p_itemnum_in		varchar(25)
	)
	returns 	varchar(15)
as
begin
	declare @v_costcenter	varchar(15)
	declare @v_ityp			varchar(6)
	declare @v_dept			varchar(10)
	declare @v_psys			varchar(20)
	declare @v_location		varchar(30)
	declare @v_sublocation1	varchar(30)
	declare @v_sublocation2	varchar(30)
	declare @v_sublocation3	varchar(30)


	if @p_eqnum_in = '-'
	/*
		LOCATION BASED, GET COSTCENTER FROM LOCATION
	*/
	begin
		select	@v_costcenter	= costcenter
		from	location
		where	@v_sublocation1	= sublocation1	and 
				@v_sublocation2	= sublocation2	and 
				@v_sublocation3	= sublocation3 
		
		goto exitline
	end
	else
	/*
		EQUIPMENT BASED, GET DEPT AND PARENTSYS
	*/
	begin
		select	@v_dept			= dept,
				@v_psys			= ud5
		from	equip
		where	@p_eqnum_in		= eqnum
		
		/*
			IF ITEM IS '-' THEN SERVICE ELSE GET ITEMTYPE 
		*/
		if @p_itemnum_in = '-'
		begin
			/*
				SERVICE, GET FROM DEPTCC 
			*/
			select	@v_costcenter		= costcenter
			from	st_deptcc
			where	@v_dept				= dept			and
					psys				is null			and
					ityp				is null
		end
		else
		begin
			/*
				ITEM BASED, GET ITEMTYPE, GET FROM DEPTCC 
			*/
			select	@v_ityp				= type
			from	invy
			where	@p_itemnum_in		= itemnum

			select	@v_costcenter		= costcenter
			from	st_deptcc
			where	@v_dept				= dept			and
					@v_psys				= psys			and
					@v_ityp				= ityp

			if 	@v_costcenter is null 
			begin
				select	@v_costcenter	= costcenter
				from	st_deptcc
				where	@v_dept			= dept			and
						@v_ityp			= ityp
			end
		end
		

		goto exitline
	end

	return @v_costcenter

exitline:
	return @v_costcenter
end

go
