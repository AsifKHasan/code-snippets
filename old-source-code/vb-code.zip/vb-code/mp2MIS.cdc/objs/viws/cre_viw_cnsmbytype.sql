/*
-- NAME		cre_viw_cnsmbytype.sql
-- LOCA		$SPECTRUM\Projects\mp2MIS\objs\viws\
-- AUTH		MEH, 2004/01/24
-- APPL		mp2MIS
-- ABBR		Consumption By Type
-- TEXT		Date to Date Inventory Consumption By Inventory Type
-- NOTE		
-- DPND		
*/


execute
(
'if exists	(
			select 	name 
			from 	sysobjects 
			where 	type like ''v'' and name like ''sv_cnsmbytype''
			) 
drop view sv_cnsmbytype'
)

go


create view	sv_cnsmbytype
			(
			invytype,
			itemnum,
			description,
			qty,
			avgcost,
			consumption
			)
as
(
select 		invytype, 
			itemnum, 
			description,
			sum(qty), 
			sum(consumption)/sum(qty), 
			sum(consumption)
from 		sv_invytrancc
where 		issuedate >= 'STDT' 	and 
			issuedate <= 'ENDT'
group by 	invytype, 
			itemnum, 
			description
having 		(sum(qty) <> 0)
)

go
