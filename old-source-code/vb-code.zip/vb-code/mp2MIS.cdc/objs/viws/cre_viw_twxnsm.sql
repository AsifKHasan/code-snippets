/*
-- NAME		cre_viw_twxnsm.sql
-- LOCA		$SPECTRUM\Projects\mp2MIS\objs\viws\
-- AUTH		MEH, 2004/03/24
-- APPL		mp2MIS
-- ABBR		Typewise Inventory Transaction Summary
-- TEXT		Typewise Inventory Transaction Summary
-- NOTE		
-- DPND		st_intr
*/


execute
(
'if exists	(
			select 	name 
			from 	sysobjects 
			where 	type like ''v'' and name like ''sv_twxnsm''
			) 
drop view sv_twxnsm'
)

go


create view	sv_twxnsm	
			(
			twxnsm_ityp,
			twxnsm_opbl,
			twxnsm_inin,
			twxnsm_inot,
			twxnsm_prin,
			twxnsm_prot,
			twxnsm_sadj,
			twxnsm_qrcv,
			twxnsm_pinv
			)
as
(
select		itemtype,
			sum(opening * mp2mis),
			sum(inin * mp2mis),
			sum(inot * mp2mis),
			sum(prin * mp2mis),
			sum(prot * mp2mis),
			sum(sadj * mp2mis),
			sum(qrcv * mp2mis),
			sum(pinv * mp2mis)
from		sv_intr
group by	itemtype
)

go
