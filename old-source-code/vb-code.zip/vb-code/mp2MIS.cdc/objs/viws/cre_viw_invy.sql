/*
-- NAME		cre_viw_invy.sql
-- LOCA		$SPECTRUM\Projects\mp2MIS\objs\viws\
-- AUTH		MEH, 2004/01/27
-- APPL		mp2MIS
-- ABBR		Inventory
-- TEXT		view to get full information about an item
-- NOTE		
-- DPND		INVY, STOCK, INVCOST
*/

execute
(
'if exists	(
		select 	name 
		from 	sysobjects 
		where 	type like ''v'' and name like ''sv_invy''
		) 
drop view sv_invy'
)

go


create view	sv_invy
		(
		itemnum, 
		itemtype,
		description, 
		qtyonhand, 
		mp2unitcost, 
		mp2basecost, 
		unitname
		) 
as
(
select  i.itemnum					itemnum,
		i.type						itemtype,
		i.description				description,
		isnull(s.qtyonhand, 0)		qtyonhand,
		isnull(c.unitcost, 0)		mp2unitcost,
		isnull(c.basecost, 0)		mp2basecost,
		i.uom						unitname
from    invy 						i 	
		left outer join
					(
					select 		stock.itemnum, round(sum(stock.qtyonhand),2) as qtyonhand
					from 		stock 		stock
					where		stock.warehouseid	= 'Meghnaghat'
					group by 	stock.itemnum
					)			s 	
					on i.itemnum 	= s.itemnum  
		left outer join
					invcost 	c 
					on i.itemnum = c.itemnum and c.warehouseid = 'Meghnaghat'
)

go
