create view	sv_tranbycc
			(
			dept,
			costcenter,
			itemnum,
			description,
			qty,
			avgcost,
			consumption
			)
as
(
select 		dbo.DeptFromCostcenter(costcenter),
			costcenter, 
			itemnum, 
			description,
			sum(qty), 
			sum(consumption)/sum(qty), 
			sum(consumption)
from 		sv_invytrancc
where 		issuedate >= 'STDT' 	and 
			issuedate <= 'ENDT'
group by 	dbo.DeptFromCostcenter(costcenter), 
			costcenter, 
			itemnum, 
			description
having 		(sum(qty) <> 0)
)
