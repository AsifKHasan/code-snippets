/*
-- NAME		cre_viw_pord.sql
-- LOCA		$SPECTRUM\Projects\mp2MIS\objs\viws\
-- AUTH		MEH, 2004/01/22
-- APPL		mp2MIS
-- ABBR		Purchase Orders
-- TEXT		Transpotation Charge  
-- NOTE		
-- DPND		POHEADER
*/


execute
(
'if exists	(
			select 	name 
			from 	sysobjects 
			where 	type like ''v'' and name like ''sv_pord''
			) 
drop view sv_pord'
)

go


create view	sv_pord	
			(	
			ponum,
			releasenum,
			closedate,
			status,
			potype,
			vendorbranchid,
			totalshippingcharge,
			misccharge,
			mp2currency,
			exchangerate,
			orderdate,
			purchasingcenterid,
			totalreceivedprice,
			paid,
			totalitemprice
			)
as
select		po.ponum,
			po.releasenum,
			po.closedate,
			po.status,
			po.potype,
			vn.name,
			isnull(po.totalshippingcharge, 0.0),
			isnull(po.misccharge, 0.0),
			isnull(po.mp2currency, 'USD'),
			isnull(po.exchangerate, 1.0),
			po.orderdate,
			po.purchasingcenterid,
			isnull(po.totalreceivedprice, 0.0),
			isnull(po.paid, 0.0),
			isnull(pi.total, 0.0)
from		VENDOR		vn,
			POHEADER	po
			right join	(
						select		purq.ponum								ponum,
									purq.releasenum							releasenum,
									sum(purq.unitcost * purq.qtyrequested)	total,
									sum(purq.unitcost * purq.qtyreceived)	received
						from		sv_purq									purq
						group by	purq.ponum, 
									purq.releasenum
						)			pi
						on			pi.ponum			= po.ponum	and
									pi.releasenum		= po.releasenum
where		po.vendorbranchid		= vn.vendorbranchid	
			and			
			po.status				<> 'Closed'	and
			po.purchasingcenterid	= 'Meghnaghat'

go
