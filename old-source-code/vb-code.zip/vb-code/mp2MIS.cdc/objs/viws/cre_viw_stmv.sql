/*
-- NAME		sv_viw_stmv.sql
-- LOCA		$SPECTRUM\Projects\mp2MIS\objs\viws\
-- AUTH		MEH, 2004/03/11
-- APPL		mp2MIS
-- ABBR		Store Movement
-- TEXT		view to get top 1 item quantity  for stock movement
-- NOTE		
-- DPND		issrec
*/


execute
(
'if exists	(
			select 	name 
			from 	sysobjects 
			where 	type like ''v'' and name like ''sv_stmv''
			) 
drop view sv_stmv'
)

go


create view	sv_stmv
			(
			itemnum, 
			issuedate,
			issuetime, 
			qty 
			) 
as
(
select 		itemnum,
			issuedate,
			issuetime,
			qty
from		issrec	i1
where		i1.transtype = 'MV'		and
			dateadd(ss, datepart(hh, i1.issuetime) * 3600 + datepart(mi, i1.issuetime) * 60 + datepart(ss, i1.issuetime), i1.issuedate) 	<=
			(
			select				min(dateadd(ss, datepart(hh, i2.issuetime) * 3600 + datepart(mi, i2.issuetime) * 60 + datepart(ss, i2.issuetime), i2.issuedate))
			from				issrec 		i2
			where				i2.itemnum 	= i1.itemnum	
			)
)

go
