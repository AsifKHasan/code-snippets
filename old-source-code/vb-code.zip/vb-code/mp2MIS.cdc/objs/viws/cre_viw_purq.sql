/*
-- NAME		cre_viw_purq.sql
-- LOCA		$SPECTRUM\Projects\mp2MIS\objs\viws\
-- AUTH		MEH, 2004/01/28
-- APPL		mp2MIS
-- ABBR		Vendor Information
-- TEXT		Vendor Info  
-- NOTE		
-- DPND		PURREQ
*/


execute
(
'if exists	(
			select 	name 
			from 	sysobjects 
			where 	type like ''v'' and name like ''sv_purq''
			) 
drop view sv_purq'
)

go


create view	sv_purq	
			(
			seqnum,
			closedate,
			itemnum,
			orderwarehouse,
			invytype, 
			itemtype,
			descriptiononpo,
			qtyrequested,
			qtyreceived,
			dategenerated,
			unitname,
			requisitionnum,
			ponum,
			releasenum,
			unitcost,
			unitcostmc,
			total, 
			vendorbranchid,
			receiveto,
			destid,
			lastmodifiedbytime,
			itemstatus,
			purchasingcenterid
			)
as
select		p.seqnum,
			p.closedate,
			p.itemnum,
			p.orderwarehouse,
			p.invytype, 
			p.itemtype,
			p.descriptiononpo,
			p.qtyrequested,
			p.qtyreceived,
			p.dategenerated,
			p.uom,
			p.requisitionnum,
			p.ponum,
			p.releasenum,
			p.unitcost,
			p.unitcostmc,
			p.total, 
			v.name,
			p.receiveto,
			p.destid,
			p.lastmodifiedbytime,
			p.itemstatus,
			p.purchasingcenterid
from		PURREQ		p
			left outer join
			VENDOR		v
			on			where		p.vendorbranchid	= v.vendorbranchid	

go
