execute
(
'if exists	(
			select 	name 
			from 	sysobjects 
			where 	type like ''v'' and name like ''sv_porecv''
			) 
drop view sv_porecv'
)

go

create view sv_porecv
			(
			ponum,
			releasenum,
			potype,
			status,
			orderdate,
			vendorbranchid,
			itemtotal,
			total,
			received,
			returned
			)
as
(
select		po.ponum,
			po.releasenum,
			po.potype,
			po.status,
			po.orderdate,
			po.vendorbranchid,
			po.subtotal,
			po.subtotal + isnull(po.totalshippingcharge, 0) + isnull(po.misccharge, 0),
			isnull(pr.received, 0),
			isnull(rv.returned, 0)
from		poheader		po
			right join		(
							select		issr.ponum								ponum,
										issr.releasenum							releasenum,
										sum(issr.avgunitcost * issr.qty)		received
							from		issrec									issr
							where		issr.transtype		= 'PR'				and
										issr.issuedate 		between '01/01/2004' and '04/01/2004'
							group by	issr.ponum, issr.releasenum
							)			pr
							on			pr.ponum			= po.ponum			and
										pr.releasenum		= po.releasenum
			left outer join	(
							select		issr.ponum								ponum,
										issr.releasenum							releasenum,
										sum(issr.avgunitcost * issr.qty * -1)	returned
							from		issrec									issr
							where		issr.transtype		= 'RV'				and
										issr.issuedate 		between '01/01/2004' and '04/01/2004'
							group by	issr.ponum, issr.releasenum
							)			rv
							on			rv.ponum			= po.ponum			and
										rv.releasenum		= po.releasenum
where		po.purchasingcenterid	= 'Meghnaghat'
)

go
