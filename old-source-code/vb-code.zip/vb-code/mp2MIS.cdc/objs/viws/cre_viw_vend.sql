/*
-- NAME		cre_viw_vend.sql
-- LOCA		$SPECTRUM\Projects\mp2MIS\objs\viws\
-- AUTH		MEH, 2004/01/24
-- APPL		mp2MIS
-- ABBR		Vendor Information
-- TEXT		Vendor Info  
-- NOTE		
-- DPND		VENDOR
*/


execute
(
'if exists	(
			select 	name 
			from 	sysobjects 
			where 	type like ''v'' and name like ''sv_vend''
			) 
drop view sv_vend'
)

go


create view	sv_vend	
			(	
			vendorbranchid,
			name,
			addr1,
			addr2
			)
as
select		vendorbranchid,
			name,
			addr1,
			addr2
from		VENDOR	

go
