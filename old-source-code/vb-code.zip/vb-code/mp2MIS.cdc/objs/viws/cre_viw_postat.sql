execute
(
'if exists	(
			select 	name 
			from 	sysobjects 
			where 	type like ''v'' and name like ''sv_postat''
			) 
drop view sv_postat'
)

go

create view sv_postat
			(
			ponum,
			releasenum,
			potype,
			status,
			orderdate,
			vendorbranchid,
			total,
			received,
			paid,
			due,
			paymentdue
			)
as
(
select		po.ponum,
			po.releasenum,
			po.potype,
			po.status,
			po.orderdate,
			po.vendorbranchid,
			pi.total + po.totalshippingcharge + po.misccharge,
			pi.received * ( 1 + (po.totalshippingcharge + po.misccharge)/pi.total),
			po.paid,
			(pi.total + po.totalshippingcharge + po.misccharge) - (pi.received * ( 1 + (po.totalshippingcharge + po.misccharge)/pi.total)),
			(pi.total + po.totalshippingcharge + po.misccharge - po.paid)
from		sv_pord		po
			right join	(
						select		purq.ponum								ponum,
									purq.releasenum							releasenum,
									sum(purq.unitcost * purq.qtyrequested)	total,
									sum(purq.unitcost * purq.qtyreceived)	received
						from		sv_purq									purq
						group by	purq.ponum, purq.releasenum
						)			pi
						on			pi.ponum			= po.ponum	and
									pi.releasenum		= po.releasenum
where		po.status				<> 'Closed'			and
			po.potype				is not null			and
			po.purchasingcenterid	= 'Meghnaghat'
)

go
