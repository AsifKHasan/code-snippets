/*
-- NAME		sv_viw_invytrancc.sql
-- LOCA		$SPECTRUM\Projects\mp2MIS\objs\viws\
-- AUTH		MEH, 2004/01/27
-- APPL		mp2MIS
-- ABBR		Inventory Transaction
-- TEXT		view to get full information about an item
-- NOTE		
-- DPND		ISSREC, WOEQLIST
*/

execute
(
'if exists	(
			select 	name 
			from 	sysobjects 
			where 	type like ''v'' and name like ''sv_invytrancc''
			) 
drop view sv_invytrancc'
)

go

create	view sv_invytrancc
		(
		serialnum,
		costcenter,
		transtype,
		itemnum,
		invytype,
		itemtype,
		description,
		issuedate,
		qty,
		mp2unitcost,
		avgunitcost,
		consumption
		)
as
(
select	i.serialnum,
		i.numchargedto, 
		i.transtype,
		i.itemnum, 	
		i.invytype,
		i.itemtype,
		i.description,	
		i.issuedate, 
		i.qty * -1, 	
		i.avgunitcost,
		isnull(ic.icst_cost, i.avgunitcost),	
		isnull(ic.icst_cost, i.avgunitcost) * (i.qty * -1)
from 	sv_issr		i
		left outer join (
						select  	icst.icst_item		itemnum,
									icst.icst_cost  	icst_cost
						from 		st_icst 	icst 
						) 			ic 
						on i.itemnum 	= ic.itemnum 
where 	i.chargeto 		= 'CostCenter' 		and 
		i.transtype 	in ('IC', 'IR')
union
select 	i.serialnum,
		dbo.CostcenterFromWO(i.numchargedto, i.itemnum),
		i.transtype,
		i.itemnum, 	
		i.invytype,
		i.itemtype,
		i.description,	
		i.issuedate, 
		i.qty * -1, 	
		i.avgunitcost,
		isnull(ic.icst_cost, i.avgunitcost),	
		isnull(ic.icst_cost, i.avgunitcost) * (i.qty * -1)
from 	sv_issr 		i 
		left outer join (
						select  	icst.icst_item		itemnum,
									icst.icst_cost  	icst_cost
						from 		st_icst 	icst 
						) 			ic 
						on i.itemnum 	= ic.itemnum 
where 	i.chargeto 		= 'WorkOrder' 		and 
		i.transtype 	in ('IC', 'IR')	
)

go
