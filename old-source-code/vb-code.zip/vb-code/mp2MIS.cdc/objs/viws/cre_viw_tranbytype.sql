/*
-- NAME		cre_viw_tranbytype.sql
-- LOCA		$SPECTRUM\Projects\mp2MIS\objs\viws\
-- AUTH		MEH, 2004/01/24
-- APPL		mp2MIS
-- ABBR		Vendor Information
-- TEXT		Vendor Info  
-- NOTE		
-- DPND		
*/


execute
(
'if exists	(
			select 	name 
			from 	sysobjects 
			where 	type like ''v'' and name like ''sv_tranbytype''
			) 
drop view sv_tranbytype'
)

go


create view	sv_tranbytype
		(
		itemnum,
		description,
		transtype, 
		qty, 
		reason, 
		avgunitcost,
		mp2unitcost,
		mp2basecost,
		issuedate, 
		unitname, 
		chargeto, 
		numchargedto,
		mp2misunitcost,
		mp2mistotal
		)
as
select	i.itemnum,
		i.description,
		i.transtype, 
		i.qty, 
		i.reason, 
		i.avgunitcost, 
		i.mp2unitcost, 
		i.mp2basecost, 
		i.issuedate, 
		i.unitname, 
		i.chargeto, 
		i.numchargedto,
		isnull(ic.icst_cost, i.avgunitcost),
		isnull(ic.icst_cost, i.avgunitcost) * i.qty
from	dbo.sv_issr		i
		left outer join (
						select  	icst.icst_item		itemnum,
									icst.icst_cost  	icst_cost
						from 		st_icst 	icst 
						) 			ic 
						on i.itemnum 	= ic.itemnum 
where	(issuedate >= 'STDT') and (issuedate <= 'ENDT') 
		and 
		(transtype IN (TTYP))

go
