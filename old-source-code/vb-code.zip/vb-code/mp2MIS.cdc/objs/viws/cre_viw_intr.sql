/*
-- NAME		sv_viw_intr.sql
-- LOCA		$SPECTRUM\Projects\mp2MIS\objs\viws\
-- AUTH		MEH, 2004/01/27
-- APPL		mp2MIS
-- ABBR		Inventory Transaction
-- TEXT		view to get full information about an item
-- NOTE		
-- DPND		INVY, STOCK, INVCOST, sv_issr
*/

execute
(
'if exists	(
			select 	name 
			from 	sysobjects 
			where 	type like ''v'' and name like ''sv_intr''
			) 
drop view sv_intr'
)

go


create view	sv_intr
			(
			itemnum, 
			itemtype, 
			description, 
			qtyonhand, 
			mp2unitcost, 
			mp2basecost, 
			unitname, 
			opening, 
			inin, 
			inot, 
			prin, 
			prot, 
			sadj, 
			pinv, 
			qrcv, 
			mp2mis
			) 
as  
(
select 		i.itemnum 										itemnum,
			i.type 											itemtype,
			i.description 									description,
			isnull(s.qtyonhand, 0) 							qtyonhand,
			isnull(c.unitcost, 0) 							mp2unitcost,
			isnull(c.basecost, 0) 							mp2basecost,
			i.uom  											unitname,
			isnull(op.opening,0)+ isnull(mv.movement,0) 	opening,
			isnull(ir.inin,0) 								inin,
			isnull(ic.inot,0) 								inot,
			(isnull(pr.prin,0) - isnull(pf.prad,0))			prin,
			(isnull(rv.prot,0) - isnull(rf.rvad,0))			prot,
			isnull(sa.sadj,0) 								sadj, 
			isnull(pi.pinv,0) 								pinv, 
			isnull(qr.qrcv,0) 								qrcv, 
			isnull(mp.icst_cost, c.unitcost) 				mp2mis  
from 		invy 											i 
			left outer join (
							select 		stock.itemnum, round(sum(stock.qtyonhand),2) as qtyonhand 
							from 		stock stock  
							where 		stock.warehouseid = 'SITE' 
							group by 	stock.itemnum
							) 			s 
							on i.itemnum  	= s.itemnum  
			left outer join invcost 	c 
							on i.itemnum 	= c.itemnum 	and 	c.warehouseid 	= 'SITE' 
			left outer join (
							select  	icst.icst_item		itemnum,
										icst.icst_cost  	icst_cost
							from 		st_icst 	icst 
							) 			mp 
							on i.itemnum 	= mp.itemnum 
			left outer join (
							select 		issr.itemnum, sum(issr.qty) 	as opening 	
							from 		sv_issr issr 
							where 		issr.issuedate <= '04/28/2004' 	
										and 
										issr.transtype in ('IR', 'IC', 'PR', 'RV', 'SA', 'QR', 'PI', 'RF', 'PF') 
										and
										not
										(
										issr.transtype			in ('PR', 'RV')	and
										issr.chargeto			<> 'Stock'
										)										
							group by 	issr.itemnum
							) 			op 
							on i.itemnum = op.itemnum 
			left outer join (select issr.itemnum, sum(issr.qty) 	as inin 	from sv_issr issr where issr.issuedate >= '04/28/2004' and issr.issuedate <= '04/28/2004' and issr.transtype = 'IR' group by issr.itemnum) ir on i.itemnum = ir.itemnum 
			left outer join (select issr.itemnum, sum(issr.qty) 	as inot 	from sv_issr issr where issr.issuedate >= '04/28/2004' and issr.issuedate <= '04/28/2004' and issr.transtype = 'IC' group by issr.itemnum) ic on i.itemnum = ic.itemnum 
			left outer join (select issr.itemnum, sum(issr.qty) 	as prin 	from sv_issr issr where issr.issuedate >= '04/28/2004' and issr.issuedate <= '04/28/2004' and issr.transtype = 'PR' and issr.chargeto <> 'Stock' group by issr.itemnum) pr on i.itemnum = pr.itemnum 
			left outer join (select issr.itemnum, sum(issr.qty) 	as prad 	from sv_issr issr where issr.issuedate >= '04/28/2004' and issr.issuedate <= '04/28/2004' and issr.transtype = 'PF' group by issr.itemnum) pf on i.itemnum = pf.itemnum 
			left outer join (select issr.itemnum, sum(issr.qty) 	as prot 	from sv_issr issr where issr.issuedate >= '04/28/2004' and issr.issuedate <= '04/28/2004' and issr.transtype = 'RV' and issr.chargeto <> 'Stock' group by issr.itemnum) rv on i.itemnum = rv.itemnum 
			left outer join (select issr.itemnum, sum(issr.qty) 	as rvad 	from sv_issr issr where issr.issuedate >= '04/28/2004' and issr.issuedate <= '04/28/2004' and issr.transtype = 'RF' group by issr.itemnum) rf on i.itemnum = rf.itemnum 
			left outer join (select issr.itemnum, sum(issr.qty) 	as sadj 	from sv_issr issr where issr.issuedate >= '04/28/2004' and issr.issuedate <= '04/28/2004' and issr.transtype = 'SA' group by issr.itemnum) sa on i.itemnum = sa.itemnum 
			left outer join (select issr.itemnum, sum(issr.qty) 	as pinv 	from sv_issr issr where issr.issuedate >= '04/28/2004' and issr.issuedate <= '04/28/2004' and issr.transtype = 'PI' group by issr.itemnum) pi on i.itemnum = pi.itemnum 
			left outer join (select issr.itemnum, sum(issr.qty) 	as qrcv 	from sv_issr issr where issr.issuedate >= '04/28/2004' and issr.issuedate <= '04/28/2004' and issr.transtype = 'QR' group by issr.itemnum) qr on i.itemnum = qr.itemnum  
			left outer join (select stmv.itemnum, stmv.qty 			as movement from sv_stmv stmv) mv on i.itemnum = mv.itemnum 
)

go
