-- /*
-- NAME		cre_viwss.sql
-- LOCA		$SPECTRUM\Projects\mp2MIS\objs\tbls\
-- AUTH		MEH, 2004/01/28
-- APPL		mp2MIS
-- ABBR		Transpotation Summary 
-- TEXT		
-- NOTE		
-- */


cre_viw_vend.sql
cre_viw_pord.sql
cre_viw_purq.sql
cre_viw_invy.sql
cre_viw_issr.sql
cre_viw_stmv.sql
cre_viw_intr.sql

cre_viw_twxnsm.sql
