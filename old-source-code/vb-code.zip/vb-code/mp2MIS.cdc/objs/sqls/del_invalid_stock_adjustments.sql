
delete
from		issrec
where		issrec.transtype 	= 'SA'		and
		issrec.qty		< 0		and
		dateadd(ss, datepart(hh, issrec.issuetime) * 3600 + datepart(mi, issrec.issuetime) * 60 + datepart(ss, issrec.issuetime), issrec.issuedate) 	<=
		(
		select				min(dateadd(ss, datepart(hh, i2.issuetime) * 3600 + datepart(mi, i2.issuetime) * 60 + datepart(ss, i2.issuetime), i2.issuedate))
		from				issrec 		i2
		where				i2.itemnum 	= issrec.itemnum	
		)
