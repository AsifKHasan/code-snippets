update 	sv_issr 
set 	qty	= qty * -1 
where 	transtype in ('IC','RV')	and
	qty 	< 0

go


select itemnum, description, qtyonhand, opening from sv_intr where qtyonhand <> opening

select itemnum, description, qtyonhand, opening from sv_intr where round(qtyonhand, 2) <> round(opening, 2)