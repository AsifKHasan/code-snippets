select itemnum, description, qtyonhand, opening from sv_intr where round(qtyonhand, 2) <> round(opening, 2) order by itemnum


/* AC-CW-M-CT-01--NZZL-01
*/
update	issrec
set	issuedate 	= '3/18/2003'
where	itemnum 	= 'AC-CW-M-CT-01--NZZL-01'	and
	issuedate	= '3/19/2003'			and
	transtype	= 'MV'



/* CHEM-AMINE-01
*/
update	issrec
set	issuedate 	= '3/28/2003'
where	itemnum 	= 'CHEM-AMINE-01'	and
	issuedate	= '4/3/2003'		and
	transtype	= 'MV'


/* CHEM-AMINE-02
*/
update	issrec
set	issuedate 	= '3/28/2003'
where	itemnum 	= 'CHEM-AMINE-02'	and
	issuedate	= '4/3/2003'		and
	transtype	= 'MV'


/* CHEM-BD1500
*/
update	issrec
set	qty 		= 5.0
where	itemnum 	= 'CHEM-BD1500'		and
	issuedate	= '3/19/2003'		and
	transtype	= 'MV'


/* CHEM-BL5323
*/
update	issrec
set	qty 		= 300.0
where	itemnum 	= 'CHEM-BL5323'		and
	issuedate	= '3/19/2003'		and
	transtype	= 'MV'


/* CHEM-CT1300
*/
update	issrec
set	qty 		= 60.0
where	itemnum 	= 'CHEM-CT1300'		and
	issuedate	= '3/19/2003'		and
	transtype	= 'MV'


/* CHEM-H2SO4-01
*/
update	issrec
set	issuedate 	= '03/19/2003'
where	itemnum 	= 'CHEM-H2SO4-01'	and
	issuedate	= '03/18/2003'		and
	transtype	= 'SA'


/* CHEM-MS6209
*/
update	issrec
set	qty 		= 300.0
where	itemnum 	= 'CHEM-MS6209'		and
	issuedate	= '3/19/2003'		and
	transtype	= 'MV'


/* CHEM-NaOH-01
*/
update	issrec
set	issuedate 	= '03/20/2003'
where	itemnum 	= 'CHEM-NaOH-01'	and
	issuedate	= '03/19/2003'		and
	transtype	= 'SA'


/* CHEM-NX-1106
*/
delete	
from	issrec
where	itemnum 	= 'CHEM-NX-1106'	and
	issuedate	= '4/5/2003'		and
	transtype	= 'SA'


/* CNSM-BAR-COPPER-1-01
*/
delete	
from	issrec
where	itemnum 	= 'CNSM-BAR-COPPER-1-01'	and
	issuedate	= '2/23/2003'			and
	transtype	= 'IC'


/* CNSM-BAR-TEFLON-1-01
*/
delete	
from	issrec
where	itemnum 	= 'CNSM-BAR-TEFLON-1-01'	and
	issuedate	= '2/25/2003'			and
	transtype	= 'IC'


/* CNSM-BAR-TEFLON-1.5-01
*/
delete	
from	issrec
where	itemnum 	= 'CNSM-BAR-TEFLON-1.5-01'	and
	issuedate	= '2/23/2003'			and
	transtype	in ('IC', 'IR')




/* CNSM-BRUSH-PAINT-03
*/
update	issrec
set	qty		= 6.00
where	itemnum 	= 'CNSM-BRUSH-PAINT-03'	and
	issuedate	= '5/11/2003'		and
	transtype	= 'SA'


/* CNSM-HOSE-05
*/
delete	
from	issrec
where	itemnum 	= 'CNSM-HOSE-05'	and
	issuedate	= '3/14/2004'		and
	transtype	= 'PI'


/* CNSM-HKIP-BRUSH-02
*/
update	issrec
set	issuedate	= '5/10/2003'
where	itemnum 	= 'CNSM-HKIP-BRUSH-02'	and
	issuedate	= '5/11/2003'		and
	transtype	= 'MV'


/* CNSM-HKIP-MOP-02
*/
update	issrec
set	issuedate	= '5/10/2003'
where	itemnum 	= 'CNSM-HKIP-MOP-02'	and
	issuedate	= '5/11/2003'		and
	transtype	= 'MV'




/* CNSM-WSHR-10
*/
update	issrec
set	issuedate	= '5/16/2003'
where	itemnum 	= 'CNSM-WSHR-10'	and
	issuedate	= '5/17/2003'		and
	transtype	= 'MV'


/* DC-I-SYS--DPU4E-01
*/
update	issrec
set	qty		= 2.0,
	issuedate	= '3/30/2003'
where	itemnum 	= 'DC-I-SYS--DPU4E-01'	and
	issuedate	= '4/16/2003'		and
	transtype	= 'MV'


/* WT-M-TK-09--BOLT-02
*/
update	issrec
set	issuedate	= '3/14/2003'
where	itemnum 	= 'WT-M-TK-09--BOLT-02'	and
	issuedate	= '3/15/2003'		and
	transtype	= 'MV'



/* WT-M-DD--RESN-03
*/
delete	
from	issrec
where	itemnum 	= 'WT-M-DD--RESN-03'	and
	issuedate	= '3/18/2003'		and
	transtype	= 'SA'


/* WI-CW-M-TS-01--BUSH-01
*/
delete	
from	issrec
where	itemnum 	= 'WI-CW-M-TS-01--BUSH-01'	and
	issuedate	= '3/19/2003'			and
	transtype	= 'MV'				and
	qty		= 3.0


/* EE-CP-E-AN-01--DIOD-01
*/
delete	
from	issrec
where	itemnum 	= 'EE-CP-E-AN-01--DIOD-01'	and
	issuedate	= '4/2/2003'			and
	transtype	= 'SA'


/* EE-CP-E-AN-01--FUSE-06
*/
delete	
from	issrec
where	itemnum 	= 'EE-CP-E-AN-01--FUSE-06'	and
	issuedate	= '3/20/2003'			and
	transtype	= 'MV'



/* EE-CP-E-AN-01--LAMP-06
*/
update	issrec
set	issuedate	= '3/19/2003'
where	itemnum 	= 'EE-CP-E-AN-01--LAMP-06'	and
	issuedate	= '3/20/2003'			and
	transtype	= 'MV'



/* HG-CF-M-TK-03--BOLT-01
*/
update	issrec
set	qty		= 56
where	itemnum 	= 'HG-CF-M-TK-03--BOLT-01'	and
	issuedate	= '2/2/2003'			and
	transtype	= 'SA'


/* ST-CN-M-CN-01--BALL-01
*/
update	issrec
set	issuedate	= '3/16/2003',
	qty		= 4300
where	itemnum 	= 'ST-CN-M-CN-01--BALL-01'	and
	issuedate	= '3/18/2003'			and
	transtype	= 'MV'


/* ST-CN-M-CN-01--BALL-02
*/
update	issrec
set	qty		= 4400
where	itemnum 	= 'ST-CN-M-CN-01--BALL-02'	and
	issuedate	= '3/18/2003'			and
	transtype	= 'SA'





