-- /*
-- NAME		cre_tbl_popy.sql
-- LOCA		$SPECTRUM\Projects\mp2MIS\objs\tbls\
-- AUTH		MEH, 2004/01/22
-- APPL		mp2MIS
-- ABBR		PO PaYment
-- TEXT		Purchase Order payment to vendor
-- NOTE		
-- COLS		oid			mp2MIS generated primary key
--			popy_pohd	PONUM from POHEADER table 
--			popy_date	payment Date
--			popy_cost	payment Amount
--			popy_curr	Currency for amount 
--			popy_crat	Currency Rate
-- */


create	table	st_popy
(
oid				varchar(24)		constraint	nn_oid_popy 		not null,
popy_pohd		varchar(20)		constraint 	nn_pohd_popy		not null,
popy_rlnm		int				constraint 	nn_rlnm_popy		not null,
popy_date		datetime		constraint	nn_date_popy 		not null,
popy_cost		money			constraint	nn_cost_popy 		not null,
popy_curr		varchar(15)		constraint	nn_curr_popy 		not null,
popy_crat		money			constraint	nn_crat_popy 		not null,
constraint 		pk_popy			primary key	(oid)
)

alter 	table	st_popy
add
constraint 		uk_pohd_rlnm_popy
unique 			(popy_pohd, popy_rlnm, popy_date)
