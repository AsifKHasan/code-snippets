-- /*
-- NAME		cre_tbl_xnhs.sql
-- LOCA		$SPECTRUM\Projects\mp2MIS\objs\tbls\
-- AUTH		MEH, 2004/01/28
-- APPL		mp2MIS
-- ABBR		Transpotation Summary 
-- TEXT		
-- NOTE		
-- COLS		oid		mp2MIS generated primary key
--		xnhs_opdt	Opening Date for Transaction
--		xnhs_cldt	Closing Date for Transaction
--		xnhs_itnm	Item Name
--		xnhs_desc	Item Description
--		xnhs_opbl	Opening Qty Balance upto First date 
--		xnhs_inin	Inventory In
--		xnhs_inot	Inventory Out
--		xnhs_prin	Purchase In
--		xnhs_prot	Purchase Out
--		xnhs_sadj	Stock Adjustment
--		xnhs_qrcv	Quick Receive In
--		xnhs_pinv	Physical Inventory
--		xnhs_clbl	Closing Balance upto Second Date
--		xnhs_mtag	Whether MP2MIS Calculated Item Cost (ig: Y/N)	
--		xnhs_ityp	Inventory Type (Chem, Mech, Elec... )
-- */


create	table	st_xnhs
(
oid		varchar(24)	constraint	nn_oid_xnhs 		not null,
xnhs_opdt	datetime	constraint 	nn_opdt_xnhs		not null,
xnhs_cldt	datetime	constraint 	nn_cldt_xnhs		not null,
xnhs_itnm	varchar(25)	constraint 	nn_itnm_xnhs		not null,
xnhs_desc	varchar(50)	constraint 	nn_desc_xnhs		not null,
xnhs_opbl	money		constraint	nn_opbl_xnhs 		not null,
xnhs_inin	money		constraint	nn_inin_xnhs 		not null,
xnhs_inot	money		constraint	nn_inot_xnhs 		not null,
xnhs_prin	money		constraint	nn_prin_xnhs 		not null,
xnhs_prot	money		constraint	nn_prot_xnhs 		not null,
xnhs_sadj	money		constraint	nn_sadj_xnhs 		not null,
xnhs_qrcv	money		constraint	nn_qrcv_xnhs 		not null,
xnhs_pinv	money		constraint	nn_pinv_xnhs 		not null,
xnhs_clbl	money		constraint	nn_clbl_xnhs 		not null,
xnhs_mp2c	money		constraint	nn_mp2c_xnhs 		not null,
xnhs_opam	money		constraint	nn_opam_xnhs 		not null,
xnhs_clam	money		constraint	nn_clam_xnhs 		not null,
xnhs_mtag	varchar(1)	constraint 	nn_mtag_xnhs		not null,
xnhs_ityp	varchar(6)	constraint 	nn_ityp_xnhs		not null
constraint 	pk_xnhs		primary key	(oid)
)

alter table	st_xnhs
add
constraint uk_opdt_cldt_itnm_xnhs
unique (xnhs_opdt, xnhs_cldt ,xnhs_itnm)
