-- /*
-- NAME		cre_tbl_poch.sql
-- LOCA		$SPECTRUM\Projects\mp2MIS\objs\tbls\
-- AUTH		MEH, 2004/01/22
-- APPL		mp2MIS
-- ABBR		Transpotation Charge Handling
-- TEXT		Purchase Order Charge 
-- NOTE		
-- COLS		oid			mp2MIS generated primary key
--			poch_pohd	PONUM from POHEADER table 
--			poch_ctap	Charges Category(C & F , Tax ...etc)
--			poch_calc	whether this charge was calculated into adjusted unit cost (Y or N)
--			poch_cost	Charge Amount
--			poch_curr	Currency for amount 
--			poch_crat	Currency Rate
--			poch_vend	Charges Vendor
--			poch_date	Charges Date
-- */


create	table	st_poch
(
oid				varchar(24)		constraint	nn_oid_poch 		not null,
poch_pohd		varchar(20)		constraint 	nn_pohd_poch		not null,
poch_rlnm		int				constraint 	nn_rlnm_poch		not null,
poch_ctap		varchar(24)		constraint 	nn_ctap_poch		not null
								constraint 	fk_ctap_poch
								references	st_ctap(oid),
poch_calc		varchar(1)		constraint	nn_calc_poch 		not null,
poch_cost		money			constraint	nn_cost_poch 		not null,
poch_curr		varchar(15)		constraint	nn_curr_poch 		not null,
poch_crat		money			constraint	nn_crat_poch 		not null,
poch_vend		varchar(80),
poch_date		datetime,
constraint 		pk_poch			primary key	(oid)
)

go
