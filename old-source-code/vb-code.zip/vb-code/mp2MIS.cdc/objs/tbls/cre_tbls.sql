-- /*
-- NAME		cre_tbls.sql
-- LOCA		$SPECTRUM\Projects\mp2MIS\objs\tbls\
-- AUTH		MEH, 2004/01/28
-- APPL		mp2MIS
-- ABBR		Transpotation Summary 
-- TEXT		
-- NOTE		
-- */


cre_tbl_deptcc.sql
cre_tbl_ctap.sql
cre_tbl_poch.sql
cre_tbl_popy.sql
cre_tbl_icst.sql
cre_tbl_icbp.sql
cre_tbl_xnhs.sql
