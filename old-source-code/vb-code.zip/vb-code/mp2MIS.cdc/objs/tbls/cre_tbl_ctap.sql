/*
-- NAME		cre_tbl_ctap.sql
-- LOCA		$SPECTRUM\Projects\mp2MIS\objs\tbls\
-- AUTH		MEH, 2004/01/22
-- APPL		mp2MIS
-- ABBR		Transpotation Charge 
-- TEXT		Transpotation Charge  
-- NOTE		
-- COLS		oid			mp2MIS generated primary key
--			ctap_name	Transpotation Charge Name
--			ctap_type	Whether this charge type is applicable for full PO value or value received
--			ctap_desc	Charges Description
*/


create	table	st_ctap
(
oid				varchar(24)	constraint	nn_oid_ctap 		not null,
ctap_name		varchar(50)	constraint 	nn_name_ctap		not null,
ctap_ctyp		varchar(4)	constraint 	nn_type_ctap		not null,
ctap_desc		varchar(50),
constraint 		pk_ctap		primary key	(oid)
)

go


alter table	st_ctap
add
constraint uk_name_ctap
unique (ctap_name)

go


insert into st_ctap values('CTAPXX20040101XXXXXXXX01'	, 'C & F Charges'	, 'Part'	, null	);
insert into st_ctap values('CTAPXX20040101XXXXXXXX02'	, 'Duty'			, 'Part'	, null	);
insert into st_ctap values('CTAPXX20040101XXXXXXXX03'	, 'Local Insurance'	, 'Part'	, null	);
insert into st_ctap values('CTAPXX20040101XXXXXXXX04'	, 'Local Handling'	, 'Part'	, null	);
insert into st_ctap values('CTAPXX20040101XXXXXXXX05'	, 'Insurance'		, 'Full'	, null	); 
insert into st_ctap values('CTAPXX20040101XXXXXXXX06'	, 'LC Commission'	, 'Full'	, null	);
insert into st_ctap values('CTAPXX20040101XXXXXXXX07'	, 'LC Amendment'	, 'Full'	, null	);
insert into st_ctap values('CTAPXX20040101XXXXXXXX08'	, 'PSI Charge'		, 'Full'	, null	);

go
