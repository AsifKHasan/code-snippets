-- /*
-- NAME		cre_tbl_icst.sql
-- LOCA		$SPECTRUM\Projects\mp2MIS\objs\tbls\
-- AUTH		MEH, 2004/02/24
-- APPL		mp2MIS
-- ABBR		(I)tem (C)ost
-- TEXT		Keeps track of calculated cost of Item 
-- NOTE		
-- COLS		oid			mp2MIS generated primary key
--			icst_item	item for which the calculation is
--			icst_mp2c	unit cost of item as calculated by mp2
--			icst_cost	actual unit cost as calculated by mp2MIS
-- */


create	table	st_icst
(
oid				varchar(24)		constraint		nn_oid_icst 		not null,
icst_item		varchar(25)		constraint 		nn_item_icst		not null,
icst_mp2c		money			constraint		nn_mp2c_icst 		not null,
icst_cost		money			constraint		nn_cost_icst 		not null,
constraint 		pk_icst			primary key		(oid)
)

go


alter table		st_icst
add
constraint 		uk_item_icst
unique 			(icst_item)

go
