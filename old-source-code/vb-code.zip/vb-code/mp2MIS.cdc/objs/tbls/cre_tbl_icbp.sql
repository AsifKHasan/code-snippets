-- /*
-- NAME		cre_tbl_icbp.sql
-- LOCA		$SPECTRUM\Projects\mp2MIS\objs\tbls\
-- AUTH		KAH, 2004/02/01
-- APPL		mp2MIS
-- ABBR		(I)tem (C)ost (B)y (P)urchase Order
-- TEXT		Keeps track of calculated cost of Item by purchase order and calculation date
-- NOTE		
-- COLS		oid			mp2MIS generated primary key 
--			icbp_seqn	PURREQ->SEQNUM
--			icbp_pohd	PONUM from POHEADER table 
--			icbp_rlnm	releasenum from POHEADER table 
--			icbp_item	item for which the calculation is
--			icbp_date	item receive date
--			icbp_qnty	quantity of item in PO on which the cost was calculated
--			icbp_mp2c	unit cost of item as calculated by mp2
--			icbp_cost	actual unit cost as calculated by mp2MIS
-- */


create	table	st_icbp
(
oid				varchar(24)		constraint		nn_oid_icbp 		not null,
icbp_seqn		int				constraint		nn_seqn_icbp 		not null,
icbp_pohd		varchar(20)		constraint 		nn_pohd_icbp		not null,
icbp_rlnm		int				constraint 		nn_rlnm_icbp		not null,
icbp_item		varchar(25)		constraint 		nn_item_icbp		not null,
icbp_date		datetime		constraint 		nn_date_icbp		not null,
icbp_qnty		float			constraint 		nn_qnty_icbp		not null,
icbp_mp2c		money			constraint		nn_mp2c_icbp 		not null,
icbp_cost		money			constraint		nn_cost_icbp 		not null,
constraint 		pk_icbp			primary key		(oid)
)

go


alter table		st_icbp
add
constraint 		uk_deqn_icbp
unique 			(icbp_seqn)

go
