-- /*
-- NAME		cre_tbl_deptcc.sql
-- LOCA		$SPECTRUM\Projects\mp2MIS\objs\tbls\
-- AUTH		MEH, 2004/02/24
-- APPL		mp2MIS
-- ABBR		DEPartmenT CostCenter
-- TEXT		Keeps track of calculated cost of Item by purchase order and calculation date
-- NOTE		
-- COLS		
-- */


create	table	st_deptcc
(
costcenter	varchar(15)	constraint 	nn_costcenter_deptcc		not null,
dept		varchar(10),
psys		varchar(20),
ityp		varchar(6)
)

go


insert into st_deptcc values('OE8332'		, null	, null	, null		);
insert into st_deptcc values('OE8737'		, null	, null	, null		);
insert into st_deptcc values('OE8740'		, null	, null	, null		);
insert into st_deptcc values('OE8750'		, null	, null	, null		);
insert into st_deptcc values('SAF002'		, null	, null	, null		);
insert into st_deptcc values('CAP-1832'		, null	, null	, null		);
insert into st_deptcc values('CAP-1870'		, null	, null	, null		);
insert into st_deptcc values('CAP-1871'		, null	, null	, null		);
insert into st_deptcc values('CAP-1876'		, null	, null	, null		);
insert into st_deptcc values('WARRANTY'		, null	, null	, null		);
insert into st_deptcc values('X-MEGHNA'		, null	, null	, null		);
insert into st_deptcc values('X-HARIPUR'	, null	, null	, null		);

insert into st_deptcc values('BOP-LB1103'	, 'BOP'	, null	, null		);
insert into st_deptcc values('BOP-MS1102'	, 'BOP'	, null	, null		);
insert into st_deptcc values('BOP-CH1000'	, 'BOP'	, null	, 'CHEM'	);
insert into st_deptcc values('BOP-OL1867'	, 'BOP'	, null	, 'LUBE'	);
insert into st_deptcc values('BOP-SP1864'	, 'BOP'	, null	, 'CONSUM'	);
insert into st_deptcc values('BOP-TL1868'	, 'BOP'	, null	, 'TOOLS'	);
insert into st_deptcc values('BOP-AC1862'	, 'BOP'	, 'AC'	, 'MECH'	);
insert into st_deptcc values('BOP-AC1863'	, 'BOP'	, 'AC'	, 'INST'	);
insert into st_deptcc values('BOP-AC1863'	, 'BOP'	, 'AC'	, 'ELEC'	);
insert into st_deptcc values('BOP-CC1862'	, 'BOP'	, 'CC'	, 'MECH'	);
insert into st_deptcc values('BOP-CC1863'	, 'BOP'	, 'CC'	, 'INST'	);
insert into st_deptcc values('BOP-CC1863'	, 'BOP'	, 'CC'	, 'ELEC'	);
insert into st_deptcc values('BOP-RS1872'	, 'BOP'	, 'LE'	, 'INST'	);
insert into st_deptcc values('BOP-SW1862'	, 'BOP'	, 'SW'	, 'MECH'	);
insert into st_deptcc values('BOP-SW1863'	, 'BOP'	, 'SW'	, 'INST'	);
insert into st_deptcc values('BOP-SW1863'	, 'BOP'	, 'SW'	, 'ELEC'	);
insert into st_deptcc values('BOP-WI1862'	, 'BOP'	, 'WI'	, 'MECH'	);
insert into st_deptcc values('BOP-WI1863'	, 'BOP'	, 'WI'	, 'INST'	);
insert into st_deptcc values('BOP-WI1863'	, 'BOP'	, 'WI'	, 'ELEC'	);
insert into st_deptcc values('BOP-WT1862'	, 'BOP'	, 'WT'	, 'MECH'	);
insert into st_deptcc values('BOP-WT1863'	, 'BOP'	, 'WT'	, 'INST'	);
insert into st_deptcc values('BOP-WT1863'	, 'BOP'	, 'WT'	, 'ELEC'	);

insert into st_deptcc values('CRE-CA1862'	, 'CRE'	, 'CA'	, 'MECH'	);
insert into st_deptcc values('CRE-CA1863'	, 'CRE'	, 'CA'	, 'INST'	);
insert into st_deptcc values('CRE-CA1863'	, 'CRE'	, 'CA'	, 'ELEC'	);
insert into st_deptcc values('CRE-FF1862'	, 'CRE'	, 'FF'	, 'MECH'	);
insert into st_deptcc values('CRE-FF1863'	, 'CRE'	, 'FF'	, 'INST'	);
insert into st_deptcc values('CRE-FF1863'	, 'CRE'	, 'FF'	, 'ELEC'	);
insert into st_deptcc values('CRE-LB1103'	, 'CRE'	, null	, null		);
insert into st_deptcc values('CRE-MS1102'	, 'CRE'	, null	, null		);
insert into st_deptcc values('CRE-OL1867'	, 'CRE'	, null	, 'LUBE'	);
insert into st_deptcc values('CRE-SP1864'	, 'CRE'	, null	, 'CONSUM'	);
insert into st_deptcc values('CRE-ST1862'	, 'CRE'	, 'ST'	, 'MECH'	);
insert into st_deptcc values('CRE-ST1863'	, 'CRE'	, 'ST'	, 'INST'	);
insert into st_deptcc values('CRE-ST1863'	, 'CRE'	, 'ST'	, 'ELEC'	);
insert into st_deptcc values('CRE-TL1868'	, 'CRE'	, null	, 'TOOLS'	);
insert into st_deptcc values('CRE-VC1862'	, 'CRE'	, 'VC'	, 'MECH'	);
insert into st_deptcc values('CRE-VC1863'	, 'CRE'	, 'VC'	, 'INST'	);
insert into st_deptcc values('CRE-VC1863'	, 'CRE'	, 'VC'	, 'ELEC'	);

insert into st_deptcc values('I&E-DC1863'	, 'I&E'	, 'DC'	, 'INST'	);
insert into st_deptcc values('I&E-EE1862'	, 'I&E'	, 'EE'	, 'MECH'	);
insert into st_deptcc values('I&E-EE1863'	, 'I&E'	, 'EE'	, 'INST'	);
insert into st_deptcc values('I&E-EE1863'	, 'I&E'	, 'EE'	, 'ELEC'	);
insert into st_deptcc values('I&E-LB1103'	, 'I&E'	, null	, null		);
insert into st_deptcc values('I&E-MC1862'	, 'I&E'	, 'MC'	, 'MECH'	);
insert into st_deptcc values('I&E-MC1863'	, 'I&E'	, 'MC'	, 'INST'	);
insert into st_deptcc values('I&E-MC1863'	, 'I&E'	, 'MC'	, 'ELEC'	);
insert into st_deptcc values('I&E-MS1102'	, 'I&E'	, null	, null		);
insert into st_deptcc values('I&E-OL1867'	, 'I&E'	, null	, 'LUBE'	);
insert into st_deptcc values('I&E-SP1864'	, 'I&E'	, null	, 'CONSUM'	);
insert into st_deptcc values('I&E-SY1862'	, 'I&E'	, 'SY'	, 'MECH'	);
insert into st_deptcc values('I&E-SY1863'	, 'I&E'	, 'SY'	, 'INST'	);
insert into st_deptcc values('I&E-SY1863'	, 'I&E'	, 'SY'	, 'ELEC'	);
insert into st_deptcc values('I&E-TL1868'	, 'I&E'	, null	, 'TOOLS'	);

insert into st_deptcc values('MMT-CR1862'	, 'MMT'	, 'CR'	, 'MECH'	);
insert into st_deptcc values('MMT-CR1863'	, 'MMT'	, 'CR'	, 'INST'	);
insert into st_deptcc values('MMT-CR1863'	, 'MMT'	, 'CR'	, 'ELEC'	);
insert into st_deptcc values('MMT-LB1103'	, 'MMT'	, null	, null		);
insert into st_deptcc values('MMT-MS1102'	, 'MMT'	, null	, null		);
insert into st_deptcc values('MMT-OL1867'	, 'MMT'	, null	, 'LUBE'	);
insert into st_deptcc values('MMT-SP1864'	, 'MMT'	, null	, 'CONSUM'	);
insert into st_deptcc values('MMT-TL1868'	, 'MMT'	, null	, 'TOOLS'	);
insert into st_deptcc values('MMT-WK1862'	, 'MMT'	, 'WK'	, 'MECH'	);
insert into st_deptcc values('MMT-WK1863'	, 'MMT'	, 'WK'	, 'INST'	);
insert into st_deptcc values('MMT-WK1863'	, 'MMT'	, 'WK'	, 'ELEC'	);

insert into st_deptcc values('PB-CH1000'	, 'PB'	, null	, 'CHEM'	);
insert into st_deptcc values('PB-DG1862'	, 'PB'	, 'DG'	, 'MECH'	);
insert into st_deptcc values('PB-DG1863'	, 'PB'	, 'DG'	, 'INST'	);
insert into st_deptcc values('PB-DG1863'	, 'PB'	, 'DG'	, 'ELEC'	);
insert into st_deptcc values('PB-FG1862'	, 'PB'	, 'FG'	, 'MECH'	);
insert into st_deptcc values('PB-FG1863'	, 'PB'	, 'FG'	, 'INST'	);
insert into st_deptcc values('PB-FG1863'	, 'PB'	, 'FG'	, 'ELEC'	);
insert into st_deptcc values('PB-GT1862'	, 'PB'	, 'GT'	, 'MECH'	);
insert into st_deptcc values('PB-GT1863'	, 'PB'	, 'GT'	, 'INST'	);
insert into st_deptcc values('PB-GT1863'	, 'PB'	, 'GT'	, 'ELEC'	);
insert into st_deptcc values('PB-HG1862'	, 'PB'	, 'HG'	, 'MECH'	);
insert into st_deptcc values('PB-HG1863'	, 'PB'	, 'HG'	, 'INST'	);
insert into st_deptcc values('PB-HG1863'	, 'PB'	, 'HG'	, 'ELEC'	);
insert into st_deptcc values('PB-LB1103'	, 'PB'	, null	, null		);
insert into st_deptcc values('PB-MS1102'	, 'PB'	, null	, null		);
insert into st_deptcc values('PB-OL1867'	, 'PB'	, null	, 'LUBE'	);
insert into st_deptcc values('PB-SP1862'	, 'PB'	, 'SP'	, 'MECH'	);
insert into st_deptcc values('PB-SP1863'	, 'PB'	, 'SP'	, 'INST'	);
insert into st_deptcc values('PB-SP1863'	, 'PB'	, 'SP'	, 'ELEC'	);
insert into st_deptcc values('PB-SP1864'	, 'PB'	, null	, 'CONSUM'	);
insert into st_deptcc values('PB-TL1868'	, 'PB'	, null	, 'TOOLS'	);

insert into st_deptcc values('SS-LB1103'	, 'SS'	, null	, null		);
insert into st_deptcc values('SS-OS8691'	, 'SS'	, null	, null		);
insert into st_deptcc values('SS-SP1864'	, 'SS'	, null	, 'CONSUM'	);

go
