create view	sv_tranbytype
		(
		itemnum,
		description,
		transtype, 
		qty, 
		reason, 
		avgunitcost,
		mp2unitcost,
		mp2basecost,
		issuedate, 
		unitname, 
		chargeto, 
		numchargedto,
		mp2misunitcost,
		mp2mistotal
		)
as
select	i.itemnum,
		i.description,
		i.transtype, 
		i.qty, 
		i.reason, 
		i.avgunitcost, 
		i.mp2unitcost, 
		i.mp2basecost, 
		i.issuedate, 
		i.unitname, 
		i.chargeto, 
		i.numchargedto,
		isnull(ic.icst_cost, i.mp2unitcost),
		isnull(ic.icst_cost, i.mp2unitcost) * i.qty
from	dbo.sv_issr		i
		left join (
						select  	icst.icst_item		itemnum,
									icst.icst_cost  	icst_cost
						from 		st_icst 	icst 
						) 			ic 
						on i.itemnum 	= ic.itemnum 
where	(issuedate >= 'STDT') and (issuedate <= 'ENDT') 
		and 
		(transtype IN (TTYP))
