create view	sv_cnsmbytype
			(
			invytype,
			itemnum,
			description,
			qty,
			avgcost,
			consumption
			)
as
(
select 		invytype, 
			itemnum, 
			description,
			sum(qty), 
			sum(consumption)/sum(qty), 
			sum(consumption)
from 		sv_invytrancc
where 		issuedate >= 'STDT' 	and 
			issuedate <= 'ENDT'
group by 	invytype, 
			itemnum, 
			description
having 		(sum(qty) <> 0)
)
