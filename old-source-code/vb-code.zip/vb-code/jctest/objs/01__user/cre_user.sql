-- 
-- NAME		: cre_user.sql
-- LOCA		: $PROJECTDIR/objs/01__user/
-- AUTH		: KAH, 2004/09/05
-- TEXT		: for creating JCtest user
-- PLAT		: MySQL
-- NOTE		: 
-- 


GRANT ALL PRIVILEGES ON *.* TO JCtest@localhost IDENTIFIED BY 'JCtest' WITH GRANT OPTION;
GRANT ALL PRIVILEGES ON *.* TO JCtest@'%' 		IDENTIFIED BY 'JCtest' WITH GRANT OPTION;
