--
-- NAME	: 	cre_tbl_user.sql
-- LOCA	: 	$PROJECTDIR/objs/03__tbls/
-- AUTH	: 	KAH, 2004/09/05
-- ABBR	: 	USER
-- TEXT	: 
-- NOTE	: 
-- COLS		user_text	user ID
-- 		  	user_pass	user Password
-- 		  	user_name	user Full Name
-- 		  	user_stat	Is user Active
--						'N' means Not Active
--						'Y' means Active
-- 

create table	t_user
(
user_text		varchar(16)		not null,
user_pass		varchar(16)		not null,
user_name		varchar(64)		not null,
user_stat		varchar(1)		not null,
constraint		pk_user			primary key	(user_text)
);
