/*
-- NAME		cre_tbl_tmrk.sql
-- LOCA		$LEGAL_DOC_MAN\objs\tbls\
-- AUTH		KAH, 2004/09/12
-- APPL		LegalDocMan
-- ABBR		(T)rade(M)a(RK)
-- TEXT		Trademark Details
-- NOTE		
-- COLS		OID			
--			TMRK_NAME	Name of the Trademark
--			TMRK_FILD	Filing Date of the Trademark
--			TMRK_FILN	Filing TM No of the Trademark
--			TMRK_CTMD	CTM Referenece of Date of the Trademark
--			TMRK_CTMP	CTM Referenece of Person Applying for the Trademark
--			TMRK_CLSS	Class Mark of the Trademark
--			TMRK_STAT	Status of the Trademark
--			TMRK_DESC	Description of the Trademark
--			TMRK_BREF	Billing Reference of the Trademark
--						Amount of Filing
--						Final Bill
--						Opposition
--						Billing Party
--			TMRK_CRTD	Certificate Issue Date of the Trademark
--			TMRK_RNWD	Next Certificate Renewal Date of the Trademark
*/


create	table	t_tmrk
(
oid			varchar(24)		constraint	nn_oid_tmrk 		not null,
tmrk_name		varchar(64)		constraint 	nn_name_tmrk		not null,
tmrk_fild		datetime		constraint 	nn_fild_tmrk		not null,
tmrk_filn		varchar(32)		constraint 	nn_filn_tmrk		not null,
tmrk_ctmd		datetime		constraint 	nn_ctmd_tmrk		not null,
tmrk_ctmp		varchar(64)		constraint 	nn_ctmp_tmrk		not null,
tmrk_clss		varchar(24)		constraint 	nn_clss_tmrk		not null,
tmrk_stat		varchar(24)		constraint 	nn_stat_tmrk		not null,
tmrk_desc		varchar(256),
tmrk_bref		varchar(256),
tmrk_crtd		datetime,
tmrk_rnwd		datetime,
constraint 		pk_tmrk			primary key	(oid)
)

go


alter table	t_tmrk
add
constraint uk_name_tmrk
unique (tmrk_name)

go


insert into 
t_tmrk 		(
			oid						, tmrk_name			,	 
			tmrk_fild					, tmrk_filn			, 
			tmrk_ctmd					, tmrk_ctmp			, 
			tmrk_clss					, tmrk_stat			, 
			tmrk_desc					, tmrk_bref			, 
			tmrk_crtd					, tmrk_rnwd
			)
values		(
			'TMRK0000000000000001'				, 'DREAMFLOWER (word)'		, 
			10/12/2000					, '3718'			,
			10/12/2000					, 'Mr. Khan'			,
			'3'						, 'Applied For Renewal'		,
			'Dream Flower'					, null				,
			'09/28/1962'					, '09/28/1999'
			);

go



/* ------------------------------- */

create	table	t_tdoc
(
oid		varchar(24)	constraint	nn_oid_tdoc	not null,
tdoc_name	varchar(24)	constraint	nn_name_tdoc 	not null,
tdoc_docs	image,
tdoc_tmrk	varchar(24)	constraint 	nn_tmrk_tdoc	not null,

constraint 	pk_tdoc		primary key	(oid),
constraint 	fk_tdoc		foreign key	(tdoc_tmrk)	references 	t_tmrk(oid)
)

go



/* ------------------------------- */

create	table	t_rnwl
(

oid		varchar(24)	constraint	nn_oid_rnwl	not null,
rnwl_rnwd	datetime	constraint	nn_rnwd_rnwl	not null,
rnwl_rfno	varchar(24)	constraint	nn_rfno_rnwl	not null,
rnwl_stdt	datetime	constraint	nn_stdt_rnwl	not null,
rnwl_tmrk	varchar(24)	constraint 	nn_tmrk_rnwl	not null,
rnwl_desc	varchar(256),
constraint 	pk_rnwl		primary key	(oid),
constraint	fk_rnwl		foreign key	(rnwl_tmrk)	references	t_tmrk(oid)

)


/* -------------------------------- */

/* Table   		t_stat

-- COLS			OID			
--			SDAT_ORSD	Objevtion Raised (Y/N)
--			SDAT_DESC	Description	
--			SDAT_CLDT	Time allowed to Clearify
--			SDAT_MTDT	Due date for Mitigation
--			SDAT_OBMT	Objection Mitigated (Y/N) 
--			SDAT_SPDT	Due date for Journal Material Supply
--			SDAT_JPUB	Journal Published (Y/N)
--			SDAT_ISSU	Journal Issue No.
--			SDAT_PBDT	Date of Publication

--			SDAT_PSND	Paper Sent to CTM
--			SDAT_PRSN	To Whom
--			SDAT_MEAN	By Which means

--			SDAT_CTDT	Due date for Issuance of certificate

--			SDAT_TMRK	Primary Key of t_tmrk table 
--*/

create	table	t_sdat
(
oid			varchar(24)		constraint	nn_oid_sdat 		not null,
sdat_orsd		varchar(1),
sdat_desc		varchar(256),
sdat_cldt		datetime,
sdat_mtdt		datetime,
sdat_obmt		varchar(1),
sdat_spdt		datetime,
sdat_jpub		varchar(1),
sdat_issu		varchar(24),
sdat_pbdt		datetime,
sdat_psnd		varchar(1),
sdat_prsn		varchar(64),
sdat_mean		varchar(64),
sdat_ctdt		datetime,
sdat_tmrk		varchar(24),
constraint 		pk_sdat			primary key	(oid),
constraint		fk_sdat			foreign key	(sdat_tmrk)	references t_tmrk(oid)
)

go




