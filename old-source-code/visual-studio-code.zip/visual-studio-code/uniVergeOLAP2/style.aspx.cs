using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace mssqlbiwebctrlsample
{
	/// <summary>
	/// Summary description for style.
	/// </summary>
	public class style : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.RadioButtonList rblStyles;
		protected System.Web.UI.WebControls.Button btnApplyStyle;
		protected MSSQLBI.Web.Olap.OlapControl OlapControl1;

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			if(!Page.IsPostBack)
			{
				//- set up connection
				OlapControl1.Connection = new MSSQLBI.XmlAnalysis.Data.MdxConnection("http://europa/xmla/msxisapi.dll","Provider=MSOLAP;Data Source=local","uniVerge","Usage");
				OlapControl1.AutoResize = true;

				// get ResultCube object
				MSSQLBI.XmlAnalysis.Data.ResultCube rc = OlapControl1.ResultCube;
	
				rc.MeasuresOnRows = true;

				// add dimensions to row axis
				rc.ColumnAxis.Add("[Time]");

				// add dimensions to column axis
				rc.RowAxis.Add("[Store]");
				rc.RowAxis.Add("[Product]");

				// add measures to data area
				rc.Measures.Add("[Measures].[Store Cost]");
				rc.Measures.Add("[Measures].[Profit]");

				// add dimensions to slicer pane
				rc.SlicerAxis.Add("[Customers]");
				rc.SlicerAxis.Add("[Gender]");
				rc.SlicerAxis.Add("[Promotion Media]");

				// drilldown on [Time].[1997].[Q1]
				rc.GetDimensionByName("[Time]").DimensionMembers["[Time].[1997].[Q1]"].MemberAction = MSSQLBI.XmlAnalysis.Data.MemberState.ShowChildren;
				rc.GetDimensionByName("[Store]").DimensionMembers["[Store].[All Stores].[USA]"].MemberAction = MSSQLBI.XmlAnalysis.Data.MemberState.ShowChildren;
				rc.GetDimensionByName("[Product]").DimensionMembers["[Product].[All Products].[Drink]"].MemberAction = MSSQLBI.XmlAnalysis.Data.MemberState.ShowChildren;

				rblStyles.Items.Add("Default");
				rblStyles.Items.Add("Light Colors");
				rblStyles.Items.Add("Black and Brown");
				rblStyles.SelectedIndex = 0;
				rblStyles.RepeatDirection = RepeatDirection.Horizontal;
				rblStyles.RepeatColumns = 6;
			}
		}

		#region default style
		private void ApplyDefaultStyle()
		{
			MSSQLBI.Web.Style style;

			// control properties
			OlapControl1.Font.Italic = false;
			OlapControl1.Font.Name = "";
			OlapControl1.Font.Overline = false;
			OlapControl1.Font.Size = FontUnit.Medium;
			OlapControl1.Font.Strikeout = false;
			OlapControl1.Font.Underline = false;

			OlapControl1.ForeColor = Color.Black;
			OlapControl1.BackColor = Color.Gray;

			// data style
			style = new MSSQLBI.Web.Style();
			style.Alignment = MSSQLBI.Web.TextAlign.Right;
			style.BackColor = Color.White;
			style.BorderColor = Color.DarkGray;
			style.BorderBottomStyle = BorderStyle.Solid;
			style.BorderLeftStyle = BorderStyle.None;
			style.BorderTopStyle = BorderStyle.None;
			style.BorderRightStyle = BorderStyle.Solid;
			style.BorderWidth = new Unit(1);
			style.Font = new MSSQLBI.Web.FontInfo();
			style.ForeColor = Color.Black;

			OlapControl1.DataStyle = style;
			
			// data aggregate style
			style = new MSSQLBI.Web.Style();
			style.Alignment = MSSQLBI.Web.TextAlign.Right;
			style.BackColor = Color.White;
			style.BorderColor = Color.DarkGray;
			style.BorderBottomStyle = BorderStyle.Solid;
			style.BorderLeftStyle = BorderStyle.None;
			style.BorderTopStyle = BorderStyle.None;
			style.BorderRightStyle = BorderStyle.Solid;
			style.BorderWidth = new Unit(1);
			style.Font = new MSSQLBI.Web.FontInfo();
			style.ForeColor = Color.Black;
			OlapControl1.DataAggregateStyle = style;

			OlapControl1.RowHeaderStyles.Clear();
			OlapControl1.ColumnHeaderStyles.Clear();
		}
		#endregion

		#region light colors style
		private void ApplyLightColorsStyle()
		{
			OlapControl1.RowHeaderStyles.Clear();
			OlapControl1.ColumnHeaderStyles.Clear();

			MSSQLBI.Web.Style style;
			MSSQLBI.Web.Olap.HeaderStyle headerStyle;

			// control properties
			OlapControl1.Font.Bold = false;
			OlapControl1.Font.Italic = false;
			OlapControl1.Font.Name = "Arial";
			OlapControl1.Font.Overline = false;
			OlapControl1.Font.Size = FontUnit.XSmall;
			OlapControl1.Font.Strikeout = false;
			OlapControl1.Font.Underline = false;

			OlapControl1.ForeColor = Color.Black;
			OlapControl1.BackColor = Color.LightGray;

			// data style
			style = new MSSQLBI.Web.Style();
			style.Alignment = MSSQLBI.Web.TextAlign.Right;
			style.BackColor = Color.White;
			style.BorderColor = Color.DarkGray;
			style.BorderBottomStyle = BorderStyle.Solid;
			style.BorderLeftStyle = BorderStyle.None;
			style.BorderTopStyle = BorderStyle.None;
			style.BorderRightStyle = BorderStyle.Solid;
			style.BorderWidth = new Unit(1);
			style.Font = new MSSQLBI.Web.FontInfo();
			style.ForeColor = Color.Black;

			OlapControl1.DataStyle = style;
			
			// data aggregate style
			style = new MSSQLBI.Web.Style();
			style.Alignment = MSSQLBI.Web.TextAlign.Right;
			style.BackColor = Color.LemonChiffon;
			style.BorderColor = Color.DarkGray;
			style.BorderBottomStyle = BorderStyle.Solid;
			style.BorderLeftStyle = BorderStyle.None;
			style.BorderTopStyle = BorderStyle.None;
			style.BorderRightStyle = BorderStyle.Solid;
			style.BorderWidth = new Unit(1);
			style.Font.CopyFrom(OlapControl1.Font);
			style.Font.Italic = true;
			style.ForeColor = Color.Black;

			OlapControl1.DataAggregateStyle = style;

			// row header style
			// 0
			style = new MSSQLBI.Web.Style();
			style.Alignment = MSSQLBI.Web.TextAlign.Left;
			style.BackColor = Color.LightCyan;
			style.BorderColor = Color.DarkGray;
			style.BorderBottomStyle = BorderStyle.Solid;
			style.BorderLeftStyle = BorderStyle.None;
			style.BorderTopStyle = BorderStyle.None;
			style.BorderRightStyle = BorderStyle.Solid;
			style.BorderWidth = new Unit(1);
			style.Font = new MSSQLBI.Web.FontInfo();
			style.ForeColor = Color.Black;
			
			headerStyle = new MSSQLBI.Web.Olap.HeaderStyle();
			headerStyle.Expand = style;
			headerStyle.Collapse = style;

			style = new MSSQLBI.Web.Style();
			style.Alignment = MSSQLBI.Web.TextAlign.Left;
			style.BackColor = Color.LemonChiffon;
			style.BorderColor = Color.DarkGray;
			style.BorderBottomStyle = BorderStyle.Solid;
			style.BorderLeftStyle = BorderStyle.None;
			style.BorderTopStyle = BorderStyle.None;
			style.BorderRightStyle = BorderStyle.Solid;
			style.BorderWidth = new Unit(1);
			style.Font = new MSSQLBI.Web.FontInfo();
			style.ForeColor = Color.Black;

			headerStyle.Aggregate = style;

			OlapControl1.RowHeaderStyles.Add(headerStyle);


			// 1
			style = new MSSQLBI.Web.Style();
			style.Alignment = MSSQLBI.Web.TextAlign.Left;
			style.BackColor = Color.FromArgb(0xcc, 0xff, 0xcc);
			style.BorderColor = Color.DarkGray;
			style.BorderBottomStyle = BorderStyle.Solid;
			style.BorderLeftStyle = BorderStyle.None;
			style.BorderTopStyle = BorderStyle.None;
			style.BorderRightStyle = BorderStyle.Solid;
			style.BorderWidth = new Unit(1);
			style.Font = new MSSQLBI.Web.FontInfo();
			style.ForeColor = Color.Black;
			
			headerStyle = new MSSQLBI.Web.Olap.HeaderStyle();
			headerStyle.Expand = style;
			headerStyle.Collapse = style;

			style = new MSSQLBI.Web.Style();
			style.Alignment = MSSQLBI.Web.TextAlign.Left;
			style.BackColor = Color.LemonChiffon;
			style.BorderColor = Color.DarkGray;
			style.BorderBottomStyle = BorderStyle.Solid;
			style.BorderLeftStyle = BorderStyle.None;
			style.BorderTopStyle = BorderStyle.None;
			style.BorderRightStyle = BorderStyle.Solid;
			style.BorderWidth = new Unit(1);
			style.Font = new MSSQLBI.Web.FontInfo();
			style.ForeColor = Color.Black;

			headerStyle.Aggregate = style;

			OlapControl1.RowHeaderStyles.Add(headerStyle);

			// 2
			style = new MSSQLBI.Web.Style();
			style.Alignment = MSSQLBI.Web.TextAlign.Left;
			style.BackColor = Color.FromArgb(0xff, 0xcc, 0xcc);
			style.BorderColor = Color.DarkGray;
			style.BorderBottomStyle = BorderStyle.Solid;
			style.BorderLeftStyle = BorderStyle.None;
			style.BorderTopStyle = BorderStyle.None;
			style.BorderRightStyle = BorderStyle.Solid;
			style.BorderWidth = new Unit(1);
			style.Font = new MSSQLBI.Web.FontInfo();
			style.ForeColor = Color.Black;
			
			headerStyle = new MSSQLBI.Web.Olap.HeaderStyle();
			headerStyle.Expand = style;
			headerStyle.Collapse = style;

			style = new MSSQLBI.Web.Style();
			style.Alignment = MSSQLBI.Web.TextAlign.Left;
			style.BackColor = Color.LemonChiffon;
			style.BorderColor = Color.DarkGray;
			style.BorderBottomStyle = BorderStyle.Solid;
			style.BorderLeftStyle = BorderStyle.None;
			style.BorderTopStyle = BorderStyle.None;
			style.BorderRightStyle = BorderStyle.Solid;
			style.BorderWidth = new Unit(1);
			style.Font = new MSSQLBI.Web.FontInfo();
			style.ForeColor = Color.Black;

			headerStyle.Aggregate = style;
			
			OlapControl1.RowHeaderStyles.Add(headerStyle);

			// column header style
			// 0
			style = new MSSQLBI.Web.Style();
			style.Alignment = MSSQLBI.Web.TextAlign.Left;
			style.BackColor = Color.FromArgb(0xff, 0xcc, 0x99);
			style.BorderColor = Color.DarkGray;
			style.BorderBottomStyle = BorderStyle.Solid;
			style.BorderLeftStyle = BorderStyle.None;
			style.BorderTopStyle = BorderStyle.None;
			style.BorderRightStyle = BorderStyle.Solid;
			style.BorderWidth = new Unit(1);
			style.Font = new MSSQLBI.Web.FontInfo();
			style.ForeColor = Color.Black;
			
			headerStyle = new MSSQLBI.Web.Olap.HeaderStyle();
			headerStyle.Expand = style;
			headerStyle.Collapse = style;

			style = new MSSQLBI.Web.Style();
			style.Alignment = MSSQLBI.Web.TextAlign.Left;
			style.BackColor = Color.LemonChiffon;
			style.BorderColor = Color.DarkGray;
			style.BorderBottomStyle = BorderStyle.Solid;
			style.BorderLeftStyle = BorderStyle.None;
			style.BorderTopStyle = BorderStyle.None;
			style.BorderRightStyle = BorderStyle.Solid;
			style.BorderWidth = new Unit(1);
			style.Font = new MSSQLBI.Web.FontInfo();
			style.ForeColor = Color.Black;

			headerStyle.Aggregate = style;
			
			OlapControl1.ColumnHeaderStyles.Add(headerStyle);

			//OlapControl.CSSFileName;
			//OlapControl.CollapseImage;
			//OlapControl.ExpandImage;
			//OlapControl.ViewStyle;
			//OlapControl.SplitPositionTop;
			//OlapControl.SlicerPane;
		}
		#endregion

		#region Black and Brown
		private void ApplyBlackBrownStyle()
		{
			OlapControl1.RowHeaderStyles.Clear();
			OlapControl1.ColumnHeaderStyles.Clear();

			MSSQLBI.Web.Style style;
			MSSQLBI.Web.Olap.HeaderStyle headerStyle;

			// control properties
			OlapControl1.Font.Bold = false;
			OlapControl1.Font.Italic = false;
			OlapControl1.Font.Name = "Arial";
			OlapControl1.Font.Overline = false;
			OlapControl1.Font.Size = FontUnit.XSmall;
			OlapControl1.Font.Strikeout = false;
			OlapControl1.Font.Underline = false;

			OlapControl1.ForeColor = Color.Black;
			OlapControl1.BackColor = Color.LightGray;

			// data style
			style = new MSSQLBI.Web.Style();
			style.Alignment = MSSQLBI.Web.TextAlign.Right;
			style.BackColor = Color.White;
			style.BorderColor = Color.Black;
			style.BorderBottomStyle = BorderStyle.None;
			style.BorderLeftStyle = BorderStyle.None;
			style.BorderTopStyle = BorderStyle.None;
			style.BorderRightStyle = BorderStyle.Solid;
			style.BorderWidth = new Unit(2);
			style.Font = new MSSQLBI.Web.FontInfo();
			style.ForeColor = Color.Black;

			OlapControl1.DataStyle = style;
			
			// data aggregate style
			style = new MSSQLBI.Web.Style();
			style.Alignment = MSSQLBI.Web.TextAlign.Right;
			style.BackColor = Color.FromArgb(0xff, 0xff, 0xcc);
			style.BorderColor = Color.Black;
			style.BorderBottomStyle = BorderStyle.None;
			style.BorderLeftStyle = BorderStyle.None;
			style.BorderTopStyle = BorderStyle.None;
			style.BorderRightStyle = BorderStyle.Solid;
			style.BorderWidth = new Unit(2);
			style.Font.CopyFrom(OlapControl1.Font);
			style.Font.Bold = true;
			style.Font.Italic = true;
			style.ForeColor = Color.Black;

			OlapControl1.DataAggregateStyle = style;

			// row header style
			// 0
			headerStyle = new MSSQLBI.Web.Olap.HeaderStyle();

			style = new MSSQLBI.Web.Style();
			style.Alignment = MSSQLBI.Web.TextAlign.Left;
			style.BackColor = Color.LightGray;
			style.BorderColor = Color.Black;
			style.BorderBottomStyle = BorderStyle.None;
			style.BorderLeftStyle = BorderStyle.None;
			style.BorderTopStyle = BorderStyle.None;
			style.BorderRightStyle = BorderStyle.None;
			style.BorderWidth = new Unit(2);
			style.Font = new MSSQLBI.Web.FontInfo();
			style.ForeColor = Color.Black;
			headerStyle.Expand = style;

			style = new MSSQLBI.Web.Style();
			style.Alignment = MSSQLBI.Web.TextAlign.Left;
			style.BackColor = Color.LightGray;
			style.BorderColor = Color.Black;
			style.BorderBottomStyle = BorderStyle.None;
			style.BorderLeftStyle = BorderStyle.None;
			style.BorderTopStyle = BorderStyle.None;
			style.BorderRightStyle = BorderStyle.Solid;
			style.BorderWidth = new Unit(2);
			style.Font = new MSSQLBI.Web.FontInfo();
			style.Font.CopyFrom(OlapControl1.Font);
			style.Font.Bold = true;
			style.ForeColor = Color.Black;
			headerStyle.Collapse = style;

			style = new MSSQLBI.Web.Style();
			style.Alignment = MSSQLBI.Web.TextAlign.Left;
			style.BackColor = Color.FromArgb(0x00, 0x00, 0x00);
			style.BorderColor = Color.Black;
			style.BorderBottomStyle = BorderStyle.Solid;
			style.BorderLeftStyle = BorderStyle.None;
			style.BorderTopStyle = BorderStyle.None;
			style.BorderRightStyle = BorderStyle.None;
			style.BorderWidth = new Unit(2);
			style.Font.CopyFrom(OlapControl1.Font);
			style.Font.Bold = true;
			style.ForeColor = Color.FromArgb(0xff, 0xcc, 0x00);
			headerStyle.Aggregate = style;

			OlapControl1.RowHeaderStyles.Add(headerStyle);

			// 1
			headerStyle = new MSSQLBI.Web.Olap.HeaderStyle();
			style = new MSSQLBI.Web.Style();
			style.Alignment = MSSQLBI.Web.TextAlign.Left;
			style.BackColor = Color.LightGray;
			style.BorderColor = Color.Black;
			style.BorderBottomStyle = BorderStyle.None;
			style.BorderLeftStyle = BorderStyle.None;
			style.BorderTopStyle = BorderStyle.None;
			style.BorderRightStyle = BorderStyle.None;
			style.BorderWidth = new Unit(2);
			style.Font = new MSSQLBI.Web.FontInfo();
			style.ForeColor = Color.Black;
			headerStyle.Expand = style;

			style = new MSSQLBI.Web.Style();
			style.Alignment = MSSQLBI.Web.TextAlign.Left;
			style.BackColor = Color.LightGray;
			style.BorderColor = Color.Black;
			style.BorderBottomStyle = BorderStyle.None;
			style.BorderLeftStyle = BorderStyle.None;
			style.BorderTopStyle = BorderStyle.None;
			style.BorderRightStyle = BorderStyle.Solid;
			style.BorderWidth = new Unit(2);
			style.Font.CopyFrom(OlapControl1.Font);
			style.Font.Bold = true;
			style.ForeColor = Color.Black;
			headerStyle.Collapse = style;

			style = new MSSQLBI.Web.Style();
			style.Alignment = MSSQLBI.Web.TextAlign.Left;
			style.BackColor = Color.FromArgb(0xff, 0xcc, 0x00);
			style.BorderColor = Color.Black;
			style.BorderBottomStyle = BorderStyle.Solid;
			style.BorderLeftStyle = BorderStyle.None;
			style.BorderTopStyle = BorderStyle.None;
			style.BorderRightStyle = BorderStyle.Solid;
			style.BorderWidth = new Unit(2);
			style.Font.CopyFrom(OlapControl1.Font);
			style.Font.Bold = true;
			style.ForeColor = Color.Black;
			headerStyle.Aggregate = style;

			OlapControl1.RowHeaderStyles.Add(headerStyle);

			// 2
			headerStyle = new MSSQLBI.Web.Olap.HeaderStyle();
			style = new MSSQLBI.Web.Style();
			style.Alignment = MSSQLBI.Web.TextAlign.Left;
			style.BackColor = Color.LightGray;
			style.BorderColor = Color.Black;
			style.BorderBottomStyle = BorderStyle.Solid;
			style.BorderLeftStyle = BorderStyle.None;
			style.BorderTopStyle = BorderStyle.None;
			style.BorderRightStyle = BorderStyle.Solid;
			style.BorderWidth = new Unit(2);
			style.Font = new MSSQLBI.Web.FontInfo();
			style.ForeColor = Color.Black;
			headerStyle.Expand = style;
			headerStyle.Collapse = style;

			style = new MSSQLBI.Web.Style();
			style.Alignment = MSSQLBI.Web.TextAlign.Left;
			style.BackColor = Color.LemonChiffon;
			style.BorderColor = Color.Black;
			style.BorderBottomStyle = BorderStyle.Solid;
			style.BorderLeftStyle = BorderStyle.None;
			style.BorderTopStyle = BorderStyle.None;
			style.BorderRightStyle = BorderStyle.None;
			style.BorderWidth = new Unit(1);
			style.Font = new MSSQLBI.Web.FontInfo();
			style.ForeColor = Color.Black;

			headerStyle.Aggregate = style;
			
			OlapControl1.RowHeaderStyles.Add(headerStyle);

			// column header style
			// 0
			headerStyle = new MSSQLBI.Web.Olap.HeaderStyle();

			style = new MSSQLBI.Web.Style();
			style.Alignment = MSSQLBI.Web.TextAlign.Left;
			style.BackColor = Color.Black;
			style.BorderColor = Color.White;
			style.BorderBottomStyle = BorderStyle.Solid;
			style.BorderLeftStyle = BorderStyle.None;
			style.BorderTopStyle = BorderStyle.None;
			style.BorderRightStyle = BorderStyle.Solid;
			style.BorderWidth = new Unit(1);
			style.Font.CopyFrom(OlapControl1.Font);
			style.Font.Bold = true;
			style.ForeColor = Color.White;
			headerStyle.Expand = style;

			style = new MSSQLBI.Web.Style();
			style.Alignment = MSSQLBI.Web.TextAlign.Left;
			style.BackColor = Color.LightGray;
			style.BorderColor = Color.DarkGray;
			style.BorderBottomStyle = BorderStyle.Solid;
			style.BorderLeftStyle = BorderStyle.None;
			style.BorderTopStyle = BorderStyle.None;
			style.BorderRightStyle = BorderStyle.Solid;
			style.BorderWidth = new Unit(1);
			style.Font = new MSSQLBI.Web.FontInfo();
			style.ForeColor = Color.Black;
			headerStyle.Collapse = style;

			style = new MSSQLBI.Web.Style();
			style.Alignment = MSSQLBI.Web.TextAlign.Left;
			style.BackColor = Color.LemonChiffon;
			style.BorderColor = Color.DarkGray;
			style.BorderBottomStyle = BorderStyle.Solid;
			style.BorderLeftStyle = BorderStyle.None;
			style.BorderTopStyle = BorderStyle.None;
			style.BorderRightStyle = BorderStyle.Solid;
			style.BorderWidth = new Unit(1);
			style.Font = new MSSQLBI.Web.FontInfo();
			style.ForeColor = Color.Black;
			headerStyle.Aggregate = style;
			
			OlapControl1.ColumnHeaderStyles.Add(headerStyle);
		}
		#endregion

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);
			this.btnApplyStyle.Click += new System.EventHandler(this.btnApplyStyle_Click);

		}
		#endregion

		private void btnApplyStyle_Click(object sender, System.EventArgs e)
		{
			switch(rblStyles.SelectedItem.Value)
			{
				case "Default":
					ApplyDefaultStyle();
					break;

				case "Light Colors":
					ApplyLightColorsStyle();
					break;

				case "Black and Brown":
					ApplyBlackBrownStyle();
					break;
			}
		}

	}
}
