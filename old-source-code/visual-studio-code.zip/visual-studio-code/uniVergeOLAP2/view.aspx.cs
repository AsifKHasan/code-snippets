using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace mssqlbiwebctrlsample
{
	/// <summary>
	/// Summary description for view.
	/// </summary>
	public class view : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.Button btnApplyStyle;
		protected System.Web.UI.HtmlControls.HtmlInputRadioButton rbStatic;
		protected System.Web.UI.HtmlControls.HtmlInputRadioButton rbDynamic;
		protected System.Web.UI.HtmlControls.HtmlInputRadioButton rbDynamicWithDesigner;
		protected System.Web.UI.HtmlControls.HtmlInputRadioButton rbDynamic2;
		protected System.Web.UI.WebControls.CheckBox chkAutoResize;
		protected System.Web.UI.WebControls.CheckBox chkFixHeaders;
		protected MSSQLBI.Web.Olap.OlapControl OlapControl1;

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			if(!Page.IsPostBack)
			{
				//- set up connection
				OlapControl1.Connection = new MSSQLBI.XmlAnalysis.Data.MdxConnection("http://europa/xmla/msxisapi.dll","Provider=MSOLAP;Data Source=local","uniVerge","Usage");
				OlapControl1.AutoResize = true;

				// get ResultCube object
				MSSQLBI.XmlAnalysis.Data.ResultCube rc = OlapControl1.ResultCube;
	
				rc.MeasuresOnRows = true;

				// add dimensions to row axis
				rc.ColumnAxis.Add("[Time]");

				// add dimensions to column axis
				rc.RowAxis.Add("[Store]");
				rc.RowAxis.Add("[Product]");

				// add measures to data area
				rc.Measures.Add("[Measures].[Store Cost]");
				rc.Measures.Add("[Measures].[Profit]");

				// add dimensions to slicer pane
				rc.SlicerAxis.Add("[Customers]");
				rc.SlicerAxis.Add("[Gender]");
				rc.SlicerAxis.Add("[Promotion Media]");

				// drilldown on [Time].[1997].[Q1]
				rc.GetDimensionByName("[Time]").DimensionMembers["[Time].[1997].[Q1]"].MemberAction = MSSQLBI.XmlAnalysis.Data.MemberState.ShowChildren;
				rc.GetDimensionByName("[Store]").DimensionMembers["[Store].[All Stores].[USA]"].MemberAction = MSSQLBI.XmlAnalysis.Data.MemberState.ShowChildren;
				rc.GetDimensionByName("[Product]").DimensionMembers["[Product].[All Products].[Drink]"].MemberAction = MSSQLBI.XmlAnalysis.Data.MemberState.ShowChildren;

				// initialize web controls
				if(OlapControl1.ViewStyle == MSSQLBI.Web.Olap.ClientView.Static)
					rbStatic.Checked = true;
				else if(OlapControl1.ViewStyle == MSSQLBI.Web.Olap.ClientView.Dynamic)
					rbDynamic.Checked = true;
				else if(OlapControl1.ViewStyle == MSSQLBI.Web.Olap.ClientView.DynamicWithDesigner)
					rbDynamicWithDesigner.Checked = true;

				chkAutoResize.Checked = OlapControl1.AutoResize;
				chkFixHeaders.Checked = OlapControl1.FixHeaders;
			}

		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.btnApplyStyle.Click += new System.EventHandler(this.btnApplyStyle_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void btnApplyStyle_Click(object sender, System.EventArgs e)
		{
			if(rbStatic.Checked)
				OlapControl1.ViewStyle = MSSQLBI.Web.Olap.ClientView.Static;
			else if(rbDynamic.Checked)
				OlapControl1.ViewStyle = MSSQLBI.Web.Olap.ClientView.Dynamic;
			else if(rbDynamicWithDesigner.Checked)
				OlapControl1.ViewStyle = MSSQLBI.Web.Olap.ClientView.DynamicWithDesigner;

			OlapControl1.AutoResize = chkAutoResize.Checked;
			OlapControl1.FixHeaders = chkFixHeaders.Checked;
		}
	}
}
