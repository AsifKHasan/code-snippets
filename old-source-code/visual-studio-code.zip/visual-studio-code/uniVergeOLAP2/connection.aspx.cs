using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace mssqlbiwebctrlsample
{
	/// <summary>
	/// Summary description for WebForm1.
	/// </summary>
	public class Connection : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.Button btnGetDataSources;
		protected System.Web.UI.WebControls.DropDownList ddlDataSource;
		protected System.Web.UI.WebControls.Button btnGetCatalogs;
		protected System.Web.UI.WebControls.Label Label1;
		protected System.Web.UI.WebControls.Label Label2;
		protected System.Web.UI.WebControls.Button btnGetCubes;
		protected System.Web.UI.WebControls.DropDownList ddlCatalogs;
		protected System.Web.UI.WebControls.Label Label3;
		protected System.Web.UI.WebControls.DropDownList ddlCubes;
		protected System.Web.UI.WebControls.Button btnInitOlapControl;
		protected System.Web.UI.WebControls.Label Label4;
		protected MSSQLBI.Web.Olap.OlapControl OlapControl1;
		protected System.Web.UI.WebControls.TextBox txtUrl;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.btnGetDataSources.Click += new System.EventHandler(this.btnGetDataSources_Click);
			this.btnGetCatalogs.Click += new System.EventHandler(this.btnGetCatalogs_Click);
			this.btnGetCubes.Click += new System.EventHandler(this.btnGetCubes_Click);
			this.btnInitOlapControl.Click += new System.EventHandler(this.btnInitOlapControl_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void btnGetDataSources_Click(object sender, System.EventArgs e)
		{
			MSSQLBI.XmlAnalysis.Data.DataSource[] dataSources =	MSSQLBI.Web.Olap.OlapControl.GetDataSourceList(txtUrl.Text, null);
			
			ddlDataSource.Items.Clear();
			for(int i=0; i<dataSources.Length;i++)
				ddlDataSource.Items.Add(dataSources[i].DataSourceInfo);

		}

		private void btnGetCatalogs_Click(object sender, System.EventArgs e)
		{
			MSSQLBI.XmlAnalysis.Data.DataSource[] dataSources =	MSSQLBI.Web.Olap.OlapControl.GetDataSourceList(txtUrl.Text, null);
			int nIndex = ddlDataSource.Items.IndexOf(ddlDataSource.Items.FindByValue(ddlDataSource.SelectedItem.Value));
			
			ddlCatalogs.Items.Clear();
			MSSQLBI.XmlAnalysis.Data.Catalog[] catalogs = MSSQLBI.Web.Olap.OlapControl.GetCatalogList(dataSources[nIndex], null);
			for(int i=0; i<catalogs.Length;i++)
				ddlCatalogs.Items.Add(catalogs[i].Name);
		}

		private void btnGetCubes_Click(object sender, System.EventArgs e)
		{
			MSSQLBI.XmlAnalysis.Data.DataSource[] dataSources =	MSSQLBI.Web.Olap.OlapControl.GetDataSourceList(txtUrl.Text, null);
			int nIndex = ddlDataSource.Items.IndexOf(ddlDataSource.Items.FindByValue(ddlDataSource.SelectedItem.Value));
			
			MSSQLBI.XmlAnalysis.Data.Catalog[] catalogs = MSSQLBI.Web.Olap.OlapControl.GetCatalogList(dataSources[nIndex], null);
			int nIndex2 = ddlCatalogs.Items.IndexOf(ddlCatalogs.Items.FindByValue(ddlCatalogs.SelectedItem.Value));

			ddlCubes.Items.Clear();
			MSSQLBI.XmlAnalysis.Data.Cube[] cubes = MSSQLBI.Web.Olap.OlapControl.GetCubeList(catalogs[nIndex2], null);
			for(int i=0; i<cubes.Length;i++)
				ddlCubes.Items.Add(cubes[i].Name);
		}

		private void btnInitOlapControl_Click(object sender, System.EventArgs e)
		{
			MSSQLBI.XmlAnalysis.Data.DataSource[] dataSources =	MSSQLBI.Web.Olap.OlapControl.GetDataSourceList(txtUrl.Text, null);
			int nIndex = ddlDataSource.Items.IndexOf(ddlDataSource.Items.FindByValue(ddlDataSource.SelectedItem.Value));
			
			MSSQLBI.XmlAnalysis.Data.Catalog[] catalogs = MSSQLBI.Web.Olap.OlapControl.GetCatalogList(dataSources[nIndex], null);
			int nIndex2 = ddlCatalogs.Items.IndexOf(ddlCatalogs.Items.FindByValue(ddlCatalogs.SelectedItem.Value));

			MSSQLBI.XmlAnalysis.Data.Cube[] cubes = MSSQLBI.Web.Olap.OlapControl.GetCubeList(catalogs[nIndex2], null);
			int nIndex3 = ddlCubes.Items.IndexOf(ddlCubes.Items.FindByValue(ddlCubes.SelectedItem.Value));

			OlapControl1.AutoResize = true;
			OlapControl1.Connection = new MSSQLBI.XmlAnalysis.Data.MdxConnection(txtUrl.Text, dataSources[nIndex].DataSourceInfo, catalogs[nIndex2].Name, cubes[nIndex3].Name);
		}

	}
}
