using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace mssqlbiwebctrlsample
{
	/// <summary>
	/// Summary description for drillthroughsample.
	/// </summary>
	public class drillthroughsample : System.Web.UI.Page
	{
		protected MSSQLBI.Web.Olap.OlapControl OlapControl1;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			if(!Page.IsPostBack)
			{
				//- set up connection
				OlapControl1.Connection = new MSSQLBI.XmlAnalysis.Data.MdxConnection("http://europa/xmla/msxisapi.dll","Provider=MSOLAP;Data Source=local","uniVerge","Usage");

				OlapControl1.AllowDrillthrough = true;

				// get ResultCube object
				MSSQLBI.XmlAnalysis.Data.ResultCube rc = OlapControl1.ResultCube;
	
				// add dimensions to row axis
				rc.ColumnAxis.Add("[Time]");

				// add dimensions to column axis
				rc.RowAxis.Add("[Store]");

				// add measures to data area
				rc.Measures.Add("[Measures].[Store Cost]");

				// add dimensions to slicer pane
				rc.SlicerAxis.Add("[Customers]");
				rc.SlicerAxis.Add("[Gender]");
				rc.SlicerAxis.Add("[Promotion Media]");

				// drilldown on [Time].[1997].[Q1]
				rc.GetDimensionByName("[Time]").DimensionMembers["[Time].[1997].[Q1]"].MemberAction = MSSQLBI.XmlAnalysis.Data.MemberState.ShowChildren;
			}
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.OlapControl1.Drillthrough += new MSSQLBI.Web.Olap.DrilledthroughEventHandler(this.OlapControl1_Drillthrough);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void OlapControl1_Drillthrough(object source, MSSQLBI.Web.Olap.DrilledthroughEventArgs e)
		{
			MSSQLBI.XmlAnalysis.Data.DrillthruCell dc = e.Drillthrough;
			
			this.Session["MdxConnection"] = OlapControl1.Connection;
			this.Session["DrillthruCell"] = dc;

			this.RegisterStartupScript("pageload", "<script language=JavaScript> var nleft=(screen.width - 600)/2;var ntop=(screen.height - 450)/2; window.open(\"drillthrough.aspx\", \"Drillthrough\", \"left=\" + nleft.toString() + \",top=\" + ntop.toString() + \",height=450,width=600,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=yes\", true); </script>");

		}


	}
}
