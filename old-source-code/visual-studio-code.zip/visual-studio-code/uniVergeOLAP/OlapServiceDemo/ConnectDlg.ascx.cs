//=================================================================
//  File:		ConnectDlg.aspx.cs
//
//  Namespace:	Dundas.OlapChartSamples.OlapServiceDemo.ConnectDlg
//
//	Classes:	OlapServiceDemo
//
//  Purpose:	Connection dialog user control.
//
//	Reviewed:	
//
//===================================================================
// Dundas Chart Control .Net
// Copyright � Dundas Software 2005, all rights reserved
//===================================================================

namespace Dundas.OlapChartSamples.OlapServiceDemo
{
	using System;
	using System.Data;
	using System.Drawing;
	using System.Web;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;
	using Dundas.Olap.Manager;
	using Dundas.Olap.Data;
	using Dundas.Olap.WebUIControls;
	using System.Reflection;
	using System.ComponentModel;

	/// <summary>
	/// Connection dialog user control.
	/// </summary>
	public abstract class ConnectDlg : System.Web.UI.UserControl
	{
		#region Fields	

		protected System.Web.UI.WebControls.Button ButtonCancel;
		protected System.Web.UI.WebControls.Button ButtonOK;
		protected System.Web.UI.WebControls.TextBox Catalog;
		protected System.Web.UI.WebControls.TextBox OlapServerID;
		protected System.Web.UI.WebControls.RadioButtonList ConnectionType;
		protected System.Web.UI.WebControls.Label Label1;
		protected Dundas.Olap.Manager.OlapManager OlapManager1;

		
		#endregion //Fields

		#region Constructors
		private static readonly object EventClose;

		/// <summary>
		/// Occurs when the class is loaded.
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		static ConnectDlg()
		{
			ConnectDlg.EventClose = new object();
		}


		#endregion //Constructors

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.ButtonOK.Click += new System.EventHandler(this.ButtonOK_Click);
			this.ButtonCancel.Click += new System.EventHandler(this.ButtonCancel_Click);
			this.Load += new System.EventHandler(this.Page_Load);
			this.PreRender += new System.EventHandler(this.ConnectDlg_PreRender);

		}
		#endregion

		#region OlapManager property and CloseDialog Event

		/// <summary>
		/// Gets and sets the OlapManager object reference
		/// </summary>
		public OlapManager OlapManager
		{
			get
			{
				return this.OlapManager1;
			}
			set
			{
				this.OlapManager1 = value;
			}
		}

		/// <summary>
		/// Fires when the dialog is about to close.
		/// </summary>
		[
		Category("Action"), 
		Browsable(true),
		Description("Fires when the dialog is about to close.")
		]
		public event EventHandler CloseDialog
		{
			add
			{
				base.Events.AddHandler(ConnectDlg.EventClose, value);
			}
			remove
			{
				base.Events.RemoveHandler(ConnectDlg.EventClose, value);
			}
		}

		/// <summary>
		/// Raises the CloseDialog event of the ConnectDlg control.
		/// </summary>
		/// <param name="e">A System.EventArgs that contains the event data. </param>
		protected virtual void OnCloseDialog(EventArgs e)
		{
			EventHandler handler = (EventHandler) base.Events[ConnectDlg.EventClose];
			if (handler != null)
			{
				handler(this, e);
			}
		}

		#endregion //OlapClient property and CloseDialog Event

		#region Event Handlers
		/// <summary>
		/// Occurs when the control is loaded.
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			if ( !this.IsPostBack )
			{
				this.OlapServerID.Text = Environment.MachineName;
			}
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void ConnectDlg_PreRender(object sender, System.EventArgs e)
		{
			// disable ok button if olap client is null
			ButtonOK.Enabled = this.OlapManager != null;
			this.EnableControls(this.ConnectionType.SelectedItem.Value == "Server");
		}

		/// <summary>
		/// Changes "enable" state of some controls
		/// </summary>
		/// <param name="enable"></param>
		private void EnableControls( bool enable )
		{
			this.OlapServerID.Enabled = enable;
			this.Catalog.Enabled = enable;
			if ( this.OlapServerID.Text.Length == 0)
			{
				this.OlapServerID.Text = this.Request[this.OlapServerID.ID];
			}
		}

		private void ButtonOK_Click(object sender, System.EventArgs e)
		{
			// Build connection string
			OlapReport report = new OlapReport();
			
			string connectionString = string.Empty;
			if ( ConnectionType.SelectedIndex == 0 )
			{
				connectionString = "Data Source=" + this.OlapServerID.Text + "; ";
				connectionString += "Provider=msolap; ";
				connectionString += "Initial Catalog=" + this.Catalog.Text + "; ";
			}
			else
			{
				connectionString += String.Format("Data Source={0}; Provider=msolap;", this.Server.MapPath("~/OfflineData/WarehouseAndSales.cub"));
				report.CubeName = "Warehouse and Sales";
			}

			IDataProvider dataProvider = this.OlapManager1.DataProvider;
			string oldConnectionString = ConnectDlg.GetDataProviderConnectionString( dataProvider );
			try
			{
				dataProvider.Close();
				
				ConnectDlg.SetDataProviderConnectionString( 
					dataProvider, 
					connectionString);

				this.OlapManager.ReloadDataSchema();

				// reset olap reports.				
				this.OlapManager.OlapReports.Clear();
				this.OlapManager.OlapReports.Add( report);
				this.OlapManager.SetCurrentOlapReport(report);

				this.OnCloseDialog( EventArgs.Empty );
			}
			catch ( Exception exception)
			{
				this.Label1.Text = exception.Message;
				this.Label1.Visible = true;
				ConnectDlg.SetDataProviderConnectionString( 
					dataProvider, 
					oldConnectionString);
			}
		}


		private void ButtonCancel_Click(object sender, System.EventArgs e)
		{
			this.OnCloseDialog( EventArgs.Empty );
		}

		#endregion //Event Handlers

		#region 

		internal static void SetDataProviderConnectionString(
			IDataProvider dataProvider, 
			string connectionString)
		{
			if(dataProvider != null)
			{
				PropertyInfo pi = dataProvider.GetType().GetProperty("ConnectionString");
				if(pi != null)
				{
					pi.SetValue(dataProvider, connectionString, null);
				}

			}
		}

		internal static string GetDataProviderConnectionString(IDataProvider dataProvider)
		{
			if(dataProvider != null)
			{
				PropertyInfo pi = dataProvider.GetType().GetProperty("ConnectionString");
				if(pi != null)
				{
					return (string)pi.GetValue(dataProvider, null);
				}
			}
			return string.Empty;
		}

		#endregion
	}
}
