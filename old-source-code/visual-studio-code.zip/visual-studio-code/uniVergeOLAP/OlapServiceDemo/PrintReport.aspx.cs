using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace Dundas.OlapChartSamples.OlapServiceDemo
{
	/// <summary>
	/// Summary description for PrintPreview.
	/// </summary>
	public class PrintPreview : System.Web.UI.Page
	{
		protected Dundas.Olap.Manager.OlapManager OlapManager1;
		protected Dundas.Olap.WebUIControls.OlapChart OlapChart1;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			if ( this.Request["olapkey"] != null )
			{
				this.OlapManager1.SessionKey = this.Request["olapkey"];
				this.OlapManager1.LoadPersistenceData();
			}
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
	}
}
