//=================================================================
//  File:		OlapServiceDemo.aspx.cs
//
//  Namespace:	Dundas.OlapChartSamples.OlapServiceDemo
//
//	Classes:	OlapServiceDemo
//
//  Purpose:	Dundas OLAP Services Demo application main mage.
//
//	Reviewed:	
//
//===================================================================
// Dundas Chart Control .Net
// Copyright � Dundas Software 2005, all rights reserved
//===================================================================

using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.IO;
using Dundas.Olap.WebUIControls;

namespace Dundas.OlapChartSamples.OlapServiceDemo
{
	/// <summary>
	/// Dundas OLAP Services Demo application main mage.
	/// </summary>
	public class OlapServiceDemo : System.Web.UI.Page
	{
		protected Dundas.OlapChartSamples.OlapServiceDemo.ConnectDlg ConnectDlg;
		protected Dundas.OlapChartSamples.OlapServiceDemo.LoadReportDlg LoadReportDlg;

		protected Dundas.Olap.Data.Adomd.AdomdDataProvider adomdDataProvider;
		protected System.Web.UI.WebControls.Button ButtonConnect;
		protected System.Web.UI.WebControls.Button ButtonLoad;
		protected System.Web.UI.HtmlControls.HtmlInputButton ButtonPrint;
		protected System.Web.UI.WebControls.Button ButtonAdvanced;
		protected Dundas.Olap.WebUIControls.OlapClient OlapClient;
		protected System.Web.UI.WebControls.Panel PanelToolBar;
		protected System.Web.UI.WebControls.Button ButtonSave;
		//protected System.Web.UI.WebControls.Panel PanelToolBar;

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			if ( !this.Page.IsPostBack)
			{
				//set the provider default connection string.
				//note that provider will be keeped into OlapManager state, in a session variable.
				
				this.adomdDataProvider.ConnectionString = 
					String.Format("Data Source={0}; Provider=msolap;", 
						this.Server.MapPath("~/OfflineData/WarehouseAndSales.cub")
					);

				//load default reports
				this.OlapClient.OlapManager.LoadReports( 
						this.Server.MapPath("~/OfflineCubeReports.xml")
					);
				// set first report as current.
				this.OlapClient.OlapManager.SetCurrentOlapReport(
						this.OlapClient.OlapManager.OlapReports[0]
					);

				// set the javascript click event of the print button.
				// note that we transfer the olap manager session key
				this.ButtonPrint.Attributes["onclick"] = 
					String.Format(
					"javascript:window.open('PrintReport.aspx?olapkey={0}','_blank')",
					this.OlapClient.OlapManager.SessionKey 
					);
			}
		}

		#region Web Form Designer generated code

		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.adomdDataProvider = new Dundas.Olap.Data.Adomd.AdomdDataProvider();
			this.ButtonConnect.Click += new System.EventHandler(this.ButtonConnect_Click);
			this.ButtonLoad.Click += new System.EventHandler(this.ButtonLoad_Click);
			this.ButtonSave.Click += new System.EventHandler(this.ButtonSave_Click);
			this.ButtonAdvanced.Click += new System.EventHandler(this.ButtonAdvanced_Click);
			// 
			// adomdDataProvider
			// 
			this.adomdDataProvider.ConnectionString = "";
			this.Load += new System.EventHandler(this.Page_Load);
			this.Init += new System.EventHandler(this.OlapServiceDemo_Init);

		}
		#endregion

		#region Methods

		private void SetButtonsEnableFlag( bool enable)
		{
			this.ButtonConnect.Enabled = enable;
			this.ButtonLoad.Enabled = enable;
			this.ButtonPrint.Disabled = !enable;
			this.ButtonAdvanced.Enabled = enable;
			this.ButtonSave.Enabled = enable;
		}

		#endregion //Methods

		#region Event Handlers

		/// <summary>
		/// Initializes page
		/// </summary>
		/// <param name="sender">The page</param>
		/// <param name="e">An empty event argument</param>
		private void OlapServiceDemo_Init(object sender, System.EventArgs e)
		{
			// setup dialog controls
			this.ConnectDlg.OlapManager = this.OlapClient.OlapManager;
			this.ConnectDlg.CloseDialog += new System.EventHandler(this.Dialog_CloseDialog);

			this.LoadReportDlg.OlapManager = this.OlapClient.OlapManager;
			this.LoadReportDlg.CloseDialog += new System.EventHandler(this.Dialog_CloseDialog);

		}

		/// <summary>
		/// The method handles CloseDialog Events of UserControl dialogs.
		/// </summary>
		/// <param name="sender">The sender object ( some dialog - user control)</param>
		/// <param name="e">An empty event argument</param>
		private void Dialog_CloseDialog(object sender, System.EventArgs e)
		{
			// hide dialog control and show olap client control
			((UserControl) sender).Visible = false;
			this.OlapClient.Visible = true;
			this.SetButtonsEnableFlag( true );
		}  

		/// <summary>
		/// The method handles ButtonConnect click event.
		/// </summary>
		/// <param name="sender">The sender object - button</param>
		/// <param name="e">An empty event argument</param>
		private void ButtonConnect_Click(object sender, System.EventArgs e)
		{
			// show dialog control and hide olap client control
			this.ConnectDlg.Visible = true;
			this.OlapClient.Visible = false;
			this.SetButtonsEnableFlag( false );
		}

		/// <summary>
		/// The method handles ButtonLoad click event.
		/// </summary>
		/// <param name="sender">The sender object - button</param>
		/// <param name="e">An empty event argument</param>
		private void ButtonLoad_Click(object sender, System.EventArgs e)
		{
			// show dialog control and hide olap client control
			this.LoadReportDlg.Visible = true;
			this.OlapClient.Visible = false;
			this.SetButtonsEnableFlag( false );
		}

		/// <summary>
		/// The method handles ButtonAdvanced click event.
		/// </summary>
		/// <param name="sender">The sender object - button</param>
		/// <param name="e">An empty event argument</param>
		private void ButtonAdvanced_Click(object sender, System.EventArgs e)
		{
			// setup olap client control showXXX properties
			bool advancedView = !this.OlapClient.ShowDimensionBrowser;
			this.OlapClient.ShowDimensionBrowser = advancedView;
			this.OlapClient.ShowCubeSelector = advancedView;
			this.OlapClient.ShowAxisBuilderCategorical = advancedView;
			this.OlapClient.ShowAxisBuilderSeries = advancedView;
			this.OlapClient.ShowAxisBuilderSlicer = advancedView;
			ButtonAdvanced.Text = advancedView ? "Simple View" : "Advanced View";
		}

		/// <summary>
		/// The method handles ButtonSave click event.
		/// </summary>
		/// <param name="sender">The sender object - button</param>
		/// <param name="e">An empty event argument</param>
		private void ButtonSave_Click(object sender, System.EventArgs e)
		{
			// writes the serialized olap reports in response
			using( MemoryStream stream = new MemoryStream())
			{
				this.OlapClient.OlapManager.SaveReports(stream);
				this.Response.Clear();
				this.Response.AppendHeader( "content-disposition","attachment; filename=OlapReportSet.rep");
				this.Response.ContentType = "application/bin";
				this.Response.BinaryWrite( stream.GetBuffer());
				this.Response.End();
			}
		}

		#endregion //Event Handlers


	}
}
