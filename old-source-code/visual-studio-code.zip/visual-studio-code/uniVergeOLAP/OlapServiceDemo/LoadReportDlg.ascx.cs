//=================================================================
//  File:		LoadReportDlg.aspx.cs
//
//  Namespace:	Dundas.OlapChartSamples.OlapServiceDemo.LoadReportDlg
//
//	Classes:	OlapServiceDemo
//
//  Purpose:	Load OLAP report dialog user control.
//
//	Reviewed:	
//
//===================================================================
// Dundas Chart Control .Net
// Copyright � Dundas Software 2005, all rights reserved
//===================================================================

namespace Dundas.OlapChartSamples.OlapServiceDemo
{
	using System;
	using System.Data;
	using System.Drawing;
	using System.Web;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;
	using System.ComponentModel;
	using System.IO;
	using Dundas.Olap.WebUIControls;
	using Dundas.Olap.Manager;	

	/// <summary>
	///	Load OLAP report dialog user control.
	/// </summary>
	public abstract class LoadReportDlg : System.Web.UI.UserControl
	{
		#region Fields		
		protected System.Web.UI.WebControls.Label ErrorLabel;
		protected System.Web.UI.WebControls.RadioButtonList ReportSourceType;
		protected System.Web.UI.WebControls.Button ButtonOK;
		protected System.Web.UI.WebControls.Button ButtonCancel;
		protected System.Web.UI.HtmlControls.HtmlInputFile FileControl;

		protected Dundas.Olap.Manager.OlapManager OlapManager1;
		private static readonly object EventClose;
		
		#endregion //Fields

		#region Constructors
		static LoadReportDlg()
		{
			LoadReportDlg.EventClose = new object();
		}

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
		}

		#endregion //Constructors

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.ReportSourceType.SelectedIndexChanged += new System.EventHandler(this.ReportSourceType_SelectedIndexChanged);
			this.ReportSourceType.PreRender += new System.EventHandler(this.ReportSourceType_PreRender);
			this.ButtonOK.Click += new System.EventHandler(this.ButtonOK_Click);
			this.ButtonCancel.Click += new System.EventHandler(this.ButtonCancel_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		#region OlapManager property and CloseDialog Event

		/// <summary>
		/// Gets and sets the OlapManager object reference
		/// </summary>
		public OlapManager OlapManager
		{
			get
			{
				return this.OlapManager1;
			}
			set
			{
				this.OlapManager1 = value;
			}
		}

		/// <summary>
		/// Fires when the dialog is about to close
		/// </summary>
		[
		Category("Action"), 
		Browsable(true),
		Description("Fires when the dialog is about to close.")
		]
		public event EventHandler CloseDialog
		{
			add
			{
				base.Events.AddHandler(LoadReportDlg.EventClose, value);
			}
			remove
			{
				base.Events.RemoveHandler(LoadReportDlg.EventClose, value);
			}
		}

		/// <summary>
		/// Raises the CloseDialog event of the ConnectDlg control.
		/// </summary>
		/// <param name="e">A System.EventArgs that contains the event data. </param>
		protected virtual void OnCloseDialog(EventArgs e)
		{
			EventHandler handler = (EventHandler) base.Events[LoadReportDlg.EventClose];
			if (handler != null)
			{
				handler(this, e);
			}
		}

		#endregion //OlapClient property and CloseEvent

		#region Event Handlers

		private void ButtonOK_Click(object sender, System.EventArgs e)
		{
			Dundas.Olap.Manager.OlapManager olapManager = this.OlapManager;
			if ( ReportSourceType.SelectedIndex == 1 )
			{
				if (FileControl.PostedFile != null) 
				{
					using ( MemoryStream saveStream = new MemoryStream())
					{
						try 
						{
							olapManager.SaveReports( saveStream);
							olapManager.LoadReports( FileControl.PostedFile.InputStream);
							olapManager.SetCurrentOlapReport(olapManager.OlapReports[0]);
						}
						catch (Exception ex) 
						{
							saveStream.Position = 0;
							olapManager.LoadReports( saveStream);
							olapManager.SetCurrentOlapReport(olapManager.OlapReports[0]);
							this.ErrorLabel.Text = ex.Message;
							this.ErrorLabel.Visible = true;
						}
					}
				}
			}
			else
			{
				olapManager.LoadReports( this.Server.MapPath("~/OfflineCubeReports.xml"));
				olapManager.SetCurrentOlapReport(olapManager.OlapReports[0]);
			}
			this.OnCloseDialog( EventArgs.Empty );
		}

		private void ReportSourceType_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			FileControl.Disabled = ReportSourceType.SelectedIndex == 0;
		}

		private void ReportSourceType_PreRender(object sender, System.EventArgs e)
		{
			this.ButtonOK.Enabled = this.OlapManager != null;
		}

		private void ButtonCancel_Click(object sender, System.EventArgs e)
		{
			this.OnCloseDialog( EventArgs.Empty );
		}

		#endregion //Event Handlers
	}
}
