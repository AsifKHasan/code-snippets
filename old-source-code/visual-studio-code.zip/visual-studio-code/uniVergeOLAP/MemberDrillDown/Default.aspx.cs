using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using Dundas.Olap.Manager;
using Dundas.Olap.Data;
using Dundas.Olap.WebUIControls;

namespace Dundas.OlapChartSamples.MemberDrillDown
{
	/// <summary>
	/// Summary description for _Default.
	/// </summary>
	public class MemberDrillDown : System.Web.UI.Page
	{
		protected Dundas.Olap.Manager.OlapManager OlapManager;
		protected Dundas.Olap.WebUIControls.OlapChart OlapChart;
		protected Dundas.Olap.Data.Adomd.AdomdDataProvider adomdDataProvider;

	
		private bool canDrillDown = true;

		private void Page_Load(object sender, System.EventArgs e)
		{

			//********************************************************
			// Customize chart control
			//********************************************************

			// Disable member drill-down
			this.OlapChart.EnableMemberDrillDown = false;

			// Disable legend
			this.OlapChart.Legends["Default"].Enabled = false;

			
			if ( !this.IsPostBack)
			{
				//set the provider default connection string.
				//note that provider will be keeped into OlapManager state.
				
				this.adomdDataProvider.ConnectionString = 
					String.Format("Data Source={0}; Provider=msolap;", 
					this.Server.MapPath("~/OfflineData/WarehouseAndSales.cub")
					);

				// In order to keep 'back' feature the olapmanager data
				// will be deployed to form viewstate.
				this.OlapManager.UsePageViewState = true;

				//********************************************************
				// Create initial OLAP report shown in the chart
				//********************************************************

				// Create and initialize new report
				OlapReport report = new OlapReport();
				report.Name = "ChartReport";
				report.CubeName = "Warehouse and Sales";
				report.DataTitleFormat = "\r\n" + report.DataTitleFormat;

				// Specify Categorical dimensions (Dimension Name, Level and Members)
				DimensionDescriptor productDescriptor = new DimensionDescriptor();
				productDescriptor.ShowAllParentLevels = false;
				productDescriptor.DimensionName = "Product";
				productDescriptor.LevelName = "Product Department";
				productDescriptor.Members.Add("Beverages");
				productDescriptor.Members.Add("Canned Foods");
				productDescriptor.Members.Add("Deli");
				productDescriptor.Members.Add("Frozen Foods");
				productDescriptor.Members.Add("Produce");
				productDescriptor.Members.Add("Household");
				report.AxisDescriptorCategorical.Dimensions.Add(productDescriptor);


				// Specify Series dimensions
				DimensionDescriptor measuresDescriptor = new DimensionDescriptor();
				measuresDescriptor.DimensionName = "Measures";
				measuresDescriptor.Members.Add("Store Sales");
				report.AxisDescriptorSeries.Dimensions.Add(measuresDescriptor);

				// Set current OlapManager report
				this.OlapManager.OlapReports.Add(report);
				this.OlapManager.SetCurrentOlapReport(report);

				// Add title promting the user to click on the data points
				Title title = new Title("Click on the Product value for more details!", Docking.Top);
				title.Name = "Analyze";
				title.Font = new Font("Verdana", 7);
				title.Alignment = ContentAlignment.TopLeft;
				title.DockInsideChartArea = false;
				title.DockToChartArea = "Default";
				this.OlapChart.Titles.Add(title);

			}
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.adomdDataProvider = new Dundas.Olap.Data.Adomd.AdomdDataProvider();
			this.OlapChart.Command += new System.Web.UI.WebControls.CommandEventHandler(this.OlapChart_Command);
			this.OlapChart.Customize += new Dundas.Olap.WebUIControls.CustomizeEventHandler(this.OlapChart_Customize);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void OlapChart_Customize(Dundas.Olap.WebUIControls.Chart sender)
		{
			// Customize datapoint map areas
			DataPointCollection dataPoints = this.OlapChart.Series[0].Points;
			for( int index = 0; index < dataPoints.Count; index ++)
			{
				DataPoint p = dataPoints[index];

				if ( this.canDrillDown )
				{
					p.MapAreaAttributes =  " onmouseover=\"javascript:pointOver(this)\" ";
					// Add postback command "DrillDown" with point index as parameter.
					p.Href = this.Page.GetPostBackClientHyperlink(
								this.OlapChart,
								"DrillDown:" + index.ToString()
							);
				}
			}
		}

		private void OlapChart_Command(object sender, System.Web.UI.WebControls.CommandEventArgs e)
		{
			if ( e.CommandName.StartsWith("DrillDown:"))
			{
				
				int index = Int32.Parse(e.CommandName.Replace("DrillDown:",""));
				
				// Force data populating.
				this.OlapChart.PopulateChartData();
				// Locate tuple accoding the command parameter.
				Tuple tuple = this.OlapChart.GetDataPointCategoricalTuple( index);

				if(tuple != null)
				{
					// Get last member in the tuple
					Member tupleMember = tuple.Members[tuple.Members.Count - 1];

					// Check if clicked member has cild members
					if(tupleMember.ChildMembers.Count > 0)
					{

						// Generate report title
						string memberCaption = tupleMember.GetFullCaption(this.OlapManager.GetDataSchema(), true);
						this.OlapManager.CurrentOlapReport.DataTitleFormat = "\r\n#MEASURES of " + memberCaption;
						this.OlapManager.CurrentOlapReport.DataTitleFormat = this.OlapManager.CurrentOlapReport.DataTitleFormat.Replace(": ", "\r\n");

						// Fill collection of members in the descriptor using child
						// members of clicked memeber.
						DimensionDescriptor descriptor = this.OlapManager.CurrentOlapReport.AxisDescriptorCategorical.Dimensions.FindByName("Product");
						descriptor.Members.Clear();
						this.canDrillDown = false;
						foreach(Member childMember in tupleMember.ChildMembers)
						{
							descriptor.Members.Add(
								childMember.Name, 
								childMember.UniqueName);

							// Check if further drill down is possible
							if(childMember.HasChildMembers)
							{
								this.canDrillDown = true;
							}
						}

						// Update current chart categorical axis dimension descriptor
						// of the "Product" dimension
						this.OlapManager.SetAxisDimensionDescriptor(DataAxisType.Categorical, descriptor);
					}

					// Notify end-user that there is no more drill down
					if(!this.canDrillDown)
					{
						this.OlapChart.Titles["Analyze"].Text = "No more details available!";
					}
				}
			}
		}
	}
}
