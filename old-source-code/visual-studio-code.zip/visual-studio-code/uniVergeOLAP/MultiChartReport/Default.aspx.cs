using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.IO;
using Dundas.Olap.WebUIControls;
using Dundas.Olap.Manager;
using Dundas.Olap.Data;

namespace Dundas.OlapChartSamples.MultiChartReport
{
	/// <summary>
	/// Summary description for _Default.
	/// </summary>
	public class DefaultPage : System.Web.UI.Page
	{

		// OLAP intitial report
		private	OlapReport		initialReport = null;
		// Memory stream used to save/load chart appearance
		private	MemoryStream			chartTemplateStream = null;

		private ArrayList   olapChartList = new ArrayList();

		protected System.Web.UI.WebControls.Table ChartTable;
		protected Dundas.Olap.Data.Adomd.AdomdDataProvider adomdDataProvider;
		protected Dundas.Olap.Manager.OlapManager OlapManager;
		protected System.Web.UI.WebControls.CheckBox CheckBoxSameYScale;
		protected Dundas.Olap.WebUIControls.OlapChart LegendChart;
		protected System.Web.UI.WebControls.DropDownList ComboBoxLevel;
		protected System.Web.UI.WebControls.Label HeadLabel;


		private void Page_Load(object sender, System.EventArgs e)
		{
			// set the provider default connection string.
			this.adomdDataProvider.ConnectionString = 
				String.Format("Data Source={0}; Provider=msolap;", 
				this.Server.MapPath("~/OfflineData/WarehouseAndSales.cub")
				);
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.adomdDataProvider = new Dundas.Olap.Data.Adomd.AdomdDataProvider();
			// 
			// adomdDataProvider
			// 
			this.adomdDataProvider.ConnectionString = "";
			this.Load += new System.EventHandler(this.Page_Load);
			this.Init += new System.EventHandler(this.Page_Init);
			this.PreRender += new System.EventHandler(this.Page_PreRender);

		}
		#endregion

		private OlapChart CreateOlapChart()
		{
			// Create and add a new OLAP chart control
			OlapChart chart = new OlapChart();
			this.chartTemplateStream.Seek(0, SeekOrigin.Begin);
			chart.Serializer.Load(this.chartTemplateStream);
				
			// Create new OLAP Manager and associate it with the chart
			OlapManager newOlapManager = new OlapManager();
			newOlapManager.SetCurrentOlapReport(this.initialReport.Clone());
			newOlapManager.DataSchemaCacheObject = this.OlapManager.DataSchemaCacheObject;
			newOlapManager.DataProvider = this.adomdDataProvider;
			chart.OlapManager = newOlapManager;
			chart.ImageUrl = "~/temp/ChartPic_#SEQ(300,3)";
			chart.EnableMemberDrillDown = false;
			chart.Width = 190;
			chart.Height = 190;
			return chart;
		}

		private void Page_Init(object sender, System.EventArgs e)
		{

			// loads template into memory stream.
			using (FileStream stream = new FileStream( this.Server.MapPath("SmallChartTemplate.xml"), FileMode.Open, FileAccess.Read, FileShare.Read))
			{
				byte[] buffer = new byte[stream.Length];
				stream.Read( buffer, 0, (int)stream.Length);
				this.chartTemplateStream = new MemoryStream( buffer); 
			}

			// Create and initialize new report
			this.initialReport = new OlapReport();
			this.initialReport.Name = "ChartReport";
			this.initialReport.CubeName = "Warehouse and Sales";
			this.initialReport.DataTitleFormat = "Test";

			// Specify Categorical dimensions (Dimension Name, Level and Members)
			DimensionDescriptor descriptor = new DimensionDescriptor();
			descriptor.ShowAllParentLevels = true;
			descriptor.DimensionName = "Time";
			descriptor.LevelName = "Quarter";
			this.initialReport.AxisDescriptorCategorical.Dimensions.Add(descriptor);


			// Specify Series dimensions
			DimensionDescriptor measuresDescriptor = new DimensionDescriptor();
			measuresDescriptor.DimensionName = "Measures";
			measuresDescriptor.Members.Add("Store Sales");
			measuresDescriptor.Members.Add("Store Cost");
			this.initialReport.AxisDescriptorSeries.Dimensions.Add(measuresDescriptor);
		
		}

		private void PopulateChartTable()
		{
			this.HeadLabel.Text = " Sales Performance Report By " + ComboBoxLevel.SelectedItem.Value + ":";

			// Get members from the specified Level of the 'Store' dimension
			CubeDataSchema dataSchema = this.OlapManager.GetDataSchema("Warehouse and Sales");
			Dimension storeDimension = dataSchema.Dimensions.FindByName("Store");
			Level storeLevel = storeDimension.GetDefaultHierarchy().Levels.FindByName(ComboBoxLevel.SelectedItem.Value);
			MemberCollection members = storeLevel.Members;


			// Iterate through all members and create OLAP charts
			double	maxYValue = double.MinValue;
			foreach(Member member in members)
			{
				if(member.Name.Length > 0)
				{
					// Get new OLAP chart control from the cache and insert it into the panel
					OlapChart chart = this.CreateOlapChart();
					this.olapChartList.Add(chart);

					// Set OLAP manger report using current member as a slicer
					chart.OlapManager.CurrentOlapReport.DataTitleFormat = member.Caption;
					DimensionDescriptor	storeSlicerDescriptor = new DimensionDescriptor();
					storeSlicerDescriptor.DimensionName = "Store";
					storeSlicerDescriptor.Members.Add(member.Name, member.UniqueName);
					chart.OlapManager.CurrentOlapReport.AxisDescriptorSlicer.Dimensions.Clear();
					chart.OlapManager.CurrentOlapReport.AxisDescriptorSlicer.Dimensions.Add(storeSlicerDescriptor);
					chart.PopulateChartData();

					// Recalculate axes scale maximum and minimum
					chart.ChartAreas["Default"].ReCalc();
					maxYValue = Math.Max(maxYValue, chart.ChartAreas["Default"].AxisY.Maximum);
				}
			}

			// Apply the same Y axis scale for the rest
			if(this.CheckBoxSameYScale.Checked)
			{
				foreach( OlapChart chart in this.olapChartList)
				{
					chart.ChartAreas["Default"].AxisY.Maximum = maxYValue;
				}
			}

			int rowCount = this.olapChartList.Count / 3 + 1;
			int currentChart = 0;
			for( int rowIndex = 0; rowIndex < rowCount; rowIndex++)
			{
				TableRow row = new TableRow();
				this.ChartTable.Rows.Add( row);
				for( int cellIndex = 0; cellIndex < 3; cellIndex ++)
				{
					TableCell cell= new TableCell();
					row.Cells.Add( cell);
					if ( currentChart < this.olapChartList.Count )
					{
						cell.Controls.Add( (OlapChart)this.olapChartList[currentChart]);
						currentChart++;
					}
				}
			}

		}

		private void Page_PreRender(object sender, System.EventArgs e)
		{
			this.PopulateChartTable();
		}


	}
}
