using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using Dundas.Olap.Manager;
using Dundas.Olap.Data;

namespace Dundas.OlapChartSamples.SimpleOlapChart
{
	/// <summary>
	/// Summary description for _Default.
	/// </summary>
	public class SimpleOlapChart : System.Web.UI.Page
	{
		protected Dundas.Olap.WebUIControls.OlapChartToolbar OlapChartToolbar1;
		protected Dundas.Olap.Data.Adomd.AdomdDataProvider adomdDataProvider;
		protected Dundas.Olap.Manager.OlapManager OlapManager;
		protected Dundas.Olap.WebUIControls.OlapChart OlapChart1;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			if ( !this.IsPostBack )
			{


				//set the provider default connection string.
				//note that provider will be keeped into OlapManager state, in a session variable.
				
				this.adomdDataProvider.ConnectionString = 
					String.Format("Data Source={0}; Provider=msolap;", 
					this.Server.MapPath("~/OfflineData/WarehouseAndSales.cub")
					);
				
				//********************************************************
				// Set current OLAP report.
				//********************************************************

				// Create and initialize new report
				OlapReport report = new OlapReport();
				report.Name = "Default Report";

				report.CubeName = "Warehouse and Sales";

				// Add 'Time' dimension to the Categorical axis
				DimensionDescriptor descriptor = new DimensionDescriptor();
				descriptor.ShowAllParentLevels = true;
				descriptor.DimensionName = "Time";
				report.AxisDescriptorCategorical.Dimensions.Add(descriptor);

				// Add 'Yearly Income' dimension to the Categorical axis
				descriptor = new DimensionDescriptor();
				descriptor.DimensionName = "Yearly Income";
				descriptor.LevelName = "Yearly Income";
				report.AxisDescriptorCategorical.Dimensions.Add(descriptor);

				// Show Warehouse Sales and Cost as series by adding them to the Series axis
				DimensionDescriptor measuresDescriptor = new DimensionDescriptor();
				measuresDescriptor.DimensionName = "Measures";
				measuresDescriptor.Members.Add("Store Sales");
				measuresDescriptor.Members.Add("Store Cost");
				report.AxisDescriptorSeries.Dimensions.Add(measuresDescriptor);
				
				this.OlapManager.OlapReports.Add( report );
				// Set report as current
				this.OlapManager.SetCurrentOlapReport(report);
			}
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.adomdDataProvider = new Dundas.Olap.Data.Adomd.AdomdDataProvider();
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
	}
}
