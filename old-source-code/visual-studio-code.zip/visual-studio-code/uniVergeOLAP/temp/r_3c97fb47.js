


var DundasLib = {

browserVersion : -1,
msieFlag: false,
geckoFlag: false,

init: function(){
	DundasLib.browserVersion = parseInt(window.navigator.appVersion.charAt(0), 10);
	DundasLib.msieFlag  = window.navigator.userAgent.indexOf("MSIE") > -1;
	DundasLib.geckoFlag = window.navigator.userAgent.indexOf("Gecko") > -1;
},

fixEvent : function( e )
	{
			if (typeof(e) == 'undefined') e = window.event;
			if (typeof(e.layerX) == 'undefined') e.layerX = e.offsetX;
			if (typeof(e.layerY) == 'undefined') e.layerY = e.offsetY;
			if (typeof(e.target) == 'undefined') e.target = e.srcElement;
			
			return e;
	},
	
attachEvent : function(obj, evType, fn, useCapture){
	if (obj.addEventListener)
	{
		obj.addEventListener(evType, fn, useCapture ? true : useCapture);
		return true;
	}
	else if (obj.attachEvent)
	{
		var r = obj.attachEvent("on"+evType, fn);
		return r;
	}
	else 
	{
		return false;
	}
},
		
detachEvent: function (obj, evType, fn, useCapture){
	if (obj.removeEventListener)
	{
		obj.removeEventListener(evType, fn, useCapture);
		return true;
	}
	else if (obj.detachEvent)
	{
		var r = obj.detachEvent("on"+evType, fn);
		return r;
	}
	else
	{
		alert("Handler could not be removed");
	}
},

getScreenHeight: function () {
	if (window.innerHeight!=window.undefined) return window.innerHeight;
	if (document.compatMode=='CSS1Compat') return document.documentElement.clientHeight;
	if (document.body) return document.body.clientHeight; 
	return window.undefined; 
},
			
getScreenWidth : function () {
	if (window.innerWidth!=window.undefined) return window.innerWidth; 
	if (document.compatMode=='CSS1Compat') return document.documentElement.clientWidth; 
	if (document.body) return document.body.clientWidth; 
	return window.undefined; 
},

tabIndexes   : new Array(),

disableTabs: function () {
	if (document.all) {
		var tabs = new Array("A","BUTTON","TEXTAREA","INPUT","IFRAME");
		storage = new Array();
		for (var i = 0; i < tabs.length; i++) {
			var tagElements = document.getElementsByTagName(tabs[i]);
			for (var j = 0 ; j < tagElements.length; j++) {
				var data = new Object();
				data.element  = tagElements[j];
				data.tabIndex = tagElements[j].tabIndex;
				storage[storage.length] = data;
				tagElements[j].tabIndex="-1";
			}
		}
		DundasLib.tabIndexes = storage;
	}
},


restoreTabs: function () {
	if (document.all) {
		for( var i = 0; i < DundasLib.tabIndexes.length; i++)
		{
			var elm = DundasLib.tabIndexes[i].element;
			elm.tabIndex = DundasLib.tabIndexes[i].tabIndex;
		}
	}
},

hidenSelects : null,

hideSelects : function () {
	if ( DundasLib.msieFlag )
	{
		var storage = new Array();
		for(var i = 0; i < document.forms.length; i++) {
			for(var e = 0; e < document.forms[i].length; e++){
				if(document.forms[i].elements[e].tagName == "SELECT") {
					var elm = document.forms[i].elements[e];
					if ( elm.style.visibility != "hidden" )
					{
						try
						{
						storage[storage.length] = new Array( elm, elm.style.visibility);
						elm.style.visibility = "hidden";
						} catch(exc) {;}
					}
				}
			}
		}
		DundasLib.hidenSelects = storage;
	}
},

restoreSelects: function () {
	if ( DundasLib.msieFlag && DundasLib.hidenSelects != null)
	{
		var storage = DundasLib.hidenSelects;
		for(var i = 0; i < storage.length; i++) {
			var data = storage[i]; 
			data[0].style.visibility=data[1];
		}
	}
},

dialogMask      : null,
dialogContainer : null,
dialogFrame		: null,
dialogTitleBar  : null,
dialogTitle		: null,
dialogInner		: null,
dialogControls	: null,


dialogMaskS     : "AZGSANAH",
dialogContainerS: "AHSS6636",
dialogFrameS	: "HYWW7HS8",
dialogTitleBarS : "SJS8AH6W",
dialogTitleS	: "X873HSST",
dialogInnerS	: "AHSYWSH8",
dialogControlsS	: "AAU7WY7A",


initPopUp : function () {
		
		DundasLib.dialogMask      = document.getElementById(DundasLib.dialogMaskS	   );
		DundasLib.dialogContainer = document.getElementById(DundasLib.dialogContainerS );
		DundasLib.dialogFrame	  = document.getElementById(DundasLib.dialogFrameS	   );
		DundasLib.dialogTitleBar  = document.getElementById(DundasLib.dialogTitleBarS  );
		DundasLib.dialogTitle	  = document.getElementById(DundasLib.dialogTitleS	   );
		DundasLib.dialogInner	  = document.getElementById(DundasLib.dialogInnerS	   );
		DundasLib.dialogControls  = document.getElementById(DundasLib.dialogControlsS  );
		DundasLib.attachEvent(window, "resize", DundasLib.centerDialog);
		DundasLib.attachEvent(window, "scroll", DundasLib.centerDialog);
},

noCenter		: false,
dialogIsShown	: false,
dialogRetFunc	: null,
dialogDragData  : null,
showDialog : function(url, width, height, returnFunc, left, top, title){
	
	DundasLib.dialogIsShown = true;
	DundasLib.noCenter = false;
	
	DundasLib.disableTabs();
	
	DundasLib.startUp();	
	
	DundasLib.dialogMask.style.display = "block";
	DundasLib.dialogContainer.style.display = "block";

	DundasLib.centerDialog(width, height);
	
	if ( left && top)
	{
		DundasLib.dialogContainer.style.top  = top;
		DundasLib.dialogContainer.style.left = left;
		DundasLib.noCenter = true;
	}
	
	
	var titleBarHeight = parseInt(DundasLib.dialogTitleBar.offsetHeight, 10);

	DundasLib.dialogContainer.style.width = width + "px";
	DundasLib.dialogContainer.style.height = (height+titleBarHeight) + "px";
	DundasLib.dialogFrame.style.width  = parseInt(DundasLib.dialogTitleBar.offsetWidth, 10) + "px";
	DundasLib.dialogFrame.style.height = (height) + "px";
	
	DundasLib.dialogFrame.src = url;
	if ( title )
	{
		DundasLib.dialogTitle.innerHTML = title;		
	}
	else
	{	
		DundasLib.dialogTitle.innerHTML = "";		
	}
	
	DundasLib.dialogRetFunc = returnFunc;
	if (DundasLib.msieFlag) {
		DundasLib.hideSelects();
	}
	if ( DundasLib.dialogTitle.onmousedown == null )
	{
		DundasLib.dialogTitle.onmousedown = DundasLib.startDlgDrag;
	}
	DundasLib.dialogDragData = null;
}, 	

startDlgDrag : function ( event)
{
	var e = DundasLib.fixEvent(event);
	DundasLib.dialogDragData = {x:e.screenX, y:e.screenY};
	DundasLib.dialogTitle.style.cursor = "move";
	DundasLib.attachEvent(document,"mousemove", DundasLib.moveDlgDrag);
	DundasLib.attachEvent(document,"mouseup", DundasLib.stopDlgDrag);
	return false;
},

stopDlgDrag :function ( )
{
	DundasLib.dialogDragData = null;
	DundasLib.dialogTitle.style.cursor = "default";
	DundasLib.detachEvent(document,"mousemove", DundasLib.moveDlgDrag);
	DundasLib.detachEvent(document,"mouseup", DundasLib.stopDlgDrag);
},

moveDlgDrag :function ( event)
{
	if ( DundasLib.dialogDragData != null )
	{ 
		var e = DundasLib.fixEvent(event);
		var oldData = DundasLib.dialogDragData;
		var newData = {x:e.screenX, y:e.screenY};
		var top  = parseInt(DundasLib.dialogContainer.style.top);
		var left = parseInt(DundasLib.dialogContainer.style.left);
		DundasLib.dialogContainer.style.top  = top  + (newData.y - oldData.y);
		DundasLib.dialogContainer.style.left = left + (newData.x - oldData.x);
		DundasLib.dialogDragData = newData;
	}
},

centerDialog : function(width, height)
{
	if (DundasLib.dialogIsShown)
	{
		if (width == null || isNaN(width)) {
			width = DundasLib.dialogContainer.offsetWidth;
		}
		if (height == null) {
			height = DundasLib.dialogContainer.offsetHeight;
		}
		
		var fullHeight = DundasLib.getScreenHeight();
		var fullWidth = DundasLib.getScreenWidth();

		var scTop = parseInt(document.body.scrollTop,10);
		var scLeft = parseInt(document.body.scrollLeft,10);
		
		DundasLib.dialogMask.style.height = fullHeight + "px";
		DundasLib.dialogMask.style.width = fullWidth + "px";
		DundasLib.dialogMask.style.top = scTop + "px";
		DundasLib.dialogMask.style.left = scLeft + "px";
		
		if ( !DundasLib.noCenter )
		{
			var titleBarHeight = parseInt(DundasLib.dialogTitleBar.offsetHeight, 10);
			
			DundasLib.dialogContainer.style.top = (scTop + ((fullHeight - (height+titleBarHeight)) / 2)) + "px";
			DundasLib.dialogContainer.style.left =  (scLeft + ((fullWidth - width) / 2)) + "px";
		}
	
	}
},

closeDialog : function(getResult)
{
	DundasLib.dialogIsShown = false;
	DundasLib.restoreTabs();
	DundasLib.dialogMask.style.display = "none";
	DundasLib.dialogContainer.style.display = "none";
	if (getResult == true && DundasLib.dialogRetFunc != null)
	{
		DundasLib.dialogRetFunc(DundasLib.dialogFrame.returnVal);
	}
	
	//DundasLib.dialogFrame.src = "scripts/loading.html";
	DundasLib.dialogFrame.src = _olapResourceURL + "wait.htm";

	if (DundasLib.msieFlag) {
		DundasLib.restoreSelects();
	}

},

//*******************************************************

createElementID : function ( tag, id) {
	var result = document.createElement( tag);
	result.id = id;
	result.name = id;
	return result;
},

adjustPosition : function(e_x, e_y, element)
{

	e_x = parseInt(e_x);
	e_y = parseInt(e_y);
	wnd_height=document.body.clientHeight;
	wnd_width=document.body.clientWidth;
	tooltip_width =(element.style.pixelWidth) ? element.style.pixelWidth  : element.offsetWidth;
	tooltip_height=(element.style.pixelHeight)? element.style.pixelHeight : element.offsetHeight;
	
	offset_y = (e_y + tooltip_height - document.body.scrollTop + 30 >= wnd_height) ? - tooltip_height: 0;
	offset_x = (e_x + tooltip_width  - document.body.scrollLeft + 30 >= wnd_width) ? - tooltip_width: 0;

	element.style.left = e_x + offset_x;
	element.style.top = e_y + offset_y;
	element.style.display = "block";
},


getElmPosition : function ( obj, afterAbs ){

	var r = { x:0, y:0, w:obj.offsetWidth, h:obj.offsetHeight};
	if (obj == null) { return r; }
	var saveElement = obj;
	if (obj.offsetParent)
	{
		while (obj.offsetParent)
		{
			r.y += obj.offsetTop;
			r.x += obj.offsetLeft;
			obj = obj.offsetParent;
			if ( DundasLib.msieFlag )
			{
				if ( obj.style.position == "absolute" && afterAbs != true)
				{
					break;
				}
			}
		}
	}
	else if (obj.y)
	{
		r.y += obj.y;
		r.x += obj.x;
	}
			
	obj = saveElement;
	
	if (obj.parentNode )
	{
		while( obj.parentNode && obj.tagName != "BODY")
		{
			if(obj.style && obj.style.overflow == "auto" && typeof(obj.scrollLeft) != 'undefined') 
			{
				r.x += obj.scrollLeft;
				r.y += obj.scrollTop;
			}
			obj = obj.parentNode;					
		}
	}
	return r;
},


dimInFlag : false,

dimElement : false,

dimMouse : function (inout){
	DundasLib.dimInFlag = inout;
},

dimSelect : function(src, dimName) {
	var elm = document.getElementById(dimName+"_addto");
	if ( elm && elm.style.display == "none")
	{
		var r = DundasLib.getElmPosition(src.offsetParent);
		DundasLib.dimElement = elm;
		elm.style.left = r.x + r.w;
		if ( DundasLib.msieFlag )
		{
			elm.style.top  = r.y;
		}
		else
		{
			elm.style.top  = r.y;
		}
		elm.style.position = "absolute";
		elm.style.zIndex = 1000;
		elm.style.display = "block";
		DundasLib.attachEvent(document, "mousedown", DundasLib.dimClose);
	}
	return false;
},

dimClose : function() {
	var elm = DundasLib.dimElement;
	if ( elm && elm.style.display == "block" && !DundasLib.dimInFlag)
	{
		elm.style.display = "none";
		DundasLib.dimInFlag = false;
		DundasLib.detachEvent(document, "mousedown", DundasLib.dimClose);
	}
},

popupRenRep : function(sKey) {
	var url = _olapResourceURL + "renreport.aspx?"; 
	var frameHeight = 80;
	var frameWidth  = 400;
	if ( DundasLib.geckoFlag )
	{
		//frameHeight = 288;
	}
	DundasLib.showDialog( url + "key="+sKey, frameWidth, frameHeight, null, null, null, "Rename Report");
},

popupFilter : function(axtype, sKey) {
	var url = _olapResourceURL + "filterdlg.aspx?"; 
	var frameHeight = 296;
	var frameWidth  = 410;
	if ( DundasLib.geckoFlag )
	{
		frameHeight = 288;
	}
	DundasLib.showDialog( url + "key="+sKey+"&axtype=" + axtype, frameWidth, frameHeight, null, null, null, "Sorting and Filtering");
},

poupDescr : function ( axtype, id, elName, sKey) {
	var targetEl = document.getElementById(elName);
	var rect = DundasLib.getElmPosition( targetEl, true );
	if ( targetEl )
	{
		var frameHeight = 314;
		var frameWidth  = 266;
		if ( DundasLib.msieFlag )
		{
			frameHeight = 312;
			frameWidth  = 260;
		}
		var top = 0;
		var left = 0;
		if ( axtype.indexOf("Categorical") > -1)
		{
			top  = rect.y - frameHeight - 6 - 24;
			left = rect.x;
		}
		else if( axtype.indexOf("Slicer") > -1)
		{
			top  = rect.y + rect.h + 4;
			left = rect.x;
		}
		else
		{
			top  = rect.y + rect.h + 4;
			left = rect.x + rect.w - frameWidth;
		}
		if ( left < 0 || top < 0)
		{
			left = null;
			top  = null;
		}
		if ( axtype == "Slicer")
		{
			frameHeight -= 26;			
		}
		var url = _olapResourceURL + "dimbrdlg.aspx?"; 
		DundasLib.showDialog( url + "key="+sKey+"&type="+axtype+"&dsid="+id+"&el="+elName, frameWidth, frameHeight, null, left, top, "Edit "+ axtype +" Axis Item")
	}
	return false;
},

popupDimBr : function ( axtype, id, sKey) {
	var frameHeight = 314 - 26;
	var frameWidth  = 266;
	var url = _olapResourceURL + "dimbrgdlg.aspx?"; 
	DundasLib.showDialog( url + "key="+sKey+"&type="+axtype+"&dsid="+id, frameWidth, frameHeight, null, null, null, "Add Dimension to "+ axtype)
	return false;
},

labels : new Array(),

addAbsLabel : function( labelID)
{
	DundasLib.labels[DundasLib.labels.length] = labelID;
},

fixLabel: function( labelID )
{
	var el = document.getElementById( labelID);
	if ( el )
	{
		var r = DundasLib.getElmPosition( el.parentNode );
		if ( r )
		{
			el.style.top = r.y;
			el.style.left = r.x + 10;
			el.style.display = "block";
		}
	}
},

fixLabels : function()
{
	var a = DundasLib.labels;
	for( var i = 0; i < a.length; i++)
	{
		DundasLib.fixLabel( a[i]);		
	}
},

fixChartFrame: function( chartFrame)
{
	var el = document.getElementById(chartFrame);
	var w = el.clientWidth;
	var h = el.clientHeight;
	var src = el.src.substr(0, el.src.indexOf("&w")) + "&w=" + w + "&h=" + h;
	el.src = src;
	el.style.visibility = "visible";
},
startUpFlag : false,
startUp: function()
{
	if ( !DundasLib.startUpFlag )
	{
		if ( typeof(_axd1a) != "undefined" )
		{
			for( var i = 0; i < _axd1a.length; i++)
			{
				_axd1a[i]();	
			}
		}
		DundasLib.fixLabels();
		DundasLib.initPopUp();
		DundasLib.startUpFlag = true;
	}
}

}

var DundasTB = {

activeMenu : null,
btnElement : null,

popMenu: function( elm, url, e, afterAbs)
{
	var e = e ? DundasLib.fixEvent( e) : null;
	
	DundasTB.closeMenu();
	var fr = document.getElementById("ds_popframe");
	if ( e )
	{
		var scTop = parseInt(document.body.scrollTop,10);
		var scLeft = parseInt(document.body.scrollLeft,10);
		fr.style.left = e.clientX + scLeft;
		fr.style.top  = e.clientY + scTop;
	}
	else
	{
		var r = DundasLib.getElmPosition( elm, true);
		fr.style.left = r.x;
		fr.style.top  = r.y + r.h;
	}
	fr.style.display = "block";
	fr.src = url;
	DundasTB.btnElement = elm;
	DundasTB.tbOver( DundasLib.btnElement);
	DundasTB.activeMenu = fr;
	window.setTimeout("DundasTB.setCloseMenu()", 100)
},

showMenu: function ( elm, menuID )
{
	DundasTB.closeMenu();
	var el = document.getElementById(menuID);
	el.style.display =  'block';
	var r = DundasLib.getElmPosition( el.parentNode);
	el.style.left = r.x - 3;
	DundasTB.btnElement = elm;
	DundasTB.tbOver( DundasLib.btnElement);
	DundasTB.activeMenu = el;
	window.setTimeout("DundasTB.setCloseMenu()", 100)
},

menuHandlerAttached : false,

cancelCloseMenu : function ()
{
	if ( DundasTB.menuHandlerAttached )
	{
		DundasLib.detachEvent(document, "click", DundasTB.closeMenu);
		DundasTB.menuHandlerAttached = false;
	}
},

setCloseMenu : function ()
{
	if ( !DundasTB.menuHandlerAttached )
	{
		DundasLib.attachEvent(document, "click", DundasTB.closeMenu);
		DundasTB.menuHandlerAttached = true; 
	}
},

closeMenu : function ()
{
	DundasTB.cancelCloseMenu();
	if ( DundasTB.activeMenu != null )
	{
		DundasTB.activeMenu.style.display="none";
		DundasTB.activeMenu.style.width = 0;
		DundasTB.activeMenu.style.height = 0;
		DundasTB.activeMenu = null;
		DundasTB.tbOut( DundasTB.btnElement);
		DundasTB.btnElement = null;
    }
},

tbOverMnu : function ( el )
{
	el.className = "ds_mtbover";
},

tbOutMnu: function ( el )
{
	el.className = "ds_tbbtn";
},

tbOver : function ( el )
{
	if ( DundasTB.activeMenu == null && el)
	{
		el.className = "ds_tbover";
	}
},

tbOut : function ( el )
{
	if ( DundasTB.activeMenu == null && el)
	{
		el.className = "ds_tbbtn";
	}
},

AXBackHover : function (control)
{
	if ( control.rows )
	{
		var cells = control.rows[0].cells;
		for( var i = 0; i < cells.length; i++)
		{
			cells[i].style.backgroundImage = cells[i].style.backgroundImage.replace("hv-0","hv-1");
		}
	}
},

AXBackOut : function (control)
{
	if ( control.rows )
	{
		var cells = control.rows[0].cells;
		for( var i = 0; i < cells.length; i++)
		{
			cells[i].style.backgroundImage = cells[i].style.backgroundImage.replace("hv-1","hv-0");
		}
	}
}

}

var DundasDrag = {
	
	dragSources : new Array(),
	dragTargets : new Array(),
	
	addSource : function ( elID, onGetDragDataF )
	{
		var el = document.getElementById( elID);
		if ( el )
		{
			el.setAttribute("dragndrop", "true");
			var obj = new Object();
			obj.element = el;
			obj.getDragData = onGetDragDataF;
			obj.dragData  = null;
			DundasDrag.dragSources[DundasDrag.dragSources.length] = obj;
		}	
	},
	
	addTarget : function ( elID, onCanAcceptF, onEndDragF )
	{
		var el = document.getElementById( elID);
		if ( el )
		{
			el.setAttribute("dragndrop", "true");
			var obj = new Object();
			obj.element = el;
			obj.canAccept = onCanAcceptF;
			obj.endDrag = onEndDragF;
			DundasDrag.dragTargets[DundasDrag.dragTargets.length] = obj;
		}		
	},
	
img_drag : null,

showCursor : function (e, accept)
	{
			var scTop = parseInt(document.body.scrollTop,10);
			var scLeft = parseInt(document.body.scrollLeft,10);
			img_drag.style.left  = e.clientX + 8 + scLeft;
			img_drag.style.top   = e.clientY + 12 + scTop;
			if ( accept )
			{
				img_drag.src = img_drag.src.replace("0.gif","1.gif")
			}
			else
			{
				img_drag.src = img_drag.src.replace("1.gif","0.gif")
			}
			if ( img_drag.style.display == "none")
			{
				img_drag.style.display = "block";
			}
	},

hideCursor : function ()
	{
		img_drag.style.display = "none";
	},
	
initDrag : function ()
	{
		DundasLib.attachEvent(document, "mousedown", DundasDrag.dragStart);
		img_drag = document.getElementById("img_drag_na");
	},


locateEventSrc : function ( el )
	{
		while ( el  )
		{
			if ( el.getAttribute && el.getAttribute("dragndrop") == "true" )
			{
				return el;
			}
			el = el.parentNode;
		}
		return null;
	},

locateElement : function ( el, dragArr )
	{
		for( var i = 0; i < dragArr.length; i++)
		{
			if ( dragArr[i].element == el )
			{
				return dragArr[i];
			}		
		}
		return null;
	},
dragSource : null,
dragActive : false,
dragHack   : false,
dragPoint  : null,
dragSquare : 8,
isDragMove :function( e )
{
	var dp1 = DundasDrag.dragPoint;
	var dp2 = {X:e.screenX, Y:e.screenY};
	var result = Math.abs(dp1.X - dp2.X) + "/" + Math.abs(dp1.Y - dp2.Y);
	return ( Math.abs(dp1.X - dp2.X) > DundasDrag.dragSquare || Math.abs(dp1.Y - dp2.Y) > DundasDrag.dragSquare )
},

dragStart : function ( event)
	{
		
		DundasLib.startUp();
		
		var e = DundasLib.fixEvent(event);
		if ( e.button && e.button != 1)
		{
			return (false);
		}
		DundasDrag.dragPoint = {X:e.screenX, Y:e.screenY};
		var srcElm = DundasDrag.locateEventSrc( e.target);
		if ( srcElm )
		{
			var d = DundasDrag.locateElement( srcElm, DundasDrag.dragSources);
			if ( d )
			{
				d.dragData = d.getDragData( srcElm, e.target);
				if ( d.dragData != null )
				{
					DundasDrag.dragSource = d;
					document.body.style.cursor = "default";
					DundasLib.attachEvent(document, "mousemove", DundasDrag.dragMove);
					DundasLib.attachEvent(document, "mouseup", DundasDrag.dragDrop);
					DundasDrag.dragSquare = 8;
					if ( DundasLib.dragHack )
					{
						DundasDrag.dragSquare = -1;
						DundasDrag.dragMove(event);
						DundasLib.dragHack = false;
					}
				}
			}
			return false;
		}
	},
iiii : 0,
mapID: null,
dragFixMap : function ( e )
{
	e.targetX = e.target;
	DundasDrag.mapID = null;
	var srcElm = DundasDrag.locateEventSrc( e.target);
	if ( !srcElm && e.target && e.target.tagName && e.target.tagName == "AREA")
	{
		var map = e.target.parentNode
		if ( map )
		{
			DundasDrag.mapID = e.target;
			var name = map.id != '' ? map.id :  map.getAttribute("name");
			//e.target = document.getElementById(name.replace("ImageMap",""));
			e.targetX = document.getElementById(name.replace("ImageMap",""));
			srcElm = DundasDrag.locateEventSrc( e.targetX);
		}
	}
	return srcElm
},

dragMove: function( event)
	{
		if ( DundasDrag.dragSource != null )
		{
			var e = DundasLib.fixEvent(event)
			if ( !DundasDrag.dragActive )
			{
				if ( !DundasDrag.isDragMove( e ) )
				{
					return false;
				}
			}
			DundasDrag.dragActive = true;
			accept = false;
			var srcElm = DundasDrag.dragFixMap( e);
			if ( srcElm )
			{
				var d = DundasDrag.locateElement( srcElm, DundasDrag.dragTargets);
				if ( d )
				{
					accept = d.canAccept(srcElm, e.targetX, e);			
				}
			}
			DundasDrag.showCursor( e, accept);
			return false;
		}
	},
	
dragDrop: function( event)
	{
		DundasDrag.hideCursor();
		DundasLib.detachEvent(document, "mousemove", DundasDrag.dragMove);
		DundasLib.detachEvent(document, "mouseup", DundasDrag.dragDrop);
		document.body.style.cursor = "";
		if ( DundasDrag.dragActive )
		{
			var e = DundasLib.fixEvent(event)
			var srcElm = DundasDrag.dragFixMap( e);
			if ( srcElm )
			{
				var d = DundasDrag.locateElement( srcElm, DundasDrag.dragTargets);
				if ( d && d.canAccept(srcElm, e.targetX, e) )
				{		
					d.endDrag(srcElm, e.targetX, e);
				}
			}
		}
		DundasDrag.dragSource = null;
		DundasDrag.dragActive = false;
		return false;
	},
	
DBStartDrag : function( tree, element)
	{
		var input   = DundasTree.getInputByName("SelectedNode", tree);
		var selectedNode = DundasTree.getSelectedNode( input.value, tree);
		var slnNode = new DundasTreeNode( element);
		if ( element.getAttribute("value") != null && slnNode.isValid() )
		{
			return "B:" + slnNode.getValue();
		}						
		return null;
	},

DBCanAccept : function( container, element)
{
	if ( DundasDrag.dragSource && DundasDrag.dragSource.dragData )
	{
		var s = DundasDrag.dragSource.dragData;
		return s.indexOf("X:") > -1 && s.indexOf(",true") == -1;
	}
	return false;
},

DBDrop: function( control, element)
{
	if ( DundasDrag.dragSource != null )
	{
		var s = DundasDrag.dragSource.dragData;
		__doPostBack(control.id, "drop@" + s);		
	}
},

ChartCanAccept : function( container, element)
{
	if ( DundasDrag.dragSource && DundasDrag.dragSource.dragData )
	{
		var s = DundasDrag.dragSource.dragData;
		return s.indexOf("B:") > -1;
	}
	return false;
},

ChartDrop: function( control, element)
{
	if ( DundasDrag.dragSource != null )
	{
		var attr = "";
		if ( DundasDrag.mapID )
		{
			attr = DundasDrag.mapID.getAttribute("adds")
			if (!attr)
			{
				attr = "";
			}
		}
		var s = DundasDrag.dragSource.dragData + attr;
		__doPostBack(control.id, "drop@" + s);		
	}
},

AXGetIdElement : function ( element, control )
{
		var el = element;
		while ( el.id.length == 0 )
		{
			el = el.parentNode;	
		}
		if ( el.id == control.id )
		{
			var el1 = element;
			while ( el1 && el1.id.length == 0 )
			{
				el1 = el1.firstChild;
				if ( el1 && el1.nodeType == 3 )
				{
					el1 = null;
				}	
			}
			if ( el1 && el1.id.length > 0 )
			{
				el = el1;
			}
		}
		return el;
},

AXGetTopElement : function ( controlID )
{
		var idx = 0;
		var result = null;
		var check = null;
		while (( check = document.getElementById(controlID +  "_C" + idx++)))
		{
			result = check;
		}
		return result;
},

AXBStartDrag : function (control, element)
{
	if ( control.getAttribute("axtype") != null)
	{
		if ( element.onclick != null)
		{
			return null;
		}
		var type = control.getAttribute("axtype")
		var el = DundasDrag.AXGetIdElement(element, control);
		var noID = el.id.replace( control.id, "");
		var isMeasure =  false;
		if ( el.getAttribute("measure"))
		{
			isMeasure = true;
		}
		if ( noID != "" )
		{
			DundasLib.dragHack = true;
			return "X:" + type + "," + noID.replace("_P","") + "," + isMeasure;
		}
	}
	return null;
},

AXBCanAccept : function (control, element, e)
{
	if ( DundasDrag.dragSource && DundasDrag.dragSource.dragData )
	{
		var s = DundasDrag.dragSource.dragData;
		var type = control.getAttribute("axtype");
		if ( type == "Slicer" )
		{
			if ( s.indexOf("X:") > -1 && s.indexOf(",true") > -1)
			{
				return false;
			}
			var mname = control.getAttribute("mesaure");
			var idx = s.indexOf(mname);
			if ( s.indexOf("B:") > -1 && (idx == 2 || idx == 3))
			{
				return false;
			}
		}
		var el = DundasDrag.AXGetIdElement(element, control);
		var name = el.id.replace( control.id, "");
		var borderName = "";
		if ( name.indexOf("_P") > -1)
		{
			var rect = el.rect ? el.rect : DundasLib.getElmPosition( el, true);
			control.rect = rect;
			
			var idx = parseInt(name.replace("_P",""));
			var isvert = control.getAttribute("vertical") == "true";
			if ( !isvert )
			{
				if ( (e.clientX - rect.x) > (rect.w/2) )
				{
					idx ++;
				}
			}
			else
			{
				if ( (e.clientY - rect.y) > (rect.h/2) )
				{
					idx ++;
				}
			}
			borderName = control.id + "_C" + idx.toString();
		}
		else if ( name.indexOf("_C") > -1)
		{
			borderName = control.id + name;
		}
		else
		{
			var elm = DundasDrag.AXGetTopElement( control.id );
			if ( elm )
			{
				borderName = elm.id;
			}
		}
		if ( borderName != "")
		{
			var borderEl   = document.getElementById( borderName );
			if ( control.selectedDropArea )
			{
				control.selectedDropArea.style.backgroundColor = "";
			}
			if ( borderEl )
			{
				borderEl.style.backgroundColor = "black";
				control.selectedDropArea = borderEl;
			}
		}
		return s.indexOf("B:") > -1 || s.indexOf("X:") > -1 && control.selectedDropArea;
	}
	return false;
},

AXBDrop : function (control, element, e)
{
	if ( control.selectedDropArea )
	{
		var el = control.selectedDropArea;
		var s = DundasDrag.dragSource.dragData;
		var dragData = DundasDrag.AXBStartDrag( control, element);
		if ( dragData != s )
		{
			s += "!>>" + el.id.replace( control.id + "_C", "");
			__doPostBack(control.id, "drop@" + s);
		}
	}
},

AXMouseOut : function(event, element)
{
	var e = DundasLib.fixEvent( event );
	//if (element.selectedDropArea && e.target == element)
	if (element.selectedDropArea)
	{
		element.selectedDropArea.style.backgroundColor = "";
		element.selectedDropArea = null;
	}
}

}

DundasLib.init();
DundasLib.attachEvent(window, "load", DundasLib.startUp);
DundasLib.attachEvent(window, "resize", DundasLib.fixLabels);


