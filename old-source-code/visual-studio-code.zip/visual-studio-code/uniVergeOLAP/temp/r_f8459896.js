
var DundasTree = {

	click : function( e, control )
	{
		 e = DundasTree.fixEvent(e);
		 DundasTree.callee_control = control;
		 
		 var element = e.target;
		 if ( "IMG,A,INPUT".indexOf(element.tagName) != -1)
		 {
			if ( element.tagName == "A")
			{
				DundasTree.selectNode( element, control);
				return false;
			}
			else if ( element.tagName == "IMG")
			{
				if ( element.getAttribute("checked") == null)
				{
					DundasTree.expandOrColapse(element, control)
				}
				else
				{
					DundasTree.checkBoxProcess(element, control)
				}
			}
		 }
		 return false;
	},	
	
	fixEvent : function( e )
	{
			if (typeof(e) == 'undefined') e = window.event;
			if (typeof(e.layerX) == 'undefined') e.layerX = e.offsetX;
			if (typeof(e.layerY) == 'undefined') e.layerY = e.offsetY;
			if (typeof(e.target) == 'undefined') e.target = e.srcElement;
			
			return e;
	},
	
	scroll : function( e, control )
	{
		 var input = DundasTree.getInputByName( "ScrollTo", control);
		 if ( input )
		 {
			input.value = control.scrollLeft + ";" + control.scrollTop;
		 }
	},
	
	callee_control  : null,
	
	getControl : function ( o )
	{
		return DundasTree.callee_control;
	},

	getParentByTag : function ( o, tagName)	
	{
		if ( o == null )
		{
			return null;
		}	
		var target = o;
		while ( target.tagName != tagName)
		{
			target = target.parentNode;
			if ( target == null )
			{
				break;
			}
		}
		return target;
	},


	getElementByName : function ( nodeList, id)
	{
		for( i = 0; i < nodeList.length; i++)
		{
			if (nodeList.item(i).name == id)
			{
				return nodeList.item(i);
			}
		}
	},


	getSelectedNode : function ( nodePath, control ) 
	{
		if ( nodePath.length == 0 )
		{
			return null;
		}
		var result = null;
		var nodes = control.childNodes;
		for( i = 0; i < nodes.length; i++)
		{
			if ( nodes[i].tagName == "TABLE")
			{
				result = (new DundasTreeNode(nodes[i])).getByPath(nodePath);
				if ( result )
				{
					return result;
				}
			}
		}		
		return null;
	},

	getInputByName : function ( name, control)
	{
		var form    = DundasTree.getParentByTag( control, "FORM");
		if ( form )
		{
			return DundasTree.getElementByName ( form.getElementsByTagName("INPUT"), control.id + "_" + name);
		}
		return null;	
	},
	
	nodeResult   : "",
	
	selectNode : function ( item, control )
	{
		var input   = DundasTree.getInputByName("SelectedNode", control);
		var oldSelectedNode = DundasTree.getSelectedNode( input.value, control);
		var newSelectedNode = new DundasTreeNode( item);
		
		if ( oldSelectedNode )
		{
			oldSelectedNode.applySelectStyle( "s" + control.id);
			input.value = "";
		}		
		if ( newSelectedNode )
		{
			newSelectedNode.applySelectStyle( "ss" + control.id);
			input.value = newSelectedNode.getPath();
			DundasTree.nodeResult = input.value;
		}	
		return;
	},
		
	expandOrColapse : function (element, control)
	{	
		var o = new DundasTreeNode( element)
		if ( o.isValid() )
		{
			var input = DundasTree.getInputByName( "ExpandedNodes", control);
			o.switchExpanded( control);
			if ( input )
			{
				if ( !o.isExpanded())
				{
					input.value = input.value.replace("{" +o.getPath() + "};", "");
				}		
				else
				{
					input.value = input.value + "{" + o.getPath() + "};"
				}
			}
			return true;
		}
		return false;
	},
	
	checkBoxProcess : function (element, control)
	{	
		var o = new DundasTreeNode( element)
		if ( o.isValid() && o.isCheckBox())
		{
			var input = DundasTree.getInputByName( "CheckedNodes", control);
			o.switchCBox( control, input);
			return true;
		}
		return false;
	},
	
	fixScroll: function ( name, x, y ) 
	{ 

		if (document.getElementById) 
		{ 
			var el = document.getElementById(name);
			if ( el) 
			{ 
				if ( el.style.display == "none" ) 
				{ 
					var isGecko = window.navigator.userAgent.indexOf("Gecko") > -1;
					var p = el.offsetParent ? el.offsetParent : el.parentNode; 
					if (p) 
					{
						if ( isGecko )
						{
							el.style.width	= (p.clientWidth  - 4)+"px"; 
							el.style.height = (p.clientHeight - 4)+"px";	
						}
						else
						{
							el.style.width	= (p.clientWidth  - 4)+"px"; 
							el.style.height = (p.clientHeight - 4)+"px";	
						}
						el.style.display = "block";
					} 
				}
				el.scrollLeft=x; 
				el.scrollTop=y; 
				if ( el.scrollLeft!=x)  el.scrollLeft=x; 
				if ( el.scrollTop !=y)  el.scrollTop=y; 
			}
		}
	}
};

var cbState_checked    = "c";
var cbState_unchecked  = "u";
var cbState_multiple   = "m";

function DundasTreeNode( element)
{
	this.image = null;
	this.anchor = null;
	this.span = null;
	this.table = null;
	this.cbox  = null;
	
	this.isValid = function () { return this.getValue() != null }
	
	
	this.isExpanded = function() { 
		if (this.span)
		{
			return this.span.style.display == "block";
		}
		return false;
	}

	this.isCheckBox = function() { return this.cbox != null }
	
	this.switchCBox = function ( control, input)
	{
		var state = this.getCBoxState();
		var single = control.getAttribute('single') == 'true';
		if ( single )
		{
			if (state != cbState_checked)
			{
				this.uncheckAll( control, input);
				this.setCBoxState( cbState_checked, control, input );
			}
		}
		else 
		{		
			if ( !this.hasChildren() )
			{
				if ( state == cbState_checked )
				{
					this.setCBoxState( cbState_unchecked, control, input );
				}
				else if ( state == cbState_unchecked )
				{
					this.setCBoxState( cbState_checked, control, input);
				}
			}
			else
			{
				if ( state == cbState_checked )
				{
					this.setCBoxState( cbState_multiple, control, input );
				}
				else if ( state == cbState_unchecked )
				{
					this.setCBoxState( cbState_checked, control, input );
				}
				else if ( state == cbState_multiple )
				{
					this.setCBoxState( cbState_unchecked, control, input );
				}
			}
		}
	}

	this.uncheckRecs = function(control, input)
	{
		this.setCBoxState( cbState_unchecked, control, input, true );
		if ( this.hasChildren())
		{
			var list = this.getChildren();
			for( var i = 0; i < list.length; i++)
			{
				list[i].uncheckRecs(control, input);
			}
		}
	}
	
	this.uncheckAll = function( control, input)
	{
		var elms = control.getElementsByTagName("TABLE");
		for(var i = 0; i < elms.length; i++)
		{
			var node = new DundasTreeNode( elms[i]);
			if ( node.isValid())
			{
				node.setCBoxState( cbState_unchecked, control, input, true );
			}
		}
	}
			
	this.getCBoxState = function () {
		if ( this.cbox != null )
		{
			return this.cbox.getAttribute("checked");
		}		
		return "0";
	}

	this.setCBoxState = function ( state, control, input, stopProp) {
		if ( this.cbox != null )
		{
			
			this.cbox.setAttribute("checked", state);
			this.cbox.src = control.getAttribute( "imgcb" + state);

			if ( input )
			{
				if ( state == cbState_checked)
				{
					input.value = input.value + "{" + this.getPath() + "};"
				}		
				else
				{
					input.value = input.value.replace(new RegExp("\\{" + this.getPath() + "\\};","i"), "");
				}
			}			

			
			if ( stopProp == null )
			{
				if ( this.hasChildren() && state != cbState_checked)
				{
					var list = this.getChildren();
					for( var i = 0; i < list.length; i++)
					{
						if ( state == cbState_multiple )
						{
							list[i].setCBoxState( cbState_checked, control, input, true );
						}
						else if ( state == cbState_unchecked )
						{
							if ( list[i].getCBoxState() != cbState_unchecked )
							{
								list[i].setCBoxState( cbState_unchecked, control, input);
							}
						}
					}
				}
				
				var p = this.getParent();
				while ( p != null )
				{
					if ( state != cbState_unchecked )
					{
						p.setCBoxState( cbState_multiple, control, input, true );
					} 
					else if ( p.getCBoxState() == cbState_multiple)
					{
						list = p.getChildren();
						var hasChecked = false;
						for ( var i = 0; i < list.length; i++)
						{
							if ( list[i].getCBoxState() != cbState_unchecked)
							{	
								hasChecked = true;
								break;
							}
						}
						if ( !hasChecked )
						{	
							p.setCBoxState( cbState_unchecked, control, input, true );
						}
					}
					p = p.getParent();
				}
			}
			return true;
		}		
		return false;
	}
	
	this.switchExpanded = function( control) { 
		if (this.span)
		{
			if ( this.isExpanded() )
			{
				this.span.style.display = "none";
				this.image.src = control.getAttribute( "imgc");
			}
			else
			{
				this.span.style.display = "block";
				this.image.src = control.getAttribute( "imge");
			}
		}
	}

	this.getParent = function (){
		if ( this.table )
		{
			var parentSpan = DundasTree.getParentByTag(this.table,"SPAN");
			if ( parentSpan && parentSpan.previousSibling.tagName == "TABLE")
			{
				return new DundasTreeNode(parentSpan.previousSibling);
			}
		}		
		return null;
	}
	
	this.applySelectStyle = function ( sname ) {this.anchor.className = sname; }
	
	this.hasChildren = function ()	{ return this.span != null; }
	
	this.getChildren = function ()	{
		var list = new Array();
		if ( this.span )
		{
			for( i = 0; i < this.span.childNodes.length; i++)
			{
				var node = this.span.childNodes.item(i);
				if ( node.tagName == "TABLE")
				{
					list[list.length] = new DundasTreeNode( node);
				}
			}
		}	
		return list;
	}
	
	this.getByPath = function ( path ) {
		var pathList = path.split("/");
		if ( pathList.length > 0 )
		{
			if ( this.getValue() == pathList[0] )
			{
				if ( pathList.length > 1 )
				{
					pathList.shift();
					var path1 =  pathList.join("/");
					var c = this.getChildren();
					for( i = 0; i < c.length; i ++)
					{
						var res = c[i].getByPath( path1 );
						if ( res != null )
						{
							return res;
						}
					}
				}
				else
				{
					return this;
				}
			}
		}
		return null;	
	}
	
	this.getValue = function () { return this.anchor ? this.anchor.getAttribute("value") : null }
	
	this.getPath = function() {
		var p = this.getParent();
		if ( p != null )
		{
			return p.getPath() + "/" + this.getValue();	
		}
		return this.getValue();
	}
	
	if ( element )
	{
		if ( element.tagName != "TABLE")
		{
			this.table = DundasTree.getParentByTag(element,"TABLE");
		}
		else
		{
			this.table = element;
		}
		if ( this.table)
		{
			elms = this.table.getElementsByTagName("IMG");
			if ( elms.length > 0 )
			{
				this.cbox  = elms[elms.length-1]
			}
			
			this.image  = this.table.getElementsByTagName("IMG")[0]

			elms = this.table.getElementsByTagName("A")
			if ( elms.length > 0 )
			{
				this.anchor = elms[elms.length-1]	
			}
			
			this.span = this.table.nextSibling;
			if ( this.span && this.span.tagName != "SPAN")
			{
				this.span = null;
			}
		}
	}
}
