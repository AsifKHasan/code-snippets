using System;
using NUnit.Framework;
using NUnit.Core;
using DataAccess;

namespace Test01
{
	[TestFixture]
	public class DataAccessTest
	{
		[Test]
		public void testRowCount()
		{
			Component1 component1 = new Component1();
			Assert.IsNotNull(component1);
			
			Assert.AreEqual(0, component1.GetRowCount());
			component1.Init();

			Assert.IsTrue(component1.GetRowCount() > 0);			
		}

		[Test]
		public void testGetData()
		{
			Component1 component1 = new Component1();
			component1.Init();
			DataSet1 dataset = component1.GetDataSet();
			Assert.IsNotNull(dataset);
			Assert.IsTrue(dataset.x_emattn.Rows.Count > 0);
		}
	}
}
