using System;
using NUnit.Framework;
using NUnit.Core;
using Test01.localhost1;

namespace Test01
{
	[TestFixture]
	public class WebServiceTest
	{
		[Test]
		public void TestGetRow()
		{
			Service1 service1 = new Service1();
			Assert.IsNotNull(service1);
			
			String result = service1.HelloWorld();
			Assert.AreEqual("Hello World", result);

			Assert.IsTrue(service1.GetRowCount() > 0);
		}
	
		public void TestGetDataSet()
		{
			Service1 service1 = new Service1();
			DataSet1 dataset = service1.GetDataSet();
			Assert.IsTrue(dataset.x_emattn.Rows.Count > 0);
		}
	}
}
