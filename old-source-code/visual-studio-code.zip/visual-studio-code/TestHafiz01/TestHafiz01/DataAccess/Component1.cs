using System;
using System.ComponentModel;
using System.Collections;
using System.Diagnostics;

namespace DataAccess
{
	/// <summary>
	/// Summary description for Component1.
	/// </summary>
	public class Component1 : System.ComponentModel.Component
	{
		private System.Data.SqlClient.SqlCommand sqlSelectCommand1;
		private System.Data.SqlClient.SqlCommand sqlInsertCommand1;
		private System.Data.SqlClient.SqlCommand sqlUpdateCommand1;
		private System.Data.SqlClient.SqlCommand sqlDeleteCommand1;
		private System.Data.SqlClient.SqlConnection sqlConnection2;
		private System.Data.SqlClient.SqlDataAdapter sqlDataAdapter1;
		private DataAccess.DataSet1 dataSet11;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Component1(System.ComponentModel.IContainer container)
		{
			///
			/// Required for Windows.Forms Class Composition Designer support
			///
			container.Add(this);
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		public Component1()
		{
			///
			/// Required for Windows.Forms Class Composition Designer support
			///
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}


		#region Component Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.sqlSelectCommand1 = new System.Data.SqlClient.SqlCommand();
			this.sqlInsertCommand1 = new System.Data.SqlClient.SqlCommand();
			this.sqlUpdateCommand1 = new System.Data.SqlClient.SqlCommand();
			this.sqlDeleteCommand1 = new System.Data.SqlClient.SqlCommand();
			this.sqlConnection2 = new System.Data.SqlClient.SqlConnection();
			this.sqlDataAdapter1 = new System.Data.SqlClient.SqlDataAdapter();
			this.dataSet11 = new DataAccess.DataSet1();
			((System.ComponentModel.ISupportInitialize)(this.dataSet11)).BeginInit();
			// 
			// sqlSelectCommand1
			// 
			this.sqlSelectCommand1.CommandText = "SELECT emattn_text, emattn_date, emattn_stat FROM x_emattn";
			this.sqlSelectCommand1.Connection = this.sqlConnection2;
			// 
			// sqlInsertCommand1
			// 
			this.sqlInsertCommand1.CommandText = "INSERT INTO x_emattn(emattn_text, emattn_date, emattn_stat) VALUES (@emattn_text," +
				" @emattn_date, @emattn_stat); SELECT emattn_text, emattn_date, emattn_stat FROM " +
				"x_emattn WHERE (emattn_date = @emattn_date) AND (emattn_text = @emattn_text)";
			this.sqlInsertCommand1.Connection = this.sqlConnection2;
			this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@emattn_text", System.Data.SqlDbType.VarChar, 16, "emattn_text"));
			this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@emattn_date", System.Data.SqlDbType.DateTime, 8, "emattn_date"));
			this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@emattn_stat", System.Data.SqlDbType.VarChar, 1, "emattn_stat"));
			// 
			// sqlUpdateCommand1
			// 
			this.sqlUpdateCommand1.CommandText = @"UPDATE x_emattn SET emattn_text = @emattn_text, emattn_date = @emattn_date, emattn_stat = @emattn_stat WHERE (emattn_date = @Original_emattn_date) AND (emattn_text = @Original_emattn_text) AND (emattn_stat = @Original_emattn_stat); SELECT emattn_text, emattn_date, emattn_stat FROM x_emattn WHERE (emattn_date = @emattn_date) AND (emattn_text = @emattn_text)";
			this.sqlUpdateCommand1.Connection = this.sqlConnection2;
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@emattn_text", System.Data.SqlDbType.VarChar, 16, "emattn_text"));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@emattn_date", System.Data.SqlDbType.DateTime, 8, "emattn_date"));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@emattn_stat", System.Data.SqlDbType.VarChar, 1, "emattn_stat"));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_emattn_date", System.Data.SqlDbType.DateTime, 8, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "emattn_date", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_emattn_text", System.Data.SqlDbType.VarChar, 16, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "emattn_text", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_emattn_stat", System.Data.SqlDbType.VarChar, 1, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "emattn_stat", System.Data.DataRowVersion.Original, null));
			// 
			// sqlDeleteCommand1
			// 
			this.sqlDeleteCommand1.CommandText = "DELETE FROM x_emattn WHERE (emattn_date = @Original_emattn_date) AND (emattn_text" +
				" = @Original_emattn_text) AND (emattn_stat = @Original_emattn_stat)";
			this.sqlDeleteCommand1.Connection = this.sqlConnection2;
			this.sqlDeleteCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_emattn_date", System.Data.SqlDbType.DateTime, 8, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "emattn_date", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_emattn_text", System.Data.SqlDbType.VarChar, 16, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "emattn_text", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_emattn_stat", System.Data.SqlDbType.VarChar, 1, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "emattn_stat", System.Data.DataRowVersion.Original, null));
			// 
			// sqlConnection2
			// 
			this.sqlConnection2.ConnectionString = "workstation id=EUROPA;packet size=4096;integrated security=SSPI;data source=EUROP" +
				"A;persist security info=True;initial catalog=attnlogger;User ID=sa;Password=";
			// 
			// sqlDataAdapter1
			// 
			this.sqlDataAdapter1.DeleteCommand = this.sqlDeleteCommand1;
			this.sqlDataAdapter1.InsertCommand = this.sqlInsertCommand1;
			this.sqlDataAdapter1.SelectCommand = this.sqlSelectCommand1;
			this.sqlDataAdapter1.TableMappings.AddRange(new System.Data.Common.DataTableMapping[] {
																									  new System.Data.Common.DataTableMapping("Table", "x_emattn", new System.Data.Common.DataColumnMapping[] {
																																																				  new System.Data.Common.DataColumnMapping("emattn_text", "emattn_text"),
																																																				  new System.Data.Common.DataColumnMapping("emattn_date", "emattn_date"),
																																																				  new System.Data.Common.DataColumnMapping("emattn_stat", "emattn_stat")})});
			this.sqlDataAdapter1.UpdateCommand = this.sqlUpdateCommand1;
			// 
			// dataSet11
			// 
			this.dataSet11.DataSetName = "DataSet1";
			this.dataSet11.Locale = new System.Globalization.CultureInfo("en-US");
			((System.ComponentModel.ISupportInitialize)(this.dataSet11)).EndInit();

		}
		#endregion

		private void sqlConnection1_InfoMessage(object sender, System.Data.SqlClient.SqlInfoMessageEventArgs e)
		{
		
		}

		public void Init() 
		{
			InitializeComponent();
			sqlDataAdapter1.Fill(dataSet11);
		}

		public int GetRowCount()
		{
			return dataSet11.x_emattn.Rows.Count;
		}
		
		public DataSet1 GetDataSet() 
		{
			return dataSet11;
		}
	}
}
