// QueryDefinitionParser.h: interface for the QueryDefinitionParser class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_QUERYDEFINITIONPARSER_H__05FD2C0D_ECFB_49FE_BF82_AB09234BA1FE__INCLUDED_)
#define AFX_QUERYDEFINITIONPARSER_H__05FD2C0D_ECFB_49FE_BF82_AB09234BA1FE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


#define CHECK_AND_RELEASE(pInterface)  \
if(pInterface) \
{\
pInterface->Release();\
pInterface = NULL;\
}\

#define RELEASE(pInterface)  \
{\
pInterface->Release();\
pInterface = NULL;\
}\


#include "QueryDefinitionList.h"
#include "QueryDefinition.h"
#include "QueryParameterDefinition.h"
#include "QueryResultDefinition.h"

#include <string>

using namespace std;

class QueryDefinitionParser  
{
public:
	void dumpLog();
	BOOL parseQueryDefinitionXML(CString pXMLFile);
	QueryDefinitionParser();
	virtual ~QueryDefinitionParser();

private:
	BOOL loadXMLDocument(CString pXMLFile);
	void parseQueryDefinitionList();
	QueryDefinition* parseQueryDefinition(IXMLDOMElementPtr pQueryDefinitionNode);
	QueryParameterDefinition* parseQueryParameterDefinition(IXMLDOMElementPtr pQueryParameterDefinitionNode);
	QueryResultDefinition* parseQueryResultDefinition(IXMLDOMElementPtr pQueryResultDefinitionNode);
	string getAttributeValue(IXMLDOMElementPtr pIXMLDOMElement, LPCTSTR attrname);

	IXMLDOMDocumentPtr m_plDomDocument;
	IXMLDOMElementPtr m_pDocRoot;
};

#endif // !defined(AFX_QUERYDEFINITIONPARSER_H__05FD2C0D_ECFB_49FE_BF82_AB09234BA1FE__INCLUDED_)
