// ADORecordset.cpp: implementation of the ADORecordset class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "ADORecordset.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

ADORecordset::ADORecordset()
{
	m_pRecordset.CreateInstance(__uuidof(Recordset));
}

ADORecordset::~ADORecordset()
{
	m_pRecordset.Release();
}


void ADORecordset::closeRecordset()
{
	if (m_pRecordset->GetState() == adStateOpen)
	{
		m_pRecordset->Close();
	}
}


_variant_t ADORecordset::getFieldVal(CString sFieldName)
{
	_variant_t ret;

	ret = m_pRecordset->GetCollect(sFieldName.GetBuffer(0));
	return ret;
}

long ADORecordset::getFieldCount()
{
	Fields *fFields;

	fFields = m_pRecordset->GetFields();
	return fFields->Count;
}

CString ADORecordset::getFieldName(long lFldIndex)
{
	Fields *fFields;
	Field *fField;
	CString name;

	fFields = m_pRecordset->GetFields();
	ASSERT(lFldIndex<fFields->Count); // There is no such a field index
	fField = fFields->GetItem(lFldIndex);
	name.Format("%s",(char*)_bstr_t(fField->GetName()));
	return name;
}

DataTypeEnum ADORecordset::getFieldType(long lFldIndex)
{
	Fields *fFields;
	Field *fField;

	fFields = m_pRecordset->GetFields();
	ASSERT(lFldIndex<fFields->Count); // There is no such a field index
	fField = fFields->GetItem(lFldIndex);
	return fField->Type;
}

BOOL ADORecordset::openRecordset(_ConnectionPtr pConnection, CString sSQL)
{

	try
	{
		m_pRecordset->Open(_bstr_t(sSQL), pConnection.GetInterfacePtr(), adOpenDynamic, adLockOptimistic, adCmdText);
	}
	catch(_com_error *e)
	{
		//AfxMessageBox(e->ErrorMessage());
		return false;
	}
	catch(...)
	{
		//AfxMessageBox("Unknown Error...");
		return false;
	}

	return true;

}

long ADORecordset::getRecordCount()
{
	return m_pRecordset->GetRecordCount(); 
}
