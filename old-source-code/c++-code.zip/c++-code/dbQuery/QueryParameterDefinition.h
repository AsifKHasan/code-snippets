// QueryParameterDefinition.h: interface for the QueryParameterDefinition class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_QUERYPARAMETERDEFINITION_H__897AF0F0_63FD_4FCC_86E2_5CBA8089738C__INCLUDED_)
#define AFX_QUERYPARAMETERDEFINITION_H__897AF0F0_63FD_4FCC_86E2_5CBA8089738C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "LogManager.h"

#include <string>

using namespace std;

class QueryParameterDefinition  
{
public:
	void dumpLog();
	QueryParameterDefinition();
	virtual ~QueryParameterDefinition();

	void setPos(string pos);
	string getPos();
	void setType(string type);
	string getType();

private:
	string m_pos;
	string m_type;
};

#endif // !defined(AFX_QUERYPARAMETERDEFINITION_H__897AF0F0_63FD_4FCC_86E2_5CBA8089738C__INCLUDED_)
