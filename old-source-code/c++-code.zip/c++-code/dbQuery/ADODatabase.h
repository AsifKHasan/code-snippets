// ADODatabase.h: interface for the CADODatabase class.
//
//////////////////////////////////////////////////////////////////////
/*
 *
 *
 *
 */



#if !defined(AFX_ADODATABASE_H__B7198A62_E926_47A7_8456_B1B605CA78AF__INCLUDED_)
#define AFX_ADODATABASE_H__B7198A62_E926_47A7_8456_B1B605CA78AF__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "afxtempl.h"
#include "ADORecordset.h"

#include "LogManager.h"

class ADODatabase
{
public:
	static ADODatabase* getInstance();
	static void destroyInstance();

	void init(CString sConnStr);
	virtual ~ADODatabase();

	ADORecordset* openRecordset(CString sSQL);

protected:
	ADODatabase();

private:
	static ADODatabase* _instance;
	_ConnectionPtr	m_pConnection;
};

#endif // !defined(AFX_ADODATABASE_H__B7198A62_E926_47A7_8456_B1B605CA78AF__INCLUDED_)
