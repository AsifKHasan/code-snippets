// ResultFormatter.h: interface for the ResultFormatter class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_RESULTFORMATTER_H__B8C6F8E2_A643_41DE_933C_85CA97FCC73F__INCLUDED_)
#define AFX_RESULTFORMATTER_H__B8C6F8E2_A643_41DE_933C_85CA97FCC73F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class ResultFormatter  
{
public:
	ResultFormatter();
	virtual ~ResultFormatter();

};

#endif // !defined(AFX_RESULTFORMATTER_H__B8C6F8E2_A643_41DE_933C_85CA97FCC73F__INCLUDED_)
