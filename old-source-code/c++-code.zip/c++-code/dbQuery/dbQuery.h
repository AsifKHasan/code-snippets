
#if !defined(AFX_DBQUERY_H__C9C1F533_4EEA_493D_9FF2_18C05CB46742__INCLUDED_)
#define AFX_DBQUERY_H__C9C1F533_4EEA_493D_9FF2_18C05CB46742__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "resource.h"

int initializeApplication();
void finalizeApplication();

#endif // !defined(AFX_DBQUERY_H__C9C1F533_4EEA_493D_9FF2_18C05CB46742__INCLUDED_)
