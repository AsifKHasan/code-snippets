// QueryParameterDefinitionList.h: interface for the QueryParameterDefinitionList class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_QUERYPARAMETERDEFINITIONLIST_H__0D7810E6_8577_42FD_8CB5_5D1C565774D0__INCLUDED_)
#define AFX_QUERYPARAMETERDEFINITIONLIST_H__0D7810E6_8577_42FD_8CB5_5D1C565774D0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#pragma warning(disable:4786)



#include "LogManager.h"
#include "QueryParameterDefinition.h"

#include <string>
#include <map>

using namespace std;


typedef map<string, QueryParameterDefinition*> QUERYPARAMETERDEFINITIONMAP;

class QueryParameterDefinitionList  
{
public:
	int getCount();
	void dumpLog();
	QueryParameterDefinition* getQueryParameterDefinitionByKeyword(string keyword);
	void insertQueryParameterDefinition(QueryParameterDefinition* queryParameterDefinition);
	QueryParameterDefinitionList();
	virtual ~QueryParameterDefinitionList();

private:
	QUERYPARAMETERDEFINITIONMAP* m_QueryParameterDefinitionMap;
};

#endif // !defined(AFX_QUERYPARAMETERDEFINITIONLIST_H__0D7810E6_8577_42FD_8CB5_5D1C565774D0__INCLUDED_)
