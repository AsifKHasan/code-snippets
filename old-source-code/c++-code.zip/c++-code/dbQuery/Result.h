// Result.h: interface for the Result class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_RESULT_H__B66DE0A7_AE6B_4554_AD94_B6F8B1DACA2F__INCLUDED_)
#define AFX_RESULT_H__B66DE0A7_AE6B_4554_AD94_B6F8B1DACA2F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class Result  
{
public:
	Result();
	virtual ~Result();

};

#endif // !defined(AFX_RESULT_H__B66DE0A7_AE6B_4554_AD94_B6F8B1DACA2F__INCLUDED_)
