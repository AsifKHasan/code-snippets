// QueryProcessor.h: interface for the QueryProcessor class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_QUERYPROCESSOR_H__F9DB53A0_E6B3_414A_9204_4FCE913CBC6D__INCLUDED_)
#define AFX_QUERYPROCESSOR_H__F9DB53A0_E6B3_414A_9204_4FCE913CBC6D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "QueryQueue.h"

#include "SubjectObserver.h"

class QueryProcessor : public Observer
{
public:
	static QueryProcessor* getInstance();
	static void destroyInstance();

	virtual ~QueryProcessor();
	void Update(Subject *theChangedSubject);

protected:
	QueryProcessor();

private:
	static QueryProcessor* _instance;
	QueryQueue* _subject;   // reference to subject
};

#endif // !defined(AFX_QUERYPROCESSOR_H__F9DB53A0_E6B3_414A_9204_4FCE913CBC6D__INCLUDED_)
