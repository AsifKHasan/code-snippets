// QueryQueueManager.h: interface for the QueryQueueManager class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_QUERYQUEUEMANAGER_H__3FD5711A_3C86_41C6_A396_A65F846D22EB__INCLUDED_)
#define AFX_QUERYQUEUEMANAGER_H__3FD5711A_3C86_41C6_A396_A65F846D22EB__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "QueryQueue.h"

#include <string>

using namespace std;

class QueryQueueManager  
{
public:
	static QueryQueueManager* getInstance();
	static void destroyInstance();

	void storeQuery(string question);
	virtual ~QueryQueueManager();

protected:
	QueryQueueManager();

private:
	static QueryQueueManager* _instance;
};

#endif // !defined(AFX_QUERYQUEUEMANAGER_H__3FD5711A_3C86_41C6_A396_A65F846D22EB__INCLUDED_)
