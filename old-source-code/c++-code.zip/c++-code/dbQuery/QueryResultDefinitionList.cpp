// QueryResultDefinitionList.cpp: implementation of the QueryResultDefinitionList class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "dbQuery.h"
#include "QueryResultDefinitionList.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

QueryResultDefinitionList::QueryResultDefinitionList()
{
	m_QueryResultDefinitionMap = new QUERYRESULTDEFINITIONMAP();
}

QueryResultDefinitionList::~QueryResultDefinitionList()
{
	delete m_QueryResultDefinitionMap;
}

void QueryResultDefinitionList::insertQueryResultDefinition(QueryResultDefinition* queryResultDefinition)
{
	(*m_QueryResultDefinitionMap)[queryResultDefinition->getVar()] = queryResultDefinition;
}

QueryResultDefinition* QueryResultDefinitionList::getQueryResultDefinitionByKeyword(string keyword)
{
	return (*m_QueryResultDefinitionMap)[keyword];
}

void QueryResultDefinitionList::dumpLog()
{
	LogManager* logManager = (LogManager*)(LogManager::getInstance());
	QueryResultDefinition* queryResultDefinition;

	QUERYRESULTDEFINITIONMAP::iterator theIterator;

	
	logManager->getCategory().info("START Dumping QueryResultDefinitionList");
	
	for (theIterator = (*m_QueryResultDefinitionMap).begin(); theIterator != (*m_QueryResultDefinitionMap).end(); theIterator++)
	{
		queryResultDefinition = (*m_QueryResultDefinitionMap)[(*theIterator).first];
		queryResultDefinition->dumpLog();
	}

	logManager->getCategory().info("END Dumping QueryResultDefinitionList");

}
