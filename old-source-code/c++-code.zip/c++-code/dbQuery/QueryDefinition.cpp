// QueryDefinition.cpp: implementation of the QueryDefinition class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "dbQuery.h"
#include "QueryDefinition.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

QueryDefinition::QueryDefinition()
{
	m_QueryParameterDefinitionList = new QueryParameterDefinitionList();
	m_QueryResultDefinitionList = new QueryResultDefinitionList();
}

QueryDefinition::~QueryDefinition()
{
	delete 	m_QueryParameterDefinitionList;
	delete 	m_QueryResultDefinitionList;
}


string QueryDefinition::getTag()
{
	return m_tag;
}

void QueryDefinition::setTag(string tag)
{
	m_tag = tag;
}

string QueryDefinition::getSql()
{
	return m_sql;
}

void QueryDefinition::setSql(string sql)
{
	m_sql = sql;
}

void QueryDefinition::insertQueryParameterDefinition(QueryParameterDefinition* queryParameterDefinition)
{
	m_QueryParameterDefinitionList->insertQueryParameterDefinition(queryParameterDefinition);
}

QueryParameterDefinition* QueryDefinition::getQueryParameterDefinitionByKeyword(string keyword)
{
	return m_QueryParameterDefinitionList->getQueryParameterDefinitionByKeyword(keyword); 
}

void QueryDefinition::insertQueryResultDefinition(QueryResultDefinition* queryResultDefinition)
{
	m_QueryResultDefinitionList->insertQueryResultDefinition(queryResultDefinition);
}

QueryResultDefinition* QueryDefinition::getQueryResultDefinitionByKeyword(string keyword)
{
	return m_QueryResultDefinitionList->getQueryResultDefinitionByKeyword(keyword); 
}


int QueryDefinition::getQueryParameterDefinitionCount()
{
	return m_QueryParameterDefinitionList->getCount();
}

void QueryDefinition::dumpLog()
{
	LogManager* logManager = (LogManager*)(LogManager::getInstance());


	logManager->getCategory().info("");
	logManager->getCategory().info("START Dumping QueryDefinition");
	
	logManager->getCategory().info("TAG is >> %s", m_tag.c_str());
	logManager->getCategory().info("SQL is >> %s", m_sql.c_str());
	m_QueryParameterDefinitionList->dumpLog();
	m_QueryResultDefinitionList->dumpLog();

	logManager->getCategory().info("END Dumping QueryDefinition");
	logManager->getCategory().info("");

}
