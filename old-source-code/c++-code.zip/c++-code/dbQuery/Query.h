// Query.h: interface for the Query class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_QUERY_H__17AE789E_8AA1_4C43_B6E3_ABC9824D345D__INCLUDED_)
#define AFX_QUERY_H__17AE789E_8AA1_4C43_B6E3_ABC9824D345D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <string>
#include <vector>

using namespace std;

typedef enum
{
	queryNew = 0,
	queryParseSuccess = 1,
	queryParseFailure = 2,
	queryProcessed = 3
}	QUERYSTATENUM;

typedef vector<string> PARAMVECTOR;

class Query  
{
public:
	CString getSQL();
	BOOL verifyQuery();
	void dumpLog();
	BOOL tokenizeQuery();
	int getParamCount();
	void insertParam(string param);
	string getParam(int pos);
	Query();
	virtual ~Query();

	void setQuestion(string question);
	string getQuestion();
	void setQrytag(string qrytag);
	string getQrytag();
	void setUserid(string userid);
	string getUserid();
	void setPasswd(string passwd);
	string getPasswd();

private:
	QUERYSTATENUM m_status;
	string m_question;
	string m_qrytag;
	string m_userid;
	string m_passwd;
	PARAMVECTOR* m_params;
};

#endif // !defined(AFX_QUERY_H__17AE789E_8AA1_4C43_B6E3_ABC9824D345D__INCLUDED_)
