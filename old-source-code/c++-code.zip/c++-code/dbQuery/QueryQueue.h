// QueryQueue.h: interface for the QueryQueue class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_QUERYQUEUE_H__15C97CBB_B9AE_42B7_92B0_16BDB7FAB6D9__INCLUDED_)
#define AFX_QUERYQUEUE_H__15C97CBB_B9AE_42B7_92B0_16BDB7FAB6D9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "SubjectObserver.h"

#include "Query.h"
#include <queue>

using namespace std;

typedef queue<Query*> QUERYQUEUE;

class QueryQueue : public Subject
{
public:
	Query* dispatchQuery();
	void insertQuery(string question);
	static QueryQueue* getInstance();
	static void destroyInstance();

	virtual ~QueryQueue();

protected:
	QueryQueue();

private:
	static QueryQueue* _instance;
	QUERYQUEUE* m_pQueryQueue;
};

#endif // !defined(AFX_QUERYQUEUE_H__15C97CBB_B9AE_42B7_92B0_16BDB7FAB6D9__INCLUDED_)
