// ResultFormatter.cpp: implementation of the ResultFormatter class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "dbQuery.h"
#include "ResultFormatter.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

ResultFormatter::ResultFormatter()
{

}

ResultFormatter::~ResultFormatter()
{

}
