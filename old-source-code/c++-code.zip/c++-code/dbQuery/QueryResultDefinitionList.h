// QueryResultDefinitionList.h: interface for the QueryResultDefinitionList class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_QUERYRESULTDEFINITIONLIST_H__4C9B2A98_7312_4827_9B24_6867C185CF6D__INCLUDED_)
#define AFX_QUERYRESULTDEFINITIONLIST_H__4C9B2A98_7312_4827_9B24_6867C185CF6D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#pragma warning(disable:4786)


#include "LogManager.h"
#include "QueryResultDefinition.h"

#include <string>
#include <map>

using namespace std;

typedef map<string, QueryResultDefinition*> QUERYRESULTDEFINITIONMAP;

class QueryResultDefinitionList  
{
public:
	void dumpLog();
	QueryResultDefinition* getQueryResultDefinitionByKeyword(string keyword);
	void insertQueryResultDefinition(QueryResultDefinition* queryResultDefinition);
	QueryResultDefinitionList();
	virtual ~QueryResultDefinitionList();

private:
	QUERYRESULTDEFINITIONMAP* m_QueryResultDefinitionMap;
};

#endif // !defined(AFX_QUERYRESULTDEFINITIONLIST_H__4C9B2A98_7312_4827_9B24_6867C185CF6D__INCLUDED_)
