// ResultQueueManager.h: interface for the ResultQueueManager class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_RESULTQUEUEMANAGER_H__A98ED407_750E_4864_9138_5ECC8C5B76BD__INCLUDED_)
#define AFX_RESULTQUEUEMANAGER_H__A98ED407_750E_4864_9138_5ECC8C5B76BD__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class ResultQueueManager  
{
public:
	ResultQueueManager();
	virtual ~ResultQueueManager();

};

#endif // !defined(AFX_RESULTQUEUEMANAGER_H__A98ED407_750E_4864_9138_5ECC8C5B76BD__INCLUDED_)
