// QueryProcessor.cpp: implementation of the QueryProcessor class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "dbQuery.h"
#include "QueryProcessor.h"

#include "QuerySQLAccessor.h"
#include "LogManager.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

QueryProcessor* QueryProcessor::_instance = 0;

QueryProcessor::QueryProcessor()
{
	QueryQueue*	queryQueue = (QueryQueue*)(QueryQueue::getInstance());

	_subject = queryQueue;
	_subject->Attach(this); 
}

QueryProcessor::~QueryProcessor()
{
	_subject->Detach(this); 
}


QueryProcessor* QueryProcessor::getInstance() 
{
	if (_instance == 0) 
	{
		_instance = new QueryProcessor;
	}
	return _instance;
}

void QueryProcessor::destroyInstance()
{
	if(_instance)
	{
		delete _instance;
	}
	_instance = 0;
}

void QueryProcessor::Update(Subject *theChangedSubject)
{
	if(theChangedSubject != _subject)
	{
		return;
	}

	QueryQueue* queryQueue = (QueryQueue*)theChangedSubject;

	Query* query = queryQueue->dispatchQuery();
	LogManager*	logManager = (LogManager*)(LogManager::getInstance());
	if (query != NULL)
	{
		logManager->getCategory().info("QueryProcessor  -- Query Popped for Processing -- %s", query->getQuestion().c_str());
	}
	else
	{
		logManager->getCategory().info("QueryProcessor  -- No Query Popped");
		return;
	}

	// got the Query, now process
	// to process we call the tokenizeQuery method of Query
	// may be a design change is necessary here to handle the process somewhere else
	if(!query->tokenizeQuery())
	{
		return; 
	}

	// query tokenization suceessful
	// check whether userid/passwd is authentic
	QuerySQLAccessor querySQLAccessor;

	if(!querySQLAccessor.authenticate(query->getUserid(), query->getPasswd()))
	{
		return;
	}

	// check whether querytag is valid and parameters are correct
	if(!query->verifyQuery())
	{
		return;
	}

	logManager->getCategory().info("QueryProcessor  -- Query Verification Successful for Query >> %s", query->getQuestion().c_str());

	// get the SQL
	CString sql = query->getSQL();
	if(sql.IsEmpty())
	{
		logManager->getCategory().error("QueryProcessor  -- SQL Generation Failure");
		return;
	}

	logManager->getCategory().info("QueryProcessor  -- SQL Generation Successful for Query >> %s, SQL is >> %s", query->getQuestion().c_str(), (LPCTSTR)sql);

}
