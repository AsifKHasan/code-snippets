// QueryResultDefinition.h: interface for the QueryResultDefinition class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_QUERYRESULTDEFINITION_H__C7D2AEF8_F474_4CDD_B73E_5B1C6D2A1141__INCLUDED_)
#define AFX_QUERYRESULTDEFINITION_H__C7D2AEF8_F474_4CDD_B73E_5B1C6D2A1141__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "LogManager.h"
#include <string>

using namespace std;

class QueryResultDefinition  
{
public:
	void dumpLog();
	QueryResultDefinition();
	virtual ~QueryResultDefinition();

	void setVar(string var);
	string getVar();
	void setType(string type);
	string getType();
	void setText(string text);
	string getText();
	void setFormat(string format);
	string getFormat();

private:
	string m_var;
	string m_type;
	string m_text;
	string m_format;
};

#endif // !defined(AFX_QUERYRESULTDEFINITION_H__C7D2AEF8_F474_4CDD_B73E_5B1C6D2A1141__INCLUDED_)
