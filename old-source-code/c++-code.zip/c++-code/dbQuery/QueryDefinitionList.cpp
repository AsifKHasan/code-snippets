// QueryDefinitionList.cpp: implementation of the QueryDefinitionList class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "dbQuery.h"
#include "QueryDefinitionList.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////


QueryDefinitionList* QueryDefinitionList::_instance = 0;

QueryDefinitionList* QueryDefinitionList::getInstance() 
{
	if (_instance == 0) 
	{
		_instance = new QueryDefinitionList;
	}
	return _instance;
}

void QueryDefinitionList::destroyInstance()
{
	if(_instance)
	{
		delete _instance;
	}
	_instance = 0;
}

QueryDefinitionList::QueryDefinitionList()
{
	m_QueryDefinitionMap = new QUERYDEFINITIONMAP(); 
}

QueryDefinitionList::~QueryDefinitionList()
{
	delete m_QueryDefinitionMap;
}

void QueryDefinitionList::insertQueryDefinition(QueryDefinition* queryDefinition)
{
	(*m_QueryDefinitionMap)[queryDefinition->getTag()] = queryDefinition;
	//m_QueryDefinitionMap.insert(queryDefinition->getTag(), queryDefinition); 
}

QueryDefinition* QueryDefinitionList::getQueryDefinitionByKeyword(string keyword)
{
	return (*m_QueryDefinitionMap)[keyword];
}

int QueryDefinitionList::getQueryDefinitionParameterCount(string keyword)
{
	return (*m_QueryDefinitionMap)[keyword]->getQueryParameterDefinitionCount();
}

void QueryDefinitionList::dumpLog()
{
	LogManager* logManager = (LogManager*)(LogManager::getInstance());
	QueryDefinition* queryDefinition;

	QUERYDEFINITIONMAP::iterator theIterator;

	
	logManager->getCategory().info("START Dumping QueryDefinitionList");
	
	for (theIterator = (*m_QueryDefinitionMap).begin(); theIterator != (*m_QueryDefinitionMap).end(); theIterator++)
	{
		queryDefinition = (*m_QueryDefinitionMap)[(*theIterator).first];
		queryDefinition->dumpLog();
	}

	logManager->getCategory().info("END Dumping QueryDefinitionList");
}
