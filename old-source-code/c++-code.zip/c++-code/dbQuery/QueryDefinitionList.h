// QueryDefinitionList.h: interface for the QueryDefinitionList class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_QUERYDEFINITIONLIST_H__0036B95B_F002_4922_8024_8CB543D6A0D0__INCLUDED_)
#define AFX_QUERYDEFINITIONLIST_H__0036B95B_F002_4922_8024_8CB543D6A0D0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#pragma warning(disable:4786)

#include "LogManager.h"
#include "QueryDefinition.h"

#include <string>
#include <map>

using namespace std;

typedef map<string, QueryDefinition*> QUERYDEFINITIONMAP;

class QueryDefinitionList
{
public:
	int getQueryDefinitionParameterCount(string keyword);
	static QueryDefinitionList* getInstance();
	static void destroyInstance();
	void dumpLog();
	QueryDefinition* getQueryDefinitionByKeyword(string keyword);
	void insertQueryDefinition(QueryDefinition* queryDefinition);
	virtual ~QueryDefinitionList();

protected:
	QueryDefinitionList();

private:
	static QueryDefinitionList* _instance;
	QUERYDEFINITIONMAP* m_QueryDefinitionMap;
};

#endif // !defined(AFX_QUERYDEFINITIONLIST_H__0036B95B_F002_4922_8024_8CB543D6A0D0__INCLUDED_)
