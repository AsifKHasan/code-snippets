// QuerySQLAccessor.h: interface for the QuerySQLAccessor class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_QUERYSQLACCESSOR_H__6BA6A61E_A7F3_429E_8CC7_527FB16864E6__INCLUDED_)
#define AFX_QUERYSQLACCESSOR_H__6BA6A61E_A7F3_429E_8CC7_527FB16864E6__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "ADODatabase.h"

#include <string>

using namespace std;

class QuerySQLAccessor  
{
public:
	BOOL authenticate(string userid, string passwd);
	QuerySQLAccessor();
	virtual ~QuerySQLAccessor();

};

#endif // !defined(AFX_QUERYSQLACCESSOR_H__6BA6A61E_A7F3_429E_8CC7_527FB16864E6__INCLUDED_)
