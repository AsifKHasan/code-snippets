// Query.cpp: implementation of the Query class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "dbQuery.h"
#include "Query.h"

#include "QueryDefinitionList.h"
#include "LogManager.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

using namespace std;

Query::Query()
{
	m_status = queryNew;
	m_params = new PARAMVECTOR();
}

Query::~Query()
{
	m_params->clear(); 
	delete m_params;
}

void Query::setQuestion(string question)
{
	m_question = question;
}

string Query::getQuestion()
{
	return m_question;
}

void Query::setQrytag(string qrytag)
{
	m_qrytag = qrytag;
}

string Query::getQrytag()
{
	return m_qrytag;
}

void Query::setUserid(string userid)
{
	m_userid = userid;
}

string Query::getUserid()
{
	return m_userid;
}

void Query::setPasswd(string passwd)
{
	m_passwd = passwd;
}

string Query::getPasswd()
{
	return m_passwd;
}

string Query::getParam(int pos)
{
	return (*m_params)[pos];
}

void Query::insertParam(string param)
{

}

int Query::getParamCount()
{
	return m_params->size(); 
}


/*
	From m_question gets required fields delimited by :
	Field 1		Userid
	Field 2		passwd
	Field 3		query
	Field >		query parameters	
*/
BOOL Query::tokenizeQuery()
{
	LogManager*	logManager = (LogManager*)(LogManager::getInstance());

	string s;
	s.append(m_question); 
	
	char* str = (char*)s.c_str();
	char* token;

	// get the userid field
	token = strtok(str, ":");
	if(token == NULL)
	{
		logManager->getCategory().info("QueryProcessor  -- No Token Found for Query -- %s", m_question.c_str());
		// change status to parseFailed;
		m_status = queryParseFailure;
		return false;
	}
	m_userid = token;

	// get the passwd field
	token = strtok(NULL, ":");
	if(token == NULL)
	{
		logManager->getCategory().info("QueryProcessor  -- No Password Found for Query -- %s", m_question.c_str());
		// change status to parseFailed;
		m_status = queryParseFailure;
		return false;
	}
	m_passwd = token;

	// get the query field
	token = strtok(NULL, ":");
	if(token == NULL)
	{
		logManager->getCategory().info("QueryProcessor  -- No Query Tag Found for Query -- %s", m_question.c_str());
		// change status to parseFailed;
		m_status = queryParseFailure;
		return false;
	}
	m_qrytag = token;


	// get the query parameters
	token = strtok(NULL, ":");
	while( token != NULL )
	{
		/* While there are tokens insert into vector */
		m_params->push_back(token);
		/* Get next token: */
		token = strtok( NULL, ":" );
	}

	// check whether userid/passwd valid

	// check whether qrytag is valid according to DefinitionList and number of parameters correct


	// everything ok, change status to parseSuccess;
	m_status = queryParseSuccess;

	return true;

}

BOOL Query::verifyQuery()
{
	LogManager* logManager = (LogManager*)(LogManager::getInstance());
	QueryDefinitionList* 	queryDefinitionList = (QueryDefinitionList*)(QueryDefinitionList::getInstance());

	// see if QRYTAG is valid
	QueryDefinition* queryDefinition = queryDefinitionList->getQueryDefinitionByKeyword(m_qrytag);
	if(!queryDefinition)
	{
		logManager->getCategory().error("Query -- No Such QueryDefinition >> %s", m_qrytag.c_str());
		return false;
	}

	// check if the # of parameters is at least equal to that in QueryDefinition
	if(queryDefinition->getQueryParameterDefinitionCount() > m_params->size())
	{
		logManager->getCategory().error("Query -- Not Enough Parameter Supplied Required %d, Found %d", queryDefinition->getQueryParameterDefinitionCount(), m_params->size());
		return false;
	}

	return true;
}

/*
	returns the SQL query the Query implies
*/
CString Query::getSQL()
{
	LogManager* logManager = (LogManager*)(LogManager::getInstance());

	CString sql;

	// check status, process only if query was processed successfully
	if(m_status != queryParseSuccess)
	{
		sql.Empty();
		return sql;
	}

	// query successfully processed
	// get the QueryDefinition Associated with this Query
	QueryDefinitionList* 	queryDefinitionList = (QueryDefinitionList*)(QueryDefinitionList::getInstance());
	QueryDefinition* queryDefinition = queryDefinitionList->getQueryDefinitionByKeyword(m_qrytag);
	if(!queryDefinition)
	{
		sql.Empty();
		return sql;
	}

	// the sql part associated
	sql = queryDefinition->getSql().c_str();
	CString pos;
	int i = 0;

	// SQL contains 0 or more parameters as %x %y %z where x,y,z are parameter pos
	// iterate through query parameters
	// for each parameter get definition, take pos, replace 
	PARAMVECTOR::iterator paramIterator;
	for (paramIterator = (*m_params).begin(); paramIterator != (*m_params).end(); paramIterator++)
	{
		pos.Format("%d", i);
		// get the parameter definition for pos
		QueryParameterDefinition* queryParameterDefinition = queryDefinition->getQueryParameterDefinitionByKeyword((LPCTSTR)pos); 
		if(!queryParameterDefinition)
		{
			logManager->getCategory().error("Query -- No Parameter Definition for Query Definition %s Tagged %s", m_qrytag.c_str(), pos);
			sql.Empty();
			return sql;
		}

		if(!strcmp(queryParameterDefinition->getType().c_str(), "number"))
		{
			pos.Format("%%%d", i);
			sql.Replace((LPCTSTR)pos, (*paramIterator).c_str());
		}
		else
		{
			pos.Format("%%%d", i);
			CString s;
			s.Format("'%s'", (*paramIterator).c_str());
			sql.Replace((LPCTSTR)pos, (LPCTSTR)s);
		}

		i++;
	}
	return sql;
	
}

void Query::dumpLog()
{
	LogManager* logManager = (LogManager*)(LogManager::getInstance());

	logManager->getCategory().info("");
	logManager->getCategory().info("START -- Dumping Query");
	
	logManager->getCategory().info("QUESTION is >> %s", m_question.c_str());
	logManager->getCategory().info("USERID is >> %s", m_userid.c_str());
	logManager->getCategory().info("PASSWD is >> %s", m_passwd.c_str());
	logManager->getCategory().info("QRYTAG is >> %s", m_qrytag.c_str());

	PARAMVECTOR::iterator theIterator;

	for (theIterator = (*m_params).begin(); theIterator != (*m_params).end(); theIterator++)
	{
		logManager->getCategory().info("PARAMETER is >> %s", (*theIterator).c_str());
	}

	logManager->getCategory().info("END -- Dumping Query");
	logManager->getCategory().info("");
}
