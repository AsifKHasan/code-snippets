// ResultProcessor.h: interface for the ResultProcessor class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_RESULTPROCESSOR_H__AEEB22F2_9DE7_4AE3_8115_7A73ECDCD895__INCLUDED_)
#define AFX_RESULTPROCESSOR_H__AEEB22F2_9DE7_4AE3_8115_7A73ECDCD895__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class ResultProcessor  
{
public:
	ResultProcessor();
	virtual ~ResultProcessor();

};

#endif // !defined(AFX_RESULTPROCESSOR_H__AEEB22F2_9DE7_4AE3_8115_7A73ECDCD895__INCLUDED_)
