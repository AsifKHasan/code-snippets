// ResultProcessor.cpp: implementation of the ResultProcessor class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "dbQuery.h"
#include "ResultProcessor.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

ResultProcessor::ResultProcessor()
{

}

ResultProcessor::~ResultProcessor()
{

}
