// QueryQueueManager.cpp: implementation of the QueryQueueManager class.
//
//////////////////////////////////////////////////////////////////////
/*
	This class accepts Question as text and parses into Query.
	This is a Singleton.
	This class acts as the external input interface for dbQuery.
	After parsing it stores Query's into QueryQueue
*/

#include "stdafx.h"
#include "dbQuery.h"

#include "LogManager.h"

#include "QueryQueueManager.h"


#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////


QueryQueueManager* QueryQueueManager::_instance = 0;

QueryQueueManager::QueryQueueManager()
{
	LogManager*	logManager = (LogManager*)(LogManager::getInstance());
	logManager->getCategory().info("STARTUP -- QueryQueueManager");
}

QueryQueueManager::~QueryQueueManager()
{
	LogManager*	logManager = (LogManager*)(LogManager::getInstance());
	logManager->getCategory().info("SHUTDOWN -- QueryQueueManager");
}

QueryQueueManager* QueryQueueManager::getInstance() 
{
	if (_instance == 0) 
	{
		_instance = new QueryQueueManager;
	}
	return _instance;
}

void QueryQueueManager::destroyInstance()
{
	if(_instance)
	{
		delete _instance;
	}
	_instance = 0;
}

void QueryQueueManager::storeQuery(string question)
{
	QueryQueue* queryQueue = (QueryQueue*)(QueryQueue::getInstance());

	LogManager*	logManager = (LogManager*)(LogManager::getInstance());
	logManager->getCategory().info("");
	logManager->getCategory().info("QueryQueueManager  -- New Query -- %s", question.c_str());

	queryQueue->insertQuery(question); 

}
