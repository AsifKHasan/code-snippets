// QueryQueue.cpp: implementation of the QueryQueue class.
//
//////////////////////////////////////////////////////////////////////
/*
	Singleton to hold Query in a Queue.
	Notifies QueryProcessor, when a new query is in
*/

#include "stdafx.h"
#include "dbQuery.h"

#include "LogManager.h"

#include "QueryQueue.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

QueryQueue* QueryQueue::_instance = 0;

QueryQueue::QueryQueue()
{
	LogManager*	logManager = (LogManager*)(LogManager::getInstance());
	logManager->getCategory().info("STARTUP -- QueryQueue");

	m_pQueryQueue = new QUERYQUEUE();
}

QueryQueue::~QueryQueue()
{
	LogManager*	logManager = (LogManager*)(LogManager::getInstance());
	logManager->getCategory().info("SHUTDOWN -- QueryQueue");

	delete m_pQueryQueue;
}


QueryQueue* QueryQueue::getInstance() 
{
	if (_instance == 0) 
	{
		_instance = new QueryQueue;
	}
	return _instance;
}

void QueryQueue::destroyInstance()
{
	if(_instance)
	{
		delete _instance;
	}
	_instance = 0;
}

void QueryQueue::insertQuery(string question)
{
	Query* query = new Query();

	LogManager*	logManager = (LogManager*)(LogManager::getInstance());
	logManager->getCategory().info("QueryQueue  -- Queueing New Query -- %s", question.c_str());

	query->setQuestion(question);
	m_pQueryQueue->push(query); 

	this->Notify();

}

Query* QueryQueue::dispatchQuery()
{
	Query* query = m_pQueryQueue->front();

	LogManager*	logManager = (LogManager*)(LogManager::getInstance());
	if (query != NULL)
	{
		logManager->getCategory().info("QueryQueue  -- Dispatching Query -- %s", query->getQuestion().c_str());
		m_pQueryQueue->pop(); 
	}
	else
	{
		logManager->getCategory().info("QueryQueue  -- Dispatching Query -- No Query in Queue");
	}
	return query;
}
