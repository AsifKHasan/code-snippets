// ADODatabase.cpp: implementation of the CADODatabase class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "ADODatabase.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////


ADODatabase* ADODatabase::_instance = 0;

ADODatabase::ADODatabase()
{
}

ADODatabase::~ADODatabase()
{
	LogManager*	logManager = (LogManager*)(LogManager::getInstance());

	if(m_pConnection->GetState() == adStateOpen)
	{
		m_pConnection->Close();
		logManager->getCategory().info("SUCCESS -- Database Disconnection");
	}
	else
	{
		logManager->getCategory().info("FAILURE -- Database Disconnection");
	}
	m_pConnection = NULL;
}

ADODatabase* ADODatabase::getInstance() 
{
	if (_instance == 0) 
	{
		_instance = new ADODatabase;
	}
	return _instance;
}

void ADODatabase::destroyInstance()
{
	if(_instance)
	{
		delete _instance;
	}
	_instance = 0;
}

void ADODatabase::init(CString sConnStr)
{
	m_pConnection.CreateInstance(__uuidof(Connection));
	m_pConnection->Open(sConnStr.GetBuffer(0),"","",-1);

	LogManager*	logManager = (LogManager*)(LogManager::getInstance());
	if(m_pConnection->GetState() == adStateOpen)
	{
		logManager->getCategory().info("SUCCESS -- Database Connection");
	}
	else
	{
		logManager->getCategory().info("FAILURE -- Database Connection");
		m_pConnection = NULL;
	}

}

ADORecordset* ADODatabase::openRecordset(CString sSQL)
{
	LogManager*	logManager = (LogManager*)(LogManager::getInstance());
	ADORecordset* temprec = new ADORecordset();;

	if(temprec->openRecordset(m_pConnection, sSQL))
	{
		logManager->getCategory().info("SUCCESS -- Recordset Opened");
		return temprec;
	}
	else
	{
		logManager->getCategory().info("FAILURE -- Recordset Opened");
		delete temprec;
		return NULL;
	}
}
