// QueryDefinitionParser.cpp: implementation of the QueryDefinitionParser class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "dbQuery.h"
#include "LogManager.h"

#include "QueryDefinitionParser.h"


#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

QueryDefinitionParser::QueryDefinitionParser()
{

	HRESULT hr = m_plDomDocument.CreateInstance(CLSID_DOMDocument);
	if (FAILED(hr))
	{
		_com_error er(hr);
		AfxMessageBox(er.ErrorMessage());
	}
}

QueryDefinitionParser::~QueryDefinitionParser()
{

}

BOOL QueryDefinitionParser::parseQueryDefinitionXML(CString pXMLFile)
{
	QueryDefinitionList *queryDefinitionList = (QueryDefinitionList*)QueryDefinitionList::getInstance();	

	// load the XML file
	if( !this->loadXMLDocument(pXMLFile))
	{
		return false;
	}

	// parse XML
	this->parseQueryDefinitionList();

	return true;
}

BOOL QueryDefinitionParser::loadXMLDocument(CString pXMLFile)
{

	// convert xml file name string to something COM can handle (BSTR)
	_bstr_t bstrFileName;
	bstrFileName = pXMLFile.AllocSysString(); 


	// call the IXMLDOMDocumentPtr's load function to load the XML document
	variant_t vResult;
	vResult = m_plDomDocument->load(bstrFileName);
	if (((bool)vResult) == TRUE) // success!
	{
		// now that the document is loaded, we need to initialize the root pointer
		m_pDocRoot = m_plDomDocument->documentElement;
		((LogManager*)(LogManager::getInstance()))->getCategory().info("XML Document Successfully Loaded");

		return true;
	}
	else
	{
		((LogManager*)(LogManager::getInstance()))->getCategory().info("Could Not Load XML Document");
		return false;
	}

}

void QueryDefinitionParser::parseQueryDefinitionList()
{

	IXMLDOMElementPtr pQueryDefinitionNode;
	IXMLDOMNodePtr pQueryDefinitionListNode = m_pDocRoot;
	QueryDefinitionList* queryDefinitionList = (QueryDefinitionList*)(QueryDefinitionList::getInstance()); 

	// simple for loop to get all QueryDefinition
	for (pQueryDefinitionNode = pQueryDefinitionListNode->firstChild; NULL != pQueryDefinitionNode; pQueryDefinitionNode = pQueryDefinitionNode->nextSibling)
	{
		// for each child, call this function so that we get its children as well
		queryDefinitionList->insertQueryDefinition(this->parseQueryDefinition(pQueryDefinitionNode));
	}
}

QueryDefinition* QueryDefinitionParser::parseQueryDefinition(IXMLDOMElementPtr pQueryDefinitionNode)
{

	LogManager* logManager = (LogManager*)(LogManager::getInstance());
	IXMLDOMElementPtr pChildNode;
	QueryDefinition* queryDefinition = new QueryDefinition();
	BSTR bstr;

	queryDefinition->setTag(this->getAttributeValue(pQueryDefinitionNode, "tag"));
	queryDefinition->setSql(this->getAttributeValue(pQueryDefinitionNode, "sql"));

	// for loop to get all QueryParameterDefinition or QueryResultDefinition Nodes
	for (pChildNode = pQueryDefinitionNode->firstChild; NULL != pChildNode; pChildNode = pChildNode->nextSibling)
	{
		pChildNode->get_nodeName(&bstr);
		_bstr_t nodeName(bstr, FALSE);
	
		// for each child, process based on Node name
		if(!strcmp((LPCTSTR)nodeName, "ParameterDefinition"))
		{
			queryDefinition->insertQueryParameterDefinition(this->parseQueryParameterDefinition(pChildNode)); 
		}
		else if(!strcmp((LPCTSTR)nodeName, "ResultDefinition"))
		{
			queryDefinition->insertQueryResultDefinition(this->parseQueryResultDefinition(pChildNode)); 
		}
	}

	return queryDefinition;

}


QueryParameterDefinition* QueryDefinitionParser::parseQueryParameterDefinition(IXMLDOMElementPtr pQueryParameterDefinitionNode)
{

	QueryParameterDefinition* queryParameterDefinition = new QueryParameterDefinition();

	queryParameterDefinition->setPos(this->getAttributeValue(pQueryParameterDefinitionNode, "pos"));
	queryParameterDefinition->setType(this->getAttributeValue(pQueryParameterDefinitionNode, "type"));

	return queryParameterDefinition;

}


QueryResultDefinition* QueryDefinitionParser::parseQueryResultDefinition(IXMLDOMElementPtr pQueryResultDefinitionNode)
{

	QueryResultDefinition* queryResultDefinition = new QueryResultDefinition();

	queryResultDefinition->setVar(this->getAttributeValue(pQueryResultDefinitionNode, "var"));
	queryResultDefinition->setType(this->getAttributeValue(pQueryResultDefinitionNode, "type"));
	queryResultDefinition->setFormat(this->getAttributeValue(pQueryResultDefinitionNode, "format"));
	queryResultDefinition->setText(this->getAttributeValue(pQueryResultDefinitionNode, "text"));

	return queryResultDefinition;

}


string QueryDefinitionParser::getAttributeValue(IXMLDOMElementPtr pIXMLDOMElement, LPCTSTR attrname)
{
	_variant_t varValue;
	string	attrval;

	if(pIXMLDOMElement)
	{
		varValue = pIXMLDOMElement->getAttribute(attrname);

		if(varValue.vt != VT_NULL)
		{
			attrval = _bstr_t(varValue);
			return attrval;
		}
	}
	return NULL;

}

void QueryDefinitionParser::dumpLog()
{
	QueryDefinitionList* queryDefinitionList = (QueryDefinitionList*)(QueryDefinitionList::getInstance()); 
	LogManager* logManager = (LogManager*)(LogManager::getInstance());
	
	logManager->getCategory().info("START Dumping");
	queryDefinitionList->dumpLog();
	logManager->getCategory().info("END Dumping");
}
