// QueryResultDefinition.cpp: implementation of the QueryResultDefinition class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "dbQuery.h"
#include "QueryResultDefinition.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

QueryResultDefinition::QueryResultDefinition()
{

}

QueryResultDefinition::~QueryResultDefinition()
{

}

string QueryResultDefinition::getVar()
{
	return m_var;
}

void QueryResultDefinition::setVar(string var)
{
	m_var = var;
}

string QueryResultDefinition::getType()
{
	return m_type;
}

void QueryResultDefinition::setType(string type)
{
	m_type = type;
}

string QueryResultDefinition::getText()
{
	return m_text;
}

void QueryResultDefinition::setText(string text)
{
	m_text = text;
}

string QueryResultDefinition::getFormat()
{
	return m_format;
}

void QueryResultDefinition::setFormat(string format)
{
	m_format = format;
}

void QueryResultDefinition::dumpLog()
{
	LogManager* logManager = (LogManager*)(LogManager::getInstance());

	logManager->getCategory().info("START Dumping QueryResultDefinition");
	
	logManager->getCategory().info(m_var);
	logManager->getCategory().info(m_type);
	logManager->getCategory().info(m_format);
	logManager->getCategory().info(m_text);

	logManager->getCategory().info("END Dumping QueryResultDefinition");

}
