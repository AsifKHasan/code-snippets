// ResultQueue.h: interface for the ResultQueue class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_RESULTQUEUE_H__201B9B2F_93D5_4F03_A08D_A0813220444B__INCLUDED_)
#define AFX_RESULTQUEUE_H__201B9B2F_93D5_4F03_A08D_A0813220444B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class ResultQueue  
{
public:
	ResultQueue();
	virtual ~ResultQueue();

};

#endif // !defined(AFX_RESULTQUEUE_H__201B9B2F_93D5_4F03_A08D_A0813220444B__INCLUDED_)
