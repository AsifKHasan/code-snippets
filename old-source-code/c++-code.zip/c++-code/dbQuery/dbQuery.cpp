// dbQuery.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "dbQuery.h"

//#include "Category.hh"
#include "LogManager.h"

#include "QueryDefinitionParser.h"
#include "QueryDefinitionList.h"

#include "QueryQueueManager.h"
#include "QueryQueue.h"
#include "QueryProcessor.h"

#include "ADODatabase.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////

// The one and only application object
CWinApp theApp;


int _tmain(int argc, TCHAR* argv[], TCHAR* envp[])
{
	int nRetCode;
	
	// Initialize App
	nRetCode = initializeApplication();
	if(nRetCode)
	{
		return nRetCode;
	}


	
	// Do the processing

	// parse the XML
	QueryDefinitionParser* queryDefinitionParser = new(QueryDefinitionParser);

	queryDefinitionParser->parseQueryDefinitionXML("./cfgs/QueryDefinitions.xml"); 
	//queryDefinitionParser->dumpLog(); 



	// put some query
	// QueryQueueManager Initialize
	QueryQueueManager*	queryQueueManager = (QueryQueueManager*)(QueryQueueManager::getInstance());

	queryQueueManager->storeQuery("asif:asif:TIME");
	queryQueueManager->storeQuery("admin:admin:TOME");
	queryQueueManager->storeQuery("asif:asif:PASS:hasan");
	queryQueueManager->storeQuery("asif:arif:PASS:hasan");
	queryQueueManager->storeQuery("monir:monir:PASS");




	// Finalize App
	finalizeApplication();

	return nRetCode;
}

int initializeApplication()
{
	int nRetCode = 0;

	// initialize MFC and print and error on failure
	if (!AfxWinInit(::GetModuleHandle(NULL), NULL, ::GetCommandLine(), 0))
	{
		// TODO: change error code to suit your needs
		cerr << _T("Fatal Error: MFC initialization failed") << endl;
		nRetCode = 1;
		return nRetCode;
	}

	// OLE Initialization
	AfxOleInit();


	
	// Initialize COM
	::CoInitialize(NULL);


	
	// Logmanager Initialization
	LogManager*	logManager = (LogManager*)(LogManager::getInstance());
	logManager->init("log/testlog4cpp.log");
	logManager->getCategory().info("Application Started");


	// QueryDefinitionList Initialization
	QueryDefinitionList* 	queryDefinitionList = (QueryDefinitionList*)(QueryDefinitionList::getInstance());


	// QueryQueue Initialization
	QueryQueue*	queryQueue = (QueryQueue*)(QueryQueue::getInstance());

	
	// QueryProcessor Initialization
	QueryProcessor*	queryProcessor = (QueryProcessor*)(QueryProcessor::getInstance());



	// Database Connection Initialize
	ADODatabase*	adoDatabase = (ADODatabase*)(ADODatabase::getInstance());
	adoDatabase->init("driver=sql server;server=trantor;UID=nestle;PWD=nestle;database=nestle;");


	return nRetCode;
}


void finalizeApplication()
{

	// QueryQueueManager Finalization
	QueryQueueManager*	queryQueueManager = (QueryQueueManager*)(QueryQueueManager::getInstance());
	queryQueueManager->destroyInstance();


	// QueryQueue Finalization
	QueryQueue*	queryQueue = (QueryQueue*)(QueryQueue::getInstance());
	queryQueue->destroyInstance();



	// QueryDefinitionList Finalization
	QueryDefinitionList* 	queryDefinitionList = (QueryDefinitionList*)(QueryDefinitionList::getInstance());
	queryDefinitionList->destroyInstance();

	// Database Connection Finalization
	ADODatabase*	adoDatabase = (ADODatabase*)(ADODatabase::getInstance());
	adoDatabase->destroyInstance(); 


	// LogManager Finalization
	LogManager*	logManager = (LogManager*)(LogManager::getInstance());
	logManager->getCategory().info("Application Shutdown");
	logManager->destroyInstance();

}
