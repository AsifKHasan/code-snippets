// QuerySQLAccessor.cpp: implementation of the QuerySQLAccessor class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "dbQuery.h"
#include "QuerySQLAccessor.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

QuerySQLAccessor::QuerySQLAccessor()
{

}

QuerySQLAccessor::~QuerySQLAccessor()
{

}

/*
	verifies the userid/passwd

*/
BOOL QuerySQLAccessor::authenticate(string userid, string passwd)
{
	LogManager* logManager = (LogManager*)(LogManager::getInstance());
	ADODatabase*	adoDatabase = (ADODatabase*)(ADODatabase::getInstance());

	CString sql;
	sql.Format("select count(*) numrec from t_user where user_name = '%s' and user_pass = '%s'", userid.c_str(), passwd.c_str());

	ADORecordset* adoRecordset = adoDatabase->openRecordset(sql);
	if (!adoRecordset)
	{
		logManager->getCategory().error("QuerySQLAccessor -- Could Not Open Recordset");
		return false;
	}


	if(!long(adoRecordset->getFieldVal("numrec")))
	{
		logManager->getCategory().error("QuerySQLAccessor -- No Such User or Password Mismatch");
		delete adoRecordset;
		return false;
	}

	logManager->getCategory().info("QuerySQLAccessor -- Authentication Successfull for (U=%s)(P=%s)", userid.c_str(), passwd.c_str());
	delete adoRecordset;
	return true;
}
