// ADORecordset.h: interface for the ADORecordset class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ADORECORDSET_H__BF868307_FB5D_4D59_80B8_C6C6D8AFBF95__INCLUDED_)
#define AFX_ADORECORDSET_H__BF868307_FB5D_4D59_80B8_C6C6D8AFBF95__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class ADORecordset
{
public:
	long getRecordCount();
	BOOL openRecordset(_ConnectionPtr pConnection, CString sSQL);
	ADORecordset();
	virtual ~ADORecordset();

	void closeRecordset();

	DataTypeEnum getFieldType(long lFldIndex);
	CString getFieldName(long lFldIndex);
	long getFieldCount();
	_variant_t getFieldVal(CString sFieldName);

private:
	_RecordsetPtr	m_pRecordset;
};

#endif // !defined(AFX_ADORECORDSET_H__BF868307_FB5D_4D59_80B8_C6C6D8AFBF95__INCLUDED_)
