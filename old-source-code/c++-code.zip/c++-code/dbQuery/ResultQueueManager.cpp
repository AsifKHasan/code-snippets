// ResultQueueManager.cpp: implementation of the ResultQueueManager class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "dbQuery.h"
#include "ResultQueueManager.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

ResultQueueManager::ResultQueueManager()
{

}

ResultQueueManager::~ResultQueueManager()
{

}
