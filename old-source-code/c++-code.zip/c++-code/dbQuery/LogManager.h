// LogManager.h: interface for the LogManager class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_LOGMANAGER_H__1317E34B_1751_44F0_84BE_7744950CA65B__INCLUDED_)
#define AFX_LOGMANAGER_H__1317E34B_1751_44F0_84BE_7744950CA65B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


#include	"Category.hh"
#include	"FileAppender.hh"
#include	"PatternLayout.hh"

class LogManager
{
public:
	static LogManager* getInstance();
	static void destroyInstance();

	virtual ~LogManager();

	void				init(char* logfile);

	log4cpp::Category&	getCategory();

protected:
	LogManager();

private:
	static LogManager* _instance;

	log4cpp::Appender*	m_appender;
	log4cpp::Layout*	m_layout;

};

#endif // !defined(AFX_LOGMANAGER_H__1317E34B_1751_44F0_84BE_7744950CA65B__INCLUDED_)
