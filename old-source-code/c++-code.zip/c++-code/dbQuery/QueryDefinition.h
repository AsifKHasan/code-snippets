// QueryDefinition.h: interface for the QueryDefinition class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_QUERYDEFINITION_H__A98F78F5_6491_4DC3_9399_EFC9FA5D89DC__INCLUDED_)
#define AFX_QUERYDEFINITION_H__A98F78F5_6491_4DC3_9399_EFC9FA5D89DC__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "LogManager.h"
//#include "QueryParameterDefinitionList.h"
//#include "QueryResultDefinitionList.h"
#include "QueryParameterDefinitionList.h"
#include "QueryResultDefinitionList.h"

#include <string>

using namespace std;

class QueryDefinition  
{
public:
	int getQueryParameterDefinitionCount();
	void dumpLog();
	QueryParameterDefinition* getQueryParameterDefinitionByKeyword(string keyword);
	void insertQueryParameterDefinition(QueryParameterDefinition* queryParameterDefinition);
	QueryResultDefinition* getQueryResultDefinitionByKeyword(string keyword);
	void insertQueryResultDefinition(QueryResultDefinition* queryResultDefinition);

	void setTag(string tag);
	string getTag();
	void setSql(string sql);
	string getSql();
	QueryDefinition();
	virtual ~QueryDefinition();

private:
	string m_tag;
	string m_sql;

	QueryParameterDefinitionList* m_QueryParameterDefinitionList;
	QueryResultDefinitionList* m_QueryResultDefinitionList;
};

#endif // !defined(AFX_QUERYDEFINITION_H__A98F78F5_6491_4DC3_9399_EFC9FA5D89DC__INCLUDED_)
