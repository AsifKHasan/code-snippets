// QueryParameterDefinitionList.cpp: implementation of the QueryParameterDefinitionList class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "dbQuery.h"
#include "QueryParameterDefinitionList.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

QueryParameterDefinitionList::QueryParameterDefinitionList()
{
	m_QueryParameterDefinitionMap = new QUERYPARAMETERDEFINITIONMAP();
}

QueryParameterDefinitionList::~QueryParameterDefinitionList()
{
	delete m_QueryParameterDefinitionMap;
}

void QueryParameterDefinitionList::insertQueryParameterDefinition(QueryParameterDefinition* queryParameterDefinition)
{
	(*m_QueryParameterDefinitionMap)[queryParameterDefinition->getPos()] = queryParameterDefinition;
}

QueryParameterDefinition* QueryParameterDefinitionList::getQueryParameterDefinitionByKeyword(string keyword)
{
	return (*m_QueryParameterDefinitionMap)[keyword];
}

int QueryParameterDefinitionList::getCount()
{
	return m_QueryParameterDefinitionMap->size();
}

void QueryParameterDefinitionList::dumpLog()
{
	LogManager* logManager = (LogManager*)(LogManager::getInstance());
	QueryParameterDefinition* queryParameterDefinition;

	QUERYPARAMETERDEFINITIONMAP::iterator theIterator;

	
	logManager->getCategory().info("START Dumping QueryParameterDefinitionList");
	
	for (theIterator = (*m_QueryParameterDefinitionMap).begin(); theIterator != (*m_QueryParameterDefinitionMap).end(); theIterator++)
	{
		queryParameterDefinition = (*m_QueryParameterDefinitionMap)[(*theIterator).first];
		queryParameterDefinition->dumpLog();
	}

	logManager->getCategory().info("END Dumping QueryParameterDefinitionList");

}
