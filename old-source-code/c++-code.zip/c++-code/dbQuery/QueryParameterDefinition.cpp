// QueryParameterDefinition.cpp: implementation of the QueryParameterDefinition class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "dbQuery.h"
#include "QueryParameterDefinition.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

QueryParameterDefinition::QueryParameterDefinition()
{

}

QueryParameterDefinition::~QueryParameterDefinition()
{

}

string QueryParameterDefinition::getPos()
{
	return m_pos;
}

void QueryParameterDefinition::setPos(string pos)
{
	m_pos = pos;
}

string QueryParameterDefinition::getType()
{
	return m_type;
}

void QueryParameterDefinition::setType(string type)
{
	m_type = type;
}

void QueryParameterDefinition::dumpLog()
{
	LogManager* logManager = (LogManager*)(LogManager::getInstance());

	logManager->getCategory().info("START Dumping QueryParameterDefinition");
	
	logManager->getCategory().info(m_pos);
	logManager->getCategory().info(m_type);

	logManager->getCategory().info("END Dumping QueryParameterDefinition");

}
