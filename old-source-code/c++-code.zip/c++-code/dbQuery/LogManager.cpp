// LogManager.cpp: implementation of the LogManager class.
//
//////////////////////////////////////////////////////////////////////

#include	"stdafx.h"
#include	"dbQuery.h"
#include	"LogManager.h"


#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

LogManager* LogManager::_instance = 0;

LogManager::LogManager()
{
	
}

LogManager::~LogManager()
{
	log4cpp::Category::shutdown();
}

LogManager* LogManager::getInstance() 
{
	if (_instance == 0) 
	{
		_instance = new LogManager;
	}
	return _instance;
}

void LogManager::destroyInstance()
{
	if(_instance)
	{
		delete _instance;
	}
	_instance = 0;
}

log4cpp::Category&	LogManager::getCategory()
{
	return log4cpp::Category::getInstance("main_cat");
}

void LogManager::init(char* logfile)
{

	// 1 instantiate an appender object that will append to a log file
	m_appender = new log4cpp::FileAppender("FileAppender", logfile);


    // 2. Instantiate a layout object
	// BasicLayout includes a time stamp
	m_layout = new log4cpp::PatternLayout();
	((log4cpp::PatternLayout*)m_layout)->setConversionPattern("%d - %p - %m%n");


	// 3. attach the layout object to the appender object
	m_appender->setLayout(m_layout);


	// 4. Instantiate the category object
	// you may extract the root category, but it is usually more practical to directly instance a child category
	log4cpp::Category&	m_category = log4cpp::Category::getInstance("main_cat");
	


	// 5. Step 1 
	// an Appender when added to a category becomes an additional output destination unless Additivity is set to false 
	// when it is false the appender added to the category replaces all previously existing appenders
	m_category.setAdditivity(false);


	// 5. Step 2
	// this appender becomes the only one
	m_category.setAppender(m_appender);

	// 6. Set up the priority for the category and is given INFO priority
	// attempts to log DEBUG messages will fail
	m_category.setPriority(log4cpp::Priority::INFO);

}
