// BEditCtl.cpp : Implementation of the CBEditCtrl OLE control class.

#include "stdafx.h"
#include "BEdit.h"
#include "BEditCtl.h"
#include "BEditPpg.h"
#include "UniConv.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


IMPLEMENT_DYNCREATE(CBEditCtrl, COleControl)


/////////////////////////////////////////////////////////////////////////////
// Message map

BEGIN_MESSAGE_MAP(CBEditCtrl, COleControl)
	//{{AFX_MSG_MAP(CBEditCtrl)
	ON_WM_CHAR()
	ON_WM_SETFOCUS()
	ON_WM_KILLFOCUS()
	ON_WM_KEYDOWN()
	//}}AFX_MSG_MAP
	ON_OLEVERB(AFX_IDS_VERB_PROPERTIES, OnProperties)
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// Dispatch map

BEGIN_DISPATCH_MAP(CBEditCtrl, COleControl)
	//{{AFX_DISPATCH_MAP(CBEditCtrl)
	DISP_PROPERTY_EX(CBEditCtrl, "Content", GetContent, SetContent, VT_BSTR)
	DISP_STOCKPROP_BACKCOLOR()
	DISP_STOCKPROP_FORECOLOR()
	DISP_STOCKPROP_FONT()
	//}}AFX_DISPATCH_MAP
	DISP_FUNCTION_ID(CBEditCtrl, "AboutBox", DISPID_ABOUTBOX, AboutBox, VT_EMPTY, VTS_NONE)
END_DISPATCH_MAP()


/////////////////////////////////////////////////////////////////////////////
// Event map

BEGIN_EVENT_MAP(CBEditCtrl, COleControl)
	//{{AFX_EVENT_MAP(CBEditCtrl)
	// NOTE - ClassWizard will add and remove event map entries
	//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_EVENT_MAP
END_EVENT_MAP()


/////////////////////////////////////////////////////////////////////////////
// Property pages

// TODO: Add more property pages as needed.  Remember to increase the count!
BEGIN_PROPPAGEIDS(CBEditCtrl, 3)
	PROPPAGEID(CBEditPropPage::guid)
	PROPPAGEID(CLSID_CColorPropPage)
	PROPPAGEID(CLSID_CFontPropPage)
END_PROPPAGEIDS(CBEditCtrl)


/////////////////////////////////////////////////////////////////////////////
// Initialize class factory and guid

IMPLEMENT_OLECREATE_EX(CBEditCtrl, "BEDIT.BEditCtrl.1",
	0xef9114f3, 0xde49, 0x11d0, 0x82, 0x5e, 0, 0x40, 0x33, 0xa0, 0x1d, 0xac)


/////////////////////////////////////////////////////////////////////////////
// Type library ID and version

IMPLEMENT_OLETYPELIB(CBEditCtrl, _tlid, _wVerMajor, _wVerMinor)


/////////////////////////////////////////////////////////////////////////////
// Interface IDs

const IID BASED_CODE IID_DBEdit =
		{ 0xef9114f1, 0xde49, 0x11d0, { 0x82, 0x5e, 0, 0x40, 0x33, 0xa0, 0x1d, 0xac } };
const IID BASED_CODE IID_DBEditEvents =
		{ 0xef9114f2, 0xde49, 0x11d0, { 0x82, 0x5e, 0, 0x40, 0x33, 0xa0, 0x1d, 0xac } };


/////////////////////////////////////////////////////////////////////////////
// Control type information

static const DWORD BASED_CODE _dwBEditOleMisc =
	OLEMISC_ACTIVATEWHENVISIBLE |
	OLEMISC_SETCLIENTSITEFIRST |
	OLEMISC_INSIDEOUT |
	OLEMISC_CANTLINKINSIDE |
	OLEMISC_RECOMPOSEONRESIZE;

IMPLEMENT_OLECTLTYPE(CBEditCtrl, IDS_BEDIT, _dwBEditOleMisc)


/////////////////////////////////////////////////////////////////////////////
// CBEditCtrl::CBEditCtrlFactory::UpdateRegistry -
// Adds or removes system registry entries for CBEditCtrl

BOOL CBEditCtrl::CBEditCtrlFactory::UpdateRegistry(BOOL bRegister)
{
	// TODO: Verify that your control follows apartment-model threading rules.
	// Refer to MFC TechNote 64 for more information.
	// If your control does not conform to the apartment-model rules, then
	// you must modify the code below, changing the 6th parameter from
	// afxRegApartmentThreading to 0.

	if (bRegister)
		return AfxOleRegisterControlClass(
			AfxGetInstanceHandle(),
			m_clsid,
			m_lpszProgID,
			IDS_BEDIT,
			IDB_BEDIT,
			afxRegApartmentThreading,
			_dwBEditOleMisc,
			_tlid,
			_wVerMajor,
			_wVerMinor);
	else
		return AfxOleUnregisterClass(m_clsid, m_lpszProgID);
}


/////////////////////////////////////////////////////////////////////////////
// CBEditCtrl::CBEditCtrl - Constructor

CBEditCtrl::CBEditCtrl()
{
	InitializeIIDs(&IID_DBEdit, &IID_DBEditEvents);
}


/////////////////////////////////////////////////////////////////////////////
// CBEditCtrl::~CBEditCtrl - Destructor

CBEditCtrl::~CBEditCtrl()
{
	// TODO: Cleanup your control's instance data here.
}


/////////////////////////////////////////////////////////////////////////////
// CBEditCtrl::OnDraw - Drawing function

void CBEditCtrl::OnDraw(
			CDC* pdc, const CRect& rcBounds, const CRect& rcInvalid)
{
	CBrush*			pOldBrush;
	CBrush			bkBrush(TranslateColor(GetBackColor()));
	//CPen*			pOldPen;
	CFont*			pOldFont;
	TEXTMETRIC		tm;
	CRect			rcClipBounds(rcBounds);
	CString			cs;
	int				len;
		
	pdc->SetTextColor(TranslateColor(GetForeColor()));
	pdc->SetBkMode(TRANSPARENT);

	// TODO: Replace the following code with your own drawing code.
	pdc->FillRect(rcBounds, &bkBrush);
	pdc->Draw3dRect(rcBounds,(COLORREF)0x00000000, (COLORREF)0x00ffffff);

	pOldBrush = pdc->SelectObject(&bkBrush);
	pOldFont = SelectStockFont(pdc);
	pdc->GetTextMetrics(&tm);
	rcClipBounds.right -= m_rightbear;
	rcClipBounds.left += m_leftbear;
	
	AdjustCaret(pdc, rcClipBounds);
	
	len = m_display.GetLength();
	cs = m_display.Right(len - m_drawpos);
	pdc->ExtTextOut( rcClipBounds.left, ( rcClipBounds.top + rcClipBounds.bottom - tm.tmHeight) /2, 
		ETO_CLIPPED, rcClipBounds, cs, NULL );
	pdc->SelectObject(pOldFont);
	//pdc->SelectObject(pOldPen);
	pdc->SelectObject(pOldBrush);
	
}


/////////////////////////////////////////////////////////////////////////////
// CBEditCtrl::DoPropExchange - Persistence support

void CBEditCtrl::DoPropExchange(CPropExchange* pPX)
{
	OLE_COLOR	ocBk = (OLE_COLOR)0x00ffffff;
	OLE_COLOR	ocFk = (OLE_COLOR)0x00000000;
	CString		cs;

	ExchangeVersion(pPX, MAKELONG(_wVerMinor, _wVerMajor));
	COleControl::DoPropExchange(pPX);

	//PX_Color(pPX, _T("BackColor"), BackColor, oc);
	SetBackColor(ocBk);
	SetForeColor(ocFk);
	PX_String(pPX, _T("Content"), m_content, _T(""));
	m_leftbear = 10;
	m_rightbear = 10;
/*	
	cs += (TCHAR)0x09ac;
	cs += (TCHAR)0x09cd;
	cs += (TCHAR)0x098b;
	cs += (TCHAR)0x0995;
	cs += (TCHAR)0x09cd;
	cs += (TCHAR)0x09b7;
	cs += (TCHAR)0x09cd;
	cs += (TCHAR)0x09b9;
	cs += (TCHAR)0x09a4;
	cs += (TCHAR)0x09b2;
	cs += (TCHAR)0x09cd;
	cs += (TCHAR)0x098f;
	SetContent(LPCTSTR(cs));
*/
  }


/////////////////////////////////////////////////////////////////////////////
// CBEditCtrl::OnResetState - Reset control to default state

void CBEditCtrl::OnResetState()
{
	COleControl::OnResetState();  // Resets defaults found in DoPropExchange

	// TODO: Reset any other control state here.
}


/////////////////////////////////////////////////////////////////////////////
// CBEditCtrl::AboutBox - Display an "About" box to the user

void CBEditCtrl::AboutBox()
{
	CDialog dlgAbout(IDD_ABOUTBOX_BEDIT);
	dlgAbout.DoModal();
}


/////////////////////////////////////////////////////////////////////////////
// CBEditCtrl message handlers

BSTR CBEditCtrl::GetContent() 
{
	UnsortedToSorted();
	return m_content.AllocSysString();
}

void CBEditCtrl::SetContent(LPCTSTR lpszNewValue) 
{
	if(m_content != lpszNewValue)
	{
		m_content = lpszNewValue;
		SortedToUnsorted();
		SetModifiedFlag();
		InvalidateControl();
	}
}

void CBEditCtrl::OnChar(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
	CString		cs;
	CString		cs1;
	CString		cs2;
	int			len;
	TCHAR		prev;
	TCHAR		pprev;
	int			i;
	int			j;
	BOOL		concated = FALSE;
	BOOL		concatable = FALSE;

	//MessageBox((LPCTSTR)"key pressed", NULL, MB_OK);
	if(keymap[nChar] != 0x0000)
	{
		if( m_position == 1 )
		{
			prev = m_display[m_position -1];
			if(prev == CONCAT)
			{
				switch(keymap[nChar])
				{
					case AA_KAR:
						len = m_display.GetLength();
						cs1 = m_display.Left(m_position - 1);
						cs2 = m_display.Right(len - m_position);
						cs1 += AA;
						m_display = cs1 + cs2;
						SetModifiedFlag();
						InvalidateControl();
						break;
					case I_KAR:
						len = m_display.GetLength();
						cs1 = m_display.Left(m_position - 1);
						cs2 = m_display.Right(len - m_position);
						cs1 += I;
						m_display = cs1 + cs2;
						SetModifiedFlag();
						InvalidateControl();
						break;
					case II_KAR:
						len = m_display.GetLength();
						cs1 = m_display.Left(m_position - 1);
						cs2 = m_display.Right(len - m_position);
						cs1 += II;
						m_display = cs1 + cs2;
						SetModifiedFlag();
						InvalidateControl();
						break;
					case U_KAR:
						len = m_display.GetLength();
						cs1 = m_display.Left(m_position - 1);
						cs2 = m_display.Right(len - m_position);
						cs1 += U;
						m_display = cs1 + cs2;
						SetModifiedFlag();
						InvalidateControl();
						break;
					case UU_KAR:
						len = m_display.GetLength();
						cs1 = m_display.Left(m_position - 1);
						cs2 = m_display.Right(len - m_position);
						cs1 += UU;
						m_display = cs1 + cs2;
						SetModifiedFlag();
						InvalidateControl();
						break;
					case RI_KAR:
						len = m_display.GetLength();
						cs1 = m_display.Left(m_position - 1);
						cs2 = m_display.Right(len - m_position);
						cs1 += RI;
						m_display = cs1 + cs2;
						SetModifiedFlag();
						InvalidateControl();
						break;
					case E_KAR:
						len = m_display.GetLength();
						cs1 = m_display.Left(m_position - 1);
						cs2 = m_display.Right(len - m_position);
						cs1 += E;
						m_display = cs1 + cs2;
						SetModifiedFlag();
						InvalidateControl();
						break;
					case OI_KAR:
						len = m_display.GetLength();
						cs1 = m_display.Left(m_position - 1);
						cs2 = m_display.Right(len - m_position);
						cs1 += OI;
						m_display = cs1 + cs2;
						SetModifiedFlag();
						InvalidateControl();
						break;
					case O_KAR:
						len = m_display.GetLength();
						cs1 = m_display.Left(m_position - 1);
						cs2 = m_display.Right(len - m_position);
						cs1 += O;
						m_display = cs1 + cs2;
						SetModifiedFlag();
						InvalidateControl();
						break;
					case OU_KAR:
						len = m_display.GetLength();
						cs1 = m_display.Left(m_position - 1);
						cs2 = m_display.Right(len - m_position);
						cs1 += OU;
						m_display = cs1 + cs2;
						SetModifiedFlag();
						InvalidateControl();
						break;
				}	
			}
			else
			{
				len = m_display.GetLength();
				cs1 = m_display.Left(m_position);
				cs2 = m_display.Right(len - m_position);
				cs1 += keymap[nChar];
				m_display = cs1 + cs2;
				m_position ++;
				SetModifiedFlag();
				InvalidateControl();
			}
		}
		else if( m_position > 1 )
		{
			prev = m_display[m_position -1];
			if (prev == CONCAT )
			{
				switch(keymap[nChar])
				{
					case AA_KAR:
						len = m_display.GetLength();
						cs1 = m_display.Left(m_position - 1);
						cs2 = m_display.Right(len - m_position);
						cs1 += AA;
						m_display = cs1 + cs2;
						SetModifiedFlag();
						InvalidateControl();
						break;
					case I_KAR:
						len = m_display.GetLength();
						cs1 = m_display.Left(m_position - 1);
						cs2 = m_display.Right(len - m_position);
						cs1 += I;
						m_display = cs1 + cs2;
						SetModifiedFlag();
						InvalidateControl();
						break;
					case II_KAR:
						len = m_display.GetLength();
						cs1 = m_display.Left(m_position - 1);
						cs2 = m_display.Right(len - m_position);
						cs1 += II;
						m_display = cs1 + cs2;
						SetModifiedFlag();
						InvalidateControl();
						break;
					case U_KAR:
						len = m_display.GetLength();
						cs1 = m_display.Left(m_position - 1);
						cs2 = m_display.Right(len - m_position);
						cs1 += U;
						m_display = cs1 + cs2;
						SetModifiedFlag();
						InvalidateControl();
						break;
					case UU_KAR:
						len = m_display.GetLength();
						cs1 = m_display.Left(m_position - 1);
						cs2 = m_display.Right(len - m_position);
						cs1 += UU;
						m_display = cs1 + cs2;
						SetModifiedFlag();
						InvalidateControl();
						break;
					case RI_KAR:
						len = m_display.GetLength();
						cs1 = m_display.Left(m_position - 1);
						cs2 = m_display.Right(len - m_position);
						cs1 += RI;
						m_display = cs1 + cs2;
						SetModifiedFlag();
						InvalidateControl();
						break;
					case E_KAR:
						len = m_display.GetLength();
						cs1 = m_display.Left(m_position - 1);
						cs2 = m_display.Right(len - m_position);
						cs1 += E;
						m_display = cs1 + cs2;
						SetModifiedFlag();
						InvalidateControl();
						break;
					case OI_KAR:
						len = m_display.GetLength();
						cs1 = m_display.Left(m_position - 1);
						cs2 = m_display.Right(len - m_position);
						cs1 += OI;
						m_display = cs1 + cs2;
						SetModifiedFlag();
						InvalidateControl();
						break;
					case O_KAR:
						len = m_display.GetLength();
						cs1 = m_display.Left(m_position - 1);
						cs2 = m_display.Right(len - m_position);
						cs1 += O;
						m_display = cs1 + cs2;
						SetModifiedFlag();
						InvalidateControl();
						break;
					case OU_KAR:
						len = m_display.GetLength();
						cs1 = m_display.Left(m_position - 1);
						cs2 = m_display.Right(len - m_position);
						cs1 += OU;
						m_display = cs1 + cs2;
						SetModifiedFlag();
						InvalidateControl();
						break;
					default:
						pprev = m_display[m_position - 2];
						for( i = 0 ; i < CCAT_GROUPS ;i++)
						{
							if (ranges[i].ch == pprev)
							{
								concatable = TRUE;
								break;
							}
						}
						if (concatable)
						{
							for( j = ranges[i].start; i <= ranges[i].finish ; j++)
							{
								if(concat[j].second == keymap[nChar])
								{
									concated = TRUE;
									break;
								}
							}
							if(concated)
							{
								len = m_display.GetLength();
								cs1 = m_display.Left(m_position - 2);
								cs2 = m_display.Right(len - m_position);
								cs1 += concat[j].result;
								m_display = cs1 + cs2;
								m_position --;
								SetModifiedFlag();
								InvalidateControl();
							}
							else
							{
								len = m_display.GetLength();
								cs1 = m_display.Left(m_position);
								cs2 = m_display.Right(len - m_position);
								cs1 += keymap[nChar];
								m_display = cs1 + cs2;
								m_position ++;
								SetModifiedFlag();
								InvalidateControl();
							}
						}
						else
						{
							len = m_display.GetLength();
							cs1 = m_display.Left(m_position);
							cs2 = m_display.Right(len - m_position);
							cs1 += keymap[nChar];
							m_display = cs1 + cs2;
							m_position ++;
							SetModifiedFlag();
							InvalidateControl();
						}
						break;	//end of default
				}
			}
			else
			{
				len = m_display.GetLength();
				cs1 = m_display.Left(m_position);
				cs2 = m_display.Right(len - m_position);
				cs1 += keymap[nChar];
				m_display = cs1 + cs2;
				m_position ++;
				SetModifiedFlag();
				InvalidateControl();
			}
		}
		else
		{
			len = m_display.GetLength();
			cs1 = m_display.Left(m_position);
			cs2 = m_display.Right(len - m_position);
			cs1 += keymap[nChar];
			m_display = cs1 + cs2;
			m_position ++;
			SetModifiedFlag();
			InvalidateControl();
		}
	}

	//COleControl::OnChar(nChar, nRepCnt, nFlags);
}

void CBEditCtrl::OnFontChanged() 
{

	COleControl::OnFontChanged();

}

void CBEditCtrl::OnSetFocus(CWnd* pOldWnd) 
{
	//TEXTMETRIC	tm;
	//CFont*		pOldFont;
	//CDC*		pdc = COleControl::GetDC();
	//CRect		rcBounds;
	int		pcx;
	int		pcy;

	//COleControl::OnSetFocus(pOldWnd);
	
	//pOldFont = SelectStockFont(pdc);
	GetControlSize(&pcx, &pcy);
	//pdc->GetTextMetrics(&tm);

	CreateSolidCaret(1,pcy /2);	
	//pOldFont = SelectStockFont(pdc);

	m_caret.x = m_leftbear;
	m_caret.y = ( pcy - pcy/2) /2;
	//COleControl::ReleaseDC(pdc);
	m_position = 0;
	m_drawpos = 0;
	SetCaretPos(m_caret);
	ShowCaret();
}

void CBEditCtrl::OnKillFocus(CWnd* pNewWnd) 
{
	COleControl::OnKillFocus(pNewWnd);
	
	DestroyCaret();

}

BOOL CBEditCtrl::OnSetObjectRects(LPCRECT lpRectPos, LPCRECT lpRectClip) 
{
	
	return COleControl::OnSetObjectRects(lpRectPos, lpRectClip);
}

void CBEditCtrl::AdjustCaret(CDC* pdc, const CRect& rcBounds)
{
	CString		str1;
	CString		str2;
	CSize		cs;
	//CFont*	pOldFont;
	int			drawlen;

	//pOldFont = SelectStockFont(pdc);

	drawlen = rcBounds.right - rcBounds.left;
	str1 = m_display.Left(m_position);
	while (1)
	{
		str2 = str1.Right( m_position - m_drawpos);
		cs = pdc->GetOutputTextExtent( str2);
		//pdc->LPtoDP(&cs);
		m_caret.x = m_leftbear + cs.cx;
		if(	cs.cx <= drawlen && cs.cx >= 0)
		{
			break;
		}
		else if( cs.cx > drawlen )
		{
			m_drawpos ++;
		}
		else
		{
		}
	}
	SetCaretPos(m_caret);
	
	//pdc->SelectObject(pOldFont);

}

void CBEditCtrl::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
	// TODO: Add your message handler code here and/or call default
	switch(nChar)
	{
		case VK_UP:
		{
			break;
		}
		case VK_DOWN:
		{
			break;
		}
		case VK_LEFT:
		{
			if ( m_position > 0 )
			{
				m_position --;
				if (m_position < m_drawpos)
				{
					m_drawpos = m_position;
				}
				//SetModifiedFlag();
				InvalidateControl();
			}
			break;
		}
		case VK_RIGHT:
		{
			if( m_position < m_display.GetLength())
			{
				m_position ++;
				//SetModifiedFlag();
				InvalidateControl();
			}
			break;
		}
		case VK_HOME:
		{
			if ( m_position > 0 )
			{
				m_position = 0;
				m_drawpos = 0;
				//SetModifiedFlag();
				InvalidateControl();
			}
			break;
		}
		case VK_END:
		{
			if( m_position < m_display.GetLength())
			{
				m_position = m_display.GetLength();
				//SetModifiedFlag();
				InvalidateControl();
			}
			break;
		}
		case VK_DELETE:
		{
			if( m_position < m_display.GetLength())
			{
				CString		cs1;
				CString		cs2;
				int			len;

				len = m_display.GetLength();
				cs1 = m_display.Left(m_position);
				cs2 = m_display.Right(len - m_position - 1);
				m_display = cs1 + cs2;
				//SetModifiedFlag();
				InvalidateControl();
			}
			break;
		}
		case VK_BACK:
		{
			if( m_position > 0)
			{
				CString		cs1;
				CString		cs2;
				int			len;

				len = m_display.GetLength();
				cs1 = m_display.Left(m_position - 1);
				cs2 = m_display.Right(len - m_position );
				m_display = cs1 + cs2;
				m_position --;
				if (m_position < m_drawpos)
				{
					m_drawpos = m_position;
				}
				//SetModifiedFlag();
				InvalidateControl();
			}
			break;
		}
		default:
			break;
	}

	//COleControl::OnKeyDown(nChar, nRepCnt, nFlags);
}

void CBEditCtrl::SortedToUnsorted()
{
	USHORT	n_dst;
	USHORT*	src;
	USHORT*	dst;
	USHORT	n_src;
	int		i;

	n_src = (USHORT)m_content.GetLength();
	src = new USHORT[n_src];
	for( i = 0 ; i < n_src; i++)
	{
		src[i] = (USHORT)m_content[i];
	}
	dst = new USHORT[n_src * 2];

	n_dst = UniConv( S_2_U, src, dst, n_src );
	
	m_display.Empty();
	for( i = 0 ; i < n_dst; i++)
	{
		m_display += (TCHAR)dst[i];
	}
	delete src;
	delete dst;
}

void CBEditCtrl::UnsortedToSorted()
{
	USHORT	n_dst;
	USHORT*	src;
	USHORT*	dst;
	USHORT	n_src;
	int		i;

	n_src = (USHORT)m_display.GetLength();
	src = new USHORT[n_src];
	for( i = 0 ; i < n_src; i++)
	{
		src[i] = (USHORT)m_display[i];
	}
	dst = new USHORT[n_src * 4];

	n_dst = UniConv( U_2_S, src, dst, n_src);
	
	m_content.Empty();
	for( i = 0 ; i < n_dst; i++)
	{
		m_content += (TCHAR)dst[i];
	}

	delete src;
	delete dst;
}

BOOL CBEditCtrl::PreTranslateMessage(MSG* pMsg) 
{
	BOOL bHandleNow = FALSE;

    switch (pMsg->message)
    {
		case WM_KEYDOWN:
		{
			switch (pMsg->wParam)
			{
				case VK_HOME:
				case VK_END:
				case VK_BACK:
				case VK_DELETE:
		        case VK_UP:
				case VK_DOWN:
		        case VK_LEFT:
				case VK_RIGHT:
			        bHandleNow = TRUE;
				    break;
			}
			if (bHandleNow)
				OnKeyDown((UINT)pMsg->wParam, (UINT)LOWORD(pMsg 
					->lParam), (UINT)HIWORD(pMsg->lParam));
			break;
		}
		case WM_CHAR:
		{
			bHandleNow = TRUE;
			OnChar((UINT)pMsg->wParam, (UINT)LOWORD(pMsg 
                ->lParam), (UINT)HIWORD(pMsg->lParam));
			break;
		}
	}
    return bHandleNow;
}
