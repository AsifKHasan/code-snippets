-- Insert some data

connect reptest/reptest@spec
insert into t_user values ('asif'	, 'asif'	, 'Asif Hasan'		);
commit;

connect reptest/reptest@spec
insert into t_user values ('forkan'	, 'forkan'	, 'Forkan Bin Quasem'	);
commit;


connect reptest/reptest@jtlb
insert into t_user values ('mushfiq'	, 'mushfiq'	, 'Mushfiqur Rahman'	);
commit;


connect reptest/reptest@jtlb
insert into t_user values ('tanveer'	, 'tanveer'	, 'Tanveer Rahman'	);
commit;


connect reptest/reptest@spec
update t_user set user_name = 'Tanveer Ehsanur Rahman' where user_id = 'tanveer';
commit;


connect reptest/reptest@jtlb
update t_user set user_name = 'Md. Mushfiqur Rahman' where user_id = 'mushfiq';
commit;
