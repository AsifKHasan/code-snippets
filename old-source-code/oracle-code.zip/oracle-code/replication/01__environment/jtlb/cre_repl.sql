-- Connect As System
connect system/secl@jtlb


-- Create Replication Admin User
create user repadmin identified by repadmin;


-- Grant privileges to replication administrator
begin
	dbms_repcat_admin.grant_admin_any_schema 
	(
		username => 'repadmin'
	);
end;
/

grant comment any table to repadmin;
grant lock any table to repadmin;
grant select any dictionary to repadmin;


-- Register Propagator
begin
	dbms_defer_sys.register_propagator 
	(
		username => 'repadmin'
	);
end;
/



-- Register receiver
begin
	dbms_repcat_admin.register_user_repgroup 
	(
		username 	=> 'repadmin', 
		privilege_type 	=> 'receiver', 
		list_of_gnames 	=> null
	);
end;
/


-- Schedule purge at master site
connect repadmin/repadmin@jtlb

begin
	dbms_defer_sys.schedule_purge 
	(
		next_date 	=> sysdate, 
		interval 	=> 'sysdate + 1/24', 
		delay_seconds 	=> 0
	);
end;
/


