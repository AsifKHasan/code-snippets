-- Create database links between master sites.

connect system/secl@spec
drop public database link jtlb;
create public database link jtlb using 'jtlb';

connect repadmin/repadmin@spec
drop database link jtlb;
create database link jtlb connect to repadmin identified by repadmin;



-- Define a schedule for database link to create scheduled links.

connect repadmin/repadmin@spec

begin
	dbms_defer_sys.schedule_push 
	(
		destination 		=> 'jtlb', 
		interval 		=> 'sysdate + (1/144)', 
		next_date 		=> sysdate, 
		parallelism		=> 1, 
		execution_seconds	=> 1500, 
		delay_seconds		=> 1200
	);
end;
/
