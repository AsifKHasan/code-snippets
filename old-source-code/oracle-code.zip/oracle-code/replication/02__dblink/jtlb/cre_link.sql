-- Create database links between master sites.

connect system/secl@jtlb
drop public database link spec;
create public database link spec using 'spec';

connect repadmin/repadmin@jtlb
drop database link spec;
create database link spec connect to repadmin identified by repadmin;



-- Define a schedule for database link to create scheduled links.

connect repadmin/repadmin@jtlb

begin
	dbms_defer_sys.schedule_push 
	(
		destination 		=> 'spec', 
		interval 		=> 'sysdate + (1/144)', 
		next_date 		=> sysdate, 
		parallelism 		=> 1, 
		execution_seconds 	=> 1500, 
		delay_seconds 		=> 1200
	);
end;
/
