-- Create user

connect system/secl@jtlb

create user reptest identified by reptest default tablespace users temporary tablespace temp;
grant connect, resource to reptest;


-- Create two tables

connect reptest/reptest@jtlb

create table t_user
(
user_id		varchar(16)	constraint	nn_id_user	not null,
user_pass	varchar(8)	constraint	nn_pass_user	not null,
user_name	varchar(64)	constraint	nn_name_user	not null,
constraint	pk_user		primary key	(user_id)
);

create table t_role
(
role_id		varchar(16)	constraint	nn_id_role	not null,
role_name	varchar(32)	constraint	nn_name_role	not null,
constraint	pk_role		primary key	(role_id)
);

create table t_userrole
(
userrole_user	varchar(16)	constraint	nn_user_userrole	not null
				constraint	fk_user_userrole
				references	t_user(user_id),
userrole_role	varchar(16)	constraint	nn_role_userrole	not null
				constraint	fk_role_userrole
				references	t_role(role_id),
constraint	pk_userrole	primary key	(userrole_user, userrole_role)
);

