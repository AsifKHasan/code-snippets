-- Create user

connect system/secl@spec

create user reptest identified by reptest default tablespace users temporary tablespace temp;
grant connect, resource to reptest;


-- Create two tables

connect reptest/reptest@spec

create table t_user
(
user_id		varchar(16)	constraint	nn_id_user	not null,
user_pass	varchar(8)	constraint	nn_pass_user	not null,
user_name	varchar(64)	constraint	nn_name_user	not null,
constraint	pk_user		primary key	(user_id)
);

create table t_role
(
role_id		varchar(16)	constraint	nn_id_role	not null,
role_name	varchar(32)	constraint	nn_name_role	not null,
constraint	pk_role		primary key	(role_id)
);

create table t_userrole
(
userrole_user	varchar(16)	constraint	nn_user_userrole	not null
				constraint	fk_user_userrole
				references	t_user(user_id),
userrole_role	varchar(16)	constraint	nn_role_userrole	not null
				constraint	fk_role_userrole
				references	t_role(role_id),
constraint	pk_userrole	primary key	(userrole_user, userrole_role)
);



-- Create master group

connect repadmin/repadmin@spec

begin
	dbms_repcat.drop_master_repgroup 
	(
		gname 		=> 'rpg_rep',
		drop_contents 	=> false,
		all_sites 	=> true
	);
end;
/

begin
	dbms_repcat.create_master_repgroup 
	(
		gname => 'rpg_rep'
	);
end;
/


-- Add tables to master group

begin
	dbms_repcat.create_master_repobject 
	(
		gname => 'rpg_rep',
		type => 'table',
		oname => 't_user',
		sname => 'reptest',
		use_existing_object => true,
		copy_rows => false
	);
end;
/
begin
	dbms_repcat.create_master_repobject 
	(
		gname => 'rpg_rep',
		type => 'table',
		oname => 't_role',
		sname => 'reptest',
		use_existing_object => true,
		copy_rows => false
	);
end;
/
begin
	dbms_repcat.create_master_repobject 
	(
		gname => 'rpg_rep',
		type => 'table',
		oname => 't_userrole',
		sname => 'reptest',
		use_existing_object => true,
		copy_rows => false
	);
end;
/





-- Add another master site in the replication environment

begin
	dbms_repcat.add_master_database 
	(
		gname => 'rpg_rep',
		master => 'jtlb',
		use_existing_objects => true,
		copy_rows => false,
		propagation_mode => 'asynchronous'
	);
end;
/


-- Verify if jtlb appears in DBA_REPSITES view

select dblink from dba_repsites where gname = 'RPG_REP';



-- Generate replication support

begin 
	dbms_repcat.generate_replication_support 
	(
		sname => 'reptest',
		oname => 't_user', 
		type => 'table',
		min_communication => true
	); 
end;
/
begin 
	dbms_repcat.generate_replication_support 
	(
		sname => 'reptest',
		oname => 't_role', 
		type => 'table',
		min_communication => true
	); 
end;
/
begin 
	dbms_repcat.generate_replication_support 
	(
		sname => 'reptest',
		oname => 't_userrole', 
		type => 'table',
		min_communication => true
	); 
end;
/

-- Wait until the DBA_REPCATLOG view is empty before resuming master activity

select count(*) from dba_repcatlog where gname = 'RPG_REP';



-- Resume replication

begin 
	dbms_repcat.resume_master_activity 
	(
		gname => 'rpg_rep'
	); 
end;
/
