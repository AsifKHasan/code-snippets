/*

	2004/06/14, KAH, SECL

*/


drop table t_preq
drop table t_prst
drop table t_item
drop table t_dbud
drop table t_unit
drop table t_lbal
drop table t_leav
drop table t_empl
drop table t_grlv
drop table t_stat
drop table t_ltyp
drop table t_grde
drop table t_rank
drop table t_dept
drop table t_cycl




create table	t_cycl
(
cycl_code	varchar(16)	constraint	nn_code_cycl	not null,
cycl_name	varchar(32)	constraint	nn_name_cycl	not null,
cycl_stdt	datetime	constraint	nn_stdt_cycl	not null,
cycl_endt	datetime	constraint	nn_endt_cycl	not null,
constraint	pk_cycl		primary Key	(cycl_code)
)

go



create table	t_dept
(
dept_code	varchar(16)	constraint	nn_code_dept	not null,
dept_name	varchar(32)	constraint	nn_name_dept	not null,
dept_mail	varchar(32)	constraint	nn_mail_dept	not null,
constraint	pk_dept		primary Key	(dept_code)
)

go



create table	t_rank
(
rank_code	varchar(16)	constraint	nn_code_rank	not null,
rank_name	varchar(32)	constraint	nn_name_rank	not null,
constraint	pk_rank		primary Key	(rank_code)
)

go



create table	t_grde
(
grde_code	varchar(16)	constraint	nn_code_grde	not null,
grde_name	varchar(32)	constraint	nn_name_grde	not null,
constraint	pk_grde		primary Key	(grde_code)
)

go



create table	t_ltyp
(
ltyp_code	varchar(16)	constraint	nn_code_ltyp	not null,
ltyp_name	varchar(32)	constraint	nn_name_ltyp	not null,
constraint	pk_ltyp		primary Key	(ltyp_code)
)

go



create table	t_stat
(
stat_code	varchar(16)	constraint	nn_code_stat	not null,
stat_name	varchar(32)	constraint	nn_name_stat	not null,
constraint	pk_stat		primary Key	(stat_code)
)

go



create table	t_grlv
(
grlv_cycl	varchar(16)	constraint	nn_code_grlv	not null
				constraint	fk_cycl_grlv
				references	t_cycl(cycl_code),
grlv_grde	varchar(16)	constraint	nn_grde_grlv	not null
				constraint	fk_grde_grlv
				references	t_grde(grde_code),
grlv_ltyp	varchar(16)	constraint	nn_ltyp_grlv	not null
				constraint	fk_ltyp_grlv
				references	t_ltyp(ltyp_code),
grlv_days	numeric(3)	constraint	nn_days_grlv	not null,
constraint	pk_grlv		primary Key	(grlv_cycl, grlv_grde, grlv_ltyp)
)

go



create table	t_empl
(
empl_code	varchar(16)	constraint	nn_code_empl	not null,
empl_name	varchar(64)	constraint	nn_name_empl	not null,
empl_addr	varchar(128)	constraint	nn_addr_empl	not null,
empl_dept	varchar(16)	constraint	nn_dept_empl	not null
				constraint	fk_dept_empl
				references	t_dept(dept_code),
empl_rank	varchar(16)	constraint	nn_rank_empl	not null
				constraint	fk_rank_empl
				references	t_rank(rank_code),
empl_grde	varchar(16)	constraint	nn_grde_empl	not null
				constraint	fk_grde_empl
				references	t_grde(grde_code),
empl_mail	varchar(32)	constraint	nn_code_empl	not null,
empl_cell	varchar(16)	constraint	nn_code_empl	not null,
empl_mngr	varchar(16)	constraint	fk_mngr_empl
				references	t_empl(empl_code),
constraint	pk_empl		primary Key	(empl_code)
)

go



create table	t_leav
(
leav_cycl	varchar(16)	constraint	nn_cycl_leav	not null
				constraint	fk_cycl_leav
				references	t_cycl(cycl_code),
leav_empl	varchar(16)	constraint	nn_empl_leav	not null
				constraint	fk_empl_leav
				references	t_empl(empl_code),
leav_ltyp	varchar(16)	constraint	nn_ltyp_leav	not null
				constraint	fk_ltyp_leav
				references	t_ltyp(ltyp_code),
leav_stat	varchar(16)	constraint	nn_stat_leav	not null
				constraint	fk_stat_leav
				references	t_stat(stat_code),
leav_stdt	datetime	constraint	nn_stdt_leav	not null,
leav_days	numeric(3)	constraint	nn_days_leav	not null,
leav_appr	varchar(16)	constraint	fk_appr_leav
				references	t_empl(empl_code),
constraint	pk_leav		primary Key	(leav_cycl, leav_empl, leav_stdt)
)

go



create table	t_lbal
(
lbal_cycl	varchar(16)	constraint	nn_cycl_lbal	not null
				constraint	fk_cycl_lbal
				references	t_cycl(cycl_code),
lbal_empl	varchar(16)	constraint	nn_empl_lbal	not null
				constraint	fk_empl_lbal
				references	t_empl(empl_code),
lbal_ltyp	varchar(16)	constraint	nn_ltyp_lbal	not null
				constraint	fk_ltyp_lbal
				references	t_ltyp(ltyp_code),
lbal_stat	varchar(16)	constraint	nn_stat_lbal	not null
				constraint	fk_stat_lbal
				references	t_stat(stat_code),
lbal_days	numeric(3)	constraint	nn_days_lbal	not null,
constraint	pk_lbal		primary Key	(lbal_cycl, lbal_empl, lbal_ltyp, lbal_stat)
)

go









create table	t_unit
(
unit_code	varchar(16)	constraint	nn_code_unit	not null,
unit_name	varchar(32)	constraint	nn_name_unit	not null,
constraint	pk_unit		primary Key	(unit_code)
)

go



create table	t_dbud
(
dbud_cycl	varchar(16)	constraint	nn_cycl_dbud	not null
				constraint	fk_cycl_dbud
				references	t_cycl(cycl_code),
dbud_dept	varchar(16)	constraint	nn_dept_dbud	not null
				constraint	fk_dept_dbud
				references	t_dept(dept_code),
dbud_bval	numeric(16,6)	constraint	nn_bval_dbud	not null,
dbud_used	numeric(16,6)	constraint	nn_used_dbud	not null,
constraint	pk_dbud		primary Key	(dbud_cycl, dbud_dept)
)

go



create table	t_item
(
item_code	varchar(16)	constraint	nn_code_item	not null,
item_name	varchar(32)	constraint	nn_name_item	not null,
item_unit	varchar(16)	constraint	nn_unit_item	not null
				constraint	fk_unit_item
				references	t_unit(unit_code),
constraint	pk_item		primary Key	(item_code)
)

go



create table	t_prst
(
prst_code	varchar(16)	constraint	nn_code_prst	not null,
prst_name	varchar(32)	constraint	nn_name_prst	not null,
constraint	pk_prst		primary Key	(prst_code)
)

go



create table	t_preq
(
preq_code	varchar(64)	constraint	nn_code_preq	not null,
preq_cycl	varchar(16)	constraint	nn_cycl_preq	not null
				constraint	fk_cycl_preq
				references	t_cycl(cycl_code),
preq_dept	varchar(16)	constraint	nn_dept_preq	not null
				constraint	fk_dept_preq
				references	t_dept(dept_code),
preq_empl	varchar(16)	constraint	nn_empl_preq	not null
				constraint	fk_empl_preq
				references	t_empl(empl_code),
preq_item	varchar(16)	constraint	nn_item_preq	not null
				constraint	fk_item_preq
				references	t_item(item_code),
preq_date	datetime	constraint	nn_date_preq	not null,
preq_spec	text,
preq_qnty	numeric(4)	constraint	nn_qnty_preq	not null,
preq_cost	numeric(16,6)	constraint	nn_cost_preq	not null,
preq_prst	varchar(16)	constraint	nn_prst_preq	not null
				constraint	fk_prst_preq
				references	t_prst(prst_code),
constraint	pk_preq		primary Key	(preq_code)
)

go







insert into t_cycl values('2002'	, 'Calendar Year 2002'	, '01/01/2002'	, '01/01/2003'	);
insert into t_cycl values('2003'	, 'Calendar Year 2003'	, '01/01/2003'	, '01/01/2004'	);
insert into t_cycl values('2004'	, 'Calendar Year 2004'	, '01/01/2004'	, '01/01/2005'	);

go



insert into t_dept values('ADMN'	, 'Admin Department'		, 'forkan@spectrum-bd.com'	);
insert into t_dept values('FINN'	, 'Finance Department'		, 'forkan@spectrum-bd.com'	);
insert into t_dept values('PUR'		, 'Purchase Department'		, 'mushfiq@spectrum-bd.com'	);
insert into t_dept values('MKTG'	, 'Marketing Department'	, 'forkan@spectrum-bd.com'	);
insert into t_dept values('SWD'		, 'Software Department'		, 'asif@spectrum-bd.com'	);
insert into t_dept values('NWD'		, 'Network Department'		, 'tanveer@spectrum-bd.com'	);
insert into t_dept values('TRDE'	, 'Trading Department'		, 'mushfiq@spectrum-bd.com'	);
insert into t_dept values('PP'		, 'Panthapath Sales Department'	, 'mushfiq@spectrum-bd.com'	);
insert into t_dept values('IDB'		, 'IDB Sales Department'	, 'mushfiq@spectrum-bd.com'	);

go



insert into t_rank values('MD'		, 'Managing Director'			);
insert into t_rank values('DMD'		, 'Deputy Managing Director'		);
insert into t_rank values('CTO'		, 'Chief Technology Officer'		);
insert into t_rank values('CIO'		, 'Chief Information Officer'		);
insert into t_rank values('SPM'		, 'Software Project Manager'		);
insert into t_rank values('NIM'		, 'Network Implementation Manager'	);
insert into t_rank values('SSM'		, 'Software Support Manager'		);
insert into t_rank values('NSM'		, 'Network Support Manager'		);
insert into t_rank values('FM'		, 'Finace and Accounts Manager'		);
insert into t_rank values('MM'		, 'Marketing Manager'			);
insert into t_rank values('SA'		, 'Software Analyst'			);
insert into t_rank values('SD'		, 'Software Designer'			);
insert into t_rank values('SrSE'	, 'Senior Software Engineer'		);
insert into t_rank values('SE'		, 'Software Engineer'			);
insert into t_rank values('SrSSE'	, 'Senior Software Support Engineer'	);
insert into t_rank values('SSE'		, 'Software Support Engineer'		);
insert into t_rank values('SP'		, 'Software Programmer'			);
insert into t_rank values('NIE'		, 'Network Implementation Engineer'	);
insert into t_rank values('NSE'		, 'Network Support Engineer'		);
insert into t_rank values('FAE'		, 'Finance and Accounts Executive'	);

go



insert into t_grde values('DI'		, 'Director'		);
insert into t_grde values('M2'		, 'Manager Grade 2'	);
insert into t_grde values('M1'		, 'Manager Grade 1'	);
insert into t_grde values('O2'		, 'Officer Grade 2'	);
insert into t_grde values('O1'		, 'Officer Grade 1'	);
insert into t_grde values('E2'		, 'Executive Grade 2'	);
insert into t_grde values('E1'		, 'Executive Grade 2'	);
insert into t_grde values('PO'		, 'Peons and Orderly'	);

go



insert into t_ltyp values('CL'		, 'Casual Leave'	);
insert into t_ltyp values('ML'		, 'Medical Leave'	);
insert into t_ltyp values('EL'		, 'Earned Leave'	);

go



insert into t_stat values('Requested'	, 'Requested'	);
insert into t_stat values('Approved'	, 'Approved'	);
insert into t_stat values('Rejected'	, 'Rejected'	);

go



insert into t_grlv values('2004'	, 'DI'	, 'CL'	, 15	);
insert into t_grlv values('2004'	, 'DI'	, 'ML'	, 20	);
insert into t_grlv values('2004'	, 'DI'	, 'EL'	,  0	);
insert into t_grlv values('2004'	, 'M2'	, 'CL'	, 15	);
insert into t_grlv values('2004'	, 'M2'	, 'ML'	, 20	);
insert into t_grlv values('2004'	, 'M2'	, 'EL'	, 20	);
insert into t_grlv values('2004'	, 'M1'	, 'CL'	, 15	);
insert into t_grlv values('2004'	, 'M1'	, 'ML'	, 20	);
insert into t_grlv values('2004'	, 'M1'	, 'EL'	, 20	);
insert into t_grlv values('2004'	, 'O2'	, 'CL'	, 15	);
insert into t_grlv values('2004'	, 'O2'	, 'ML'	, 15	);
insert into t_grlv values('2004'	, 'O2'	, 'EL'	, 15	);
insert into t_grlv values('2004'	, 'O1'	, 'CL'	, 15	);
insert into t_grlv values('2004'	, 'O1'	, 'ML'	, 15	);
insert into t_grlv values('2004'	, 'O1'	, 'EL'	, 15	);
insert into t_grlv values('2004'	, 'E2'	, 'CL'	, 15	);
insert into t_grlv values('2004'	, 'E2'	, 'ML'	, 15	);
insert into t_grlv values('2004'	, 'E2'	, 'EL'	, 10	);
insert into t_grlv values('2004'	, 'E1'	, 'CL'	, 15	);
insert into t_grlv values('2004'	, 'E1'	, 'ML'	, 15	);
insert into t_grlv values('2004'	, 'E1'	, 'EL'	, 10	);
insert into t_grlv values('2004'	, 'PO'	, 'CL'	, 15	);
insert into t_grlv values('2004'	, 'PO'	, 'ML'	, 10	);
insert into t_grlv values('2004'	, 'PO'	, 'EL'	,  5	);

go



insert into t_empl values('forkan'		, 'Forkan Bin Quasem'		, 'Spectrum Engineering Consortium Ltd.'	, 'ADMN'	, 'MD'	, 'DI'	, 'forkan@spectrum-bd.com'	, '+88019341389'	, 'forkan'		);
insert into t_empl values('asif'		, 'Asif Hasan'			, 'Spectrum Engineering Consortium Ltd.'	, 'SWD'		, 'CTO'	, 'M1'	, 'asif@spectrum-bd.com'	, '+88017563821'	, 'forkan'		);
insert into t_empl values('sayeed'		, 'Md. Sayeed'			, 'Spectrum Engineering Consortium Ltd.'	, 'NWD'		, 'NSE'	, 'E1'	, 'sayeed@spectrum-bd.com'	, '+88019341389'	, 'asif'		);
insert into t_empl values('asad'		, 'Md. Asad'			, 'Spectrum Engineering Consortium Ltd.'	, 'NWD'		, 'NSE'	, 'E1'	, 'asad@spectrum-bd.com'	, '+88019341389'	, 'asif'		);

go



insert into t_unit values('PCS'		, 'Piece'	);
insert into t_unit values('BOX'		, 'Box'		);
insert into t_unit values('DZS'		, 'Dozen'	);

go



insert into t_dbud values('2003'	, 'ADMN'	, 100000.00	, 0.00	);
insert into t_dbud values('2003'	, 'FINN'	,  50000.00	, 0.00	);
insert into t_dbud values('2003'	, 'PUR'		,  50000.00	, 0.00	);
insert into t_dbud values('2003'	, 'MKTG'	, 300000.00	, 0.00	);
insert into t_dbud values('2003'	, 'SWD'		, 400000.00	, 0.00	);
insert into t_dbud values('2003'	, 'NWD'		, 500000.00	, 0.00	);
insert into t_dbud values('2003'	, 'TRDE'	, 100000.00	, 0.00	);
insert into t_dbud values('2003'	, 'PP'		, 200000.00	, 0.00	);
insert into t_dbud values('2003'	, 'IDB'		,  50000.00	, 0.00	);

go


insert into t_item values('Computer-PC'		, 'Computer'		, 'PCS'	);
insert into t_item values('Server'		, 'Server'		, 'PCS'	);
insert into t_item values('Notebook'		, 'Notebook'		, 'PCS'	);
insert into t_item values('Cable-CAT5'		, 'CAT5 Cable'		, 'BOX'	);
insert into t_item values('Cable-RJ11'		, 'RJ11 Cable'		, 'BOX'	);

go


insert into t_prst values('ReqSubmitted'	, 'Submitted by Requester'	);
insert into t_prst values('MgrApproved'		, 'Approved by Manager'		);
insert into t_prst values('MgrRejected'		, 'Rejected by Manager'		);
insert into t_prst values('PurApproved'		, 'Approved by Purchase'	);
insert into t_prst values('PurRejected'		, 'Rejected by Purchase'	);
insert into t_prst values('FinApproved'		, 'Approved by Finance'		);
insert into t_prst values('FinRejected'		, 'Rejected by Finance'		);















drop trigger g_ai_leav
drop trigger g_au_leav

go



create trigger g_ai_leav on t_leav
after insert as
begin

	declare	insert_cur scroll cursor for
		select	leav_cycl, leav_empl, leav_ltyp, leav_stat, leav_days
		from	inserted

	declare	@new_leav_cycl	varchar(16) 
	declare	@new_leav_empl	varchar(16) 
	declare	@new_leav_ltyp	varchar(16) 
	declare	@new_leav_days	numeric(3)
	declare	@new_leav_stat	varchar(16)
	

	open	insert_cur

	fetch	next 
	from	insert_cur 
	into	@new_leav_cycl, @new_leav_empl, @new_leav_ltyp, @new_leav_stat, @new_leav_days
		
	if @new_leav_stat <> 'Requested'
	begin
		raiserror  ('When Inserting LEAVE status must be Requested',  16,  1)
		rollback   tran
		close	insert_cur
		deallocate	insert_cur
		return
	end
	
	if exists(	select	*
			from
			t_lbal
			where	lbal_cycl = @new_leav_cycl	and
				lbal_empl = @new_leav_empl	and
				lbal_ltyp = @new_leav_ltyp	and
				lbal_stat = @new_leav_stat
		) 
	begin
		update	t_lbal
		set	lbal_days = lbal_days + @new_leav_days
		where	lbal_cycl = @new_leav_cycl	and
			lbal_empl = @new_leav_empl	and
			lbal_ltyp = @new_leav_ltyp	and
			lbal_stat = @new_leav_stat
	end
	else
	begin
		insert t_lbal 	(lbal_cycl	, lbal_empl	, lbal_ltyp	, lbal_stat	, lbal_days	) 
		values 		(@new_leav_cycl	, @new_leav_empl, @new_leav_ltyp, @new_leav_stat, @new_leav_days)
	end

	close	insert_cur
	deallocate	insert_cur

end

go




create trigger g_au_leav on t_leav
after update as
begin

	declare	insert_cur scroll cursor for
		select	leav_cycl, leav_empl, leav_ltyp, leav_stat, leav_days
		from	inserted

	declare	delete_cur scroll cursor for
		select	leav_cycl, leav_empl, leav_ltyp, leav_stat, leav_days
		from	deleted

	declare	@new_leav_cycl	varchar(16) 
	declare	@new_leav_empl	varchar(16) 
	declare	@new_leav_ltyp	varchar(16) 
	declare	@new_leav_days	numeric(3)
	declare	@new_leav_stat	varchar(16)
	
	declare	@old_leav_cycl	varchar(16) 
	declare	@old_leav_empl	varchar(16) 
	declare	@old_leav_ltyp	varchar(16) 
	declare	@old_leav_days	numeric(3)
	declare	@old_leav_stat	varchar(16)

	if update(leav_stat)
	begin

		open	insert_cur
		open	delete_cur

		fetch	next 
		from	insert_cur 
		into	@new_leav_cycl, @new_leav_empl, @new_leav_ltyp, @new_leav_stat, @new_leav_days

		fetch	next 
		from	delete_cur 
		into	@old_leav_cycl, @old_leav_empl, @old_leav_ltyp, @old_leav_stat, @old_leav_days


		if exists(	select	*
				from
				t_lbal
				where	lbal_cycl = @new_leav_cycl	and
					lbal_empl = @new_leav_empl	and
					lbal_ltyp = @new_leav_ltyp	and
					lbal_stat = @new_leav_stat
			) 
		begin
			update	t_lbal
			set	lbal_days = lbal_days + @new_leav_days
			where	lbal_cycl = @new_leav_cycl	and
				lbal_empl = @new_leav_empl	and
				lbal_ltyp = @new_leav_ltyp	and
				lbal_stat = @new_leav_stat
		end
		else
		begin
			insert t_lbal 	(lbal_cycl	, lbal_empl	, lbal_ltyp	, lbal_stat	, lbal_days	) 
			values 		(@new_leav_cycl	, @new_leav_empl, @new_leav_ltyp, @new_leav_stat, @new_leav_days)
		end


		update	t_lbal
		set	lbal_days = lbal_days - @old_leav_days
		where	lbal_cycl = @old_leav_cycl	and
			lbal_empl = @old_leav_empl	and
			lbal_ltyp = @old_leav_ltyp	and
			lbal_stat = @old_leav_stat


		close		insert_cur
		close		delete_cur
		deallocate	insert_cur
		deallocate	delete_cur
		
	end

end

go




create trigger g_au_preq on t_preq
after update as
begin

	declare	insert_cur scroll cursor for
		select	preq_cycl, preq_dept, preq_cost, preq_prst
		from	inserted

	declare	@new_preq_cycl	varchar(16) 
	declare	@new_preq_dept	varchar(16) 
	declare	@new_preq_cost	numeric(16,6) 
	declare	@new_preq_prst	varchar(16)

	if update(preq_prst)
	begin

		open	insert_cur

		fetch	next 
		from	insert_cur 
		into	@new_preq_cycl, @new_preq_dept, @new_preq_cost, @new_preq_prst

		if @new_preq_prst = 'FinApproved'
		begin
			update	t_dbud
			set	dbud_used = dbud_used + @new_preq_cost
			where	dbud_cycl = @new_preq_cycl	and
				dbud_dept = @new_preq_dept
		end

		close		insert_cur
		deallocate	insert_cur
		
	end

end

go




delete from t_leav
delete from t_lbal

insert into t_leav values ('2003', 'asif', 'ML', 'Requested', 'October 10, 2003', 1, null)

update 	t_leav 
set 	leav_stat = 'Approved'
where	leav_cycl = '2003'	and
	leav_empl = 'asif'	and
	leav_stdt = 'October 10, 2003'
	