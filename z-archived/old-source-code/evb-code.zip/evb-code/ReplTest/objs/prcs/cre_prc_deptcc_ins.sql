create procedure sp_deptcc_ins
(
	@deptcc_costcenter	varchar(15),
	@deptcc_dept		varchar(10)
)	as
begin
	insert into st_deptcc	(costcenter, dept)
	values 					(@deptcc_costcenter, @deptcc_dept)
end

go
