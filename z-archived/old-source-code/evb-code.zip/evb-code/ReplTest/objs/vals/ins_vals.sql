
/*
	----------------------------------------------------------------------------------------------------
	Item Units
	----------------------------------------------------------------------------------------------------
*/

insert into t_unit values('EA'	, 'Each'		);
insert into t_unit values('PK'	, 'Pack'		);
insert into t_unit values('DZ'	, 'Dozen'		);

go




/*
	----------------------------------------------------------------------------------------------------
	Sales Representative
	----------------------------------------------------------------------------------------------------
*/

insert into t_srep values('A001'	, 'Abul Kalam Azad'		);
insert into t_srep values('B001'	, 'Badrul Hasan'		);
insert into t_srep values('C001'	, 'Chandranath Roy'		);

go



/*
	----------------------------------------------------------------------------------------------------
	Distributor
	----------------------------------------------------------------------------------------------------
*/

insert into t_dist values('D00100'	, 'M/s Barkat Enterprise'	, 'Lalbagh, Dhaka'			);
insert into t_dist values('C00200'	, 'Anwar Agencies'			, 'Agrabad C/A, Chittagong'	);
insert into t_dist values('K00100'	, 'Pritom Traders'			, 'Rupshaghat, Khulna'		);

go



/*
	----------------------------------------------------------------------------------------------------
	Sales Items
	----------------------------------------------------------------------------------------------------
*/

insert into t_item values('S101'	, 'Lux Soap'		, 14.00		, 'EA'		);
insert into t_item values('S111'	, 'Lifeboy Soap'	, 10.00		, 'EA'		);
insert into t_item values('S121'	, 'Wheel Soap'		,  8.00		, 'EA'		);
insert into t_item values('D121'	, 'Wheel Detergent'	, 23.00		, 'PK'		);

go


/*
	----------------------------------------------------------------------------------------------------
	Tasks
	----------------------------------------------------------------------------------------------------
*/

insert into t_task values('20040520173500', '05/20/2004', '05/20/2004', 'A001'	, 'D00100'	, 'Order'	, 'New'			);
insert into t_task values('20040520173600', '05/20/2004', '05/20/2004', 'A001'	, 'D00100'	, 'Order'	, 'Done'		);
insert into t_task values('20040520173700', '05/20/2004', '05/20/2004', 'A001'	, 'D00100'	, 'Order'	, 'Cancelled'	);

go
