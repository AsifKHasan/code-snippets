


/*	----------------------------------------------------------------------------------------------------
	Sales Delivery Items
*/	----------------------------------------------------------------------------------------------------

execute
(
'if exists	(select name from sysobjects where type like ''U'' and name like ''t_dvli'') drop table t_dvli'
)

go



/*	----------------------------------------------------------------------------------------------------
	Sales Delivery
*/	----------------------------------------------------------------------------------------------------

execute
(
'if exists	(select name from sysobjects where type like ''U'' and name like ''t_dlvr'') drop table t_dlvr'
)

go



/*	----------------------------------------------------------------------------------------------------
	Sales Order Items
*/	----------------------------------------------------------------------------------------------------

execute
(
'if exists	(select name from sysobjects where type like ''U'' and name like ''t_soli'') drop table t_soli'
)

go



/*
	----------------------------------------------------------------------------------------------------
	Sales Order
*/	----------------------------------------------------------------------------------------------------

execute
(
'if exists	(select name from sysobjects where type like ''U'' and name like ''t_sord'') drop table t_sord'
)

go



/*	----------------------------------------------------------------------------------------------------
	Sales Tasks
*/	----------------------------------------------------------------------------------------------------

execute
(
'if exists	(select name from sysobjects where type like ''U'' and name like ''t_task'') drop table t_task'
)

go



/*	----------------------------------------------------------------------------------------------------
	Sales Items
*/	----------------------------------------------------------------------------------------------------

execute
(
'if exists	(select name from sysobjects where type like ''U'' and name like ''t_item'') drop table t_item'
)

go



/*	----------------------------------------------------------------------------------------------------
	Distributor
*/	----------------------------------------------------------------------------------------------------

execute
(
'if exists	(select name from sysobjects where type like ''U'' and name like ''t_dist'') drop table t_dist'
)

go



/*	----------------------------------------------------------------------------------------------------
	Sales Representative
*/	----------------------------------------------------------------------------------------------------

execute
(
'if exists	(select name from sysobjects where type like ''U'' and name like ''t_srep'') drop table t_srep'
)

go



/*	----------------------------------------------------------------------------------------------------
	Item Units
*/	----------------------------------------------------------------------------------------------------

execute
(
'if exists	(select name from sysobjects where type like ''U'' and name like ''t_unit'') drop table t_unit'
)

go
