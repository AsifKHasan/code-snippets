
/*
	----------------------------------------------------------------------------------------------------
	Item Units
	----------------------------------------------------------------------------------------------------
*/

create table	t_unit
(
	id			varchar(6)			not null,
	name		varchar(16)			not null,
	constraint	pk_unit				primary key	(id)
)

go



/*
	----------------------------------------------------------------------------------------------------
	Sales Representative
	----------------------------------------------------------------------------------------------------
*/

create table	t_srep
(
	id			varchar(6)			not null,
	name		varchar(64)			not null,
	constraint	pk_srep				primary key	(id)
)

go



/*
	----------------------------------------------------------------------------------------------------
	Distributor
	----------------------------------------------------------------------------------------------------
*/

create table	t_dist
(
	id			varchar(6)			not null,
	name		varchar(64)			not null,
	addr		varchar(128)		not null
	constraint	pk_dist				primary key	(id)
)

go



/*
	----------------------------------------------------------------------------------------------------
	Sales Items
	----------------------------------------------------------------------------------------------------
*/

create table	t_item
(
	id			varchar(6)			not null,
	name		varchar(32)			not null,
	price		numeric(12,2)		not null,
	unit		varchar(6)			not null	references t_unit(id),
	constraint	pk_item				primary key	(id)
)

go



/*
	----------------------------------------------------------------------------------------------------
	Sales Tasks
	ttyp can be		Visit
					Order
					Delivery
	tpos can be		New					server
						Overdue			client/server
						Cancelled		client/server
					Order Taken			client
					Delivery Due		server
					Delivered			client
					Done				server
	----------------------------------------------------------------------------------------------------
*/

create table	t_task
(
	id			varchar(16)			not null,
	taskdate	datetime			not null,
	tnewdate	datetime			not null,
	srep		varchar(6)			not null	references	t_srep(id),
	dist		varchar(6)			not null	references	t_dist(id),
	ttyp		varchar(16)			not null,
	tpos		varchar(24)			not null,
	constraint	pk_task				primary key	(id)
)

go



/*
	----------------------------------------------------------------------------------------------------
	Sales Order
	----------------------------------------------------------------------------------------------------
*/

create table	t_sord
(
	id			varchar(16)			not null,
	sorddate	datetime			not null,
	dlvrdate	datetime			not null,
	srep		varchar(6)			not null	references	t_srep(id),
	dist		varchar(6)			not null	references	t_dist(id),
	constraint	pk_sord	primary 	key	(id)
)

go



/*
	----------------------------------------------------------------------------------------------------
	Sales Order Items
	----------------------------------------------------------------------------------------------------
*/

create table	t_soli
(
	id			varchar(20)			not null,
	sord		varchar(16)			not null	references	t_sord(id),
	item		varchar(6)			not null	references	t_item(id),
	qty			numeric(10)			not null,
	price		numeric(12,2)		not null,
	constraint	pk_soli				primary key	(id)
)

go



/*
	----------------------------------------------------------------------------------------------------
	Sales Delivery
	----------------------------------------------------------------------------------------------------
*/

create table	t_dlvr
(
	id			varchar(16)			not null,
	sord		varchar(16)			not null	references	t_sord(id),
	dlvrdate	datetime			not null,
	srep		varchar(6)			not null	references	t_srep(id),
	dist		varchar(6)			not null	references	t_dist(id),
	constraint	pk_dlvr				primary key	(id)
)

go



/*
	----------------------------------------------------------------------------------------------------
	Sales Delivery Items
	----------------------------------------------------------------------------------------------------
*/

create table	t_dvli
(
	id			varchar(20)			not null,
	dlvr		varchar(16)			not null	references	t_dlvr(id),
	item		varchar(6)			not null	references	t_item(id),
	qty			numeric(10)			not null,
	price		numeric(12,2)		not null,
	constraint	pk_dvli				primary key	(id)
)

go
