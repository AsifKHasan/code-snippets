#define	FACTOR			100

#define	CCAT_GROUPS		57
#define	CCAT_TOTAL		175

#define	UJOIN			130
#define	UUJOIN			130
#define	RIJOIN			112

#define SPACE			(TCHAR)32
#define	RETURN			(TCHAR)127

#define	ANUSHAR			(TCHAR)118
#define	VISARGA			(TCHAR)119
#define	CHANDRA			(TCHAR)120

#define REF             (TCHAR)38
#define YA_FALA         (TCHAR)35  

#define	DARRI			(TCHAR)124

#define A               (TCHAR)65  
#define AA              (TCHAR)66    
#define I               (TCHAR)67  
#define II              (TCHAR)68  
#define U               (TCHAR)69  
#define UU              (TCHAR)70  
#define RI              (TCHAR)71  
#define E               (TCHAR)72  
#define OI              (TCHAR)73  
#define O               (TCHAR)74  
#define OU              (TCHAR)75  

#define KA              (TCHAR)76
#define KHA             (TCHAR)77
#define GA              (TCHAR)78
#define GHA             (TCHAR)79
#define NGA             (TCHAR)80
#define CHA             (TCHAR)81
#define CHHA            (TCHAR)82
#define JA              (TCHAR)83
#define JHA             (TCHAR)84
#define NYA             (TCHAR)85
#define TTA             (TCHAR)86
#define TTHA            (TCHAR)87
#define DDA             (TCHAR)88
#define DDHA            (TCHAR)89
#define NNA             (TCHAR)90
#define TA              (TCHAR)97
#define _TA				(TCHAR)98
#define THA             (TCHAR)99
#define DA              (TCHAR)100
#define DHA             (TCHAR)101
#define NA              (TCHAR)102
#define PA              (TCHAR)103
#define PHA             (TCHAR)104
#define BA              (TCHAR)105
#define BHA             (TCHAR)106
#define MA              (TCHAR)107

#define YA              (TCHAR)108
#define RA              (TCHAR)109
#define LA              (TCHAR)110
#define SHA             (TCHAR)111
#define SSA             (TCHAR)112
#define SA              (TCHAR)113
#define HA              (TCHAR)114

#define RRA             (TCHAR)115
#define RRHA            (TCHAR)116
#define YYA             (TCHAR)117

#define	CONCAT			(TCHAR)121

#define AA_KAR          (TCHAR)14
#define I_KAR           (TCHAR)15
#define II_KAR          (TCHAR)16
#define U_KAR           (TCHAR)17
#define U1_KAR          (TCHAR)18
#define U2_KAR          (TCHAR)19
#define U3_KAR          (TCHAR)20

#define UU_KAR          (TCHAR)21
#define UU1_KAR         (TCHAR)22
#define UU2_KAR         (TCHAR)23
#define RI_KAR          (TCHAR)24
#define RI1_KAR         (TCHAR)25
#define E_KAR           (TCHAR)26  
#define OI_KAR          (TCHAR)28  
#define OU_KAR          (TCHAR)30  

#define KA_KA           (TCHAR)170				//000
#define KA_TTA          (TCHAR)171				//001
#define KA_TA           (TCHAR)172				//002
#define KA_MA           (TCHAR)173				//003
#define KA_SSA			(TCHAR)174				//004
#define KA_SSA_MA		(TCHAR)175				//005
#define KA_SA			(TCHAR)176				//006

#define GA_DA           (TCHAR)177				//007
#define GA_DHA          (TCHAR)178				//008

#define NGA_KA          (TCHAR)179				//009
#define NGA_KHA         (TCHAR)180				//010
#define NGA_GA          (TCHAR)181				//011
#define NGA_GHA         (TCHAR)182				//012
#define NGA_MA          (TCHAR)183				//013

#define CHA_CHA         (TCHAR)184				//014
#define CHA_CHHA        (TCHAR)185				//015
#define CHA_NYA         (TCHAR)186				//016

#define JA_JA           (TCHAR)187				//017
#define JA_JHA          (TCHAR)188				//018
#define JA_NYA          (TCHAR)189				//019

#define NYA_CHA         (TCHAR)190				//020
#define NYA_CHHA        (TCHAR)191				//021
#define NYA_JA          (TCHAR)192				//022
#define NYA_JHA         (TCHAR)193				//023

#define TTA_TTA         (TCHAR)194				//024

#define NNA_TTA         (TCHAR)195				//025
#define NNA_TTHA        (TCHAR)196				//026
#define NNA_DDA         (TCHAR)197				//027

#define TA_TA           (TCHAR)198				//028
#define TA_THA          (TCHAR)199				//029
#define TA_MA           (TCHAR)200				//030

#define DA_DA           (TCHAR)201				//031
#define DA_DHA          (TCHAR)202				//032
#define DA_DHA_BA       (TCHAR)203				//033
#define DA_BHA          (TCHAR)204				//034
#define DA_MA           (TCHAR)205				//035

#define NA_JA           (TCHAR)206				//036
#define NA_TTA          (TCHAR)207				//037
#define NA_TTHA         (TCHAR)208				//038
#define NA_DDA          (TCHAR)209				//039
#define NA_TA           (TCHAR)210				//040
#define NA_THA          (TCHAR)211				//041
#define NA_DA           (TCHAR)212				//042
#define NA_DHA          (TCHAR)213				//043
#define NA_MA           (TCHAR)214				//044
#define NA_SA           (TCHAR)215				//045 

#define PA_TTA          (TCHAR)216				//046
#define PA_TA           (TCHAR)217				//047
#define PA_PA           (TCHAR)218				//048
#define PA_SA           (TCHAR)219				//049

#define BA_JA           (TCHAR)220				//050
#define BA_DA           (TCHAR)221				//051
#define BA_DHA          (TCHAR)222				//052			

#define MA_PA           (TCHAR)223				//053
#define MA_PHA          (TCHAR)224				//054
#define MA_BHA          (TCHAR)225				//055
#define MA_MA           (TCHAR)226				//056

#define LA_KA           (TCHAR)227				//057
#define LA_GA           (TCHAR)228				//058
#define LA_TTA          (TCHAR)229				//059
#define LA_DDA          (TCHAR)230				//060
#define LA_PA           (TCHAR)231				//061
#define LA_PHA          (TCHAR)232				//062

#define SHA_CHA         (TCHAR)233				//063
#define SHA_CHHA        (TCHAR)234				//064
#define SHA_MA          (TCHAR)235				//065

#define SSA_KA          (TCHAR)236				//066
#define SSA_NYA         (TCHAR)237				//067
#define SSA_TTA         (TCHAR)238				//068
#define SSA_TTHA        (TCHAR)239				//069
#define SSA_PA          (TCHAR)240				//070
#define SSA_PHA         (TCHAR)241				//071
#define SSA_MA          (TCHAR)242				//072

#define SA_KA           (TCHAR)243				//073				
#define SA_KHA          (TCHAR)244				//074
#define SA_TTA          (TCHAR)245				//075
#define SA_TA           (TCHAR)246				//076
#define SA_THA          (TCHAR)247				//077
#define SA_PA           (TCHAR)248				//078
#define SA_PHA          (TCHAR)249				//079
#define SA_MA           (TCHAR)250				//080

#define HA_RI           (TCHAR)251				//081
#define HA_NNA          (TCHAR)252				//082
#define HA_MA           (TCHAR)253				//083

#define RRA_GA          (TCHAR)254				//084

#define TA_RA           (TCHAR)255				//085

#define NA_FALA	        (TCHAR)157
#define NA_FALA1		(TCHAR)158

#define BA_FALA	        (TCHAR)160
#define BA_FALA1		(TCHAR)161

#define RA_FALA	        (TCHAR)162
#define RA_FALA1		(TCHAR)163
#define RA_FALA2		(TCHAR)164
#define RA_FALA3		(TCHAR)165


#define LA_FALA	        (TCHAR)166
#define LA_FALA1		(TCHAR)167

typedef struct
{
	TCHAR	first;
    TCHAR	second;
	int		num;
    TCHAR	result[2];
} CCAT;

typedef struct
{
	TCHAR	pre;
	TCHAR	post;
} JOIN;

typedef struct
{
	TCHAR	ch;
	int		start;
	int		finish;
} RANGES;

JOIN	u_table[ UJOIN ] =
		{
            { KA		, U1_KAR },
            { KHA		, U_KAR },
            { GA		, U_KAR },
            { GHA		, U_KAR },
            { NGA		, U1_KAR },
            { CHA		, U1_KAR },
            { CHHA		, U_KAR },
            { JA        , U_KAR },
            { JHA       , U1_KAR },
            { NYA       , U1_KAR },
            { TTA       , U1_KAR },
            { TTHA      , U1_KAR },
            { DDA       , U1_KAR },
            { DDHA      , U1_KAR },
            { NNA       , U_KAR },
            { TA        , U1_KAR },
            { THA       , U_KAR },
            { DA        , U_KAR },
            { DHA       , U_KAR },
            { NA        , U_KAR },
            { PA        , U_KAR },
            { PHA       , U1_KAR },
            { BA        , U_KAR },
            { BHA       , U1_KAR },
            { MA        , U_KAR },
            { YA		, U_KAR },
            { RA		, U3_KAR },
            { LA        , U_KAR },
            { SHA       , U_KAR },
            { SSA       , U_KAR },
            { SA        , U_KAR },
            { HA        , U1_KAR },
            { RRA       , U2_KAR },
            { RRHA      , U2_KAR },
            { YYA       , U_KAR },
            { KA_KA     , U1_KAR },
            { KA_TTA    , U_KAR },
            { KA_TA     , U1_KAR },
            { KA_MA     , U_KAR },
            { KA_SSA    , U1_KAR },
            { KA_SSA_MA , U_KAR },
            { KA_SA	    , U_KAR },
            { GA_DA     , U_KAR },
            { GA_DHA    , U1_KAR },
            { NGA_KA    , U1_KAR },
            { NGA_KHA   , U_KAR },
            { NGA_GA    , U_KAR },
            { NGA_GHA   , U_KAR },
            { NGA_MA    , U_KAR },
            { CHA_CHA   , U1_KAR },
            { CHA_CHHA  , U_KAR },
            { CHA_NYA   , U_KAR },
            { JA_JA     , U_KAR },
            { JA_JHA    , U_KAR },
            { JA_NYA    , U_KAR },
            { NYA_CHA   , U1_KAR },
            { NYA_CHHA  , U_KAR },
            { NYA_JA    , U1_KAR },
            { NYA_JHA   , U1_KAR },
            { TTA_TTA   , U1_KAR },
            { NNA_TTA   , U1_KAR },
            { NNA_TTHA  , U1_KAR },
            { NNA_DDA   , U_KAR },
            { TA_TA     , U_KAR },
            { TA_THA    , U2_KAR },
            { TA_MA     , U_KAR },
            { DA_DA     , U_KAR },
            { DA_DHA    , U_KAR },
            { DA_DHA_BA , U_KAR },
            { DA_BHA    , U_KAR },
            { DA_MA     , U_KAR },
            { NA_JA     , U_KAR },
            { NA_TTA    , U1_KAR },
            { NA_TTHA   , U1_KAR },
            { NA_DDA    , U1_KAR },
            { NA_TA     , U1_KAR },
            { NA_THA    , U1_KAR },
            { NA_DA     , U_KAR },
            { NA_DHA    , U_KAR },
            { NA_MA     , U_KAR },
            { NA_SA     , U_KAR },
            { PA_TTA    , U1_KAR },
            { PA_TA     , U_KAR },
            { PA_PA     , U_KAR },
            { PA_SA     , U_KAR },
            { BA_JA     , U_KAR },
            { BA_DA     , U_KAR },
            { BA_DHA    , U_KAR },
            { MA_PA		, U_KAR },
            { MA_PHA	, U_KAR },
            { MA_BHA	, U_KAR },
            { MA_MA		, U_KAR },
            { LA_KA		, U1_KAR },
            { LA_GA		, U_KAR },
            { LA_TTA	, U1_KAR },
            { LA_DDA	, U1_KAR },
            { LA_PA		, U_KAR },
            { LA_PHA	, U1_KAR },
            { SHA_CHA	, U1_KAR },
            { SHA_CHHA	, U_KAR },
            { SHA_MA	, U_KAR },
            { SSA_KA	, U1_KAR },
            { SSA_NYA	, U_KAR },
            { SSA_TTA	, U1_KAR },
            { SSA_TTHA	, U1_KAR },
            { SSA_PA	, U_KAR },
            { SSA_PHA	, U1_KAR },
            { SSA_MA    , U_KAR },
            { SA_KA     , U1_KAR },
            { SA_KHA    , U_KAR },
            { SA_TTA    , U1_KAR },
            { SA_TA     , U1_KAR },
            { SA_THA    , U_KAR },
            { SA_PA     , U_KAR },
            { SA_PHA    , U1_KAR },
            { SA_MA     , U_KAR },
            { HA_NNA    , U1_KAR },
            { HA_MA     , U_KAR },
            { RRA_GA    , U_KAR },
			{ TA_RA     , U_KAR },
			{ NA_FALA	, U2_KAR },	
			{ NA_FALA1	, U2_KAR },	
			{ BA_FALA	, U_KAR },	
			{ BA_FALA1	, U2_KAR },	
			{ RA_FALA	, U3_KAR },	
			{ RA_FALA1	, U3_KAR },	
			{ RA_FALA2	, U3_KAR },
			{ LA_FALA	, U2_KAR },	
			{ LA_FALA1	, U_KAR }	
		};

JOIN	uu_table[ UUJOIN ] =
		{
            { KA		, UU1_KAR },
            { KHA		, UU_KAR },
            { GA		, UU_KAR },
            { GHA		, UU_KAR },
            { NGA		, UU_KAR },
            { CHA		, UU1_KAR },
            { CHHA		, UU_KAR },
            { JA        , UU_KAR },
            { JHA       , UU_KAR },
            { NYA       , UU1_KAR },
            { TTA       , UU1_KAR },
            { TTHA      , UU1_KAR },
            { DDA       , UU1_KAR },
            { DDHA      , UU1_KAR },
            { NNA       , UU_KAR },
            { TA        , UU1_KAR },
            { THA       , UU_KAR },
            { DA        , UU_KAR },
            { DHA       , UU_KAR },
            { NA        , UU_KAR },
            { PA        , UU_KAR },
            { PHA       , UU1_KAR },
            { BA        , UU_KAR },
            { BHA       , UU1_KAR },
            { MA        , UU_KAR },

            { YA		, UU_KAR },
            { RA		, UU2_KAR },
            { LA        , UU_KAR },
            { SHA       , UU_KAR },
            { SSA       , UU_KAR },
            { SA        , UU_KAR },
            { HA        , UU_KAR },

            { RRA       , UU_KAR },
            { RRHA      , UU_KAR },
            { YYA       , UU_KAR },

            { KA_KA     , UU1_KAR },
            { KA_TTA    , UU1_KAR },
            { KA_TA     , UU1_KAR },
            { KA_MA     , UU_KAR },
            { KA_SSA    , UU1_KAR },
            { KA_SSA_MA , UU_KAR },
            { KA_SA	    , UU_KAR },

            { GA_DA     , UU_KAR },
            { GA_DHA    , UU1_KAR },

            { NGA_KA    , UU1_KAR },
            { NGA_KHA   , UU_KAR },
            { NGA_GA    , UU_KAR },
            { NGA_GHA   , UU_KAR },
            { NGA_MA    , UU_KAR },

            { CHA_CHA   , UU1_KAR },
            { CHA_CHHA  , UU_KAR },
            { CHA_NYA   , UU_KAR },

            { JA_JA     , UU_KAR },
            { JA_JHA    , UU1_KAR },
            { JA_NYA    , UU1_KAR },

            { NYA_CHA   , UU1_KAR },
            { NYA_CHHA  , UU_KAR },
            { NYA_JA    , UU_KAR },
            { NYA_JHA   , UU1_KAR },

            { TTA_TTA   , UU1_KAR },

            { NNA_TTA   , UU1_KAR },
            { NNA_TTHA  , UU1_KAR },
            { NNA_DDA   , UU_KAR },

            { TA_TA     , UU_KAR },
            { TA_THA    , UU1_KAR },
            { TA_MA     , UU_KAR },

            { DA_DA     , UU_KAR },
            { DA_DHA    , UU_KAR },
            { DA_DHA_BA , UU_KAR },
            { DA_BHA    , UU_KAR },
            { DA_MA     , UU_KAR },

            { NA_JA     , UU_KAR },
            { NA_TTA    , UU1_KAR },
            { NA_TTHA   , UU1_KAR },
            { NA_DDA    , UU1_KAR },
            { NA_TA     , UU_KAR },
            { NA_THA    , UU_KAR },
            { NA_DA     , UU_KAR },
            { NA_DHA    , UU_KAR },
            { NA_MA     , UU_KAR },
            { NA_SA     , UU_KAR },

            { PA_TTA    , UU1_KAR },
            { PA_TA     , UU_KAR },
            { PA_PA     , UU_KAR },
            { PA_SA     , UU_KAR },

            { BA_JA     , UU_KAR },
            { BA_DA     , UU_KAR },
            { BA_DHA    , UU_KAR },

            { MA_PA		, UU_KAR },
            { MA_PHA	, UU_KAR },
            { MA_BHA	, UU_KAR },
            { MA_MA		, UU_KAR },

            { LA_KA		, UU1_KAR },
            { LA_GA		, UU_KAR },
            { LA_TTA	, UU1_KAR },
            { LA_DDA	, UU1_KAR },
            { LA_PA		, UU_KAR },
            { LA_PHA	, UU1_KAR },

            { SHA_CHA	, UU1_KAR },
            { SHA_CHHA	, UU_KAR },
            { SHA_MA	, UU_KAR },

            { SSA_KA	, UU1_KAR },
            { SSA_NYA	, UU1_KAR },
            { SSA_TTA	, UU1_KAR },
            { SSA_TTHA	, UU1_KAR },
            { SSA_PA	, UU_KAR },
            { SSA_PHA	, UU_KAR },
            { SSA_MA    , UU_KAR },

            { SA_KA     , UU1_KAR },
            { SA_KHA    , UU_KAR },
            { SA_TTA    , UU1_KAR },
            { SA_TA     , UU_KAR },
            { SA_THA    , UU_KAR },
            { SA_PA     , UU_KAR },
            { SA_PHA    , UU1_KAR },
            { SA_MA     , UU_KAR },

            { HA_NNA    , UU1_KAR },
            { HA_MA     , UU1_KAR },

            { RRA_GA    , UU_KAR },

			{ TA_RA     , UU_KAR },
			
			{ NA_FALA	, UU_KAR },	
			{ NA_FALA1	, UU1_KAR },	

			{ BA_FALA	, UU_KAR },	
			{ BA_FALA1	, UU_KAR },	

			{ RA_FALA	, UU2_KAR },	
			{ RA_FALA1	, UU2_KAR },	
			{ RA_FALA2	, UU2_KAR },

			{ LA_FALA	, UU1_KAR },	
			{ LA_FALA1	, UU_KAR }	
		};

JOIN	ri_table[ RIJOIN ] =
		{
            { KA		, RI1_KAR },
            { KHA		, RI_KAR },
            { GA		, RI_KAR },
            { GHA		, RI_KAR },
            { CHA		, RI1_KAR },
            { CHHA		, RI_KAR },
            { JA        , RI_KAR },
            { JHA       , RI_KAR },
            { TTA       , RI1_KAR },
            { TTHA      , RI1_KAR },
            { DDA       , RI1_KAR },
            { DDHA      , RI1_KAR },
            { NNA       , RI_KAR },
            { TA        , RI1_KAR },
            { THA       , RI_KAR },
            { DA        , RI_KAR },
            { DHA       , RI_KAR },
            { NA        , RI_KAR },
            { PA        , RI_KAR },
            { PHA       , RI1_KAR },
            { BA        , RI_KAR },
            { BHA       , RI1_KAR },
            { MA        , RI_KAR },
            { YA		, RI_KAR },
            { LA        , RI_KAR },
            { SHA       , RI_KAR },
            { SSA       , RI_KAR },
            { SA        , RI_KAR },
            { KA_KA     , RI1_KAR },
            { KA_TTA    , RI1_KAR },
            { KA_TA     , RI1_KAR },
            { KA_MA     , RI_KAR },
            { KA_SSA    , RI1_KAR },
            { KA_SSA_MA , RI_KAR },
            { KA_SA	    , RI_KAR },
            { GA_DA     , RI_KAR },
            { GA_DHA    , RI1_KAR },
            { NGA_KA    , RI1_KAR },
            { NGA_KHA   , RI_KAR },
            { NGA_GA    , RI_KAR },
            { NGA_GHA   , RI_KAR },
            { NGA_MA    , RI_KAR },
            { CHA_CHA   , RI1_KAR },
            { CHA_CHHA  , RI_KAR },
            { JA_JA     , RI_KAR },
            { JA_JHA    , RI1_KAR },
            { NYA_CHA   , RI1_KAR },
            { NYA_CHHA  , RI_KAR },
            { NYA_JA    , RI_KAR },
            { NYA_JHA   , RI1_KAR },
            { TTA_TTA   , RI1_KAR },
            { NNA_TTA   , RI1_KAR },
            { NNA_TTHA  , RI1_KAR },
            { NNA_DDA   , RI_KAR },
            { TA_TA     , RI_KAR },
            { TA_THA    , RI1_KAR },
            { TA_MA     , RI_KAR },
            { DA_DA     , RI_KAR },
            { DA_DHA    , RI1_KAR },
            { DA_DHA_BA , RI1_KAR },
            { DA_BHA    , RI_KAR },
            { DA_MA     , RI_KAR },
            { NA_JA     , RI_KAR },
            { NA_TTA    , RI1_KAR },
            { NA_TTHA   , RI1_KAR },
            { NA_DDA    , RI1_KAR },
            { NA_TA     , RI_KAR },
            { NA_THA    , RI_KAR },
            { NA_DA     , RI_KAR },
            { NA_DHA    , RI1_KAR },
            { NA_MA     , RI_KAR },
            { NA_SA     , RI_KAR },
            { PA_TTA    , RI1_KAR },
            { PA_TA     , RI_KAR },
            { PA_PA     , RI_KAR },
            { PA_SA     , RI_KAR },
            { BA_JA     , RI_KAR },
            { BA_DA     , RI_KAR },
            { BA_DHA    , RI_KAR },
            { MA_PA		, RI_KAR },
            { MA_PHA	, RI_KAR },
            { MA_BHA	, RI_KAR },
            { MA_MA		, RI_KAR },
            { LA_KA		, RI1_KAR },
            { LA_GA		, RI_KAR },
            { LA_TTA	, RI1_KAR },
            { LA_DDA	, RI1_KAR },
            { LA_PA		, RI_KAR },
            { LA_PHA	, RI1_KAR },
            { SHA_CHA	, RI1_KAR },
            { SHA_CHHA	, RI_KAR },
            { SHA_MA	, RI_KAR },
            { SSA_KA	, RI1_KAR },
            { SSA_TTA	, RI1_KAR },
            { SSA_TTHA	, RI1_KAR },
            { SSA_PA	, RI_KAR },
            { SSA_PHA	, RI_KAR },
            { SSA_MA    , RI_KAR },
            { SA_KA     , RI1_KAR },
            { SA_KHA    , RI_KAR },
            { SA_TTA    , RI1_KAR },
            { SA_TA     , RI_KAR },
            { SA_THA    , RI_KAR },
            { SA_PA     , RI_KAR },
            { SA_PHA    , RI1_KAR },
            { SA_MA     , RI_KAR },
            { HA_MA     , RI1_KAR },
            { RRA_GA    , RI_KAR },
			{ BA_FALA	, RI_KAR },	
			{ BA_FALA1	, RI_KAR }
		};

TCHAR	keymap[ 128 ] = 
		{
			//000-009
			0x0000, 0x0001, 0x0002, 0x0003, 0x0004, 0x0005, 0x0006, 0x0007, 0x0008, 0x0009,
			//010-019
			0x000a, 0x000b, 0x000c, 0x000d, 0x000e, 0x000f, 0x0010, 0x0011, 0x0012, 0x0013, 
			//020-029
			0x0014, 0x0015, 0x0016, 0x0017, 0x0018, 0x0019, 0x001a, 0x001b, 0x001c, 0x001d, 
			//030-039
			0x001e, 0x001f, 0x0020, 0x0021, 0x0022, 0x0000, 0x0024, 0x0025, CHANDRA,0x0027, 
			//040-049
			0x0028, 0x0029, 0x002a, 0x002b, 0x002c, 0x002d, 0x002e, 0x002f, 0x0030, 0x0031, 
			//050-059
			0x0032, 0x0033, 0x0034, 0x0035, 0x0036, 0x0037, 0x0038, 0x0039, 0x003a, 0x003b, 
			//060-069
			0x003c, 0x003d, 0x003e, 0x003f, 0x0040, REF   , NNA   , OI_KAR, II_KAR, DDHA  , 
			//070-079
			A     , DARRI , BHA   , NYA   , KHA   , THA   , DHA   , SHA   , SSA   , GHA   , 
			//080-089
			RRHA  , ANUSHAR,PHA   , UU_KAR, TTHA  , JHA   , LA    , YYA   , OU_KAR, CHHA  , 
			//090-099
			YA_FALA,0x005b,VISARGA,0x005d, 0x005e, 0x005f , RI    , RI_KAR, NA    , E_KAR , 
			//100-109
			I_KAR , DDA   , AA_KAR, CONCAT, BA    , HA    , KA    , TA    , DA    , MA    , 
			//110-119
			SA    , GA    , RRA   , NGA   , PA    , U_KAR , TTA   , JA    , RA    , YA    , 
			//120-127
			O     , CHA   , RA_FALA,0x007b, _TA   , 0x007d, 0x007e, 0x007f
		};

CCAT	concat[CCAT_TOTAL] =
		{
			//ka		000 - 008
			{KA ,		KA		,1	,{KA_KA		}},
			{KA ,		TTA		,1	,{KA_TTA	}},
			{KA ,		TA		,1	,{KA_TA		}},
			{KA ,		BA		,2	,{KA		,BA_FALA}},
			{KA ,		MA		,1	,{KA_MA		}},           
			{KA ,		RA		,2	,{KA		,RA_FALA1}},
			{KA ,		LA		,2	,{KA		,LA_FALA}},
			{KA ,		SSA		,1	,{KA_SSA	}},    
			{KA ,		SA		,1	,{KA_SA		}},    
			
			//ks_ssa	009 - 010
			{KA_SSA ,	NA		,2	,{KA_SSA	, NA_FALA}},
			{KA_SSA ,	MA		,1	,{KA_SSA_MA	}},
  
			//kha		011 - 011
			{KHA,		RA		,2	,{KHA		,RA_FALA}},

			//ga		012 - 016
			{GA ,		DA		,1	,{GA_DA		}},
			{GA ,		DHA		,1	,{GA_DHA	}},
			{GA ,		NA		,2	,{GA		,NA_FALA1}},
			{GA ,		RA		,2	,{GA		,RA_FALA}},
			{GA ,		LA		,2	,{GA		,LA_FALA1}},
  
			//gha		017 - 019
			{GHA,		NA		,2	,{GHA		,NA_FALA1}},
			{GHA,		RA		,2	,{GHA		,RA_FALA}},
			{GHA,		LA		,2	,{GHA		,LA_FALA1}},

			//Nga		020 - 024
			{NGA ,		KA		,1	,{NGA_KA	}},		
			{NGA ,		KHA		,1	,{NGA_KHA	}},		
			{NGA ,		GA		,1	,{NGA_GA	}},		
			{NGA ,		GHA		,1	,{NGA_GHA	}},		
			{NGA ,		MA		,1	,{NGA_MA	}},		
				  		
			//cha		025 - 028
			{CHA ,		CHA		,1	,{CHA_CHA	}},		
			{CHA ,		CHHA	,1	,{CHA_CHHA	}},		
			{CHA ,		NYA		,1	,{CHA_NYA	}},		
			{CHA,		BA		,2	,{CHA		,BA_FALA1}},
				  		
			//chha		029 - 030
			{CHHA,		BA		,2	,{CHHA		,BA_FALA1}},
			{CHHA,		RA		,2	,{CHHA		,RA_FALA}},

			//ja		031 - 035
			{JA ,		JA		,1	,{JA_JA		}},		
			{JA ,		JHA		,1	,{JA_JHA	}},		
			{JA ,		NYA		,1	,{JA_NYA	}},		
			{JA,		BA		,2	,{JA		,BA_FALA}},
			{JA,		RA		,2	,{JA		,RA_FALA2}},

			//ja_ja		036 - 036
			{JA_JA,		BA		,2	,{JA_JA		,BA_FALA1}},
			
			//jha		037 - 037
			{JHA,		RA		,2	,{JHA		,RA_FALA1}},

			//nya		038 - 041
			{NYA ,		CHA		,1	,{NYA_CHA	}},		
			{NYA ,		CHHA	,1	,{NYA_CHHA	}},		
			{NYA ,		JA		,1	,{NYA_JA	}},		
			{NYA ,		JHA		,1	,{NYA_JHA	}},		
			 		
			//tta		042 - 043 
			{TTA,		TTA		,1	,{TTA_TTA	}},		
			{TTA,		RA		,2	,{TTA		,RA_FALA1}},
			 		
			//ttha		044 - 044 
			{TTHA,		RA		,2	,{TTHA		,RA_FALA1}},

			//dda		045 - 046
			{DDA,		BA		,2	,{DDA		,BA_FALA1}},
			{DDA,		RA		,2	,{DDA		,RA_FALA1}},
			  		
			//ddha		047 - 048
			{DDHA,		BA		,2	,{DDHA		,BA_FALA1}},
			{DDHA,		RA		,2	,{DDHA		,RA_FALA1}},

			//nna		049 - 052
			{NNA ,		TTA		,1	,{NNA_TTA	}},		
			{NNA ,		TTHA	,1	,{NNA_TTHA	}},		
			{NNA ,		DDA		,1	,{NNA_DDA	}},		
			{NNA,		BA		,2	,{NNA		,BA_FALA}},
			  			
			//ta		053 - 058
			{TA ,		TA		,1	,{TA_TA		}},		
			{TA ,		THA		,1	,{TA_THA	}},		
			{TA,		BA		,2	,{TA		,BA_FALA1}},
			{TA,		NA		,2	,{TA		,NA_FALA1}},
			{TA ,		MA		,1	,{TA_MA		}},		
			{TA,		RA		,1	,{TA_RA		}},

			//ta_ta		059 - 059
			{TA_TA,		BA		,2	,{TA_TA		,BA_FALA1}},
			
			//tha		060 - 060
			{THA,		RA		,2	,{THA		,RA_FALA}},

			//da		061 - 067
			{DA ,		DA		,1	,{DA_DA		}},		
			{DA ,		DHA		,1	,{DA_DHA	}},		
			{DA,		BA		,2	,{DA		,BA_FALA}},
			{DA,		BHA		,1	,{DA_BHA	}},
			{DA ,		MA		,1	,{DA_MA		}},		
			{DA,		RA		,2	,{DA		,RA_FALA2}},
			{DA,		LA		,2	,{DA		,LA_FALA1}},
			  		
			//da_dha	068 - 068
			{DA_DHA ,	BA		,1	,{DA_DHA_BA	}},		
			
			//dha		069 - 070
			{DHA ,		NA		,2	,{DHA		,NA_FALA1}},		
			{DHA ,		RA		,2	,{DHA		,RA_FALA}},		
			
			//na		071 - 082
			{NA ,		JA		,1	,{NA_JA		}},		
			{NA	,		TTA		,1	,{NA_TTA	}},		
			{NA ,		TTHA	,1	,{NA_TTHA	}},		
			{NA ,		DDA		,1	,{NA_DDA	}},		
			{NA ,		TA		,1	,{NA_TA		}},		
			{NA ,		THA		,1	,{NA_THA	}},		
			{NA ,		DA		,1	,{NA_DA		}},		
			{NA ,		DHA		,1	,{NA_DHA	}},		
			{NA,		NA		,2	,{NA		,NA_FALA1}},
			{NA,		BA		,2	,{NA		,BA_FALA1}},
			{NA ,		MA		,1	,{NA_MA		}},		
			{NA ,		SA		,1	,{NA_SA		}},		
					
			//na_tta	083 - 083
			{NA_TTA,	RA		,2	,{NA_TTA	,RA_FALA1}},
			
			//na_dda	084 - 084
			{NA_DDA,	RA		,2	,{NA_DDA	,RA_FALA}},
			
			//na_ta		085 - 085
			{NA_TA,		RA		,2	,{NA_TA		,RA_FALA1}},
			
			//na_da		086 - 086
			{NA_DA,		RA		,2	,{NA_DA		,RA_FALA}},
			
			//na_dha	087 - 087
			{NA_DHA,	RA		,2	,{NA_DHA	,RA_FALA1}},

			//na_ma 	088 - 088
			{NA_MA ,	RA		,2	,{NA_MA 	,RA_FALA}},
			
			//pa		089 - 095
			{PA	,		TTA		,1	,{PA_TTA	}},		
			{PA	,		TA		,1	,{PA_TA		}},		
			{PA,		NA		,2	,{PA		,NA_FALA1}},
			{PA	,		PA		,1	,{PA_PA		}},		
			{PA,		RA		,2	,{PA		,RA_FALA}},
			{PA,		LA		,2	,{PA		,LA_FALA1}},
			{PA	,		SA		,1	,{PA_SA		}},		
			 		
			//pha		096 - 097
			{PHA,		RA		,2	,{PHA		,RA_FALA1}},
			{PHA,		LA		,2	,{PHA		,LA_FALA}},

			//ba		098 - 103
			{BA	,		JA		,1	,{BA_JA		}},		
			{BA	,		DA		,1	,{BA_DA		}},		
			{BA	,		DHA		,1	,{BA_DHA	}},		
			{BA,		BA		,2	,{BA		,BA_FALA}},
			{BA,		RA		,2	,{BA		,RA_FALA}},
			{BA,		LA		,2	,{BA		,LA_FALA1}},
			 		
			//bha		104 - 105
			{BHA,		RA		,2	,{BHA		,RA_FALA1}},
			{BHA,		LA		,2	,{BHA		,LA_FALA1}},

			//ma		106 - 113
			{MA,		NA		,2	,{MA		,NA_FALA1}},
			{MA	,		PA		,1	,{MA_PA		}},		
			{MA	,		PHA		,1	,{MA_PHA	}},		
			{MA,		BA		,2	,{MA		,BA_FALA1}},
			{MA	,		BHA		,1	,{MA_BHA	}},		
			{MA	,		MA		,1	,{MA_MA		}},		
			{MA,		RA		,2	,{MA		,RA_FALA}},
			{MA,		LA		,2	,{MA		,LA_FALA1}},

			//ma_pa 	114 - 114
			{MA_PA ,	RA		,2	,{MA_PA 	,RA_FALA}},

			//ma_pha 	115 - 115
			{MA_PHA ,	RA		,2	,{MA_PHA 	,RA_FALA1}},

			//ma_bha 	116 - 116
			{MA_BHA ,	RA		,2	,{MA_BHA 	,RA_FALA1}},

			//la		117 - 124
			{LA	,		KA		,1	,{LA_KA		}},		
			{LA	,		GA		,1	,{LA_GA		}},		
			{LA	,		TTA		,1	,{LA_TTA	}},		
			{LA	,		DDA		,1	,{LA_DDA	}},		
			{LA	,		PA		,1	,{LA_PA		}},		
			{LA	,		PHA		,1	,{LA_PHA	}},		
			{LA,		BA		,2	,{LA		,BA_FALA}},
			{LA,		LA		,2	,{LA		,LA_FALA1}},

			//la_tta 	125 - 125
			{LA_TTA,	RA		,2	,{LA_TTA	,RA_FALA1}},

			//la_dda 	126 - 126
			{LA_DDA ,	RA		,2	,{LA_DDA 	,RA_FALA1}},

			//sha		127 - 133
			{SHA,		CHA		,1	,{SHA_CHA	}},		
			{SHA,		CHHA	,1	,{SHA_CHHA	}},		
			{SHA,		NA		,2	,{SHA		,NA_FALA1}},
			{SHA,		BA		,2	,{SHA		,BA_FALA}},
			{SHA,		MA		,1	,{SHA_MA	}},		
			{SHA,		RA		,2	,{SHA		,RA_FALA}},
			{SHA,		LA		,2	,{SHA		,LA_FALA1}},

			//ssa		134 - 141
			{SSA,		KA		,1	,{SSA_KA	}},		
			{SSA,		NYA		,1	,{SSA_NYA	}},		
			{SSA,		TTA		,1	,{SSA_TTA	}},		
			{SSA,		TTHA	,1	,{SSA_TTHA	}},		
			{SSA,		PA		,1	,{SSA_PA	}},		
			{SSA,		PHA		,1	,{SSA_PHA	}},		
			{SSA,		BA		,2	,{SSA		,BA_FALA}},
			{SSA,		MA		,1	,{SSA_MA	}},		

			//ssa_ka	142 - 142
			{SSA_KA,	RA		,2	,{SSA_KA	,RA_FALA1}},

			//ssa_pa	143 - 143
			{SSA_PA,	RA		,2	,{SSA_PA	,RA_FALA}},

			//sa		144 - 155
			{SA,		KA		,1	,{SA_KA		}},		
			{SA,		KHA		,1	,{SA_KHA	}},		
			{SA,		TTA		,1	,{SA_TTA	}},		
			{SA,		TA		,1	,{SA_TA		}},		
			{SA,		THA		,1	,{SA_THA	}},		
			{SA,		NA		,2	,{SA		,NA_FALA1}},
			{SA,		PA		,1	,{SA_PA		}},		
			{SA,		PHA		,1	,{SA_PHA	}},		
			{SA,		BA		,2	,{SA		,BA_FALA}},
			{SA,		MA		,1	,{SA_MA		}},		
			{SA,		RA		,2	,{SA		,RA_FALA}},
			{SA,		LA		,2	,{SA		,LA_FALA1}},

			//sa_ka		156 - 157
			{SA_KA,		RA		,2	,{SA_KA		,RA_FALA1}},
			{SA_KA,		LA		,2	,{SA_KA		,LA_FALA}},

			//sa_kha	158 - 158
			{SA_KHA,	RA		,2	,{SA_KHA	,RA_FALA}},

			//sa_tta	159 - 159
			{SA_TTA,	RA		,2	,{SA_TTA	,RA_FALA1}},

			//sa_ta		160 - 160
			{SA_TA,		RA		,2	,{SA_TA		,RA_FALA1}},

			//sa_tha	161 - 161
			{SA_THA,	RA		,2	,{SA_THA	,RA_FALA}},

			//sa_pa		162 - 163
			{SA_PA,		RA		,2	,{SA_PA		,RA_FALA}},
			{SA_PA,		LA		,2	,{SA_PA		,LA_FALA1}},
			
			//sa_pha	164 - 165
			{SA_PHA,	RA		,2	,{SA_PHA	,RA_FALA1}},
			{SA_PHA,	LA		,2	,{SA_PHA	,LA_FALA}},

			//ha		166 - 171
			{HA,		RI		,1	,{HA_RI		}},		
			{HA,		NNA		,1	,{HA_NNA	}},		
			{HA,		BA		,2	,{HA		,BA_FALA1}},
			{HA,		MA		,1	,{HA_MA		}},		
			{HA,		RA		,2	,{HA		,RA_FALA}},
			{HA,		LA		,2	,{HA		,LA_FALA}},
			
			//rra		172 - 172
			{RRA,		GA		,1	,{RRA_GA	}},		

			//ba_fala	173 - 173
			{BA_FALA ,	RA		,2	,{BA_FALA 	,RA_FALA}},
			
			//ba_fala1	174 - 174
			{BA_FALA1 ,	RA		,2	,{BA_FALA1 	,RA_FALA3}}

};

RANGES	ranges[CCAT_GROUPS] =
		{
			{KA,		  0,   8},		//00
			{KA_SSA,	  9,  10},		//01
			{KHA,		 11,  11},		//02
			{GA,		 12,  16},		//03
			{GHA,		 17,  19},		//04
			{NGA,		 20,  24},		//05
			{CHA,		 25,  28},		//06
			{CHHA,		 29,  30},		//07
			{JA,		 31,  35},		//08
			{JA_JA,		 36,  36},		//09
			{JHA,		 37,  47},		//10
			{NYA,		 38,  41},		//11
			{TTA,		 42,  43},		//12
			{TTHA,		 44,  44},		//13
			{DDA,		 45,  46},		//14
			{DDHA,		 47,  48},		//15
			{NNA,		 49,  52},		//16
			{TA,		 53,  58},		//17
			{TA_TA,		 59,  59},		//18
			{THA,		 60,  60},		//19
			{DA,		 61,  67},		//20
			{DA_DHA,	 68,  68},		//21
			{DHA,		 69,  70},		//22
			{NA,		 71,  82},		//23
			{NA_TTA,	 83,  83},		//24	
			{NA_DDA,	 84,  84},		//25	
			{NA_TA,		 85,  85},		//26	
			{NA_DA,		 86,  86},		//27	
			{NA_DHA,	 87,  87},		//28	
			{NA_MA,		 88,  88},		//29	
			{PA,		 89,  95},		//30
			{PHA,		 96,  97},		//31
			{BA,		 98, 103},		//32
			{BHA,		104, 105},		//33
			{MA,		106, 113},		//34
			{MA_PA,		114, 114},		//35	
			{MA_PHA,	115, 115},		//36	
			{MA_BHA,	116, 116},		//37	
			{LA,		117, 124},		//38
			{LA_TTA,	125, 125},		//39	
			{LA_DDA,	126, 126},		//40	
			{SHA,		127, 133},		//41
			{SSA,		134, 141},		//42
			{SSA_KA,	142, 142},		//43
			{SSA_PA,	143, 143},		//44
			{SA,		144, 155},		//45
			{SA_KA,		156, 157},		//46
			{SA_KHA,	158, 158},		//47
			{SA_TTA,	159, 159},		//48
			{SA_TA,		160, 160},		//49
			{SA_THA,	161, 161},		//50
			{SA_PA,		162, 163},		//51
			{SA_PHA,	164, 165},		//52
			{HA,		166, 171},		//53
			{RRA,		172, 172},		//54
			{BA_FALA,	173, 173},		//55	
			{BA_FALA1,	174, 174}		//56	
};
