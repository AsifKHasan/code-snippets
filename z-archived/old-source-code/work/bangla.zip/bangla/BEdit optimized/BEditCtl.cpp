// BEditCtl.cpp : Implementation of the CBEditCtrl OLE control class.

#include "stdafx.h"
#include "BEdit.h"
#include "BEditCtl.h"
#include "BEditPpg.h"
#include "UniConv.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


IMPLEMENT_DYNCREATE(CBEditCtrl, COleControl)


/////////////////////////////////////////////////////////////////////////////
// Message map

BEGIN_MESSAGE_MAP(CBEditCtrl, COleControl)
	//{{AFX_MSG_MAP(CBEditCtrl)
	ON_WM_CHAR()
	ON_WM_SETFOCUS()
	ON_WM_KILLFOCUS()
	ON_WM_KEYDOWN()
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONDBLCLK()
	ON_WM_SIZE()
	ON_WM_VSCROLL()
	//}}AFX_MSG_MAP
	ON_OLEVERB(AFX_IDS_VERB_PROPERTIES, OnProperties)
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// Dispatch map

BEGIN_DISPATCH_MAP(CBEditCtrl, COleControl)
	//{{AFX_DISPATCH_MAP(CBEditCtrl)
	DISP_PROPERTY_NOTIFY(CBEditCtrl, "MultiLine", m_multiLine, OnMultiLineChanged, VT_BOOL)
	DISP_PROPERTY_EX(CBEditCtrl, "Content", GetContent, SetContent, VT_BSTR)
	DISP_PROPERTY_EX(CBEditCtrl, "ContentFont", GetContentFont, SetContentFont, VT_FONT)
	DISP_DEFVALUE(CBEditCtrl, "Content")
	DISP_STOCKPROP_BACKCOLOR()
	DISP_STOCKPROP_FORECOLOR()
	DISP_STOCKPROP_FONT()
	//}}AFX_DISPATCH_MAP
	DISP_FUNCTION_ID(CBEditCtrl, "AboutBox", DISPID_ABOUTBOX, AboutBox, VT_EMPTY, VTS_NONE)
END_DISPATCH_MAP()


/////////////////////////////////////////////////////////////////////////////
// Event map

BEGIN_EVENT_MAP(CBEditCtrl, COleControl)
	//{{AFX_EVENT_MAP(CBEditCtrl)
	EVENT_CUSTOM("ContentChange", FireContentChange, VTS_NONE)
	//}}AFX_EVENT_MAP
END_EVENT_MAP()


/////////////////////////////////////////////////////////////////////////////
// Property pages

// TODO: Add more property pages as needed.  Remember to increase the count!
BEGIN_PROPPAGEIDS(CBEditCtrl, 3)
	PROPPAGEID(CBEditPropPage::guid)
	PROPPAGEID(CLSID_CColorPropPage)
	PROPPAGEID(CLSID_CFontPropPage)
END_PROPPAGEIDS(CBEditCtrl)


/////////////////////////////////////////////////////////////////////////////
// Initialize class factory and guid

IMPLEMENT_OLECREATE_EX(CBEditCtrl, "BEDIT.BEditCtrl.1",
	0xef9114f3, 0xde49, 0x11d0, 0x82, 0x5e, 0, 0x40, 0x33, 0xa0, 0x1d, 0xac)


/////////////////////////////////////////////////////////////////////////////
// Type library ID and version

IMPLEMENT_OLETYPELIB(CBEditCtrl, _tlid, _wVerMajor, _wVerMinor)


/////////////////////////////////////////////////////////////////////////////
// Interface IDs

const IID BASED_CODE IID_DBEdit =
		{ 0xef9114f1, 0xde49, 0x11d0, { 0x82, 0x5e, 0, 0x40, 0x33, 0xa0, 0x1d, 0xac } };
const IID BASED_CODE IID_DBEditEvents =
		{ 0xef9114f2, 0xde49, 0x11d0, { 0x82, 0x5e, 0, 0x40, 0x33, 0xa0, 0x1d, 0xac } };


/////////////////////////////////////////////////////////////////////////////
// Control type information

static const DWORD BASED_CODE _dwBEditOleMisc =
	OLEMISC_ACTIVATEWHENVISIBLE |
	OLEMISC_SETCLIENTSITEFIRST |
	OLEMISC_INSIDEOUT |
	OLEMISC_CANTLINKINSIDE |
	OLEMISC_RECOMPOSEONRESIZE;

IMPLEMENT_OLECTLTYPE(CBEditCtrl, IDS_BEDIT, _dwBEditOleMisc)


/////////////////////////////////////////////////////////////////////////////
// CBEditCtrl::CBEditCtrlFactory::UpdateRegistry -
// Adds or removes system registry entries for CBEditCtrl

BOOL CBEditCtrl::CBEditCtrlFactory::UpdateRegistry(BOOL bRegister)
{
	// TODO: Verify that your control follows apartment-model threading rules.
	// Refer to MFC TechNote 64 for more information.
	// If your control does not conform to the apartment-model rules, then
	// you must modify the code below, changing the 6th parameter from
	// afxRegApartmentThreading to 0.

	if (bRegister)
		return AfxOleRegisterControlClass(
			AfxGetInstanceHandle(),
			m_clsid,
			m_lpszProgID,
			IDS_BEDIT,
			IDB_BEDIT,
			afxRegApartmentThreading,
			_dwBEditOleMisc,
			_tlid,
			_wVerMajor,
			_wVerMinor);
	else
		return AfxOleUnregisterClass(m_clsid, m_lpszProgID);
}


/////////////////////////////////////////////////////////////////////////////
// CBEditCtrl::CBEditCtrl - Constructor

CBEditCtrl::CBEditCtrl(): m_contentFont( &m_xFontNotification )
{
	InitializeIIDs(&IID_DBEdit, &IID_DBEditEvents);
	m_leftbear = 5;
	m_rightbear = 5;
	m_topbear = 5;
	m_linevisible = 1;
	m_firstline = 0;
	m_lastline = 0;
	m_position = 0;
	m_drawpos = 0;
	m_maxline = 1;
	m_curline = 0;
	m_display = _T("");
	m_dbuf.Add(_T(""));
	m_redraw = TRUE;
	m_adjust = TRUE;
	m_caretshown = FALSE;
}


/////////////////////////////////////////////////////////////////////////////
// CBEditCtrl::~CBEditCtrl - Destructor

CBEditCtrl::~CBEditCtrl()
{
	// TODO: Cleanup your control's instance data here.
	m_display.Empty();
	m_content.Empty();
	m_dbuf.RemoveAll();
}

/////////////////////////////////////////////////////////////////////////////
// CBEditCtrl::OnDraw - Drawing function

void CBEditCtrl::OnDraw(
			CDC* pdc, const CRect& rcBounds, const CRect& rcInvalid)
{
	pdc->SetMapMode( MM_TEXT );
	pdc->SetTextColor(TranslateColor(GetForeColor()));
	pdc->SetBkMode(TRANSPARENT);


	if( m_adjust )
	{
		//MessageBox("Got It", NULL, MB_OK);
		AdjustBuffer(pdc, rcBounds);
	}
	
	AdjustCaret(pdc, rcBounds);
}


/////////////////////////////////////////////////////////////////////////////
// CBEditCtrl::DoPropExchange - Persistence support

void CBEditCtrl::DoPropExchange(CPropExchange* pPX)
{

	ExchangeVersion(pPX, MAKELONG(_wVerMinor, _wVerMajor));
	COleControl::DoPropExchange(pPX);

	//PX_Color(pPX, _T("BackColor"), BackColor, oc);
	PX_String(pPX, _T("Content"), m_content, _T(""));
    PX_Font(pPX, _T("ContentFont"), m_contentFont, &_fontContent);
	PX_Bool(pPX, _T("MultiLine"), m_multiLine, FALSE );
}


/////////////////////////////////////////////////////////////////////////////
// CBEditCtrl::OnResetState - Reset control to default state

void CBEditCtrl::OnResetState()
{
	COleControl::OnResetState();  // Resets defaults found in DoPropExchange

	// TODO: Reset any other control state here.
}


/////////////////////////////////////////////////////////////////////////////
// CBEditCtrl::AboutBox - Display an "About" box to the user

void CBEditCtrl::AboutBox()
{
	CDialog dlgAbout(IDD_ABOUTBOX_BEDIT);
	dlgAbout.DoModal();
}

/////////////////////////////////////////////////////////////////////////////
// CBEditCtrl message handlers

BSTR CBEditCtrl::GetContent() 
{
	CString	str1;
	CString	str2;
	int		i;

	//UnsortedToSorted();
	m_content = m_display;
	for( i = 0 ; i < m_content.GetLength() ; i++ )
	{
		if( m_content[i] == RETURN )
		{
			m_content.SetAt(i, (TCHAR)13);
			str1 = m_content.Left( i + 1 );
			str1 += (TCHAR)10;
			str2 = m_content.Right( m_content.GetLength() - i - 1);
			m_content = str1 + str2;
		}
	}
	return m_content.AllocSysString();
}

void CBEditCtrl::SetContent(LPCTSTR lpszNewValue) 
{
	CString	str1;
	CString	str2;
	int		i;


	m_content.Empty();
	m_content = lpszNewValue;
	//SortedToUnsorted();
	m_display = m_content;
	for( i = 0 ; i < m_display.GetLength() - 1 ; i++ )
	{
		if( m_display[i] == (TCHAR)13 && m_display[i+1] == (TCHAR)10)
		{
			m_display.SetAt(i, RETURN);
			str1 = m_display.Left( i + 1 );
			str2 = m_display.Right( m_display.GetLength() - i - 2);
			m_display = str1 + str2;
		}
	}
	m_adjust = TRUE;
	m_redraw = TRUE;
	SetModifiedFlag();
	InvalidateControl();
}

void CBEditCtrl::OnChar(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
	CString		cs;
	CString		cs1;
	CString		cs2;
	int			len;
	TCHAR		prev;
	TCHAR		pprev;
	int			i;
	int			j;
	BOOL		concated = FALSE;
	BOOL		concatable = FALSE;

	//MessageBox((LPCTSTR)"key pressed", NULL, MB_OK);
	if(keymap[nChar] != 0x0000)
	{
		m_adjust = TRUE;
		if( m_position == 1 )
		{
			prev = m_display[m_position -1];
			if(keymap[nChar] == AA_KAR && prev == A)
			{
				len = m_display.GetLength();
				cs1 = m_display.Left(m_position - 1);
				cs2 = m_display.Right(len - m_position);
				cs1 += AA;
				m_display = cs1 + cs2;
				InvalidateControl();
			}
			else if(prev == CONCAT)
			{
				switch(keymap[nChar])
				{
					case AA_KAR:
						len = m_display.GetLength();
						cs1 = m_display.Left(m_position - 1);
						cs2 = m_display.Right(len - m_position);
						cs1 += AA;
						m_display = cs1 + cs2;
						InvalidateControl();
						break;
					case I_KAR:
						len = m_display.GetLength();
						cs1 = m_display.Left(m_position - 1);
						cs2 = m_display.Right(len - m_position);
						cs1 += I;
						m_display = cs1 + cs2;
						InvalidateControl();
						break;
					case II_KAR:
						len = m_display.GetLength();
						cs1 = m_display.Left(m_position - 1);
						cs2 = m_display.Right(len - m_position);
						cs1 += II;
						m_display = cs1 + cs2;
						InvalidateControl();
						break;
					case U_KAR:
						len = m_display.GetLength();
						cs1 = m_display.Left(m_position - 1);
						cs2 = m_display.Right(len - m_position);
						cs1 += U;
						m_display = cs1 + cs2;
						InvalidateControl();
						break;
					case UU_KAR:
						len = m_display.GetLength();
						cs1 = m_display.Left(m_position - 1);
						cs2 = m_display.Right(len - m_position);
						cs1 += UU;
						m_display = cs1 + cs2;
						InvalidateControl();
						break;
					case RI_KAR:
						len = m_display.GetLength();
						cs1 = m_display.Left(m_position - 1);
						cs2 = m_display.Right(len - m_position);
						cs1 += RI;
						m_display = cs1 + cs2;
						InvalidateControl();
						break;
					case E_KAR:
						len = m_display.GetLength();
						cs1 = m_display.Left(m_position - 1);
						cs2 = m_display.Right(len - m_position);
						cs1 += E;
						m_display = cs1 + cs2;
						InvalidateControl();
						break;
					case OI_KAR:
						len = m_display.GetLength();
						cs1 = m_display.Left(m_position - 1);
						cs2 = m_display.Right(len - m_position);
						cs1 += OI;
						m_display = cs1 + cs2;
						InvalidateControl();
						break;
					case OU_KAR:
						len = m_display.GetLength();
						cs1 = m_display.Left(m_position - 1);
						cs2 = m_display.Right(len - m_position);
						cs1 += OU;
						m_display = cs1 + cs2;
						InvalidateControl();
						break;
				}	
			}
			else
			{
				if(prev == REF)
				{
					prev = m_display[m_position -2];
				}
				switch(keymap[nChar])
				{
					case U_KAR:
						{
							TCHAR		subst;

							subst = DecideOnU(prev);
							len = m_display.GetLength();
							cs1 = m_display.Left(m_position);
							cs2 = m_display.Right(len - m_position);
							cs1 += subst;
							m_display = cs1 + cs2;
							m_position ++;
							InvalidateControl();
						}
						break;
					case UU_KAR:
						{
							TCHAR		subst;

							subst = DecideOnUU(prev);
							len = m_display.GetLength();
							cs1 = m_display.Left(m_position);
							cs2 = m_display.Right(len - m_position);
							cs1 += subst;
							m_display = cs1 + cs2;
							m_position ++;
							InvalidateControl();
						}
						break;
					case RI_KAR:
						{
							TCHAR		subst;

							if( prev == HA )
							{
								len = m_display.GetLength();
								cs1 = m_display.Left(m_position - 1);
								cs2 = m_display.Right(len - m_position);
								cs1 += HA_RI;
								m_display = cs1 + cs2;
							}
							else
							{
								subst = DecideOnRI(prev);
								len = m_display.GetLength();
								cs1 = m_display.Left(m_position);
								cs2 = m_display.Right(len - m_position);
								cs1 += subst;
								m_display = cs1 + cs2;
								m_position ++;
							}
							InvalidateControl();
						}
						break;
					default:
						len = m_display.GetLength();
						cs1 = m_display.Left(m_position);
						cs2 = m_display.Right(len - m_position);
						cs1 += keymap[nChar];
						m_display = cs1 + cs2;
						m_position ++;
						InvalidateControl();
						break;
				}
			}
		}
		else if( m_position > 1 )
		{
			prev = m_display[m_position -1];
			if(keymap[nChar] == AA_KAR && prev == A)
			{
				len = m_display.GetLength();
				cs1 = m_display.Left(m_position - 1);
				cs2 = m_display.Right(len - m_position);
				cs1 += AA;
				m_display = cs1 + cs2;
				InvalidateControl();
			}
			else if (prev == CONCAT )
			{
				switch(keymap[nChar])
				{
					case AA_KAR:
						len = m_display.GetLength();
						cs1 = m_display.Left(m_position - 1);
						cs2 = m_display.Right(len - m_position);
						cs1 += AA;
						m_display = cs1 + cs2;
						InvalidateControl();
						break;
					case I_KAR:
						len = m_display.GetLength();
						cs1 = m_display.Left(m_position - 1);
						cs2 = m_display.Right(len - m_position);
						cs1 += I;
						m_display = cs1 + cs2;
						InvalidateControl();
						break;
					case II_KAR:
						len = m_display.GetLength();
						cs1 = m_display.Left(m_position - 1);
						cs2 = m_display.Right(len - m_position);
						cs1 += II;
						m_display = cs1 + cs2;
						InvalidateControl();
						break;
					case U_KAR:
						len = m_display.GetLength();
						cs1 = m_display.Left(m_position - 1);
						cs2 = m_display.Right(len - m_position);
						cs1 += U;
						m_display = cs1 + cs2;
						InvalidateControl();
						break;
					case UU_KAR:
						len = m_display.GetLength();
						cs1 = m_display.Left(m_position - 1);
						cs2 = m_display.Right(len - m_position);
						cs1 += UU;
						m_display = cs1 + cs2;
						InvalidateControl();
						break;
					case RI_KAR:
						len = m_display.GetLength();
						cs1 = m_display.Left(m_position - 1);
						cs2 = m_display.Right(len - m_position);
						cs1 += RI;
						m_display = cs1 + cs2;
						InvalidateControl();
						break;
					case E_KAR:
						len = m_display.GetLength();
						cs1 = m_display.Left(m_position - 1);
						cs2 = m_display.Right(len - m_position);
						cs1 += E;
						m_display = cs1 + cs2;
						InvalidateControl();
						break;
					case OI_KAR:
						len = m_display.GetLength();
						cs1 = m_display.Left(m_position - 1);
						cs2 = m_display.Right(len - m_position);
						cs1 += OI;
						m_display = cs1 + cs2;
						InvalidateControl();
						break;
					case OU_KAR:
						len = m_display.GetLength();
						cs1 = m_display.Left(m_position - 1);
						cs2 = m_display.Right(len - m_position);
						cs1 += OU;
						m_display = cs1 + cs2;
						InvalidateControl();
						break;
					default:
						pprev = m_display[m_position - 2];
						for( i = 0 ; i < CCAT_GROUPS ;i++)
						{
							if (ranges[i].ch == pprev)
							{
								concatable = TRUE;
								break;
							}
						}
						if (concatable)
						{
							for( j = ranges[i].start; j <= ranges[i].finish ; j++)
							{
								if(concat[j].second == keymap[nChar])
								{
									concated = TRUE;
									break;
								}
							}
							if(concated)
							{
								int		k;
								
								len = m_display.GetLength();
								cs1 = m_display.Left(m_position - 2);
								cs2 = m_display.Right(len - m_position);
								for( k = 0 ; k < concat[j].num ; k++)
								{
									cs1 += concat[j].result[k];
								}
								m_display = cs1 + cs2;
								if( k == 1 )
								{
									m_position --;
								}
								InvalidateControl();
							}
							else
							{
								len = m_display.GetLength();
								cs1 = m_display.Left(m_position);
								cs2 = m_display.Right(len - m_position);
								cs1 += keymap[nChar];
								m_display = cs1 + cs2;
								m_position ++;
								InvalidateControl();
							}
						}
						else
						{
							len = m_display.GetLength();
							cs1 = m_display.Left(m_position);
							cs2 = m_display.Right(len - m_position);
							cs1 += keymap[nChar];
							m_display = cs1 + cs2;
							m_position ++;
							InvalidateControl();
						}
						break;	//end of default
				}
			}
			else
			{
				if(prev == REF)
				{
					prev = m_display[m_position -2];
				}
				switch(keymap[nChar])
				{
					case U_KAR:
						{
							TCHAR		subst;

							subst = DecideOnU(prev);
							len = m_display.GetLength();
							cs1 = m_display.Left(m_position);
							cs2 = m_display.Right(len - m_position);
							cs1 += subst;
							m_display = cs1 + cs2;
							m_position ++;
							InvalidateControl();
						}
						break;
					case UU_KAR:
						{
							TCHAR		subst;

							subst = DecideOnUU(prev);
							len = m_display.GetLength();
							cs1 = m_display.Left(m_position);
							cs2 = m_display.Right(len - m_position);
							cs1 += subst;
							m_display = cs1 + cs2;
							m_position ++;
							InvalidateControl();
						}
						break;
					case RI_KAR:
						{
							TCHAR		subst;

							if( prev == HA )
							{
								len = m_display.GetLength();
								cs1 = m_display.Left(m_position - 1);
								cs2 = m_display.Right(len - m_position);
								cs1 += HA_RI;
								m_display = cs1 + cs2;
								InvalidateControl();
							}
							else
							{
								subst = DecideOnRI(prev);
								len = m_display.GetLength();
								cs1 = m_display.Left(m_position);
								cs2 = m_display.Right(len - m_position);
								cs1 += subst;
								m_display = cs1 + cs2;
								m_position ++;
								InvalidateControl();
							}
						}
						break;
					default:
						len = m_display.GetLength();
						cs1 = m_display.Left(m_position);
						cs2 = m_display.Right(len - m_position);
						cs1 += keymap[nChar];
						m_display = cs1 + cs2;
						m_position ++;
						InvalidateControl();
						break;
				}
			}
		}
		else
		{
			len = m_display.GetLength();
			cs1 = m_display.Left(m_position);
			cs2 = m_display.Right(len - m_position);
			cs1 += keymap[nChar];
			m_display = cs1 + cs2;
			m_position ++;
			InvalidateControl();
		}
	}

	//COleControl::OnChar(nChar, nRepCnt, nFlags);
}

void CBEditCtrl::OnFontChanged() 
{
	COleControl::OnFontChanged();

}

void CBEditCtrl::OnSetFocus(CWnd* pOldWnd) 
{
	CFont*		pOldFont;		
	CDC*		pdc = GetDC();
	TEXTMETRIC	tm;
	int			pcx;
	int			pcy;
	
	COleControl::OnSetFocus(pOldWnd);

	GetControlSize(&pcx, &pcy);
	pOldFont = SelectFontObject(pdc, m_contentFont);
	pdc->SetMapMode( MM_TEXT );
	pdc->GetTextMetrics(&tm);
	m_charh = tm.tmHeight;
	
	m_linelength = pcx - m_leftbear - m_rightbear;
	m_linevisible = ( pcy - m_topbear * 2 ) / m_charh;

	if( m_multiLine )
	{
		ShowScrollBar(SB_VERT, TRUE );
		//EnableScrollBar( SB_VERT, ESB_ENABLE_BOTH );
		m_firstline = 0;
		m_lastline = m_firstline + m_linevisible - 1;
		if( m_lastline >= m_maxline)
		{
			m_lastline = m_maxline - 1;
		}
		m_curline = m_firstline;
	
		SCROLLINFO  sc;

		GetScrollInfo(SB_VERT, &sc, SIF_ALL);
		sc.nPage = m_linevisible * FACTOR;
		sc.nMin = 0;
		sc.nMax = m_maxline * FACTOR;
		if(sc.nMax < (int)sc.nPage )
		{
			sc.nMax = sc.nPage;
		}
		SetScrollInfo(SB_VERT, &sc, FALSE);
		//resize scrollbar
	}
	else
	{
		ShowScrollBar(SB_VERT, FALSE );
		//EnableScrollBar( SB_VERT, ESB_DISABLE_BOTH );
	}


	CreateSolidCaret(1, m_charh);	
	m_caret.x = m_leftbear;
	m_caret.y = m_topbear;

	pdc->SelectObject(pOldFont);
	ReleaseDC(pdc);
	
	SetCaretPos(m_caret);
	if( CWnd::m_hWnd)
	{
		ShowCaret();
		m_caretshown = TRUE;
	}
	m_adjust = TRUE;
	m_redraw = TRUE;
	Refresh();
}

void CBEditCtrl::OnKillFocus(CWnd* pNewWnd) 
{
	COleControl::OnKillFocus(pNewWnd);

	HideCaret();
	m_caretshown = FALSE;
	DestroyCaret();
}

BOOL CBEditCtrl::OnSetObjectRects(LPCRECT lpRectPos, LPCRECT lpRectClip) 
{
	
	return COleControl::OnSetObjectRects(lpRectPos, lpRectClip);
}

BOOL CBEditCtrl::AdjustCaret(CDC* pdc, const CRect& rcBounds)
{
	CFont*		pOldFont;
	CString		str1;
	CString		str2;
	CSize		cs;
	int			drawlen;
	int			runlen;
	int			i;
	int			savedfirst;
	int			savedlast;
	BOOL		redrawn;

	pOldFont = SelectFontObject(pdc, m_contentFont);
	drawlen = rcBounds.right - rcBounds.left - m_leftbear - m_rightbear;
	str1 = m_display.Left(m_position);
	if( m_multiLine )
	{
		runlen = 0;

		savedfirst = m_firstline;
		savedlast = m_lastline;
		for( i = 0 ; i < m_dbuf.GetSize() ; i ++ )
		{
			runlen += m_dbuf[i].GetLength() ;
			if( runlen > m_position )
			{
				break;
			}
		}
		if( i == m_dbuf.GetSize())
		{
			i--; 
		}
		runlen -= m_dbuf[i].GetLength();
		m_curline = i;
		if( m_firstline > m_curline )
		{
			m_firstline = m_curline;
			m_lastline = m_firstline + m_linevisible - 1;
			if( m_lastline >= m_maxline )
			{
				m_lastline = m_maxline - 1;
			}
			i = 0;
		}
		else if( m_lastline < m_curline )
		{
			//MessageBox("Scroll down", NULL, MB_OK);
			m_lastline = m_curline;
			m_firstline = m_lastline - m_linevisible + 1;
			i = m_linevisible - 1;
		}

		m_caret.y = m_topbear + ( (m_curline - m_firstline) * m_charh );

		str2 = m_dbuf[m_curline].Left( m_position - runlen);
		cs = pdc->GetOutputTextExtent( str2);
		//pdc->LPtoDP(&cs);
		m_caret.x = m_leftbear + cs.cx;
		if( (savedfirst == m_firstline) && (savedlast == m_lastline) )
		{
			m_redraw = FALSE;
		}
		else
		{
			m_redraw = TRUE;
		}
		AdjustBar(pdc, rcBounds);
	}
	else
	{
		while (1)
		{
			
			str2 = str1.Right( m_position - m_drawpos);
			cs = pdc->GetOutputTextExtent( str2);
			//pdc->LPtoDP(&cs);
			if(	cs.cx <= drawlen && cs.cx >= 0)
			{
				m_caret.x = m_leftbear + cs.cx;
				break;
			}
			else if( cs.cx > drawlen )
			{
				m_drawpos ++;
				m_redraw = TRUE;
			}
			else
			{
			}
		}
	}
	
	pdc->SelectObject(pOldFont);
	
	if( m_adjust )
	{
		DrawDisplay( pdc, rcBounds );
		redrawn = FALSE;
	}
	else
	{
		m_adjust = TRUE;
		redrawn = FALSE;
	}
	if( m_redraw)
	{
		DrawDisplay( pdc, rcBounds );
		redrawn = TRUE;
	}
	else
	{
		m_redraw = TRUE;
		redrawn = FALSE;
	}
	SetCaretPos(m_caret);
	if( !m_caretshown)
	{
		if( CWnd::m_hWnd)
		{
			ShowCaret();
			m_caretshown = TRUE;
		}
	}
	return redrawn;
}

void CBEditCtrl::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
	// TODO: Add your message handler code here and/or call default
	switch(nChar)
	{
		case VK_RETURN:
		{
			m_adjust = TRUE;
			if( m_multiLine )
			{
				int			len;
				CString		cs1;
				CString		cs2;
				
				len = m_display.GetLength();
				cs1 = m_display.Left(m_position);
				cs2 = m_display.Right(len - m_position);
				cs1 += RETURN;
				m_display = cs1 + cs2;
				m_position ++;
				InvalidateControl();
			}
			break;
		}
		case VK_UP:
		{
			m_adjust = FALSE;
			if( m_multiLine )
			{
				if(m_curline > 0)
				{
					CFont*	pOldFont;
					CDC*	pdc = GetDC();
					CSize	cs;
					CString	str;
					int		x;
					int		start;
					int		end;
					int		i;
					CRect	rc;
			
					GetClientRect(&rc);
					x = m_caret.x;
					if( m_curline == m_firstline )
					{
						m_redraw = TRUE;
					}
					else
					{
						m_redraw = FALSE;
					}
					m_curline --;
					end = start = 0;
					pOldFont = SelectFontObject(pdc, m_contentFont);
					for( i = 0 ; i <= m_curline ; i++ )
					{
						end += m_dbuf[i].GetLength();
					}
					start = end - m_dbuf[i-1].GetLength();
					str = m_dbuf[i-1];
					i = 0;
					while( TRUE )
					{
						if( i >= (end - start))
						{
							break;
						}
						cs = pdc->GetOutputTextExtent( LPCTSTR(str), i);
						if(( cs.cx + m_leftbear) >= x )
						{
							break;
						}
						i++;
					}
					m_position = start + i;
					
					pdc->SelectObject(pOldFont);
					if(AdjustCaret( pdc, rc ))
					{
						Refresh();
					}
					ReleaseDC(pdc);
					//InvalidateControl();
				}
			}
			break;
		}
		case VK_DOWN:
		{
			m_adjust = FALSE;
			if( m_multiLine )
			{
				if(m_curline < (m_dbuf.GetSize() - 1))
				{
					CFont*	pOldFont;
					CDC*	pdc = GetDC();
					CSize	cs;
					CString	str;
					int		x;
					int		start;
					int		end;
					int		i;
					CRect	rc;
			
					GetClientRect(&rc);
					x = m_caret.x;
					if( m_curline == m_lastline )
					{
						m_redraw = TRUE;
					}
					else
					{
						m_redraw = FALSE;
					}
					m_curline++;
					end = start = 0;
					pOldFont = SelectFontObject(pdc, m_contentFont);
					for( i = 0 ; i <= m_curline ; i++ )
					{
						end += m_dbuf[i].GetLength();
					}
					start = end - m_dbuf[i-1].GetLength();
					str = m_dbuf[i-1];
					i = 0;
					while( TRUE )
					{
						if( i >= (end - start))
						{
							break;
						}
						cs = pdc->GetOutputTextExtent( LPCTSTR(str), i);
						if(( cs.cx + m_leftbear) >= x )
						{
							break;
						}
						i++;
					}
					m_position = start + i;
					
					pdc->SelectObject(pOldFont);
					if(AdjustCaret( pdc, rc ))
					{
						Refresh();
					}
					ReleaseDC(pdc);
					//InvalidateControl();
				}
			}
			break;
		}
		case VK_LEFT:
		{
			CDC*	pdc = GetDC();
			CRect	rc;
		
			GetClientRect(&rc);			
			m_adjust = FALSE;
			if( m_multiLine )
			{
				if(m_position > 0 )
				{
					m_position--;
					if(AdjustCaret( pdc, rc ))
					{
						Refresh();
					}
					//SetModifiedFlag();
					//InvalidateControl();
				}
			}
			else
			{
				if ( m_position > 0 )
				{
					m_position --;
					if (m_position < m_drawpos)
					{
						m_drawpos = m_position;
						m_redraw = TRUE;
					}
					if(AdjustCaret( pdc, rc ))
					{
						Refresh();
					}
					//SetModifiedFlag();
					//InvalidateControl();
				}
			}
			ReleaseDC(pdc);
			break;
		}
		case VK_RIGHT:
		{
			CDC*	pdc = GetDC();
			CRect	rc;
		
			GetClientRect(&rc);			
			m_adjust = FALSE;
			if( m_multiLine )
			{
				if( m_position < m_display.GetLength())
				{
					m_position ++;
					if(AdjustCaret( pdc, rc ))
					{
						Refresh();
					}
					//SetModifiedFlag();
					//InvalidateControl();
				}
			}
			else
			{
				if( m_position < m_display.GetLength())
				{
					m_position ++;
					if(AdjustCaret( pdc, rc ))
					{
						Refresh();
					}
					//SetModifiedFlag();
					//InvalidateControl();
				}
			}
			ReleaseDC(pdc);
			break;
		}
		case VK_HOME:
		{
			CDC*	pdc = GetDC();
			CRect	rc;
		
			GetClientRect(&rc);			
			m_adjust = FALSE;
			if( m_multiLine )
			{
				if ( m_position > 0 )
				{
					int		runlen;
					int		i;

					runlen = 0;
					for( i = 0 ; i < m_curline ; i++)
					{
						runlen += m_dbuf[i].GetLength();
					}
					if( m_position != runlen )
					{
						m_position = runlen;
					}
					if(AdjustCaret( pdc, rc ))
					{
						Refresh();
					}
					//InvalidateControl();
				}		
			}
			else
			{
				if ( m_position > 0 )
				{
					m_position = 0;
					m_drawpos = 0;
					m_redraw = TRUE;
					//SetModifiedFlag();
					if(AdjustCaret( pdc, rc ))
					{
						Refresh();
					}
					//InvalidateControl();
				}
			}
			ReleaseDC(pdc);
			break;
		}
		case VK_END:
		{
			CDC*	pdc = GetDC();
			CRect	rc;
		
			GetClientRect(&rc);			
			m_adjust = FALSE;
			if( m_multiLine )
			{
				if( m_position < m_display.GetLength())
				{
					int		runlen;
					int		i;

					runlen = 0;
					for( i = 0 ; i <= m_curline ; i++)
					{
						runlen += m_dbuf[i].GetLength();
					}
					if( m_position != runlen )
					{
						m_position = runlen;
					if(AdjustCaret( pdc, rc ))
					{
						Refresh();
					}
						//InvalidateControl();
					}
				}		
			}
			else
			{
				if( m_position < m_display.GetLength())
				{
					m_position = m_display.GetLength();
					//SetModifiedFlag();
					if(AdjustCaret( pdc, rc ))
					{
						Refresh();
					}
					//InvalidateControl();
				}
			}
			ReleaseDC(pdc);
			break;
		}
		case VK_DELETE:
		{
			if( m_position < m_display.GetLength())
			{
				CString		cs1;
				CString		cs2;
				int			len;

				len = m_display.GetLength();
				cs1 = m_display.Left(m_position);
				cs2 = m_display.Right(len - m_position - 1);
				m_display = cs1 + cs2;
				//SetModifiedFlag();
				InvalidateControl();
			}
			break;
		}
		case VK_BACK:
		{
			if( m_position > 0)
			{
				CString		cs1;
				CString		cs2;
				int			len;

				len = m_display.GetLength();
				cs1 = m_display.Left(m_position - 1);
				cs2 = m_display.Right(len - m_position );
				m_display = cs1 + cs2;
				m_position --;
				if (m_position < m_drawpos)
				{
					m_drawpos = m_position;
				}
				//SetModifiedFlag();
				InvalidateControl();
			}
			break;
		}
		default:
			break;
	}

	COleControl::OnKeyDown(nChar, nRepCnt, nFlags);
}

void CBEditCtrl::SortedToUnsorted()
{
	USHORT	n_dst;
	USHORT	src[400];
	USHORT	dst[400];
	USHORT	n_src;
	int		i;

	n_src = (USHORT)m_content.GetLength();
	//src = new USHORT[n_src];
	for( i = 0 ; i < (int)n_src; i++)
	{
		src[i] = (USHORT)m_content[i];
	}
	//dst = new USHORT[n_src * 2];

	n_dst = UniConv( S_2_U, src, dst, n_src );
	
	m_display.Empty();
	for( i = 0 ; i < (int)n_dst; i++)
	{
		m_display += (TCHAR)dst[i];
	}
	//delete dst;
	//delete src;
}

void CBEditCtrl::UnsortedToSorted()
{
	USHORT	n_dst;
	USHORT	src[400];
	USHORT	dst[400];
	USHORT	n_src;
	int		i;

	n_src = (USHORT)m_display.GetLength();
	//src = new USHORT[n_src];
	for( i = 0 ; i < (int)n_src; i++)
	{
		src[i] = (USHORT)m_display[i];
	}
	//dst = new USHORT[n_src * 4];

	n_dst = UniConv( U_2_S, src, dst, n_src);
	
	m_content.Empty();
	for( i = 0 ; i < (int)n_dst; i++)
	{
		m_content += (TCHAR)dst[i];
	}

	//delete dst;
	//delete src;
}

BOOL CBEditCtrl::PreTranslateMessage(MSG* pMsg) 
{
	BOOL bHandleNow = FALSE;

    switch (pMsg->message)
    {
		case WM_KEYDOWN:
		{
			switch (pMsg->wParam)
			{
				case VK_RETURN:
				case VK_HOME:
				case VK_END:
				case VK_BACK:
				case VK_DELETE:
		        case VK_UP:
				case VK_DOWN:
		        case VK_LEFT:
				case VK_RIGHT:
			        bHandleNow = TRUE;
				    break;
			}
			if (bHandleNow)
				OnKeyDown((UINT)pMsg->wParam, (UINT)LOWORD(pMsg 
					->lParam), (UINT)HIWORD(pMsg->lParam));
			break;
		}
		case WM_CHAR:
		{
			bHandleNow = TRUE;
			OnChar((UINT)pMsg->wParam, (UINT)LOWORD(pMsg 
                ->lParam), (UINT)HIWORD(pMsg->lParam));
			break;
		}
	}
    return bHandleNow;
}

LPFONTDISP CBEditCtrl::GetContentFont() 
{
	// TODO: Add your property handler here

	return m_contentFont.GetFontDispatch( );

}

void CBEditCtrl::SetContentFont(LPFONTDISP newValue) 
{
	// TODO: Add your property handler here
	m_contentFont.InitializeFont( &_fontContent, newValue);
    OnFontChanged();    
	SetModifiedFlag();
}

TCHAR CBEditCtrl::DecideOnU(TCHAR ch)
{
	int			i;

	for( i = 0 ; i < UJOIN ; i++ )
	{
		if( u_table[i].pre == ch )
		{
			return u_table[i].post;
			break;
		}
	}
	return U_KAR;
}

TCHAR CBEditCtrl::DecideOnUU(TCHAR ch)
{
	int			i;

	for( i = 0 ; i < UUJOIN ; i++ )
	{
		if( uu_table[i].pre == ch )
		{
			return uu_table[i].post;
			break;
		}
	}
	return UU_KAR;
}

TCHAR CBEditCtrl::DecideOnRI(TCHAR ch)
{
	int			i;

	for( i = 0 ; i < RIJOIN ; i++ )
	{
		if( ri_table[i].pre == ch )
		{
			return ri_table[i].post;
			break;
		}
	}
	return RI_KAR;
}


void CBEditCtrl::OnLButtonDown(UINT nFlags, CPoint point) 
{
	CFont*	pOldFont;
	CDC*	pdc = GetDC();
	CSize	cs;
	CString	str;
	int		i;	
	int		len;
	
	pOldFont = SelectFontObject(pdc, m_contentFont);
	len = m_display.GetLength();
	if(m_multiLine)
	{
		int		limit;
		int		ystart;
		int		yend;
		BOOL	in;

		limit = m_linevisible;
		in = FALSE;
		for( i = 0 ; i < m_linevisible ; i++ )
		{
			
			if( ( m_firstline + i ) >= ( m_maxline) )
			{
				break;
			}
			else
			{
				ystart = m_topbear + ( i * m_charh );
				yend = ystart + m_charh;
				if( (point.y >= ystart) && (point.y <= yend) )
				{
					m_caret.y = ystart;
					m_curline = m_firstline + i;
					in = TRUE;
					break;
				}
			}
		}
		if( in )
		{
			str = m_dbuf[m_curline];
			i = 0;
			len = str.GetLength();
			while( TRUE )
			{
				if( i >= len)
				{
					break;
				}
				cs = pdc->GetOutputTextExtent( LPCTSTR(str), i);
				if(( cs.cx + m_leftbear) >= point.x )
				{
					break;
				}
				i++;
			}
			
			int		j;
			
			m_position = 0;
			for( j = 0 ; j < m_curline ; j ++ )
			{
				m_position += m_dbuf[j].GetLength();
			}
			m_position += i;
			m_caret.x = cs.cx + m_leftbear;
		}
	}
	else
	{
		str = m_display.Right(len - m_drawpos);
		i = 0;
		while( TRUE )
		{
			if( (i + m_drawpos ) >= len)
			{
				break;
			}
			cs = pdc->GetOutputTextExtent( LPCTSTR(str), i);
			if(( cs.cx + m_leftbear) >= point.x )
			{
				break;
			}
			i++;
		}
		m_position = m_drawpos + i;
		m_caret.x = cs.cx + m_leftbear;
	}
	SetCaretPos(m_caret);
	if(!m_caretshown)
	{
		ShowCaret();
		m_caretshown = TRUE;
	}
	pdc->SelectObject(pOldFont);
	ReleaseDC(pdc);

	COleControl::OnLButtonDown(nFlags, point);
}

void CBEditCtrl::OnLButtonDblClk(UINT nFlags, CPoint point) 
{
	CFont*	pOldFont;
	CDC*	pdc = GetDC();
	CSize	cs;
	CString	str;
	int		i;	
	int		len;
	
	pOldFont = SelectFontObject(pdc, m_contentFont);
	len = m_display.GetLength();
	if(m_multiLine)
	{
		int		limit;
		int		ystart;
		int		yend;
		BOOL	in;

		limit = m_linevisible;
		in = FALSE;
		for( i = 0 ; i < m_linevisible ; i++ )
		{
			
			if( ( m_firstline + i ) >= ( m_maxline) )
			{
				break;
			}
			else
			{
				ystart = m_topbear + ( i * m_charh );
				yend = ystart + m_charh;
				if( (point.y >= ystart) && (point.y <= yend) )
				{
					m_caret.y = ystart;
					m_curline = m_firstline + i;
					in = TRUE;
					break;
				}
			}
		}
		if( in )
		{
			str = m_dbuf[m_curline];
			i = 0;
			len = str.GetLength();
			while( TRUE )
			{
				if( i >= len)
				{
					break;
				}
				cs = pdc->GetOutputTextExtent( LPCTSTR(str), i);
				if(( cs.cx + m_leftbear) >= point.x )
				{
					break;
				}
				i++;
			}
			
			int		j;
			
			m_position = 0;
			for( j = 0 ; j < m_curline ; j ++ )
			{
				m_position += m_dbuf[j].GetLength();
			}
			m_position += i;
			m_caret.x = cs.cx + m_leftbear;
		}
	}
	else
	{
		str = m_display.Right(len - m_drawpos);
		i = 0;
		while( TRUE )
		{
			if( (i + m_drawpos ) >= len)
			{
				break;
			}
			cs = pdc->GetOutputTextExtent( LPCTSTR(str), i);
			if(( cs.cx + m_leftbear) >= point.x )
			{
				break;
			}
			i++;
		}
		m_position = m_drawpos + i;
		m_caret.x = cs.cx + m_leftbear;
	}
	SetCaretPos(m_caret);
	if(!m_caretshown)
	{
		ShowCaret();
		m_caretshown = TRUE;
	}
	pdc->SelectObject(pOldFont);
	ReleaseDC(pdc);

	COleControl::OnLButtonDown(nFlags, point);
}

BOOL CBEditCtrl::PreCreateWindow(CREATESTRUCT& cs) 
{
	
	cs.style |= WS_VSCROLL;
	return COleControl::PreCreateWindow(cs);
}

void CBEditCtrl::OnMultiLineChanged() 
{
	m_position = m_drawpos = 0;
	if( m_multiLine )
	{
		//ShowScrollBar(SB_VERT, TRUE );
		//EnableScrollBar( SB_VERT, ESB_ENABLE_BOTH );
		m_firstline = 0;
		m_lastline = m_firstline + m_linevisible - 1;
		if( m_lastline >= m_maxline)
		{
			m_lastline = m_maxline - 1;
		}
	}
	else
	{
		//ShowScrollBar(SB_VERT, FALSE );
		//EnableScrollBar( SB_VERT, ESB_DISABLE_BOTH );
	}
	m_redraw = TRUE;
	m_adjust = TRUE;
	SetModifiedFlag();
	InvalidateControl();
}

void CBEditCtrl::DrawDisplay( CDC* pdc, const CRect& rcBounds )
{
	CFont*			pOldFont;
	CBrush			bkBrush(TranslateColor(GetBackColor()));
	CBrush*			pOldBrush;
	TEXTMETRIC		tm;
	CString			cs;
	CRect			rcNew(rcBounds);
	int				len;
	int				i;

	pOldFont = SelectFontObject(pdc, m_contentFont);
	rcNew.left += m_leftbear;
	rcNew.right -= m_rightbear;

	pOldBrush = pdc->SelectObject(&bkBrush);

	pdc->FillRect(rcBounds, &bkBrush);
	//pdc->Draw3dRect(rcBounds,(COLORREF)0x00000000, (COLORREF)0x00ffffff);

	pdc->GetTextMetrics(&tm);
	m_charh = tm.tmHeight;
	if(m_multiLine)
	{
		for( i = m_firstline ; i <= m_lastline ; i++)
		{
			rcNew.top = rcBounds.top + m_topbear + m_charh * ( i - m_firstline );
			rcNew.bottom = rcBounds.top + m_topbear + m_charh * (i - m_firstline + 1);

			pdc->ExtTextOut( rcNew.left, rcNew.top, ETO_CLIPPED, rcNew, m_dbuf[i], NULL );
		}
	}
	else
	{
		len = m_display.GetLength();
		cs = m_display.Right(len - m_drawpos);
		rcNew.top = rcNew.top + m_topbear;
		rcNew.bottom = rcNew.top + m_topbear + m_charh;

		pdc->ExtTextOut( rcNew.left, rcNew.top, ETO_CLIPPED, rcBounds, cs, NULL );
	}
	m_redraw = FALSE;
	pdc->SelectObject(pOldBrush);
	pdc->SelectObject(pOldFont);
}

BOOL CBEditCtrl::ScrollDisplay( CDC* pdc, const CRect& rcBounds )
{
	CFont*			pOldFont;
	CBrush			bkBrush(TranslateColor(GetBackColor()));
	CBrush*			pOldBrush;
	TEXTMETRIC		tm;
	CString			cs;
	CRect			rcNew(rcBounds);
	BOOL			readjust;
	int				i;

	if( (m_curline < m_firstline) || (m_curline > m_lastline ) )
	{
		if( m_caretshown )
		{
			HideCaret();
			m_caretshown = FALSE;
			readjust = FALSE;
		}
	}
	else
	{
		m_caret.y = rcBounds.top + m_topbear + ( m_curline - m_firstline) * m_charh;
		SetCaretPos(m_caret);
		if( !m_caretshown )
		{
			ShowCaret();
			m_caretshown = TRUE;
			readjust = TRUE;
		}
	}

	pOldFont = SelectFontObject(pdc, m_contentFont);
	rcNew.left += m_leftbear;
	rcNew.right -= m_rightbear;

	pOldBrush = pdc->SelectObject(&bkBrush);

	pdc->FillRect(rcBounds, &bkBrush);
	pdc->Draw3dRect(rcBounds,(COLORREF)0x00000000, (COLORREF)0x00ffffff);

	pdc->GetTextMetrics(&tm);

	if(m_multiLine)
	{
		for( i = m_firstline ; i <= m_lastline ; i++)
		{
			rcNew.top = rcBounds.top + m_topbear + m_charh * ( i - m_firstline );
			rcNew.bottom = rcBounds.top + m_topbear + m_charh * (i - m_firstline + 1);

			pdc->ExtTextOut( rcNew.left, rcNew.top, ETO_CLIPPED, rcNew, m_dbuf[i], NULL );
		}
		AdjustBar(pdc, rcBounds);
	}
	m_redraw = FALSE;

	m_adjust = TRUE;
	m_redraw = TRUE;

	pdc->SelectObject(pOldBrush);
	pdc->SelectObject(pOldFont);
	return readjust;
}

void CBEditCtrl::OnSize(UINT nType, int cx, int cy) 
{
	COleControl::OnSize(nType, cx, cy);
	
	m_linelength = cx - m_leftbear - m_rightbear;
	if( m_multiLine )
	{
		m_linevisible = ( cy - m_topbear * 2 ) / m_charh;
		m_lastline = m_firstline + m_linevisible - 1;
		if( m_lastline >= m_maxline)
		{
			m_lastline = m_maxline - 1;
		}

		SCROLLINFO  sc;

		GetScrollInfo(SB_VERT, &sc, SIF_ALL);
		sc.nPage = m_linevisible * FACTOR;
		sc.nMin = 0;
		sc.nMax = m_maxline * FACTOR;
		if(sc.nMax < (int)sc.nPage )
		{
			sc.nMax = sc.nPage;
		}
		SetScrollInfo(SB_VERT, &sc, FALSE);
	}
	else
	{
		m_linevisible = 1;
		m_firstline = m_lastline = 0;
	}
	m_redraw = TRUE;
	m_adjust = FALSE;
	InvalidateControl();
}

void CBEditCtrl::AdjustBuffer(CDC* pdc, const CRect& rc)
{
	CFont*		pOldFont;
	CSize		cs;
	CString		str1;
	CString		str2;
	BOOL		linecomplete;
	BOOL		displaycomplete;
	int			linecount;
	int			drawlen;
	int			len;
	int			start;
	int			end;
	int			savedmax;

	savedmax = m_maxline;
	
	pOldFont = SelectFontObject(pdc, m_contentFont);
	drawlen = (rc.right - rc.left - m_leftbear - m_rightbear);
	len = m_display.GetLength();
	linecount = 0;
	
	if( m_multiLine )
	{
		m_dbuf.RemoveAll();
		if( m_display.IsEmpty() )
		{
			m_dbuf.Add(_T(""));
			linecount = 1;
		}
		else
		{
			start = 0;
			end = 0;
			displaycomplete = FALSE;
			while(!displaycomplete)
			{
				linecomplete = FALSE;
				str1.Empty();
				str1 = m_display.Right( len - start );
				end = start;
				if( end == len )
				{
					linecomplete = TRUE;
					displaycomplete = TRUE;
				}
				while(!linecomplete && !displaycomplete)
				{
					cs = pdc->GetOutputTextExtent( LPCTSTR(str1), end - start);
					if( cs.cx >= drawlen )
					{
						//line is complete
						end --;
						linecomplete = TRUE;
						
					}
					else
					{
						end++;
						if( end >= len )
						{
							linecomplete = TRUE;
							displaycomplete = TRUE;
						}
						else if( m_display[end] == RETURN )
						{
							linecomplete = TRUE;
						}
					}
				}
				if(linecomplete)
				{
					if(!displaycomplete)
					{
						int		i;
						
						for( i = end ; i >= start ; i-- )
						{
							if( (m_display[i] == SPACE) || (m_display[i] == RETURN))
							{
								break;
							}
						}
						if( i >= start )
						{
							end = i + 1;
						}
					}
					str2 = str1.Left( end - start);
					m_dbuf.Add(LPCTSTR(str2));
					linecount++;
					start = end;
					//MessageBox("Line is Complete", NULL, MB_OK);
				}
			}
		}
	}
	else
	{
		m_dbuf.Add(LPCTSTR(m_display));
		linecount = 1;
	}
	m_maxline = linecount;
	if( m_maxline != savedmax )
	{
		SCROLLINFO  sc;

		GetScrollInfo(SB_VERT, &sc, SIF_ALL);
		sc.nPage = m_linevisible * FACTOR;
		sc.nMin = 0;
		sc.nMax = m_maxline * FACTOR;
		if(sc.nMax < (int)sc.nPage )
		{
			sc.nMax = sc.nPage;
		}
		SetScrollInfo(SB_VERT, &sc, FALSE);
		//resize scrollbar
	}
	m_lastline = m_firstline + m_linevisible - 1;
	if( m_lastline >= m_maxline )
	{
		m_lastline = m_maxline - 1;
	}
	pdc->SelectObject(pOldFont);
	FireContentChange();
}

void CBEditCtrl::OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar) 
{
	CDC*	pdc = GetDC();
	CRect	rc;

	GetClientRect( &rc );
	switch(nSBCode)
	{

		case	SB_BOTTOM   :
				//MessageBox("Scroll to bottom.", NULL, MB_OK);
				break;
		//case 	SB_ENDSCROLL   :
		//		MessageBox("End scroll.", NULL, MB_OK);
		//		break;
		case 	SB_LINEDOWN   :
				m_adjust = TRUE;
				m_redraw = TRUE;
				if( m_lastline < (m_dbuf.GetSize() - 1 ))
				{
					//m_curline ++;
					m_firstline ++;
					m_lastline ++;
					ScrollDisplay(pdc, rc);
					//Refresh();
					//AdjustCaret(pdc, rc);
				}
				//MessageBox("Scroll one line down.", NULL, MB_OK);
				break;
		case 	SB_LINEUP   :
				m_adjust = TRUE;
				m_redraw = TRUE;
				if( m_firstline > 0 )
				{
					//m_curline --;
					m_firstline --;
					m_lastline --;
					ScrollDisplay(pdc, rc);
					//Refresh();
					//AdjustCaret(pdc, rc); 
				}
				//MessageBox("Scroll one line up.", NULL, MB_OK);
				break;
		case 	SB_PAGEDOWN  : 
				m_adjust = TRUE;
				m_redraw = TRUE;
				if( m_lastline < (m_dbuf.GetSize() - 1 ))
				{
					//m_curline --;
					m_firstline += (m_linevisible - 1);
					m_lastline += (m_linevisible -1);
					while( m_lastline >= m_dbuf.GetSize() )
					{
						m_lastline--;
						m_firstline--;
					}
					ScrollDisplay(pdc, rc);
				}
				break;
		case 	SB_PAGEUP   :
				m_adjust = TRUE;
				m_redraw = TRUE;
				if( m_firstline > 0 )
				{
					//m_curline --;
					m_firstline -= (m_linevisible - 1);
					m_lastline -= (m_linevisible -1);
					while( m_firstline < 0 )
					{
						m_lastline++;
						m_firstline++;
					}
					ScrollDisplay(pdc, rc);
				}
				break;
		//case 	SB_THUMBTRACK   :
		//		MessageBox("Drag scroll box to specified position. The current position is provided in nPos.", NULL, MB_OK);
		//		break;
		case 	SB_TOP   :
				//MessageBox("Scroll to top.", NULL, MB_OK);
				break;
		default:
				break;
	}
	
	ReleaseDC( pdc );
	
	COleControl::OnVScroll(nSBCode, nPos, pScrollBar);
}

void CBEditCtrl::AdjustBar(CDC* pdc, const CRect& rc)
{
	int			Min;
	int			Max;
	int			position;
	float		centerline;

	Max = GetScrollLimit( SB_VERT );
	Min = 0;
	if( m_firstline == 0 )
	{
		position = Min;
	}
	else if( m_lastline == ( m_maxline - 1 ))
	{
		position = Max;
	}
	else
	{
		centerline = (float)( (m_firstline + m_lastline ) / 2 );
		position = (int)(( (Max - Min ) * centerline ) / (float)m_maxline );
	}
	SetScrollPos( SB_VERT, position, TRUE );
}
