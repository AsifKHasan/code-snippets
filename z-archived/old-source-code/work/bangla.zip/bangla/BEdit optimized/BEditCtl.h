// BEditCtl.h : Declaration of the CBEditCtrl OLE control class.

/////////////////////////////////////////////////////////////////////////////
// CBEditCtrl : See BEditCtl.cpp for implementation.
#include "BDef.h"

static const FONTDESC _fontContent =
  { sizeof(FONTDESC), OLESTR("CSE Standard"), FONTSIZE( 16 ), FW_NORMAL, 
     ANSI_CHARSET, FALSE, FALSE, FALSE };

class CBEditCtrl : public COleControl
{
	DECLARE_DYNCREATE(CBEditCtrl)

// Constructor
public:
	CBEditCtrl();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CBEditCtrl)
	public:
	virtual void OnDraw(CDC* pdc, const CRect& rcBounds, const CRect& rcInvalid);
	virtual void DoPropExchange(CPropExchange* pPX);
	virtual void OnResetState();
	virtual void OnFontChanged();
	virtual BOOL OnSetObjectRects(LPCRECT lpRectPos, LPCRECT lpRectClip);
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	protected:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
protected:
	~CBEditCtrl();
	void			AdjustBuffer(CDC*, const CRect&);
	BOOL			AdjustCaret(CDC*, const CRect&);
	void			DrawDisplay(CDC*, const CRect&);
	BOOL			ScrollDisplay(CDC*, const CRect&);
	void			AdjustBar(CDC* pdc, const CRect& rc);
	void			UnsortedToSorted();
	void			SortedToUnsorted();
	TCHAR			DecideOnU(TCHAR ch);
	TCHAR			DecideOnUU(TCHAR ch);
	TCHAR			DecideOnRI(TCHAR ch);
	CStringArray	m_dbuf;
	CFontHolder		m_contentFont;
	CString			m_content;					// Full content in sorted Unicode
	CString			m_display;					// Full content to be displayed in unsorted Unicode	
	CPoint			m_caret;					// Caret x,y position
	int				m_position;					// index of current position in m_content
	int				m_drawpos;
	int				m_topbear;
	int				m_leftbear;
	int				m_rightbear;
	int				m_linelength;
	int				m_linevisible;
	int				m_curline;
	int				m_firstline;
	int				m_lastline;
	int				m_maxline;
	int				m_charw;
	int				m_charh;
	BOOL			m_redraw;
	BOOL			m_adjust;
	int				m_shown;
	BOOL			m_caretshown;

	DECLARE_OLECREATE_EX(CBEditCtrl)    // Class factory and guid
	DECLARE_OLETYPELIB(CBEditCtrl)      // GetTypeInfo
	DECLARE_PROPPAGEIDS(CBEditCtrl)     // Property page IDs
	DECLARE_OLECTLTYPE(CBEditCtrl)		// Type name and misc status

// Message maps
	//{{AFX_MSG(CBEditCtrl)
	afx_msg void OnChar(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnSetFocus(CWnd* pOldWnd);
	afx_msg void OnKillFocus(CWnd* pNewWnd);
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

// Dispatch maps
	//{{AFX_DISPATCH(CBEditCtrl)
	BOOL m_multiLine;
	afx_msg void OnMultiLineChanged();
	afx_msg BSTR GetContent();
	afx_msg void SetContent(LPCTSTR lpszNewValue);
	afx_msg LPFONTDISP GetContentFont();
	afx_msg void SetContentFont(LPFONTDISP newValue);
	//}}AFX_DISPATCH
	DECLARE_DISPATCH_MAP()

	afx_msg void AboutBox();

// Event maps
	//{{AFX_EVENT(CBEditCtrl)
	void FireContentChange()
		{FireEvent(eventidContentChange,EVENT_PARAM(VTS_NONE));}
	//}}AFX_EVENT
	DECLARE_EVENT_MAP()

// Dispatch and event IDs
public:
	enum {
	//{{AFX_DISP_ID(CBEditCtrl)
	dispidContent = 2L,
	dispidContentFont = 3L,
	dispidMultiLine = 1L,
	eventidContentChange = 1L,
	//}}AFX_DISP_ID
	};
};
