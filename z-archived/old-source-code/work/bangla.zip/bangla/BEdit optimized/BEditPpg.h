// BEditPpg.h : Declaration of the CBEditPropPage property page class.

////////////////////////////////////////////////////////////////////////////
// CBEditPropPage : See BEditPpg.cpp.cpp for implementation.

class CBEditPropPage : public COlePropertyPage
{
	DECLARE_DYNCREATE(CBEditPropPage)
	DECLARE_OLECREATE_EX(CBEditPropPage)

// Constructor
public:
	CBEditPropPage();

// Dialog Data
	//{{AFX_DATA(CBEditPropPage)
	enum { IDD = IDD_PROPPAGE_BEDIT };
	BOOL	m_multiLine;
	//}}AFX_DATA

// Implementation
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Message maps
protected:
	//{{AFX_MSG(CBEditPropPage)
		// NOTE - ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};
