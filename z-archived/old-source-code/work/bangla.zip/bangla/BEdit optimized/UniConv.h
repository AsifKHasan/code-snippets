/*
		UniConv.h
*/


#define	U_2_S	0
#define	S_2_U	1

typedef	USHORT	(*UniProc)( USHORT*, USHORT*, USHORT ) ;

USHORT	UniConv( int, USHORT*, USHORT*, USHORT ) ;


/*************************************************************************\
 * USHORT	UniConv( int dir, USHORT *src , USHORT *dst, USHORT srclen ) *
 *-----------------------------------------------------------------------*
 * Converts UniCode Character Strings - unsorted to sorted and vice versa *
 *-----------------------------------------------------------------------*
 * dir		: Direction of Conversion									 *
 *				U_2_S Unsorted to Sorted								 *
 *				S_2_U Sorted to Unsorted								 *
 * src		: Source UniCode Charater String							 *
 * dst		: Destination UniCode Charater String						 *
 * srclen	: No of Source UniCode Charaters							 *
 *-----------------------------------------------------------------------*
 * Returns	: No of Destination UniCode Charaters						 *
\*************************************************************************/

USHORT	UniConv( int dir, USHORT *src, USHORT *dst, USHORT srclen )
{
	BOOL		fSuccess ;
	HINSTANCE	hInstDll ;
	UniProc		ProcAdd  ;
	USHORT		dstlen   ;

	fSuccess = FALSE ;
	if( dir == U_2_S )
	{
		hInstDll = LoadLibrary( _T("U2SDll.dll") ) ; 
			
		if ( hInstDll != NULL ) 
		{ 
			ProcAdd = (UniProc) GetProcAddress( (HMODULE) hInstDll, "uniU2S" ) ; 
			if ( ProcAdd != NULL ) 
			{
				dstlen = (*ProcAdd)( src, dst, srclen ) ;
				
				fSuccess = TRUE ; 
				FreeLibrary( hInstDll) ;
			}
		} 
	}
	else
	{
		hInstDll = LoadLibrary( _T("S2UDll.dll") ) ; 
			
		if ( hInstDll != NULL ) 
		{ 
			ProcAdd = (UniProc) GetProcAddress( (HMODULE) hInstDll, "uniS2U" ) ; 
			if ( ProcAdd != NULL ) 
			{
				dstlen = (*ProcAdd)( src, dst, srclen ) ;
				
				fSuccess = TRUE ; 
				FreeLibrary( hInstDll) ;
			}
		} 

	}

	if( !fSuccess )
	{
		MessageBox( NULL, _T("Error Loading Dll"), _T("Error!"), MB_OK ) ;
		FreeLibrary( hInstDll) ; 

		exit( -1 ) ;
	}	
	
	return( dstlen ) ;
}
