// BEditCtl.h : Declaration of the CBEditCtrl OLE control class.

/////////////////////////////////////////////////////////////////////////////
// CBEditCtrl : See BEditCtl.cpp for implementation.

#define	CCAT_GROUPS		52
#define	CCAT_TOTAL		182

#define A               (TCHAR)0x0985
#define AA              (TCHAR)0x0986  
#define I               (TCHAR)0x0987
#define II              (TCHAR)0x0988
#define U               (TCHAR)0x0989
#define UU              (TCHAR)0x098a
#define RI              (TCHAR)0x098b
#define LI              (TCHAR)0x098c
#define E               (TCHAR)0x098f
#define OI              (TCHAR)0x0990
#define O               (TCHAR)0x0993
#define OU              (TCHAR)0x0994

#define KA              (TCHAR)0x0995
#define KHA             (TCHAR)0x0996
#define GA              (TCHAR)0x0997
#define GHA             (TCHAR)0x0998
#define NGA             (TCHAR)0x0999
#define CHA             (TCHAR)0x099a
#define CHHA            (TCHAR)0x099b
#define JA              (TCHAR)0x099c
#define JHA             (TCHAR)0x099d
#define NYA             (TCHAR)0x099e
#define TTA             (TCHAR)0x099f
#define TTHA            (TCHAR)0x09a0
#define DDA             (TCHAR)0x09a1
#define DDHA            (TCHAR)0x09a2
#define NNA             (TCHAR)0x09a3
#define TA              (TCHAR)0x09a4
#define THA             (TCHAR)0x09a5
#define DA              (TCHAR)0x09a6
#define DHA             (TCHAR)0x09a7
#define NA              (TCHAR)0x09a8
#define PA              (TCHAR)0x09aa
#define PHA             (TCHAR)0x09ab
#define BA              (TCHAR)0x09ac
#define BHA             (TCHAR)0x09ad
#define MA              (TCHAR)0x09ae

#define YA              (TCHAR)0x09af
#define RA              (TCHAR)0x09b0
#define LA              (TCHAR)0x09b2
#define SHA             (TCHAR)0x09b6
#define SSA             (TCHAR)0x09b7
#define SA              (TCHAR)0x09b8
#define HA              (TCHAR)0x09b9
#define HASHANTA        (TCHAR)0x09bc

#define RRA             (TCHAR)0x09dc
#define RRHA            (TCHAR)0x09dd
#define YYA             (TCHAR)0x09df

#define AA_KAR          (TCHAR)0x09be
#define I_KAR           (TCHAR)0x09bf
#define II_KAR          (TCHAR)0x09c0
#define U_KAR           (TCHAR)0x09c1
#define UU_KAR          (TCHAR)0x09c2
#define RI_KAR          (TCHAR)0x09c3
#define LI_KAR          (TCHAR)0x09e2
#define E_KAR           (TCHAR)0x09c7
#define OI_KAR          (TCHAR)0x09c8
#define O_KAR           (TCHAR)0x09cb
#define OU_KAR          (TCHAR)0x09cc
#define YA_FALA         (TCHAR)0xead0
#define CONCAT          (TCHAR)0x09cd

#define KA_KA           (TCHAR)0xe800
#define KA_TTA          (TCHAR)0xe802
#define KA_TTA_RA       (TCHAR)0xe804
#define KA_TA           (TCHAR)0xe806
#define KA_TA_RA        (TCHAR)0xe808
#define KA_NA           (TCHAR)0xe80a
#define KA_BA           (TCHAR)0xe80c
#define KA_MA           (TCHAR)0xe80e
#define KA_RA           (TCHAR)0xe810
#define KA_LA           (TCHAR)0xe812
#define KA_SSA			(TCHAR)0xe814
#define KA_SSA_NA		(TCHAR)0xe816
#define KA_SSA_MA		(TCHAR)0xe818
#define KA_S			(TCHAR)0xe81a

#define KHA_NA          (TCHAR)0xe820
#define KHA_BA          (TCHAR)0xe822
#define KHA_RA          (TCHAR)0xe824
#define KHA_LA          (TCHAR)0xe826

#define GA_GA           (TCHAR)0xe830
#define GA_DA           (TCHAR)0xe832
#define GA_DHA          (TCHAR)0xe834
#define GA_NA           (TCHAR)0xe836
#define GA_BA           (TCHAR)0xe838
#define GA_RA           (TCHAR)0xe83a
#define GA_LA           (TCHAR)0xe83c

#define GHA_NA          (TCHAR)0xe850
#define GHA_BA          (TCHAR)0xe852
#define GHA_RA          (TCHAR)0xe854
#define GHA_LA          (TCHAR)0xe856

#define NGA_KA          (TCHAR)0xe860
#define NGA_KHA         (TCHAR)0xe862
#define NGA_GA          (TCHAR)0xe864
#define NGA_GHA         (TCHAR)0xe866
#define NGA_MA          (TCHAR)0xe868

#define CHA_CHA         (TCHAR)0xe870
#define CHA_CHHA        (TCHAR)0xe872
#define CHA_NYA         (TCHAR)0xe874
#define CHA_BA          (TCHAR)0xe876

#define CHHA_BA         (TCHAR)0xe880
#define CHHA_RA         (TCHAR)0xe882

#define JA_JA           (TCHAR)0xe890
#define JA_JA_BA        (TCHAR)0xe892
#define JA_JHA          (TCHAR)0xe894
#define JA_NYA          (TCHAR)0xe896
#define JA_BA           (TCHAR)0xe898
#define JA_RA           (TCHAR)0xe89a

#define JHA_RA          (TCHAR)0xe8a0

#define NYA_CHA         (TCHAR)0xe8b0
#define NYA_CHHA        (TCHAR)0xe8b2
#define NYA_JA          (TCHAR)0xe8b4
#define NYA_JHA         (TCHAR)0xe8b6

#define TTA_TTA         (TCHAR)0xe8c0
#define TTA_BA          (TCHAR)0xe8c2
#define TTA_RA          (TCHAR)0xe8c4

#define TTHA_BA         (TCHAR)0xe8d0
#define TTHA_RA         (TCHAR)0xe8d2

#define DDA_DDA         (TCHAR)0xe8e0
#define DDA_BA          (TCHAR)0xe8e2
#define DDA_RA          (TCHAR)0xe8e4

#define DDHA_BA         (TCHAR)0xe8f0
#define DDHA_RA         (TCHAR)0xe8f2

#define NNA_TTA         (TCHAR)0xe900
#define NNA_TTHA        (TCHAR)0xe902
#define NNA_DDA         (TCHAR)0xe904
#define NNA_NA          (TCHAR)0xe906
#define NNA_BA          (TCHAR)0xe908

#define TA_HASHANTA     (TCHAR)0xe910
#define TA_TA           (TCHAR)0xe912
#define TA_TA_BA        (TCHAR)0xe914
#define TA_THA          (TCHAR)0xe916
#define TA_NA           (TCHAR)0xe918
#define TA_BA           (TCHAR)0xe91a
#define TA_MA           (TCHAR)0xe91c
#define TA_RA           (TCHAR)0xe91e

#define THA_BA          (TCHAR)0xe930
#define THA_RA          (TCHAR)0xe932

#define DA_GA           (TCHAR)0xe940
#define DA_DA           (TCHAR)0xe942
#define DA_DHA          (TCHAR)0xe944
#define DA_DHA_BA       (TCHAR)0xe946
#define DA_BA           (TCHAR)0xe948
#define DA_BHA          (TCHAR)0xe94a
#define DA_BHA_RA       (TCHAR)0xe94c
#define DA_MA           (TCHAR)0xe94e
#define DA_RA           (TCHAR)0xe950
#define DA_LA           (TCHAR)0xe952

#define DHA_NA          (TCHAR)0xe960
#define DHA_BA          (TCHAR)0xe962
#define DHA_MA          (TCHAR)0xe964
#define DHA_RA          (TCHAR)0xe966
#define DHA_LA          (TCHAR)0xe968

#define NA_JA           (TCHAR)0xe970
#define NA_TTA          (TCHAR)0xe972
#define NA_TTHA         (TCHAR)0xe974
#define NA_DDA          (TCHAR)0xe976
#define NA_TA           (TCHAR)0xe978
#define NA_THA          (TCHAR)0xe97a
#define NA_DA           (TCHAR)0xe97c
#define NA_DHA          (TCHAR)0xe97e
#define NA_NA           (TCHAR)0xe980
#define NA_BA           (TCHAR)0xe982
#define NA_MA           (TCHAR)0xe984
#define NA_SA           (TCHAR)0xe986

#define PA_TTA          (TCHAR)0xe990
#define PA_TA           (TCHAR)0xe992
#define PA_NA           (TCHAR)0xe994
#define PA_PA           (TCHAR)0xe996
#define PA_RA           (TCHAR)0xe998
#define PA_LA           (TCHAR)0xe99a
#define PA_SA           (TCHAR)0xe99c

#define PHA_RA          (TCHAR)0xe9b0
#define PHA_LA          (TCHAR)0xe9b2

#define BA_JA           (TCHAR)0xe9c0
#define BA_DA           (TCHAR)0xe9c2
#define BA_DHA          (TCHAR)0xe9c4
#define BA_NA           (TCHAR)0xe9c6
#define BA_BA           (TCHAR)0xe9c8
#define BA_RA           (TCHAR)0xe9ca
#define BA_LA           (TCHAR)0xe9cc

#define BHA_RA          (TCHAR)0xe9e0
#define BHA_LA          (TCHAR)0xe9e2

#define MA_NA           (TCHAR)0xe9f0
#define MA_PA           (TCHAR)0xe9f2
#define MA_PA_RA        (TCHAR)0xe9f4
#define MA_PHA          (TCHAR)0xe9f6
#define MA_PHA_RA       (TCHAR)0xe9f8
#define MA_BA           (TCHAR)0xe9fa
#define MA_BA_RA        (TCHAR)0xe9fc
#define MA_BHA          (TCHAR)0xe9fe
#define MA_BHA_RA       (TCHAR)0xea00
#define MA_MA           (TCHAR)0xea02
#define MA_RA           (TCHAR)0xea04
#define MA_LA           (TCHAR)0xea06

#define LA_KA           (TCHAR)0xea10
#define LA_GA           (TCHAR)0xea12
#define LA_TTA          (TCHAR)0xea14
#define LA_DDA          (TCHAR)0xea16
#define LA_PA           (TCHAR)0xea18
#define LA_PHA          (TCHAR)0xea1a
#define LA_BA           (TCHAR)0xea1c
#define LA_LA           (TCHAR)0xea1e

#define SHA_CHA         (TCHAR)0xea30
#define SHA_CHHA        (TCHAR)0xea32
#define SHA_NA          (TCHAR)0xea34
#define SHA_BA          (TCHAR)0xea36
#define SHA_MA          (TCHAR)0xea38
#define SHA_MA_RA       (TCHAR)0xea3a
#define SHA_RA          (TCHAR)0xea3c
#define SHA_LA          (TCHAR)0xea3e

#define SSA_KA          (TCHAR)0xea50
#define SSA_KA_RA       (TCHAR)0xea52
#define SSA_NYA         (TCHAR)0xea54
#define SSA_TTA         (TCHAR)0xea56
#define SSA_TTHA        (TCHAR)0xea58
#define SSA_PA          (TCHAR)0xea5a
#define SSA_PA_RA       (TCHAR)0xea5c
#define SSA_PHA         (TCHAR)0xea5e
#define SSA_BA          (TCHAR)0xea60
#define SSA_MA          (TCHAR)0xea62

#define SA_KA           (TCHAR)0xea70
#define SA_KA_RA        (TCHAR)0xea72
#define SA_KHA          (TCHAR)0xea74
#define SA_KHA_RA       (TCHAR)0xea76
#define SA_TTA          (TCHAR)0xea78
#define SA_TTA_RA       (TCHAR)0xea7a
#define SA_TA           (TCHAR)0xea7c
#define SA_TA_RA        (TCHAR)0xea7e
#define SA_THA          (TCHAR)0xea80
#define SA_THA_RA       (TCHAR)0xea82
#define SA_NA           (TCHAR)0xea84
#define SA_PA           (TCHAR)0xea86
#define SA_PA_RA        (TCHAR)0xea88
#define SA_PHA          (TCHAR)0xea8a
#define SA_PHA_RA       (TCHAR)0xea8c
#define SA_BA           (TCHAR)0xea8e
#define SA_MA           (TCHAR)0xea90
#define SA_LA           (TCHAR)0xea92

#define HA_RI           (TCHAR)0xeaa0
#define HA_NNA          (TCHAR)0xeaa2
#define HA_BA           (TCHAR)0xeaa4
#define HA_MA           (TCHAR)0xeaa6
#define HA_RA           (TCHAR)0xeaa8
#define HA_LA           (TCHAR)0xeaaa

#define RRA_GA          (TCHAR)0xeab0

#define REF             (TCHAR)0xeac0

typedef struct
{
    TCHAR	result;
	TCHAR	first;
    TCHAR	second;
} CCAT;

typedef struct
{
	TCHAR	ch;
	int		start;
	int		finish;
} RANGES;

TCHAR	keymap[ 200 ] = 
		{
			//000-009
			0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000,
			//010-019
			0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 
			//020-029
			0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 
			//030-039
			0x0000, 0x0000, 0x0020, 0x0021, 0xeae3, 0x0023, 0x09f3, 0x0025, 0x0981, 0xeae2,
			//040-049
			0x0028, 0x0029, 0x002a, 0x002b, 0x002c, 0x002d, 0x002e, 0x002f, 0x09e6, 0x09e7, 
			//050-059
			0x09e8, 0x09e9, 0x09ea, 0x09eb, 0x09ec, 0x09ed, 0x09ee, 0x09ef, 0x003a, 0x003b, 
			//060-069
			0x003c, 0x003d, 0x003e, 0x003f, 0x09f6, 0xeac0, 0x09a3, 0x09c8, 0x09bf, 0x09a2, 
			//070-079
			0x0985, 0xeae0, 0x09ad, 0x099e, 0x0996, 0x09a5, 0x09a7, 0x09b6, 0x09b7, 0x0998, 
			//080-089
			0x09bd, 0x0982, 0x09ab, 0x09c2, 0x09a0, 0x099d, 0x09b2, 0x09df, 0x09d7, 0x099b, 
			//090-099
			0xead0, 0x005b, 0x0983, 0x005d, 0x005e, 0x098b, 0xeae1, 0x09c3, 0x09a8, 0x09c7, 
			//100-109
			0x09c0, 0x09a1, 0x09be, 0x09cd, 0x09ac, 0x09b9, 0x0995, 0x09a4, 0x09a6, 0x09ae, 
			//110-119
			0x09b8, 0x0997, 0x09dc, 0x0999, 0x09aa, 0x09c1, 0x099f, 0x099c, 0x09b0, 0x09af, 
			//120-129
			0x0993, 0x099a, 0x0000, 0x007b, 0xe910, 0x007d, 0xeae4, 0x0000, 0x0000
		};

CCAT	concat[CCAT_TOTAL] =
		{
			//ka		000 - 008
			{KA_KA,		KA ,		KA},
			{KA_TTA,	KA ,		TTA},
			{KA_TA,		KA ,		TA},
			{KA_NA,		KA ,		RA},
			{KA_BA,		KA ,		BA},           
			{KA_MA,		KA ,		MA},           
			{KA_RA,		KA ,		RA},          
			{KA_LA,		KA ,		LA},         
			{KA_SSA,	KA ,		SSA},    
			
			//ka_tta	009 - 009
			{KA_TTA_RA, KA_TTA ,	RA},
			
			//ka_ta		010 - 010
			{KA_TA_RA,	KA_TA ,		RA},

			//ks_ssa	011 - 012
			{KA_SSA_NA, KA_SSA ,	NA}, 
			{KA_SSA_MA, KA_SSA ,	MA},
  
			//kha		013 - 016
			{KHA_NA,	KHA ,		NA},
			{KHA_BA,	KHA ,		BA},
			{KHA_RA,	KHA ,		RA},
			{KHA_LA,	KHA ,		LA},
  
			//ga		017 - 023
			{GA_GA,		GA ,		GA},
			{GA_DA,		GA ,		DA},
			{GA_DHA,	GA ,		DHA},
			{GA_NA,		GA ,		NA},
			{GA_BA,		GA ,		BA},
			{GA_RA,		GA ,		RA},
			{GA_LA,		GA ,		LA},
  
			//gha		024 - 027
			{GHA_NA,	GHA ,		NA},
			{GHA_BA,	GHA ,		BA},
			{GHA_RA,	GHA ,		RA},
			{GHA_LA,	GHA ,		LA},
				  		
			//mga		028 - 032
			{NGA_KA,	NGA ,		KA},		
			{NGA_KHA,	NGA ,		KHA},		
			{NGA_GA,	NGA ,		GA},		
			{NGA_GHA,	NGA ,		GHA},		
			{NGA_MA,	NGA ,		MA},		
				  		
			//cha		033 - 036
			{CHA_CHA,	CHA ,		CHA},		
			{CHA_CHHA,	CHA ,		CHHA},		
			{CHA_NYA,	CHA ,		NYA},		
			{CHA_BA,	CHA ,		BA},		
				  		
			//chha		037 - 038
			{CHHA_BA,	CHHA ,		BA},		
			{CHHA_RA,	CHHA ,		RA},		
				  		
			//ja		039 - 043
			{JA_JA,		JA ,		JA},		
			{JA_JHA,	JA ,		JHA},		
			{JA_NYA,	JA ,		NYA},		
			{JA_BA,		JA ,		BA},		
			{JA_RA,		JA ,		RA},		

			//ja_ja		044 - 044
			{JA_JA_BA,	JA_JA ,		BA},		
			  			
			//jhaa		045 - 045
			{JHA_RA,	JHA ,		RA},		
			 		
			//nya		046 - 049
			{NYA_CHA,	NYA ,		CHA},		
			{NYA_CHHA,	NYA ,		CHHA},		
			{NYA_JA,	NYA ,		JA},		
			{NYA_JHA,	NYA ,		JHA},		
			 		
			//tta		050 - 052
			{TTA_TTA,	TTA ,		TTA},		
			{TTA_BA,	TTA ,		BA},		
			{TTA_RA,	TTA ,		RA},		
			 		
			//ttha		053 - 054
			{TTHA_BA,	TTHA ,		BA},		
			{TTHA_RA,	TTHA ,		RA},		
			 		
			//dda		055 - 057
			{DDA_DDA,	DDA ,		DDA},		
			{DDA_BA,	DDA ,		BA},		
			{DDA_RA,	DDA ,		RA},		
			  		
			//ddha		058 - 059
			{DDHA_BA,	DDHA ,		BA},		
			{DDHA_RA,	DDHA ,		RA },		
			 		
			//nna		060 - 064
			{NNA_TTA,	NNA ,		TTA },		
			{NNA_TTHA,	NNA ,		TTHA },		
			{NNA_DDA,	NNA ,		DDA },		
			{NNA_NA,	NNA ,		NA },		
			{NNA_BA,	NNA ,		BA },		
			  			
			//ta		065 - 070
			{TA_TA,		TA ,		TA},		
			{TA_THA,	TA ,		THA},		
			{TA_NA,		TA ,		NA},		
			{TA_BA,		TA ,		BA},		
			{TA_MA,		TA ,		MA},		
			{TA_RA,		TA ,		RA},		

			//ta-ta		071 - 071
			{TA_TA_BA,	TA_TA ,		BA},		
			 		
			//tha		072 - 073
			{THA_BA,	THA ,		BA},		
			{THA_RA,	THA ,		RA},		
			 		
			//da		074 - 081
			{DA_GA,		DA ,		GA},		
			{DA_DA,		DA ,		DA},		
			{DA_DHA,	DA ,		DHA},		
			{DA_BA,		DA ,		BA},		
			{DA_BHA,	DA ,		BHA},		
			{DA_MA,		DA ,		MA},		
			{DA_RA,		DA ,		RA},		
			{DA_LA,		DA ,		LA},		
			  		
			//da_dha	082 - 082
			{DA_DHA_BA, DA_DHA ,	BA},		
			
			//da_bha	083 - 083
			{DA_BHA_RA, DA_BHA ,	RA},		

			//dha		084 - 088
			{DHA_NA,	DHA ,		NA},		
			{DHA_BA,	DHA ,		BA},		
			{DHA_MA,	DHA ,		MA},		
			{DHA_RA,	DHA ,		RA},		
			{DHA_LA,	DHA ,		LA},		
			 		
			//na		089 - 100
			{NA_JA,		NA ,		JA},		
			{NA_TTA,	NA ,		TTA},		
			{NA_TTHA,	NA ,		TTHA},		
			{NA_DDA ,	NA ,		DDA},		
			{NA_TA,		NA ,		TA},		
			{NA_THA,	NA ,		THA},		
			{NA_DA,		NA ,		DA},		
			{NA_DHA,	NA ,		DHA},		
			{NA_NA ,	NA ,		NA},		
			{NA_BA,		NA ,		BA},		
			{NA_MA,		NA ,		MA},		
			{NA_SA,		NA ,		SA},		
					
			//pa		101 - 107
			{PA_TTA,	PA ,		TTA},		
			{PA_TA,		PA ,		TA},		
			{PA_NA,		PA ,		NA},		
			{PA_PA,		PA ,		PA},		
			{PA_RA,		PA ,		RA},		
			{PA_LA,		PA ,		LA},		
			{PA_SA,		PA ,		SA},		
			 		
			//pha		108 - 109
			{PHA_RA,	PHA ,		RA},		
			{PHA_LA,	PHA ,		LA},		
			 		
			//ba		110 - 116
			{BA_JA,		BA ,		JA},		
			{BA_DA,		BA ,		DA},		
			{BA_DHA,	BA ,		DHA},		
			{BA_NA ,	BA ,		NA},		
			{BA_BA ,	BA ,		BA},		
			{BA_RA,		BA ,		RA},		
			{BA_LA,		BA ,		LA},		
			 		
			//bha		117 - 118
			{BHA_RA,	BHA ,		RA},		
			{BHA_LA,	BHA ,		LA},		
			  		
			//ma		119 - 126
			{MA_NA,		MA ,		NA},		
			{MA_PA,		MA ,		PA},		
			{MA_PHA,	MA ,		PHA},		
			{MA_BA,		MA ,		BA},		
			{MA_BHA ,	MA ,		BHA},		
			{MA_MA,		MA ,		MA},		
			{MA_RA,		MA ,		RA},		
			{MA_LA,		MA ,		LA},		

			//ma_pa		127 - 127
			{MA_PA_RA,	MA_PA ,		RA},		
			
			//ma-pha	128 - 128
			{MA_PHA_RA, MA_PHA ,	RA},		
			
			//ma-ba		129 - 129
			{MA_BA_RA,	MA_BA ,		RA},		

			//ma-bha	130 - 130
			{MA_BHA_RA, MA_BHA ,	RA},		
			  		
			//la		131 - 138
			{LA_KA,		LA ,		KA},		
			{LA_GA,		LA ,		GA},		
			{LA_TTA,	LA ,		TTA},		
			{LA_DDA,	LA ,		DDA},		
			{LA_PA,		LA ,		PA},		
			{LA_PHA,	LA ,		PHA},		
			{LA_BA,		LA ,		BA},		
			{LA_LA,		LA ,		LA},		
			 		
			//sha		139 - 145
			{SHA_CHA,	SHA ,		CHA},		
			{SHA_CHHA,	SHA ,		CHHA},		
			{SHA_NA,	SHA ,		NA},		
			{SHA_BA,	SHA ,		BA},		
			{SHA_MA,	SHA ,		MA},		
			{SHA_RA,	SHA ,		RA},		
			{SHA_LA,	SHA ,		LA},		

			//sha_ma	146 - 146
			{SHA_MA_RA, SHA_MA ,	RA},		
			 		
			//ssa		147 - 154
			{SSA_KA,	SSA ,		KA},		
			{SSA_NYA,	SSA ,		NYA},		
			{SSA_TTA,	SSA ,		TTA},		
			{SSA_TTHA,	SSA ,		TTHA},		
			{SSA_PA,	SSA ,		PA},		
			{SSA_PHA,	SSA ,		PHA},		
			{SSA_BA,	SSA ,		BA},		
			{SSA_MA,	SSA ,		MA},		

			//ssa_ka	155 - 155
			{SSA_KA_RA, SSA_KA ,	RA},		

			//ssa_pa	156 - 156
			{SSA_PA_RA, SSA_PA ,	RA},		
			 		
			//sa		157 - 167
			{SA_KA,		SA ,		KA},		
			{SA_KHA,	SA ,		KHA},		
			{SA_TTA,	SA ,		TTA},		
			{SA_TA,		SA ,		TA},		
			{SA_THA,	SA ,		THA},		
			{SA_NA,		SA ,		NA},		
			{SA_PA,		SA ,		PA},		
			{SA_PHA,	SA ,		PHA},		
			{SA_BA,		SA ,		BA},		
			{SA_MA,		SA ,		MA},		
			{SA_LA,		SA ,		LA},		
			
			//sa_ka		168 - 168
			{SA_KA_RA,	SA_KA ,		RA},		
			
			//sa-kha	169 - 169
			{SA_KHA_RA, SA_KHA ,	RA},		
			
			//sa-tta	170 - 170
			{SA_TTA_RA, SA_TTA ,	RA},		
			
			//sa-ta		171 - 171
			{SA_TA_RA,	SA_TA ,		RA},		
				
			//sa-tha	172 - 172
			{SA_THA_RA, SA_THA ,	RA},		
			
			//sa-pa		173 - 173
			{SA_PA_RA,	SA_PA ,		RA},		

			//sa-pha	174 - 174
			{SA_PHA_RA, SA_PHA ,	RA},		
			  		
			//ha		175 - 180
			{HA_RI,		HA ,		RI},		
			{HA_NNA,	HA ,		NNA},		
			{HA_BA,		HA ,		BA},		
			{HA_MA,		HA ,		MA},		
			{HA_RA,		HA ,		RA},		
			{HA_LA,		HA ,		LA},		
			
			//rra		181 - 181
			{RRA_GA,	RRA ,		GA},		
};

RANGES	ranges[CCAT_GROUPS] =
		{
			{KA,	  0,   8},
			{KA_TTA,  9,   9},
			{KA_TA,	 10,  10},
			{KA_SSA, 11,  12},
			{KHA,	 13,  16},
			{GA,	 17,  23},
			{GHA,	 24,  27},
			{NGA,	 28,  32},
			{CHA,	 33,  36},
			{CHHA,	 37,  38},
			{JA,	 39,  43},
			{JA_JA,	 44,  44},
			{JHA,	 45,  45},
			{NYA,	 46,  49},
			{TTA,	 50,  52},
			{TTHA,	 53,  54},
			{DDA,	 55,  57},
			{DDHA,	 58,  59},
			{NNA,	 60,  64},
			{TA,	 65,  70},
			{TA-TA,	 71,  71},
			{THA,	 72,  73},
			{DA,	 74,  81},
			{DA_DHA, 82,  82},
			{DA_BHA, 83,  83},
			{DHA,	 84,  88},
			{NA,	 89, 100},
			{PA,	101, 107},
			{PHA,	108, 109},
			{BA,	110, 116},
			{BHA,	117, 118},
			{MA,	119, 126},
			{MA_PA,	127, 127},
			{MA-PHA,128, 128},
			{MA-BA,	129, 129},
			{MA-BHA,130, 130},
			{LA,	131, 138},
			{SHA,	139, 145},
			{SHA_MA,146, 146},
			{SSA,	147, 154},
			{SSA_KA,155, 155},
			{SSA_PA,156, 156},
			{SA,	157, 167},
			{SA_KA,	168, 168},
			{SA-KHA,169, 169},
			{SA-TTA,170, 170},
			{SA-TA,	171, 171},
			{SA-THA,172, 172},
			{SA-PA,	173, 173},
			{SA-PHA,174, 174},
			{HA,	175, 180},
			{RRA,	181, 181}
};


class CBEditCtrl : public COleControl
{
	DECLARE_DYNCREATE(CBEditCtrl)

// Constructor
public:
	CBEditCtrl();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CBEditCtrl)
	public:
	virtual void OnDraw(CDC* pdc, const CRect& rcBounds, const CRect& rcInvalid);
	virtual void DoPropExchange(CPropExchange* pPX);
	virtual void OnResetState();
	virtual void OnFontChanged();
	virtual BOOL OnSetObjectRects(LPCRECT lpRectPos, LPCRECT lpRectClip);
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	//}}AFX_VIRTUAL

// Implementation
protected:
	void UnsortedToSorted();
	void SortedToUnsorted();
	int m_rightbear;
	int m_leftbear;
	~CBEditCtrl();
	void AdjustCaret(CDC*, const CRect&);
	int m_position;						// index of current position in m_content
	CPoint	m_caret;					// Caret x,y position
	CString	m_content;					// Full content in sorted Unicode
	CString	m_display;					// Full content to be displayed in unsorted Unicode	
	int		m_drawpos;

	DECLARE_OLECREATE_EX(CBEditCtrl)    // Class factory and guid
	DECLARE_OLETYPELIB(CBEditCtrl)      // GetTypeInfo
	DECLARE_PROPPAGEIDS(CBEditCtrl)     // Property page IDs
	DECLARE_OLECTLTYPE(CBEditCtrl)		// Type name and misc status

// Message maps
	//{{AFX_MSG(CBEditCtrl)
	afx_msg void OnChar(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnSetFocus(CWnd* pOldWnd);
	afx_msg void OnKillFocus(CWnd* pNewWnd);
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

// Dispatch maps
	//{{AFX_DISPATCH(CBEditCtrl)
	afx_msg BSTR GetContent();
	afx_msg void SetContent(LPCTSTR lpszNewValue);
	//}}AFX_DISPATCH
	DECLARE_DISPATCH_MAP()

	afx_msg void AboutBox();

// Event maps
	//{{AFX_EVENT(CBEditCtrl)
	//}}AFX_EVENT
	DECLARE_EVENT_MAP()

// Dispatch and event IDs
public:
	enum {
	//{{AFX_DISP_ID(CBEditCtrl)
	dispidContent = 1L,
	//}}AFX_DISP_ID
	};
};
