# include <ctype.h>
//# include <curses.h>
# include <stdio.h>
# include <string.h>
//# include <termio.h>
# include <fcntl.h>
//# include <termios.h>
# include <time.h>
# include <sys/types.h>


/* --------------------- KEY DEFINES ------------------------ */
# define   F1      16394
# define   F2      16650
# define   F3      16906
# define   F4      17162
# define   F5      17418
# define   F6      17674
# define   F7      17930
# define   F8      18186
# define   F9      18442
# define   F10     18698
# define   F11     18954
# define   F12    'v' /*19210*/  
# define   F13     19466
# define   F14     19722
# define   F15     19978
# define   F16     20234
# define   UP         11
# define   DN         10
# define   RT         12
# define   LT          8
# define   INS        76
# define   BKSP        8
# define   ESC        27
# define   BACKTAB    27
# define   TAB       '\t'

# define   U_LIM      30
# define   L_LIM      20
# define   FLASH       0
# define   FLIGHT      4
# define   SCHE       15
# define   ACTU       20
# define   DEST       28
# define   VIA        34
# define   BOARD      41
# define   TYPE       49
# define   GATE       55
# define   REMARK     63
# define   MODN       79

 
# define   NUL      0x00
# define   CR       0x0d
# define   LF       0x0a
# define   DLE      0x10
# define   STX      0x02
# define   ETX      0x03
# define   SOH      0x01

# define   ACK      0x06
# define   ACK0     0x10
# define   ACK1     0x30
# define   EOT      0x04
# define   ENQ      0x05
# define   NACK     0x15

# define   I_R      0x49
# define   C_R      0x43
# define   N_R      0x4e
# define   L_R      0x4c
# define   E_R      0x45
# define   NSPEC    0x47

# define   SIZE       60

# define   NOREPLY     0
# define   LINEERR     1

# define   LINKS      10
# define   TIME    20000
# define   REQUEST     3

# define   Binsize    15 
# define   Boutsize    8
# define   Boutbuf  1200

# define   DECMODE    14
# define   CCLS       99
# define   CHOME     100
# define   CINV       19
# define   BIG        22
# define   MEDIUM     20
# define   PAGE1       1
# define   INITZ      16
# define   UNDLINE    18
# define   CHGTOUT    11

# define   BCLS       99   
# define   FLIGHTPOS   6 
# define   TOWNPOS    14 
# define   REMARKPOS  26 

# define   ARRFLIGHT   5
# define   ARRTOWN    12 
# define   ARRVIA     24
# define   ARRREMARK  36
# define   ARREND     49

# define   MAXENTRY    8 

# define   LINE_NO    22

# define   MAXADENT    8

# define   LCSTART  0xa5
# define   LCEND    0xfd 
# define   LCNORM   0xf1 
# define   LCBLANK  0xf3  
# define   LCTEST   0xf2  
# define   LCCLS    0xf5  
# define   LCCLOCK  0xf6  
# define   LCACK    0x06  

# define   ARCLS      12

# define   DEPREQ   800000

# define   SLEEPCLS   15
# define   SLEEPLINE  15 
