# include "ptc.h"

char  complrc( char* buf1 , char* buf2 )
{
	char *s, c;

	c = buf1[ 0 ];
	for( s = buf1 + 1 ; s <= buf2 ; s++ )
	{
		c ^= (*s);
	}
	return  c;
}

int   checklrc( char* stx , char* etx , char lrc )
{
	char  clrc;

	clrc = complrc( stx + 1 , etx );
	if( clrc == CR )
	{
		clrc = DLE;
	}
	if( clrc == lrc )
	{
		return  1;
	}
	else
	{
		return  0;
	}
}

void  makepollstr( int  dtype )
{
	out_cmd[ 0 ] = SOH;
	out_cmd[ 1 ] = CharPgid[ dtype ];
	out_cmd[ 2 ] = CharPdid[ dtype ];
	out_cmd[ 3 ] = ENQ;
}

void  makeselstr( int  dtype )
{
	out_cmd[ 0 ] = SOH;
	out_cmd[ 1 ] = CharSgid[ dtype ];
	out_cmd[ 2 ] = CharSdid[ dtype ];
	out_cmd[ 3 ] = ENQ;
}

char   getreport( int dtype )
{
	char *stx, *etx, lrc;
	int  i , j, received;

	received = 0;
	for( i = 0 ; i < TIME ; i++ )
	{
		if( rdchk( device_fd[ dtype ] ) > 0 )
		{
			received = 1;
			break;
		}
	}
	if( received == 0 )
	{
		printf( "\nPeripheral %d doesn't send report\n" , dtype );
		return NOREPLY;
	}
	received = read( device_fd[ dtype ] , in_rep , Binsize );
	tcflush( device_fd[ dtype ] , TCIFLUSH );
	printf( "\nPeripheral %d reports" , dtype  );
	for( j = 0 ; j < received ; j++ )
	{
		printf( "  %4x  " , in_rep[ j ] );
	}
	printf( "\n" );
	stx = strchr( in_rep , STX );
	etx = strchr( in_rep , ETX );
	if( stx == NULL || etx == NULL )
	{
		printf( "\nReport format error from %d \n" , dtype );
		return   LINEERR;
	}
	lrc = etx[ 1 ];
	if( checklrc( etx , stx , lrc ) )
	{
		if( ( int )( stx - etx ) == 4 )
		{
			printf( "\nNonspecific report from %d \n" , dtype );
			return   NSPEC;
		}
		else
		{
			printf( "\nSpecific report from %d \n" , dtype );
			return stx[ 1 ];
		}
	}
	else
	{
		printf( "\nLRC error\n" );
		return   LINEERR;
	}
}

char   getstatus( int dtype )
{
	char s[2];
	int  i , received;

	received = 0;
	for( i = 0 ; i < TIME ; i++ )
	{
		if( rdchk( device_fd[ dtype ] ) > 0 )
		{
			received = 1;
			break;
		}
	}
	if( received == 0 )
	{
		printf( "\nPeripheral %d doesn't send status\n" , dtype );
		return NOREPLY;
	}
	received = read( device_fd[ dtype ] , s , 2 );
	tcflush( device_fd[ dtype ] , TCIFLUSH );
	printf( "\nPeripheral %d's status is  %4x\n" , dtype ,( int )s[ 0 ] );
	return   s[ 0 ];
}

char   getacknow( int dtype )
{
	char s[2];
	int  received;
	int  i;

	received = 0;
	for( i = 0 ; i < TIME ; i++ )
	{
		if( rdchk( device_fd[ dtype ] ) > 0 )
		{
			received = 1;
			break;
		}
	}
	if( received == 0 )
	{
		printf( "\nPeripheral %d doesn't acknowledge\n" , dtype );
		return NOREPLY;
	}
	received = read( device_fd[ dtype ] , s , 2 );
	tcflush( device_fd[ dtype ] , TCIFLUSH );
	printf( "\nPeripheral %d acknowledges %4x\n" , dtype , ( int )s[0] );
	return   s[ 0 ];
}

void   sendack( int dtype )
{
	char  s[2];
	int   txmitted;
	int   len;

	len = 1;
	s[ 0 ] = ACK1;
	tcflush( device_fd[ dtype ] , TCIOFLUSH );
	txmitted = write( device_fd[ dtype ] , s , len );
	if( txmitted == len )
	{
		printf( "\nAck sent %4x\n" , ( int )s[ 0 ] );
	}
	else if( txmitted == 0 )
	{
		printf( "\nCouldn't send Ack\n" );
	}
	else
	{
		printf( "\In Ack %d bytes sent\n" , txmitted );
	}
}

void   sendnack( int dtype )
{
	char  s[2];
	int   txmitted;
	int   len;

	len = 1;
	s[ 0 ] = NACK;
	tcflush( device_fd[ dtype ] , TCIOFLUSH );
	txmitted = write( device_fd[ dtype ] , s , len );
	if( txmitted == len )
	{
		printf( "\nNack sent %4x\n" , ( int )s[ 0 ] );
	}
	else if( txmitted == 0 )
	{
		printf( "\nCouldn't send Nack\n" );
	}
	else
	{
		printf( "\In Nack %d bytes sent\n" , txmitted );
	}
}

void   sendeot( int dtype )
{
	char  s[ 2 ];
	int   txmitted;
	int   len;

	len = 1;
	s[ 0 ] = EOT;
	tcflush( device_fd[ dtype ] , TCIOFLUSH );
	txmitted = write( device_fd[ dtype ] , s , len );
	if( txmitted == len )
	{
		printf( "\nEot sent %4x\n" , ( int )s[ 0 ] );
	}
	else if( txmitted == 0 )
	{
		printf( "\nCouldn't send Eot\n" );
	}
	else
	{
		printf( "\In Eot %d bytes sent\n" , txmitted );
	}
}

int    sendcmd( int dtype , char* buf , int len )
{
	int  txmitted;
	int  i;

	tcflush( device_fd[ dtype ] , TCIOFLUSH );
	txmitted = write( device_fd[ dtype ] , buf , len );
	if( txmitted == len )
	{
		printf( "\nSent cmd " );
		for( i = 0 ; i < txmitted ; i++ )
		{
			printf( "  %4x  " , ( int )buf[ i ] );
		}
		printf( "\n" );
		return   _OK;
	}
	else if( txmitted == 0 )
	{
		printf( "\nNo cmd sent\n"  );
		return   MISSING;
	}
	else
	{
		printf( "\nSent bytes %d \n" , txmitted );
		return   MISSING;
	}
}

void    senddat( int dtype , int len )
{
	int  i;
	char s;

	for( i = 0 ; i < REQUEST ; i++ )
	{
		if( sendcmd( dtype , out_dat , len ) == MISSING )
		{
			Status[ dtype ] = MISSING;
			break;
		}
		s = getstatus( dtype );
		if( s == NOREPLY  )
		{
			if( i == ( REQUEST - 1 ) )
			{
				Status[ dtype ] = DEFAULT;
				break;
			}
			else
			{
				continue;
			}
		}
		else
		{
			break;
		}
	}

	if( s == NACK )
	{
		for( i = 0 ; i < REQUEST - 1 ; i++ )
		{
			sendcmd( dtype , out_dat , len );
			s = getstatus( dtype );
			if( s != NACK && s != NOREPLY )
			{
				break;
			}
		}
	}
	if( s == NOREPLY || s == NACK )
	{
		Status[ dtype ] = DEFAULT;
	}
	else if( s == ESC )
	{
		Status[ dtype ] = _OK;
	}
	else if( s == ACK0 )
	{
		Status[ dtype ] = _OK;
	}
}

void   actreport( char report, int dtype )
{
	switch( report )
	{
	case I_R:
		Status[ dtype ] = _OK;
		break;
	case C_R:
		Status[ dtype ] = _OK;
		break;
	case E_R:
		Status[ dtype ] = _OK;
		break;
	case N_R:
		Status[ dtype ] = _OK;
		break;
	case L_R:
		Status[ dtype ] = LOCAL;
		break;
	default :
		break;
	}
}

void   actstatus( char status , int dtype )
{

}

void   acknowrep( char report , int dtype )
{
	int i;
	int ack;

	actreport( report , dtype );
	for( i = 0 ; i < REQUEST ; i++ )
	{
		sendack( dtype );
		ack = getacknow( dtype );
		if( ack == EOT )
		{
			break;
		}
		else if( ack == NACK )
		{
			continue;
		}
		else if( ack == NOREPLY  && i == ( REQUEST - 1 ) )
		{
			sendeot( dtype );
			Status[ dtype ] = DEFAULT;
			continue;
		}
	}
}


void   initdevice( int dtype )
{
	device_fd[ dtype ] = open( device_file[ dtype ] , O_NDELAY|O_RDWR );
	if( device_fd[ dtype ] == -1 )
	{
		Status[ dtype ] = MISSING;
		printf( "\nPeripheral %d is missing\n" , dtype );
	}
	else
	{
		Status[ dtype ] = _OK;
		printf( "\nPeripheral %d is OK\n" , dtype );

		ioctl( device_fd[ dtype ] , TCGETA , &device_old[ dtype ] );
		ioctl( device_fd[ dtype ] , TCGETA , &device_new[ dtype ] );

		device_new[ dtype ].c_iflag = IGNPAR|INPCK|ICRNL;
		device_new[ dtype ].c_oflag = 0;
		device_new[ dtype ].c_lflag = ICANON;
		device_new[ dtype ].c_cflag = 
		B2400|CS7|CSTOPB|CREAD|CLOCAL|PARENB|PARODD;

		ioctl( device_fd[ dtype ] , TCSETAW , &device_new[ dtype ] );
	}
}


void   testdevice( int dtype )
{
	int  i;
	char report;

	makepollstr( dtype );
	for( i = 0 ; i < REQUEST ; i++ )
	{
		sendeot( dtype );
		if( sendcmd( dtype , out_cmd , 4 ) == MISSING )
		{
			Status[ dtype ] = MISSING;
			break;
		}
		report = getreport( dtype );
		if( report == NOREPLY  )
		{
			if( i == ( REQUEST - 1 ) )
			{
				Status[ dtype ] = DEFAULT;
				break;
			}
			else
			{
				continue;
			}
		}
		else
		{
			break;
		}
	}

	if( report == LINEERR )
	{
		for( i = 0 ; i < REQUEST ; i++ )
		{
			sendnack( dtype );
			report = getreport( dtype );
			if( report != LINEERR && report != NOREPLY )
			{
				break;
			}
		}
	}
	if( report == NOREPLY || report == LINEERR )
	{
		Status[ dtype ] = DEFAULT;
	}
	else
	{
		acknowrep( report , dtype );
	}
	sendeot( dtype );
}



void   talkdevice( int dtype , int len )
{
	int  i;
	char s;

	makeselstr( dtype );
	for( i = 0 ; i < REQUEST ; i++ )
	{
		sendeot( dtype );
		if( sendcmd( dtype , out_cmd , 4 ) == MISSING )
		{
			Status[ dtype ] = MISSING;
			break;
		}
		s = getacknow( dtype );
		if( s == NOREPLY  )
		{
			if( i == ( REQUEST - 1 ) )
			{
				Status[ dtype ] = DEFAULT;
				break;
			}
			else
			{
				continue;
			}
		}
		else
		{
			break;
		}
	}
	if( s == ACK0 )
	{
		senddat( dtype , len );
	}
	sendeot( dtype );
}


void   stopdevice( int dtype )
{
	tcflush( device_fd[ dtype ] , TCIOFLUSH );
	ioctl( device_fd[ dtype ] , TCSETAW , &device_old[ dtype ] );
	close( device_fd[ dtype ] );
}


void main( void )
{
	initdevice( VQ7 ); 
	testdevice( VQ7 ); 
	stopdevice( VQ7 );
}
