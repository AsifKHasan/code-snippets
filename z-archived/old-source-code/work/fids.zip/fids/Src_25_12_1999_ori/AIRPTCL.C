
/* This function computes LRC of a given range of character buffer */

char  complrc( char* buf1 , char* buf2 )
  {
	 char *s, c;

	 c = buf1[ 0 ];
	 for( s = buf1 + 1 ; s <= buf2 ; s++ )
	    {
		 c ^= (*s);
	    }
	 return c;
  }

/* End of complrc */

/* This function computes LRC of a given range of character buffer and checks
   it against the received LRC */

int   checklrc( char* stx , char* etx , char lrc )
  {
	 char  clrc;

	 clrc = complrc( stx + 1 , etx );
	 if( clrc == CR ) 		clrc = DLE;
	 if( clrc == lrc ) 	     return  1;
	 else               	return  0;
  }

/* End of checklrc */

/* This function makes the polling string in out_cmd */

void  makepollstr( int  dtype )
  {
	 out_cmd[ 0 ] = SOH;
	 out_cmd[ 1 ] = CharPgid[ dtype ];
	 out_cmd[ 2 ] = CharPdid[ dtype ];
	 out_cmd[ 3 ] = ENQ;
  }

/* End of makepollstr */

/* This function makes the selecting string in out_cmd */

void  makeselstr( int  dtype )
  {
	 out_cmd[ 0 ] = SOH;
	 out_cmd[ 1 ] = CharSgid[ dtype ];
	 out_cmd[ 2 ] = CharSdid[ dtype ];
	 out_cmd[ 3 ] = ENQ;
  }

/* End of makeselstr */

/* This function gets the poll report from a device */

char   getreport( int dtype )
  {
	  char *stx, *etx, lrc;
	  int  i , j, b;

	  for(  i = 0 ; i < TIME ; i++ )
		{
		   b = read( device_fd[ dtype ] , in_rep , Binsize );
		   if(  b != 0 )
			{
                  fprintf( errfile , "\nperipheral %d reports" , dtype  );
                  for( j = 0 ; j < b ; j++ )
                     {
                        fprintf( errfile , "  %x  " , ( int )in_rep[ j ] );
                     }
                  fprintf( errfile , "\n" );
			   stx = strchr( in_rep , STX );
			   etx = strchr( in_rep , ETX );
			   if( stx == NULL || etx == NULL )
				  {
                         fprintf( errfile , "\nreport format error from %d \n" , dtype );
					return  LINEERR;
				  }
			   lrc = etx[ 1 ];
			   if( checklrc( etx , stx , lrc ) )
				{
				   if( ( stx - etx ) == 4 )
					  {
                             fprintf( errfile , "\nnonspecific report from %d \n" , dtype );
					    return  NSPEC;
					  }
				   else
					  {
                             fprintf( errfile , "\nspecific report from %d \n" , dtype );
					    return stx[ 1 ];
					  }
				}
			   else
				{
                       fprintf( errfile , "\nLRC error\n" );
				   return LINEERR;
				}
			}
		}
       fprintf( errfile , "\nperipheral %d doesn't send report\n" , dtype );
	  return NOREPLY ;
  }

/* End of getreport */


/* This function gets the status of device after a command is txmitted */

char   getstatus( int dtype )
  {
	  char s[2];
	  int  i , received;

	  for( i = 0 ; i < TIME ; i++ )
		{
		  received = read( device_fd[ dtype ] , s , 2 );
		  if( received != 0 )
		    {
                fprintf( errfile , "\nperipheral %d's status is  %x\n" , dtype ,( int )s[ 0 ] );
			 return s[ 0 ];
		    }
		}
       fprintf( errfile , "\nperipheral %d doesn't send status\n" , dtype  );
	  return  NOREPLY ;
  }

/* End of getstatus */

/* This function gets acknowledgement from a device */

char   getacknow( int dtype )
  {
	  char s[2];
	  int  b;
	  int  i;

	  for( i = 0 ; i < TIME ; i++ )
		{
		  b = read( device_fd[ dtype ] , s , 2 );
		  if( b != 0 )
		    {
                fprintf( errfile , "\nperipheral %d acknowledges %x\n" , dtype , ( int )s[0] );
			 return s[ 0 ];
		    }
		}
       fprintf( errfile , "\nperipheral %d doesn't ackowledges\n" , dtype  );
	  return  NOREPLY ;
  }

/* End of getacknow */

/* This function sends acknowledgement to a device */

void   sendack( int dtype )
  {
	  char  s[2];

	  s[ 0 ] = ACK0;
	  write( device_fd[ dtype ] , s , 1 );
  }

/* End of sendack */

/* This function sends negative acknowledgement to a device */

void   sendnack( int dtype )
  {
	  char  s[2];

	  s[ 0 ] = NACK;
	  write( device_fd[ dtype ] , s , 1 );
  }

/* End of sendnack */

/* This function sends the recovery or EOT to a device */

void   sendeot( int dtype )
  {
	  char  s[ 2 ];

	  s[ 0 ] = EOT;
	  write( device_fd[ dtype ] , s , 1 );
  }

/* End of sendeot */

/* This function sends a data in buffer to a device */

int    sendcmd( int dtype , char* buf , int len )
  {
	  int  txmitted;

	  txmitted = write( device_fd[ dtype ] , buf , len );
	  if( txmitted == len )  return _OK;
	  else                   return MISSING;
  }

/* End of sendcmd */

/* This function sends data to a device and gets status from it in selecting
   sequence */

void    senddat( int dtype , int len )
  {
	  int  i, txmitted;
	  char s;

	  for( i = 0 ; i < REQUEST ; i++ )
		{
		  if( sendcmd( dtype , out_dat , len ) == MISSING )
			 {
			    Status[ dtype ] = MISSING;
			    break;
			 }
		  s = getstatus( dtype );
		  if( s == NOREPLY  )
			 {
			   if( i == ( REQUEST - 1 ) )
				  {
				    Status[ dtype ] = DEFAULT;
				    break;
				  }
			   else  continue;
			 }
		    else  break;
		}

	  if( s == NACK )
		{
		   for( i = 0 ; i < REQUEST - 1 ; i++ )
			 {
			   sendcmd( dtype , out_dat , len );
			   s = getstatus( dtype );
			   if( s != NACK && s != NOREPLY )
				  {
				    break;
				  }
			 }
		}
	  if( s == NOREPLY || s == NACK )
		 {
		   Status[ dtype ] = DEFAULT;
		 }
	  else if( s == ESC )
		 {
		 }
	  else if( s == ACK0 )
		 {
		 }
  }

/* End of senddat */



void   actreport( char report, int dtype )
  {
	  switch( report )
		{
			case I_R:
				Status[ dtype ] = _OK;
				break;
			case C_R:
				Status[ dtype ] = _OK;
				break;
			case E_R:
				Status[ dtype ] = _OK;
				break;
			case N_R:
				Status[ dtype ] = _OK;
				break;
			case L_R:
				Status[ dtype ] = LOCAL;
				break;
			default :
				break;
		}
  }

void   actstatus( char status , int dtype )
  {

  }

void   acknowrep( char r , int dtype )
  {
	  int i;

	  actreport( r , dtype );
	  for(  i = 0 ; i < REQUEST ; i++ )
		{
		   sendack( dtype );
		   r = getacknow( dtype );
		   if( r == EOT )
			{
			   break;
			}
		   else if( r == NACK )
			{
			   continue;
			}
		   else if( r == NOREPLY  && i == ( REQUEST - 1 ) )
			{
			   sendeot( dtype );
			   Status[ dtype ] = DEFAULT;
			   continue;
			}
		}
  }


void   initdevice( int dtype )
  {
	  device_fd[ dtype ] = open( device_file[ dtype ] , O_NDELAY | O_RDWR );
	  if( device_fd[ dtype ] == -1 )
		{
             Status[ dtype ] = MISSING;
             fprintf( errfile , "\nperipheral %d is missing\n" , dtype );		
                 }
	  else
		{
	           Status[ dtype ] = _OK; 
                   fprintf( errfile , "\nperipheral %d is OK\n" , dtype );	
                   ioctl( device_fd[ dtype ] , TCGETA , &device_old[ dtype ] );
		   ioctl( device_fd[ dtype ] , TCGETA , &device_new[ dtype ] );
		   device_new[ dtype ].c_cflag = ( device_new[ dtype ].c_cflag & ~CBAUD ) | B4800 ;
             device_new[ dtype ].c_cflag = ( device_new[ dtype ].c_cflag & ~CSIZE ) | CS7;
             device_new[ dtype ].c_cflag &= CSTOPB;
             device_new[ dtype ].c_cflag &= PARENB;
             device_new[ dtype ].c_cflag &= device_par[ dtype ];
		   device_new[ dtype ].c_oflag &= ICANON ;

		   ioctl( device_fd[ dtype ] , TCSETA , &device_new[ dtype ] );
		}
  }


void   testdevice( int dtype )
  {
	  int  i;
	  char r;

	  makepollstr( dtype );
	  for(  i = 0 ; i < REQUEST ; i++ )
		{
		    sendeot( dtype );
		    if( sendcmd( dtype , out_cmd , 4 ) == MISSING )
			 {
			    Status[ dtype ] = MISSING;
			    break;
			 }
		    r = getreport( dtype );
		    if( r == NOREPLY  )
			   {
				if( i == ( REQUEST - 1 ) )
				    {
					 sendeot( dtype );
					 Status[ dtype ] = DEFAULT;
					 break;
				    }
				else  continue;
			   }
		    else  break;
		}

	  if( r == LINEERR )
		{
		   for(  i = 0 ; i < REQUEST ; i++ )
			 {
			    sendnack( dtype );
			    r = getreport( dtype );
			    if(  r != LINEERR && r != NOREPLY )
				 {
				    break;
				 }
			 }
		}
	  if( r == NOREPLY || r == LINEERR )
		 {
		   Status[ dtype ] = DEFAULT;
		   sendeot( dtype );
		 }
	  else  acknowrep( r , dtype );
  }



void   talkdevice( int dtype , int len )
  {
	  int  i;
	  char s;
          
	  makeselstr( dtype );
	  for(  i = 0 ; i < REQUEST ; i++ )
		{
		    sendeot( dtype );
		    if( sendcmd( dtype , out_cmd ,  4 ) == MISSING )
			 {
			    Status[ dtype ] = MISSING;
			    break;
			 }
		    s = getacknow( dtype );
		    if( s == NOREPLY  )
			   {
				if( i == ( REQUEST - 1 ) )
				    {
					 Status[ dtype ] = DEFAULT;
					 break;
				   }
				 else   continue;
			   }
		    else   break;
		}
	  if( s == ACK0 )
		 {
		   senddat( dtype , len );
		 }
	  sendeot( dtype );
  }


void   stopdevice( int dtype )
  {
	  ioctl( device_fd[ dtype ] , TCSETA , &device_old[ dtype ] );
	  close( device_fd[ dtype ] );
  }


void initterm( void )
  {
	int  i;

	for( i = VP6 ; i <= RP4 ; i++ )
	   {
		initdevice( i );
	   }
	for( i = RQ4 ; i <= RW4 ; i++ )
	   {
		device_fd[ i ] = device_fd[ RP4 ];
	        Status[ i ] = Status[ RP4 ]; 
           }
           
  }

void stopterm( void )
  {
	int  i;

	for( i = VP6 ; i <= RP4 ; i++ )
	   {
		stopdevice( i );
	   }
  }

