# include "depart.h"

void   initdevice( void )
{
	device_fd = open( device_file , O_NDELAY|O_RDWR ); 

	ioctl( device_fd , TCGETA , &device_old );
	ioctl( device_fd , TCGETA , &device_new );

	device_new.c_iflag = DOSMODE; 
	device_new.c_oflag = 0; 
	device_new.c_lflag = 0; 
	device_new.c_cflag = B600|CS8|CSTOPB|CREAD|CLOCAL;
		
	ioctl( device_fd , TCSETAW , &device_new );
}


void  depgetack( void )
{
	long i;
	int  received;

	received = 0;
	for( i = 0 ; i < DEPREQ ; i++ )
	{
		if( ( received = read( device_fd , ( char* )in_rep , 1 ) ) > 0 ) 
		{
			received = 1; 
			break;
		}
	}
	if( received == 0 )
	{
		return; 
	}
	tcflush( device_fd , TCIOFLUSH ); 
}

void  depclear( void )
{
	out_dat[ 0 ] = LCSTART;
	out_dat[ 1 ] = LCCLS;
	out_dat[ 2 ] = LCEND;
	depsenddat( 3 );
}


void   depclock( void )   
{
	struct TIMEST  t;
	unsigned char  ts[ 5 ];
	int            len; 

	airtime( &t );
	sprintf( ts , "%4d" , t.hs );
	out_dat[ 0 ] = LCSTART; 
	out_dat[ 1 ] = LCCLOCK;
	out_dat[ 2 ] = NUL; 
	strcat( out_dat , ts ); 
	len = strlen( out_dat ); 
	out_dat[ len ] = LCEND; 	
	depsenddat( len + 1 ); 
}

void   depsenddat( int len )
{
	unsigned char s[ 2 ];
	int  i; 

	for( i = 0 ; i < len ; i++ )
	{
		s[ 0 ] = out_dat[ i ]; 
		initdevice(); 
		write( device_fd , s , 1 ); 
		stopdevice(); 
	}
	depgetack();
	sleep( 5 ); 
}


void   talkdevice( void )
{
	int  i, j, k, c ;
	FILE *fil;

	i = 0;
	j = 0;  
	fil = fopen ( "deplog" , "rt" ); 
	while( j < MAXADENT && !feof( fil ) )
	{
		fscanf( fil , "%c" , &c );
		out_dat[ i ] = c; 
		i++; 
		if( out_dat[ i - 1 ] == 'd' )
		{
			j++; 
			for( k = 0 ; k < i ; k++ )
			{
				if( out_dat[ k ] == 'c' )
				{
					out_dat[ k ] = CR;
				}
				if( out_dat[ k ] == 'd' )
				{
					out_dat[ k ] = LCEND; 
				}
				out_dat[ 0 ] = LCSTART; 
				out_dat[ 1 ] = LCNORM; 
			}
			depsenddat( i );
			i = 0; 
		}
	}
	fclose ( fil );
} 	

void   stopdevice( void )
{
	ioctl( device_fd , TCSETAW , &device_old );
	close( device_fd );
}

void main( void )
{
	depclear();
	sleep( 5 ); 
	depclock();
	sleep( 5 ); 
	talkdevice();
}

void  airtime( struct TIMEST* TT )
{
	struct  tm   *tp;	
	time_t        t;

	t = time( 0 );
	tp = localtime( &t );
	TT->hs = tp->tm_hour * 100 + tp->tm_min; 
	TT->md = ( tp->tm_mon + 1 ) * 100 + tp->tm_mday; 
	TT->day = tp->tm_wday + 1; 
	TT->year = tp->tm_year + 1900; 
}		
