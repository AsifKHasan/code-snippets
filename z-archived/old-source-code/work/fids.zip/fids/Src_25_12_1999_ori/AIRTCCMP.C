void tc_cmp( void )
  {
	 /**/
  }
