/* ------- finished and tested ------------ */


void coding_comp ( void )
{
	int a , escape = FALSE , ref = TRUE;
	while ( !escape )
	{
		if ( ref )
		{
			show ( scr3 );
			move ( 2 , 58 );
			printw  ( "%s",ftype_string[ _I ] );
			ref = FALSE;
		}
		a = getchoice ( 14 , 39 );
		switch ( a )
		{
		case '0':
			typ_fil();
			ref = TRUE;
			break;
		case '1':
			creation0();
			ref = TRUE;
			break;
		case '2':
			display0();
			ref = TRUE;
			break;
		case '3':
			modifn0();
			ref = TRUE;
			break;
		case '4':
			deletion0();
			ref = TRUE;
			break;
		case '5':
			verifn0();
			ref = TRUE;
			break;
		case '6':
			p_out0();
			ref = TRUE;
			break;
		case '7':
		case '8':
			move( 19 , 22 );
			printw ( "IMPOSSIBILITY WITH CODING FILES" );
			refresh ();
			ref = TRUE;

			sleep( 2 );
			move ( 19 , 22 );
			printw( "                               " );
			refresh ();

			break;
		case F16:
			escape = TRUE;
			break;
		}
	}
}

/*---------------------- FUNCTIONS UNDER SUBGROUP OF C_COMP ---------------*/

void typ_fil( void )
{
	int i;
	int p , q , r , s;
	char a[3];
	a[ 0 ] = 0;
	move ( 18 , 21 );
	printw ( "TYPE OF FILE ( DD,ID,DA,IA ) : ? " );
	refresh();
	gettext ( a , 2 , 18 , 55 );
	if ( a [ 0 ] == 1 &&  a [ 1 ] == 79 )
		return;
	for ( i = _IA ; i <= _DD ; i++ )
		if ( a[0] == ftype_string[i][0] && a[1] == ftype_string[i][1] )
			ftype = i;
	move ( 20 , 21 );
	printw ( "FROM  TO     ( WINTER PERIOD )" );
	move ( 21 , 21 );
	p = ( flight[ ftype ].winter_from % 10000 ) / 100;
	q = flight[ ftype ].winter_from % 100;
	r = ( flight[ ftype ].winter_to % 10000 ) / 100;
	s = ( flight[ ftype ].winter_to % 100 );
	printw ( "%.2d/%.2d %.2d/%.2d" , p , q , r , s );
	move ( 22 , 21 );
	printw ( "FROM  TO     ( SUMMER PERIOD )" );
	move ( 23 , 21 );
	p = ( flight[ ftype ].summer_from % 10000 ) / 100;
	q = flight[ ftype ].summer_from % 100;
	r = ( flight[ ftype ].summer_to % 10000 ) / 100;
	s = ( flight[ ftype ].summer_to % 100 );
	printw ( "%.2d/%.2d %.2d/%.2d" , p , q , r , s );

	refresh ();
	p = isdate ( getdate(flight[ ftype ].winter_from , 21 , 21 ) );
	if ( p != DN && p != F16 && p != UP )
		flight[ ftype ].winter_from = p;
	p = isdate ( getdate(flight[ ftype ].winter_to , 21 , 27 ) );
	if ( p != DN && p != F16 && p != UP )
		flight[ ftype ].winter_to = p;
	p = isdate ( getdate(flight[ ftype ].summer_from , 23 , 21 ) );
	if ( p != DN && p != F16 && p != UP )
		flight[ ftype ].summer_from = p;
	p = isdate ( getdate(flight[ ftype ].summer_to , 23 , 27 ) );
	if ( p != DN && p != F16 && p != UP )
		flight[ ftype ].summer_to = p;
}

void creation0( void )
{
	move ( 18 , 22 );
	if ( code_index == 10000 )
	{
		printw ( "Code maximum reached" );
		refresh();
		sleep ( 2 );
		return;
	}
	printw ( "IATA CODE     TOWN" );
	IATA[ code_index ].code[0] = 0;
	IATA[ code_index ].town[0] = 0;
	gettext ( IATA[ code_index ].code , 3 , 19 , 24 );
	if ( IATA[ code_index].code[ 0 ] != 0 && IATA[ code_index ].code[ 0 ] != 1 )
	{
		gettext ( IATA[ code_index ].town , 12 , 19 , 36 );
		if ( IATA[code_index].town[0] != 0 && IATA[ code_index ].town[ 0 ] != 1 )
		{
			int i , dupli = FALSE;
			for ( i = 0 ; i < code_index ; i++ )
			{
				if ( strcmp ( IATA[ i ].code , IATA[ code_index ].code ) == 0 )
				{
					dupli = TRUE;
				}
			}
			if ( !dupli )
			{
				code_index++;
			}
			else
			{
				move ( 18 , 15 );
				printw ("  IATA code already exists. Creation aborted.      " );
				refresh();
				sleep ( 1 );
			}
		}

	}
};



void display0( void )
{
	char temp[ 4 ];
	int i , done = FALSE;

	move ( 18 , 22 );
	printw ( "IATA CODE     TOWN");
	while ( !done )
	{
		move( 19 , 24 );
		printw( "                                  ");
		temp[ 0 ] = 0;
		gettext ( temp , 3 , 19 , 24 );
		if ( temp[0] == 0 ) return;
		for ( i = 0 ; i < code_index ; i ++ )
		{
			if ( temp[0] == IATA[i].code[0]
			    && temp[1] == IATA[ i ].code[1]
			    && temp[2] == IATA[i].code[2] )
			{
				done = TRUE;  
				break;
			}
		}
		if ( !done )
		{
			move ( 19 , 36 );
			printw ( "Unknown IATA code" );
			refresh();
			sleep ( 2 );
		}
	}
	move( 19 , 36 ) ;
	printw ( "%s" , IATA[i].town );
	refresh();
	getch();
};


void modifn0( void )
{
	char temp[ 4 ];
	int i , done = FALSE;
	temp[ 0 ] = 0;
	move ( 18 , 22 );
	printw ( "IATA CODE     TOWN");
	while ( !done )
	{
		move( 19 , 24 );
		printw( "                                  ");
		gettext ( temp , 3 , 19 , 24 );
		if ( temp[0] == 0 ) return;
		for ( i = 0 ; i < code_index ; i ++ )
		{
			if ( temp[0] == IATA[i].code[0] && temp[1] == IATA[ i ].code[1]&&
			    temp[2] == IATA[i].code[2] )
			{
				done = TRUE;  
				break;
			}
		}
		if ( !done )
		{
			move ( 19 , 36 );
			printw ( "Unknown IATA code" );
			refresh();
			sleep ( 2 );
		}
	}
	gettext( IATA[i].town , 12 , 19 , 36 );

};

void deletion0( void )
{
	char temp[ 4 ];
	int i , done = FALSE;
	temp[ 0 ] = 0;
	move ( 18 , 22 );
	printw ( "IATA CODE     TOWN");
	while ( !done )
	{
		move( 19 , 24 );
		printw( "                                  ");
		gettext ( temp , 3 , 19 , 24 );
		if ( temp[0] == 0 ) return;
		for ( i = 0 ; i < code_index ; i ++ )
		{
			if ( temp[0] == IATA[i].code[0] && temp[1] == IATA[ i ].code[1]&&
			    temp[2] == IATA[i].code[2] )
			{
				done = TRUE;  
				break;
			}
		}
		if ( !done )
		{
			move ( 19 , 36 );
			printw ( "Unknown IATA code" );
			refresh();
			sleep ( 2 );
		}
	}
	move( 19 , 36 ) ;
	printw ( "%s" , IATA[i].town );
	move ( 20 , 24 );
	printw( "Deletion confirm ?" );
	refresh();
	temp[ 0 ] = 0;
	gettext( temp , 1 , 20 , 43 );
	if ( temp[ 0 ] == 'Y' || temp[ 0 ] == 'y' )
	{
		IATA[ i ] = IATA[ code_index - 1 ];
		code_index--;
	}
};

void verifn0( void )
{
	int row, i;
	clear();
	move ( 0 , 15 );
	printw( "IATA CODE       TOWN" );
	for ( i = 0 , row = 1 ; i < code_index ; i++ , row++ )
	{
		move ( row + 1 , 15 );
		printw ("%s              %s" , IATA[i].code , IATA[i].town );
		if ( row > 20 || i == code_index - 1 )
		{
			char second , first;
			row = 1;
			refresh();
			first = getch();
			if ( first == 1 )
			{
				first  == getch();
				second == getch();
				if ( first == 79 && second == 10 )
					return;
			}
			clear();
			move( 0 , 15 );
			printw( "IATA CODE     TOWN" );
			refresh();
		}
	}
};



void p_out0( void )
{
	int row, i , first = TRUE;
	clear();
	move ( 1 , 0 );
	printw( "IATA CODE ..... TOWN" );
	for ( i = 0 , row = 2 ; i < code_index ; i++ , row++ )
	{
		move ( row , 0 );
		printw( "%s ........... %s" , IATA[ i ].code , IATA[ i ].town );
		if ( row == 23 || i == code_index - 1 )
		{
			refresh();
			endwin();
			printf( "%cP\n" , 27 );
			sleep ( 10 );
			initscr();
			noecho();
			row = 1;
			clear();
		}
	}
};

