void arriv_exp( void )
{
	int row = 2 , col = 0;
	int arr = 0 ;
	int curr_pos = 0 , key = 0;
	int ref = TRUE;
	int finished = FALSE;
	struct exploitation last;
	int posindex;
	struct TIMEST tim;

	if ( numaexp == 0 )
	{
		airtime( &tim );
		last.date = tim.md;
		last.day = tim.day;
		sprintf ( last.sche , "%.4d" , tim.hs );
	}
	else 
	{
		last = arrival[ numaexp - 1 ];
	}
	clear();
	while( numaexp < L_LIM )
	{
		arrival[ numaexp ] = choose ( last , _DA , _IA );
		last = arrival[ numaexp ];
		numaexp++;
	}

	/* End of reading. Display now. */

	while ( !finished )
	{
		if ( ref )
		{
			show_aexp ( curr_pos );
			if ( row == LINE_NO && rows[ row ] )
				row = LINE_NO - 1;
			ref = FALSE;
		}
		move ( row , col );
		key = getkey();
		posindex = row - _lines( row ) + curr_pos - 1;
		switch ( key )
		{
		case UP:
			if ( row + curr_pos > 2 )
			{
				row --;
				if ( row < 2 )
				{
					row = 2;
					curr_pos --;
					ref = TRUE;
				}
				else if ( rows[ row ] )
				{
					row--;
					if ( row < 2 )
					{
						row = 2;
						curr_pos --;
						ref = TRUE;
					}
				}
			}
			break;
		case DN:
			if ( posindex + curr_pos < numaexp )
			{
				row ++;

				if ( row > LINE_NO )
				{
					row = LINE_NO;
					curr_pos ++;
					ref = TRUE;
				}
				else if ( rows[ row ] )
				{
					row++;
					if ( row > LINE_NO )
					{
						row = LINE_NO;
						curr_pos ++;
						ref = TRUE;
					}
				}
			}
			break;
		case LT:
			if ( col > 0 )
			{
				col--;
			}
			else
			{
				col = 79;
			}
			break;

		case RT:
			if ( col < 79 )
			{
				col++;
			}
			else
			{
				col = 0;
			}
			break;
		case BACKTAB:
			btaba( &col );
			break;
		case TAB:
			taba ( &col );
			break;
		case F14:
			col = 0;
			break;
		case F6:
			if ( col >= 28 && col <= 30 )
			{
				char ctemp[ 4 ];
				char ttemp[ 13 ];
				move ( 23 , 0 );
				printw( "                                                                                " );
				move ( 23 , 0 );
				strcpy( ctemp , arrival[ posindex ].dest );
				strcpy ( ttemp , town( ctemp ) );
				printw( "IATA CODE: %s   TOWN: %s" , ctemp , ( ttemp[ 0 ] == 0 ) ? "Unknown IATA code" :
				    ttemp );
			}
			else if ( col >= 34 && col <= 36 )
			{
				char ctemp[ 4 ];
				char ttemp[ 13 ];
				move ( 23 , 0 );
				printw( "                                                                                " );
				move ( 23 , 0 );
				strcpy ( ctemp , arrival[ posindex ].via );
				strcpy( ttemp , town( ctemp ) );
				printw( "IATA CODE: %s   TOWN: %s" , ctemp , ( ttemp[ 0 ] == 0 ) ? "Unknown IATA code" :
				    ttemp );
			}
			else
			{
				move ( 23 , 0 );
				printw( "                                                                                " );
			}
			break;



		case F7: /* Roll up */
			delete( arrival , posindex + 1 , TRUE , numaexp);
			modified ( arrival , numaexp );
			numaexp--;
			if ( numaexp < L_LIM )
			{
				arrival [ numaexp ] = choose( arrival[ numaexp - 1 ] , _DA , _IA );
				numaexp++;
			}

			ref = TRUE;
			break;
		case F8: /* Roll up recup */
			delete( arrival , posindex + 1 , FALSE , numaexp);
			modified ( arrival , numaexp );
			ref = TRUE;
			break;
		case F9:
			if ( numaexp < U_LIM )
			{
				inserta ( posindex , row , curr_pos );
				modified ( arrival , numaexp );
				ref = TRUE;
			}
			else
			{
				move ( 23 , 0 );
				printw ( "Maximum roll down. No more roll down possible." );
				refresh();
				sleep ( 2 );
				move ( 23 , 0 );
				printw( "                                               " );
				refresh();
			}
			break;

		case F10:
			move ( row , 0 );
			printw( "                                                                                " );
			getlined ( posindex ,  row );
			modified ( arrival , numaexp );
			ref = TRUE;
			break;

		case F11:
			getfielda ( posindex , row , col );
			modified ( arrival , numaexp );
			ref = TRUE;
			break;
		case F12:
			move( 23 , 0 );
			printw( "Validation in progress. Please wait." );
			refresh();
			make_arr_output ( arrival );
			flushinp();
			ref = TRUE;
			break;
		case F13:
			modified ( arrival , numaexp );
                        if ( arrival[ posindex ].flash == 'F' )
                        {
			        arrival[ posindex ].flash = 0;
                        }
                        else
                        {
			        arrival[ posindex ].flash = 'F';
                        }

			ref = TRUE;
			break;


		case F15:
			modified ( arrival , numaexp );
			edita ( posindex , row , col );
			ref = TRUE;
			break;


		case F16:
			finished = TRUE;
			break;
		}
	}


}


