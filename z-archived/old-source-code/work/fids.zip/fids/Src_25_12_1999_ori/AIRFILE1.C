/* File finished. Flight composition  */

void flight_comp( void )
{
	int a , escape = FALSE , ref = TRUE;
	while ( !escape )
	{
		if ( ref )
		{
			show ( scr3 );
			move ( 2 , 58 );
			printw ( "%s",ftype_string[ ftype ] );
			ref = FALSE;
		}

		a = getchoice ( 14 , 39 );
		switch ( a )
		{
		case '0':
			typ_fil();
			ref = TRUE;
			break;
		case '1':
			creation();
			break;
		case '2':
			display();
			break;
		case '3':
			modifn();
			break;
		case '4':
			deletion();
			break;
		case '5':
			verifn();
			ref = TRUE;
			break;
		case '6':
			p_out();
			ref = TRUE;
			break;
		case '7':
			o_all_modn();
			break;
		case '8':
			calendar();
			ref = TRUE;
			break;
		case F16:
			escape = TRUE;
			break;
		}
	}
}


/*---------------------- FUNCTIONS UNDER SUBGROUP OF F_COMP ---------------*/

void creation( void )
{
	if ( not_selected() )
	{
		return;
	}
	move ( 20 , 5 );
	printw ( "flight              time           to           via       gate" );
	move ( 21 , 5 );
	printw ( "phr/v     ......    ......         ......" );
	move ( 22 , 5 );
	printw ( "periods" );
	gettext ( flights[ ftype ][ flight_index[ ftype ] ].num  , 7 , 20 , 15 );
	if ( flights[ ftype ][ flight_index[ ftype ] ].num[ 0 ] == 0
	    || dupli_f (  flights[ ftype ][ flight_index[ ftype ] ].num ) )
	{
		cle();
		return;
	}

	gettext ( flights[ ftype ][ flight_index[ ftype ] ].time , 4 , 20 , 30 );
	gettext ( flights[ ftype ][ flight_index[ ftype ] ].dest , 3 , 20 , 43 );
	gettext ( flights[ ftype ][ flight_index[ ftype ] ].via  , 3 , 20 , 57 );
	gettext ( flights[ ftype ][ flight_index[ ftype ] ].gate , 2 , 20 , 68 );
	flights[ ftype ][ flight_index[ ftype ] ].per1 = 
		getdate1 ( 0 , 22 , 15 );
	flights[ ftype ][ flight_index[ ftype ] ].per2 = 
		getdate1 ( 0 , 22 , 21 );
	gettext ( flights[ ftype ][ flight_index[ ftype ] ].day  , 9 , 22 , 27 );

	flights[ ftype ][ flight_index[ ftype ] ].per11 = 
		getdate1 ( 0 , 22 , 35 );
	flights[ ftype ][ flight_index[ ftype ] ].per12 = 
		getdate1 ( 0 , 22 , 41 );
	gettext ( flights[ ftype ][ flight_index[ ftype ] ].day1  , 9 , 22 , 47 );

	flights[ ftype ][ flight_index[ ftype ] ].per21 = 
		getdate1 ( 0 , 22 , 55 );
	flights[ ftype ][ flight_index[ ftype ] ].per22 = 
		getdate1 ( 0 , 22 , 61 );
	gettext ( flights[ ftype ][ flight_index[ ftype ] ].day2  , 9 , 22 , 67 );

	flights[ ftype ][ flight_index[ ftype ] ].per31 = 
		getdate1 ( 0 , 23 , 15 );
	flights[ ftype ][ flight_index[ ftype ] ].per32 = 
		getdate1 ( 0 , 23 , 21 );
	gettext ( flights[ ftype ][ flight_index[ ftype ] ].day3  , 9 , 23 , 27 );

	date_trans( &flights[ ftype ][ flight_index[ ftype ] ].per1 , &flights[ ftype ][ flight_index[ ftype ] ].per2 , ftype );
	date_trans( &flights[ ftype ][ flight_index[ ftype ] ].per11 , &flights[ ftype ][ flight_index[ ftype ] ].per12 , ftype );
	date_trans( &flights[ ftype ][ flight_index[ ftype ] ].per21 , &flights[ ftype ][ flight_index[ ftype ] ].per22 , ftype );
	date_trans( &flights[ ftype ][ flight_index[ ftype ] ].per31 , &flights[ ftype ][ flight_index[ ftype ] ].per32 , ftype );

	flight_index[ ftype ]++;
	move ( 20 , 0 );
	printw ( "                                                                                " );
	move ( 21 , 0 );
	printw ( "                                                                                " );
	move ( 22 , 0 );
	printw ( "                                                                                " );
	move ( 23 , 0 );
	printw ( "                                                                                " );
	refresh();

}

void display( void )
{
	int i , match , found = FALSE;
	char temp[ 8 ];
	temp[ 0 ] = 0;

	if ( not_selected() )
	{
		return;
	}

	move ( 18 , 25 );
	printw ( "flight" );
	refresh ();
	gettext ( temp , 7 , 18 , 32 );
	move ( 18 , 25 );
	printw ( "                                                       " );
	refresh ();
	for ( i = 0 ; i <= flight_index[ ftype ] ; i++ )
	{
		match = strcmp ( temp , flights[ ftype ][ i ].num );
		if ( match == 0 )
		{
			found = TRUE;
			break;
		}
	}
	if ( !found )
	{
		move ( 18 , 29 );
		printw ( "UNKNOWN NUMBER" );
		refresh();
		sleep ( 2 );
		move ( 18 , 22 );
		printw( "              " );
		refresh();
		return;
	}
	move ( 20 , 5 );
	printw ( "flight              time           to           via       gate" );
	move ( 21 , 5 );
	printw ( "phr/v     ......    ......         ......" );
	move ( 22 , 5 );
	printw ( "periods" );
	move ( 20 , 15 );
	printw ( "%s" , flights[ ftype ][ i ].num );
	move ( 20 , 30 );
	printw ( "%s" , flights[ ftype ][ i ].time );
	move ( 20 , 43 );
	printw ( "%s" , flights[ ftype ][ i ].dest );
	move ( 20 , 57 );
	printw ( "%s" , flights[ ftype ][ i ].via );
	move ( 20 , 69 );
	printw ( "%s" , flights[ ftype ][ i ].gate );

	move ( 22 , 15 );
	printw ( "%.2d/%.2d" , flights[ ftype ][ i ].per1/100 , flights[ ftype ][ i ].per1 % 100 );
	move ( 22 , 21 );
	printw ( "%.2d/%.2d" , flights[ ftype ][ i ].per2/100 , flights[ ftype ][ i ].per2 % 100 );
	move ( 22 , 27 );
	printw ( "%s" , flights[ ftype ][ i ].day );

	move ( 22 , 35 );
	printw ( "%.2d/%.2d" , flights[ ftype ][ i ].per11/100 , flights[ ftype ][ i ].per11 % 100 );
	move ( 22 , 41 );
	printw ( "%.2d/%.2d" , flights[ ftype ][ i ].per12/100 , flights[ ftype ][ i ].per12 % 100 );
	move ( 22 , 47 );
	printw ( "%s" , flights[ ftype ][ i ].day1 );

	move ( 22 , 55 );
	printw ( "%.2d/%.2d" , flights[ ftype ][ i ].per21/100 , flights[ ftype ][ i ].per21 % 100 );
	move ( 22 , 61 );
	printw ( "%.2d/%.2d" , flights[ ftype ][ i ].per22/100 , flights[ ftype ][ i ].per22 % 100 );
	move ( 22 , 67 );
	printw ( "%s" , flights[ ftype ][ i ].day2 );

	move ( 23 , 15 );
	printw ( "%.2d/%.2d" , flights[ ftype ][ i ].per31/100 , flights[ ftype ][ i ].per31 % 100 );
	move ( 23 , 21 );
	printw ( "%.2d/%.2d" , flights[ ftype ][ i ].per32/100 , flights[ ftype ][ i ].per32 % 100 );
	move ( 23 , 27 );
	printw ( "%s" , flights[ ftype ][ i ].day3 );

	refresh ();
	getch ();
	move ( 20 , 0 );
	printw ( "                                                                                " );
	move ( 21 , 0 );
	printw ( "                                                                                " );
	move ( 22 , 0 );
	printw ( "                                                                                 " );
	move ( 23 , 0 );
	printw ( "                                                                                 " );

	refresh ();

}
void modifn( void )
{

	int i , match , found = FALSE;
	char temp[ 8 ];
	temp[ 0 ] = 0;
	if ( not_selected() )
	{
		return;
	}

	move ( 18 , 25 );
	printw ( "flight" );
	refresh ();
	gettext ( temp , 7 , 18 , 32 );
	move ( 18 , 25 );
	printw ( "                                     " );
	refresh ();
	for ( i = 0 ; i <= flight_index[ ftype ] ; i++ )
	{
		match = strcmp ( temp , flights[ ftype ][ i ].num );
		if ( match == 0 )
		{
			found = TRUE;
			break;
		}
	}
	if ( !found )
	{
		move ( 18 , 29 );
		printw ( "UNKNOWN NUMBER" );
		refresh();
		sleep ( 2 );
		move ( 18 , 22 );
		printw( "              " );
		refresh();
		return;
	}
	move ( 20 , 5 );
	printw ( "flight              time           to           via       gate" );
	move ( 21 , 5 );
	printw ( "phr/v     ......    ......         ......" );
	move ( 22 , 5 );
	printw ( "periods" );
	move ( 20 , 15 );
	printw ( "%s" , flights[ ftype ][ i ].num );
	move ( 20 , 30 );
	printw ( "%s" , flights[ ftype ][ i ].time );
	move ( 20 , 43 );
	printw ( "%s" , flights[ ftype ][ i ].dest );
	move ( 20 , 57 );
	printw ( "%s" , flights[ ftype ][ i ].via );
	move ( 20 , 69 );
	printw ( "%s" , flights[ ftype ][ i ].gate );
	move ( 22 , 15 );
	printw ( "%.2d/%.2d" , flights[ ftype ][ i ].per1/100 , flights[ ftype ][ i ].per1 % 100 );
	move ( 22 , 21 );
	printw ( "%.2d/%.2d" , flights[ ftype ][ i ].per2/100 , flights[ ftype ][ i ].per2 % 100 );
	move ( 22 , 27 );
	printw ( "%s" , flights[ ftype ][ i ].day );

	move ( 22 , 35 );
	printw ( "%.2d/%.2d" , flights[ ftype ][ i ].per11/100 , flights[ ftype ][ i ].per11 % 100 );
	move ( 22 , 41 );
	printw ( "%.2d/%.2d" , flights[ ftype ][ i ].per12/100 , flights[ ftype ][ i ].per12 % 100 );
	move ( 22 , 47 );
	printw ( "%s" , flights[ ftype ][ i ].day1 );

	move ( 22 , 55 );
	printw ( "%.2d/%.2d" , flights[ ftype ][ i ].per21/100 , flights[ ftype ][ i ].per21 % 100 );
	move ( 22 , 61 );
	printw ( "%.2d/%.2d" , flights[ ftype ][ i ].per22/100 , flights[ ftype ][ i ].per22 % 100 );
	move ( 22 , 66 );
	printw ( "%s" , flights[ ftype ][ i ].day2 );

	move ( 23 , 15 );
	printw ( "%.2d/%.2d" , flights[ ftype ][ i ].per31/100 , flights[ ftype ][ i ].per31 % 100 );
	move ( 23 , 21 );
	printw ( "%.2d/%.2d" , flights[ ftype ][ i ].per32/100 , flights[ ftype ][ i ].per32 % 100 );
	move ( 23 , 27 );
	printw ( "%s" , flights[ ftype ][ i ].day3 );


	refresh ();
	gettext ( flights[ ftype ][ i ].num  , 7 , 20 , 15 );
	gettext ( flights[ ftype ][ i ].time , 4 , 20 , 30 );
	gettext ( flights[ ftype ][ i ].dest , 3 , 20 , 43 );
	gettext ( flights[ ftype ][ i ].via  , 3 , 20 , 57 );
	gettext ( flights[ ftype ][ i ].gate , 2 , 20 , 69 );

	flights[ ftype ][ i ].per1 =
	    getdate1 ( flights[ ftype ][ i ].per1 , 22 , 15 );
	flights[ ftype ][ i ].per2 =
	    getdate1 ( flights[ ftype ][ i ].per2 , 22 , 21 );
	gettext ( flights[ ftype ][ i ].day  , 9 , 22 , 27 );

	flights[ ftype ][ i ].per11 =
	    getdate1 ( flights[ ftype ][ i ].per11 , 22 , 35 );
	flights[ ftype ][ i ].per12 =
	    getdate1 ( flights[ ftype ][ i ].per12 , 22 , 41 );
	gettext ( flights[ ftype ][ i ].day1  , 9 , 22 , 47 );

	flights[ ftype ][ i ].per21 =
	    getdate1 ( flights[ ftype ][ i ].per21 , 22 , 55 );
	flights[ ftype ][ i ].per22 =
	    getdate1 ( flights[ ftype ][ i ].per22 , 22 , 61 );
	gettext ( flights[ ftype ][ i ].day2  , 9 , 22 , 67 );

	flights[ ftype ][ i ].per31 =
	    getdate1 ( flights[ ftype ][ i ].per31 , 23 , 15 );
	flights[ ftype ][ i ].per32 =
	    getdate1 ( flights[ ftype ][ i ].per32 , 23 , 21 );
	gettext ( flights[ ftype ][ i ].day3  , 9 , 23 , 27 );
	date_trans( &flights[ ftype ][ flight_index[ ftype ] ].per1 , &flights[ ftype ][ flight_index[ ftype ] ].per2 , ftype );
	date_trans( &flights[ ftype ][ flight_index[ ftype ] ].per11 , &flights[ ftype ][ flight_index[ ftype ] ].per12 , ftype );
	date_trans( &flights[ ftype ][ flight_index[ ftype ] ].per21 , &flights[ ftype ][ flight_index[ ftype ] ].per22 , ftype );
	date_trans( &flights[ ftype ][ flight_index[ ftype ] ].per31 , &flights[ ftype ][ flight_index[ ftype ] ].per32 , ftype );

	move ( 20 , 0 );
	printw ( "                                                                                " );
	move ( 21 , 0 );
	printw ( "                                                                                " );
	move ( 22 , 0 );
	printw ( "                                                                                " );
	move ( 23 , 0 );
	printw ( "                                                                                " );

}


int dupli_f ( char* text )
{
	int i;

	for ( i = 0 ; i < flight_index[ ftype ] ; i++ )
	{
		if ( strcmp ( text ,  flights[ ftype ][ i ].num ) == 0 )
		{
			move ( 23 , 10 );
			printw ( "Flight already exists. Creation aborted." );
			refresh();
			sleep ( 2 );
			move ( 23 , 10 );
			printw ( "                                        " );
			refresh();
			return TRUE;
		}
	}
	return FALSE;
}
