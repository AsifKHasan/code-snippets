void tc_vis( void )
  {
	 /**/
  }
