void  airtime( struct TIMEST* TT )
{
	struct  tm   *tp;	
	time_t        t;

	t = time( 0 );
	tp = localtime( &t );
	TT->hs = tp->tm_hour * 100 + tp->tm_min; 
	TT->md = ( tp->tm_mon + 1 ) * 100 + tp->tm_mday; 
	TT->day = tp->tm_wday + 1; 
	TT->year = tp->tm_year + 1900; 
}		
