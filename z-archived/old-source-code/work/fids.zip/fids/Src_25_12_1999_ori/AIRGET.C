
int gettime( int olddate , char row , char col )
{
	int newdate = 0 , i , factor;
	char first, second;
	move( row , col );
	printw( "%.2d/%.2d" , olddate / 100 , olddate % 100 );
	refresh();
	i = 5;
	newdate = olddate;
	factor = 0;
	col = col + 5;
	move ( row , col );
	refresh();
	while( i <= 5)
	{
		first = getch();
		if ( ( first == BKSP ) && i != 0 )
		{
			col --;
			i--;
			if ( i != 2 )
			{
				if ( factor == 0 ) factor = 1 ;
				else factor = factor * 10;
				newdate = newdate -  newdate % ( factor * 10 );
			}
			move ( row , col );
			refresh();
		}
		else
		{
			if ( i == 5 )
			{
				if ( first == 10 || first == '\t' )
				{
					return newdate;
				}
			}
			else
			{
				if ( i == 2 )
				{
					if ( first == ':' )
					{
						printw ( "%c" , ':' );
						refresh();
						i++; 
						col++;
					}
				}
				else if (  first >= '0' && first <= '9' )
				{
					printw ( "%c" , first );
					refresh();
					i++; 
					col++;
					newdate += ( first - '0' ) * factor;
					factor = factor / 10;
				}
			}
		}
	}
};

