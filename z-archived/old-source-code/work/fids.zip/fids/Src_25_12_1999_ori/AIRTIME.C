# include <time.h>
# include <stdio.h>
# include <sys/types.h>

struct TIMEST
	{
	   int  hs;
	   int  md;
           int  day;
	   int  year;
        }; 

void  airtime( struct TIMEST* );
	
void  main( void )
{
	struct TIMEST   tim;
	
	airtime( &tim );




        printf( "\nTime : %d\n" , tim.hs ); 
        printf( "\nDate : %d\n" , tim.md ); 
        printf( "\nDate : %d\n" , tim.day );
	printf( "\nYear : %d\n" , tim.year );
}



int isleap ( void )
{
	struct TIMEST tim;
	int year;

	airtime( &tim );
	if ( ( tim.year % 4 == 0 ) && ( tim.year % 100 != 0 ) )
	{
		return TRUE;
	}
	else
	{
		return FALSE;
	}
}	
void  airtime( struct TIMEST* TT )
{
	struct  tm   *tp;	
	time_t        t;

	t = time( 0 );
	tp = localtime( &t );
	TT->hs = tp->tm_hour * 100 + tp->tm_min; 
	TT->md = ( tp->tm_mon + 1 ) * 100 + tp->tm_mday; 
	TT->day = tp->tm_wday + 1; 
	TT->year = tp->tm_year + 1900; 
}		
