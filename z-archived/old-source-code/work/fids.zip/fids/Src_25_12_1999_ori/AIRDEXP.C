void depart_exp( void )
{
	int row = 2 , col = 0;
	int dep = 0 ;
	int curr_pos = 0 , key = 0;
	int ref = TRUE;
	int finished = FALSE;
	struct exploitation last;
	int posindex;
	struct TIMEST tim;

	if ( numdexp == 0 )
	{
		airtime ( &tim );
		last.date = tim.md;
		last.day = tim.day;
		sprintf ( last.sche , "%.4d" , tim.hs );
	}
	else
	{
		last = departure[ numdexp - 1];
	}	
	clear();
	while( numdexp < L_LIM )
	{
		departure[ numdexp ] = choose ( last , _DD , _ID );
		last = departure[ numdexp ];
		numdexp++;
	}

	/* End of reading. Display now. */

	while ( !finished )
	{
		if ( ref )
		{
			show_dexp ( curr_pos );
			if ( row == LINE_NO && rows[ row ] )
				row = LINE_NO - 1;
			ref = FALSE;
		}
		move ( row , col );
		key = getkey();
		posindex = row - _lines( row ) + curr_pos - 1;
		switch ( key )
		{
		case UP:
			if ( posindex + curr_pos > 0 )
			{
				row --;
				if ( row < 2 )
				{
					row = 2;
					curr_pos --;
					ref = TRUE;
				}
				else if ( rows[ row ] )
				{
					row--;
					if ( row < 2 )
					{
						row = 2;
						curr_pos --;
						ref = TRUE;
					}
				}
			}
			break;
		case DN:
			if ( posindex + curr_pos < numdexp )
			{
				row ++;

				if ( row > LINE_NO )
				{
					row = LINE_NO;
					curr_pos ++;
					ref = TRUE;
				}
				else if ( rows[ row ] )
				{
					row++;
					if ( row > LINE_NO )
					{
						row = LINE_NO;
						curr_pos ++;
						ref = TRUE;
					}
				}
			}
			break;
		case LT:
			if ( col > 0 )
			{
				col--;
			}
			else
			{
				col = 79;
			}
			break;

		case RT:
			if ( col < 79 )
			{
				col++;
			}
			else
			{
				col = 0;
			}
			break;
		case BACKTAB:
			btabd( &col );
			break;
		case TAB:
			tabd ( &col );
			break;
		case F14:
			col = 0;
			break;
		case F6:
			if ( col >= 28 && col <= 30 )
			{
				char ctemp[ 4 ];
				char ttemp[ 13 ];
				move ( 23 , 0 );
				printw( "                                                                                " );
				move ( 23 , 0 );
				strcpy( ctemp , departure[ posindex ].dest );
				strcpy ( ttemp , town( ctemp ) );
				printw( "IATA CODE: %s   TOWN: %s" , ctemp , ( ttemp[ 0 ] == 0 ) ? "Unknown IATA code" :
				    ttemp );
			}
			else if ( col >= 34 && col <= 36 )
			{
				char ctemp[ 4 ];
				char ttemp[ 13 ];
				move ( 23 , 0 );
				printw( "                                                                                " );
				move ( 23 , 0 );
				strcpy ( ctemp , departure[ posindex ].via );
				strcpy( ttemp , town( ctemp ) );
				printw( "IATA CODE: %s   TOWN: %s" , ctemp , ( ttemp[ 0 ] == 0 ) ? "Unknown IATA code" :
				    ttemp );
			}
			else
			{
				move ( 23 , 0 );
				printw( "                                                                                " );
			}
			break;



		case F7: /* Roll up */
			delete( departure , posindex + 1 , TRUE ,numdexp);
			modified ( departure , numdexp );
			numdexp--;
			if ( numdexp < L_LIM )
			{
				departure [ numdexp ] = choose( departure[ numdexp - 1 ] , _DD , _ID );
				numdexp++;
			}

			ref = TRUE;
			break;
		case F8: /* Roll up recup */
			delete( departure , posindex + 1 , FALSE ,numdexp);
			modified ( departure , numdexp );
			ref = TRUE;
			break;
		case F9:
			if ( numdexp < U_LIM )
			{
				insertd ( posindex , row , curr_pos );
				modified ( departure , numdexp );
				ref = TRUE;
			}
			else
			{
				move ( 23 , 0 );
				printw ( "Maximum roll down. No more roll down possible." );
				refresh();
				sleep ( 2 );
				move ( 23 , 0 );
				printw( "                                               " );
				refresh();
			}
			break;

		case F10:
			move ( row , 0 );
			printw( "                                                                                " );
			getlined ( posindex ,  row );
			modified ( departure , numdexp );
			ref = TRUE;
			break;

		case F11:
			getfieldd ( posindex , row , col );
			modified ( departure , numdexp );
			ref = TRUE;
			break;
		case F12:
			move( 23 , 0 );
			printw( "Validation in progress. Please wait." );
			refresh();
			make_dep_output ( departure );
			flushinp();
			ref = TRUE;
			break;
		case F13:
			modified ( departure , numdexp );
			if ( departure[ posindex ].flash == 'F' )
			{
				departure[ posindex ].flash = 0;
			}
			else
			{
				departure[ posindex ].flash = 'F';
			}						
			ref = TRUE;
			break;


		case F15:
			modified ( departure , numdexp );
			editd ( posindex , row , col );
			ref = TRUE;
			break;


		case F16:
			finished = TRUE;
			break;
		}
	}


}


