/*--------------- GetKey ----------------*/

int getkey ( void )
{
	char a , b;
	int c;
	a = getch ();
	if ( a == 1 )
	{
		a = getch ();
		b = getch ();
		c = a * 256 + b;
	}
	else if ( a == 126 )
	{
		b = getch();
		if ( b == 12 ) c = UP;
		if ( b == 11 ) c = DN;
	}
	else
	{
		c = a;
	}
	return c;
};


/*--------------- GetDate ----------------*/
int getdate ( int olddate , char row , char col )
{
	int newdate = 0 , i , factor;
	char first, second;
	if ( olddate == 0 )
	{
		i = 0;
		factor = 1000;
	}
	else
	{
		i = 5;
		newdate = olddate;
		factor = 0;
		col = col + 5;
	}
	move ( row , col );
	refresh();
	while( i <= 5)
	{
		first = getch();
		if ( first == '.' ) first = 0;
		if ( ( first == BKSP ) && i != 0 )
		{
			col --;
			i--;
			if ( i != 2 )
			{
				if ( factor == 0 ) factor = 1 ;
				else factor = factor * 10;
				newdate = newdate -  newdate % ( factor * 10 );
			}
			move ( row , col );
			refresh();
		}

		else if ( first == UP )
			return UP;
		else if ( ( first == DN || first == '\t' ) && i == 0 )
			return DN;
		else if ( first == 1 )
		{
			first = getch();
			second = getch();
			if ( first == 79 && second == 10 )
				return F16;
		}
		else
		{
			if ( i == 5 )
			{
				if ( first == 10 || first == '\t' )
				{
					newdate = isdate ( newdate );
					return newdate;
				}
			}
			else
			{
				if ( i == 2 )
				{
					if ( first == '/' )
					{
						printw ( "%c" , '/' );
						refresh();
						i++; 
						col++;
					}
				}
				else if (  first >= '0' && first <= '9' )
				{
					printw ( "%c" , first );
					refresh();
					i++; 
					col++;
					newdate += ( first - '0' ) * factor;
					factor = factor / 10;
				}
			}
		}
	}
};



int getdate1 ( int olddate , char row , char col )
{
	int newdate = 0 , i , factor;
	char first, second;
	move( row , col );
	printw( "%.2d/%.2d" , olddate / 100 , olddate % 100 );
	refresh();
	if ( olddate == 0 )
	{
		i = 0;
		factor = 1000;
	}
	else
	{
		i = 5;
		newdate = olddate;
		factor = 0;
		col = col + 5;
	}
	move ( row , col );
	refresh();
	while( i <= 5)
	{
		first = getch();
		if ( first == 'W' && i == 0 )
		{
			printw( "%c    " , 'W' );
			return 'W';	
		}
		else if ( first == 'S' && i == 0 )
		{
			printw( "%c    " , 'S' );
			return 'S';
		}
		if ( first == '.' ) first = 0;
		if ( ( first == BKSP ) && i != 0 )
		{
			col --;
			i--;
			if ( i != 2 )
			{
				if ( factor == 0 ) factor = 1 ;
				else factor = factor * 10;
				newdate = newdate -  newdate % ( factor * 10 );
			}
			move ( row , col );
			refresh();
		}

		else if ( ( first == DN || first == '\t' ) && i == 0 )
			return 0;
		else if ( first == 1 )
		{
			first = getch();
			second = getch();
			if ( first == 79 && second == 10 )
				return 0;
		}
		else
		{
			if ( i == 5 )
			{
				if ( first == 10 || first == '\t' )
				{
					newdate = isdate ( newdate );
					return newdate;
				}
			}
			else
			{
				if ( i == 2 )
				{
					if ( first == '/' )
					{
						printw ( "%c" , '/' );
						refresh();
						i++; 
						col++;
					}
				}
				else if (  first >= '0' && first <= '9' )
				{
					printw ( "%c" , first );
					refresh();
					i++; 
					col++;
					newdate += ( first - '0' ) * factor;
					factor = factor / 10;
				}
			}
		}
	}
};


/*--------------- GetChoice ----------------*/
int getchoice ( char row, char col )
{
	char first , second;
	move( row , col );
	while ( TRUE )
	{
		first = getch();
		if ( first >= '0' && first <= '9' )
		{
			printw("%c",first);
			refresh();
			while ( TRUE )
			{
				second = getch();
				if ( second == 10 )
				{
					return first;
				}
				if ( second == BKSP )
				{
					move( row , col );
					break;
				}
			}
		}
		else if ( first == 1 )
		{
			first = getch();
			second = getch();
			if ( first == 79 && second == 10 )
				return F16;
		}
	}

}
/*--------------- GetText ----------------*/

void gettext ( char* a , int _size , char row , char col )
{
	int i;
	char first, second;

        move ( row , col );
	for ( i = 0 ; i < _size ; i++ )
	{
		printw( "%c" , ' ' );
	}
	refresh();
	move( row , col );
	printw( "%s" , a );
	i = strlen ( a );
	col = col + i;
	refresh();

	while( i <= _size)
	{
		first = getch();
		first = toupper ( first );
		if ( ( first == BKSP ) && i != 0 )
		{
			col --;
			i--;
			move( row , col );
			printw( " " );
			move ( row , col );
			refresh();
		}

		else if ( first == 1 )
		{
			first = getch();
			second = getch();
			if ( _size >= 10 )
			{
				switch ( first * 256 + second )
				{
					case F1:
					strcpy( a , "DEPTD-" );
					i = 6;
					break;
					case F2:
					strcpy ( a , "CHECK-IN" );
					return;
					break;
					case F3:
					strcpy ( a , "DELAYED" );
					return;
					break;
					case F4:
					strcpy ( a , "LANDED-" );
					i = 7;
					break;
					case F5:
					strcpy ( a , "ETA-" );
					i = 4;
					break;
					case F6:
					strcpy( a , "EXP-" );
					i = 4;
					break;
				}
			} 


			if ( first * 256 + second == F16 )
			{
				a[0] = 0;
				return;
			}
		}
		else
		{
			if ( first == 10 || first == '\t' )
			{
				a[i] = 0;
				return;
			}
			else
			{
				if ( ( first == '-'
				    || isupper( first ) || isdigit( first ) )
				    && i != _size )

				{
					printw ( "%c" , first );
					refresh();
					a[i] = first;
					i++; 
					col++;
				}
			}
		}
	}
};
int spec_date ( int* date , char row , char col )
{
	int dates;

	dates = getdate1 ( *date , row , col );
	if ( dates == 0 )
	{
		cle();
		return TRUE;
	}
	else
	{
		*date = dates;
		return FALSE;
	}

}



void getlined( int pos , int row  )
{
	gettext ( departure[ pos ].flight , 7 , row , FLIGHT );
	gettext ( departure[ pos ].sche , 4 , row , SCHE );
	gettext ( departure[ pos ].actu , 4 , row , ACTU );
	gettext ( departure[ pos ].dest , 3 , row , DEST );
	gettext ( departure[ pos ].via , 3 , row , VIA );
	gettext ( departure[ pos ].board , 4 , row , BOARD );
	gettext ( departure[ pos ].type , 1 , row , TYPE );
	gettext ( departure[ pos ].gate , 2 , row , GATE );
	gettext ( departure[ pos ].remark , 11 , row , REMARK );
}


void getlinea( int pos , int row  )
{
	gettext ( arrival[ pos ].flight , 7 , row , FLIGHT );
	gettext ( arrival[ pos ].sche , 4 , row , SCHE );
	gettext ( arrival[ pos ].actu , 4 , row , ACTU );
	gettext ( arrival[ pos ].dest , 3 , row , DEST );
	gettext ( arrival[ pos ].via , 3 , row , VIA );
	gettext ( arrival[ pos ].type , 1 , row , TYPE );
	gettext ( arrival[ pos ].gate , 2 , row , GATE );
	gettext ( arrival[ pos ].remark , 11 , row , REMARK );
}


void getfieldd( int posindex , int row , int col )
{

	if ( col == FLIGHT )
	{
		departure[ posindex ].flight[ 0 ] = 0;
		gettext ( departure[ posindex ].flight , 7 , row , col );
	}
	else if ( col == SCHE )
	{
		departure[ posindex ].sche[ 0 ] = 0;
		gettext ( departure[ posindex ].sche , 4 , row , col );
	}
	else if ( col == ACTU )
	{
		departure[ posindex ].actu[ 0 ] = 0;
		gettext ( departure[ posindex ].actu , 4 , row , col );
	}
	else if ( col == DEST )
	{
		departure[ posindex ].dest[ 0 ] = 0;
		gettext ( departure[ posindex ].dest , 3 , row , col );
	}
	else if ( col == VIA )
	{
		departure[ posindex ].via[ 0 ] = 0;
		gettext ( departure[ posindex ].via , 3 , row , col );
	}
	else if ( col == BOARD )
	{
		departure[ posindex ].board[ 0 ] = 0;
		gettext ( departure[ posindex ].board , 4 , row , col );
	}
	else if ( col == TYPE )
	{
		departure[ posindex ].type[ 0 ] = 0;
		gettext ( departure[ posindex ].type , 1 , row , col );
	}
	else if ( col == GATE )
	{
		departure[ posindex ].gate[ 0 ] = 0;
		gettext ( departure[ posindex ].gate , 2 , row , col );
	}
	else if ( col == REMARK )
	{
		departure[ posindex ].remark[ 0 ] = 0;
		gettext ( departure[ posindex ].remark , 11 , row , col );
	}
}

void getfielda( int posindex , int row , int col )
{

	if ( col == FLIGHT )
	{
		arrival[ posindex ].flight[ 0 ] = 0;
		gettext ( arrival[ posindex ].flight , 7 , row , col );
	}
	else if ( col == SCHE )
	{
		arrival[ posindex ].sche[ 0 ] = 0;
		gettext ( arrival[ posindex ].sche , 4 , row , col );
	}
	else if ( col == ACTU )
	{
		arrival[ posindex ].actu[ 0 ] = 0;
		gettext ( arrival[ posindex ].actu , 4 , row , col );
	}
	else if ( col == DEST )
	{
		arrival[ posindex ].dest[ 0 ] = 0;
		gettext ( arrival[ posindex ].dest , 3 , row , col );
	}
	else if ( col == VIA )
	{
		arrival[ posindex ].via[ 0 ] = 0;
		gettext ( arrival[ posindex ].via , 3 , row , col );
	}
	else if ( col == TYPE )
	{
		arrival[ posindex ].type[ 0 ] = 0;
		gettext ( arrival[ posindex ].type , 1 , row , col );
	}
	else if ( col == GATE )
	{
		arrival[ posindex ].gate[ 0 ] = 0;
		gettext ( arrival[ posindex ].gate , 2 , row , col );
	}
	else if ( col == REMARK )
	{
		arrival[ posindex ].remark[ 0 ] = 0;
		gettext ( arrival[ posindex ].remark , 11 , row , col );
	}
}


void editd( int posindex , int row , int col )
{

	if ( col < SCHE )
		gettext ( departure[ posindex ].flight , 7 , row , FLIGHT );
	else if ( col < ACTU )
		gettext ( departure[ posindex ].sche , 4 , row , SCHE );
	else if ( col < DEST )
		gettext ( departure[ posindex ].actu , 4 , row , ACTU );
	else if ( col < VIA )
		gettext ( departure[ posindex ].dest , 3 , row , DEST );
	else if ( col < BOARD )
		gettext ( departure[ posindex ].via , 3 , row , VIA );
	else if ( col < TYPE )
		gettext ( departure[ posindex ].board , 4 , row , BOARD );
	else if ( col < GATE )
 		gettext ( departure[ posindex ].type , 1 , row , TYPE );
	else if ( col < REMARK )
		gettext ( departure[ posindex ].gate , 2 , row , GATE );
	else 
		gettext ( departure[ posindex ].remark , 11 , row , REMARK ); 
}



void edita( int posindex , int row , int col )
{

	if ( col < SCHE )
		gettext ( arrival[ posindex ].flight , 7 , row , FLIGHT );
	else if ( col < ACTU )
		gettext ( arrival[ posindex ].sche , 4 , row , SCHE );
	else if ( col < DEST )
		gettext ( arrival[ posindex ].actu , 4 , row , ACTU );
	else if ( col < VIA )
		gettext ( arrival[ posindex ].dest , 3 , row , DEST );
	else if ( col < TYPE )
		gettext ( arrival[ posindex ].via , 3 , row , VIA );
	else if ( col < GATE )
 		gettext ( arrival[ posindex ].type , 1 , row , TYPE );
	else if ( col < REMARK )
		gettext ( arrival[ posindex ].gate , 2 , row , GATE );
	else
		gettext ( arrival[ posindex ].remark , 11 , row , REMARK );
}

int gettime( int olddate , char row , char col )
{
	int newdate = 0 , i , factor;
	char first, second;
	move( row , col );
	printw( "%.2d:%.2d" , olddate / 100 , olddate % 100 );
	refresh();
	i = 5;
	newdate = olddate;
	factor = 0;
	col = col + 5;
	move ( row , col );
	refresh();
	while( i <= 5)
	{
		first = getch();
		if ( ( first == BKSP ) && i != 0 )
		{
			col --;
			i--;
			if ( i != 2 )
			{
				if ( factor == 0 ) factor = 1 ;
				else factor = factor * 10;
				newdate = newdate -  newdate % ( factor * 10 );
			}
			move ( row , col );
			refresh();
		}
		else
		{
			if ( i == 5 )
			{
				if ( first == 10 )
				{
					return newdate;
				}
			}
			else
			{
				if ( i == 2 )
				{
					if ( first == ':' )
					{
						printw ( "%c" , ':' );
						refresh();
						i++; 
						col++;
					}
				}
				else if (  first >= '0' && first <= '9' )
				{
					printw ( "%c" , first );
					refresh();
					i++; 
					col++;
					newdate += ( first - '0' ) * factor;
					factor = factor / 10;
				}
			}
		}
	}
};

