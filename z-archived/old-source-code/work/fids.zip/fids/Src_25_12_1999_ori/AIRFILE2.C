/* --------- Second part of fligh composition. This has been finished
  as well ---------------- */

void deletion( void )
{
	int i , match , found = FALSE;
	char temp[ 8 ];
	temp[ 0 ] = 0;
	if ( not_selected() )
	{
		return;
	}

	move ( 18 , 25 );
	printw ( "flight" );
	refresh ();
	gettext ( temp , 7 , 18 , 32 );
	move ( 18 , 25 );
	printw ( "                                     " );
	refresh ();
	for ( i = 0 ; i <= flight_index[ ftype ] ; i++ )
	{
		match = strcmp ( temp , flights[ ftype ][ i ].num );
		if ( match == 0 )
		{
			found = TRUE;
			break;
		}
	}
	if ( !found )
	{
		move ( 18 , 30 );
		printw ( "UNKNOWN NUMBER" );
		refresh();
		sleep ( 2 );
		move ( 18 , 30 );
		printw( "              " );
		refresh();
		return;
	}
	move ( 20 , 5 );
	printw ( "flight              time           to           via       gate" );
	move ( 21 , 5 );
	printw ( "phr/v     ......    ......         ......" );
	move ( 22 , 5 );
	printw ( "periods" );
	move ( 20 , 15 );
	printw ( "%s" , flights[ ftype ][ i ].num );
	move ( 20 , 30 );
	printw ( "%s" , flights[ ftype ][ i ].time );
	move ( 20 , 43 );
	printw ( "%s" , flights[ ftype ][ i ].dest );
	move ( 20 , 57 );
	printw ( "%s" , flights[ ftype ][ i ].via );
	move ( 20 , 69 );
	printw ( "%s" , flights[ ftype ][ i ].gate );

	move ( 22 , 15 );
	printw ( "%.2d/%.2d" , flights[ ftype ][ i ].per1/100 , flights[ ftype ][ i ].per1 % 100 );
	move ( 22 , 21 );
	printw ( "%.2d/%.2d" , flights[ ftype ][ i ].per2/100 , flights[ ftype ][ i ].per2 % 100 );
	move ( 22 , 27 );
	printw ( "%s" , flights[ ftype ][ i ].day );

	move ( 22 , 35 );
	printw ( "%.2d/%.2d" , flights[ ftype ][ i ].per11/100 , flights[ ftype ][ i ].per11 % 100 );
	move ( 22 , 41 );
	printw ( "%.2d/%.2d" , flights[ ftype ][ i ].per12/100 , flights[ ftype ][ i ].per12 % 100 );
	move ( 22 , 47 );
	printw ( "%s" , flights[ ftype ][ i ].day1 );

	move ( 22 , 55 );
	printw ( "%.2d/%.2d" , flights[ ftype ][ i ].per21/100 , flights[ ftype ][ i ].per21 % 100 );
	move ( 22 , 61 );
	printw ( "%.2d/%.2d" , flights[ ftype ][ i ].per22/100 , flights[ ftype ][ i ].per22 % 100 );
	move ( 22 , 67 );
	printw ( "%s" , flights[ ftype ][ i ].day2 );

	move ( 23 , 15 );
	printw ( "%.2d/%.2d" , flights[ ftype ][ i ].per31/100 , flights[ ftype ][ i ].per31 % 100 );
	move ( 23 , 21 );
	printw ( "%.2d/%.2d" , flights[ ftype ][ i ].per32/100 , flights[ ftype ][ i ].per32 % 100 );
	move ( 23 , 27 );
	printw ( "%s" , flights[ ftype ][ i ].day3 );

	refresh ();
	move ( 18 , 30 );
	printw( "Deletion Confirm ?" );
	refresh();
	temp[ 0 ] = 0;
	gettext ( temp , 1 , 18 , 49 );
	if ( temp[ 0 ] == 'y' || temp[ 0 ] == 'Y' )
	{
		flight_index[ ftype ]--;
		flights[ ftype ][ i ] = flights[ ftype ][ flight_index[ ftype ] ];
	}
	move ( 18 , 30 );
	printw( "                               " );
	move ( 20 , 0 );
	printw ( "                                                                                " );
	move ( 21 , 0 );
	printw ( "                                                                                " );
	move ( 22 , 0 );
	printw ( "                                                                                 " );
	move ( 23 , 0 );
	printw ( "                                                                                 " );

	refresh ();


}
void verifn( void )
{

	int i;
	int tdate1 = 0, tdate2= 0;
	char temp[ 10 ];
	int row = 3;
	temp[ 0 ] = 0;

	if ( not_selected() )
	{
		return;
	}

	move ( 20 , 22 );
	printw ( "FROM   TO       DAY" );
	refresh ();
	tdate1 = getdate1 ( tdate1 , 21 , 22 );
	tdate2 = getdate1 ( tdate2 , 21 , 29 );
	date_trans( &tdate1 , &tdate2 , ftype );
	gettext ( temp , 9 , 21 , 38 );
	clear();
	move ( 1 , 0 );
	printw( "FLIGHTS ON %s LIST                ASKED PERIOD : %.2d/%.2d    %.2d/%.2d  %s"
	    , ( ftype == _ID || ftype == _DD ) ? "DEPARTURE" : "ARRIVAL" , tdate1/100 , tdate1%100 , tdate2 / 100 , tdate2 %
	    100 , temp );

	for ( i = 0 ; i < flight_index[ ftype ] ; i++ )
	{

		if ( matches ( temp , tdate1 , tdate2 , i ) )
		{
			move ( row , 5 );
			printw ( "flight              time           to           via       gate" );
			move ( row + 1 , 5 );
			printw ( "phr/v     ......    ......         ......" );
			move ( row + 2 , 5 );
			printw ( "periods" );
			move ( row , 15 );
			printw ( "%s" , flights[ ftype ][ i ].num );
			move ( row , 30 );
			printw ( "%s" , flights[ ftype ][ i ].time );
			move ( row , 43 );
			printw ( "%s" , flights[ ftype ][ i ].dest );
			move ( row , 57 );
			printw ( "%s" , flights[ ftype ][ i ].via );
			move ( row , 69 );
			printw ( "%s" , flights[ ftype ][ i ].gate );

			move ( row + 2 , 15 );
			printw ( "%.2d/%.2d" , flights[ ftype ][ i ].per1/100 , flights[ ftype ][ i ].per1 % 100 );
			move ( row + 2 , 21 );
			printw ( "%.2d/%.2d" , flights[ ftype ][ i ].per2/100 , flights[ ftype ][ i ].per2 % 100 );
			move ( row + 2 , 27 );
			printw ( "%s" , flights[ ftype ][ i ].day );

			move ( row + 2 , 35 );
			printw ( "%.2d/%.2d" , flights[ ftype ][ i ].per11/100 , flights[ ftype ][ i ].per11 % 100 );
			move ( row + 2 , 41 );
			printw ( "%.2d/%.2d" , flights[ ftype ][ i ].per12/100 , flights[ ftype ][ i ].per12 % 100 );
			move ( row + 2 , 47 );
			printw ( "%s" , flights[ ftype ][ i ].day1 );

			move ( row + 2 , 55 );
			printw ( "%.2d/%.2d" , flights[ ftype ][ i ].per21/100 , flights[ ftype ][ i ].per21 % 100 );
			move ( row + 2 , 61 );
			printw ( "%.2d/%.2d" , flights[ ftype ][ i ].per22/100 , flights[ ftype ][ i ].per22 % 100 );
			move ( row + 2 , 67 );
			printw ( "%s" , flights[ ftype ][ i ].day2 );

			move ( row + 3 , 15 );
			printw ( "%.2d/%.2d" , flights[ ftype ][ i ].per31/100 , flights[ ftype ][ i ].per31 % 100 );
			move ( row + 3 , 21 );
			printw ( "%.2d/%.2d" , flights[ ftype ][ i ].per32/100 , flights[ ftype ][ i ].per32 % 100 );
			move ( row + 3 , 27 );
			printw ( "%s" , flights[ ftype ][ i ].day3 );


			refresh ();
			row += 5;





		}
		if ( row == 23 || i == flight_index[ ftype ] - 1 )
		{
			char first , second;
			row = 3;
			first = getch();
			if ( first == 1 )
			{
				first  == getch();
				second == getch();
				if ( first == 79 && second == 10 )
					return;
			}
			clear();
			move( 1 , 0 );
			printw( "FLIGHTS ON %s LIST                ASKED PERIOD : %.2d/%.2d    %.2d/%.2d  %s" ,  
               	( ftype == _DA || ftype == _DD ) ? "DEPARTURE" : "ARRIVAL" , tdate1/100 , tdate1%100 , tdate2/100 , tdate2%
			    100 , temp );
		}
	}
}

void o_all_modn( void )
{
	int i;
	int tdate1 = 0, tdate2= 0 ;
	char temp[ 10 ];
	temp[ 0 ] = 0;

	if ( not_selected() )
	{
		return;
	}

	move ( 20 , 22 );
	printw ( "FROM   TO       DAY" );
	refresh ();
	tdate1 = getdate1 ( tdate1 , 21 , 22 );
	tdate2 = getdate1 ( tdate2 , 21 , 29 );
	date_trans( &tdate1 , &tdate2 , ftype );
	gettext ( temp , 9 , 21 , 38 );


	for ( i = 0 ; i < flight_index[ ftype ] ; i++ )
	{

		if ( matches ( temp , tdate1 , tdate2 , i ) )
		{
			move ( 20 , 5 );
			printw ( "flight              time           to           via       gate" );
			move ( 21 , 5 );
			printw ( "phr/v     ......    ......         ......" );
			move ( 22 , 5 );
			printw ( "periods" );
			move ( 20 , 15 );
			printw ( "%s" , flights[ ftype ][ i ].num );
			move ( 20 , 30 );
			printw ( "%s" , flights[ ftype ][ i ].time );
			move ( 20 , 43 );
			printw ( "%s" , flights[ ftype ][ i ].dest );
			move ( 20 , 57 );
			printw ( "%s" , flights[ ftype ][ i ].via );
			move ( 20 , 69 );
			printw ( "%s" , flights[ ftype ][ i ].gate );
			refresh();

			if ( spec_date ( &flights[ ftype ][ i ].per1 , 22 , 15 ) )
			{
				return;
			}

			if ( spec_date ( &flights[ ftype ][ i ].per2 , 22 , 21 ) )
			{
				return;
			}

			gettext ( flights[ ftype ][ i ].day , 9 , 22 , 27 );
			if ( flights[ ftype ][ i ].day[ 0 ] == 0 )
			{
				cle();
				return;
			}

			if ( spec_date ( &flights[ ftype ][ i ].per11 , 22 , 35 ) )
			{
				return;
			}

			if ( spec_date ( &flights[ ftype ][ i ].per12 , 22 , 41 ) )
			{
				return;
			}


			gettext ( flights[ ftype ][ i ].day1 , 9 , 22 , 47 );
			if ( flights[ ftype ][ i ].day1[ 0 ] == 0 )
			{
				cle();
				return;
			}

			if ( spec_date ( &flights[ ftype ][ i ].per21 , 22 , 55 ) )
			{
				return;
			}

			if ( spec_date ( &flights[ ftype ][ i ].per22 , 22 , 61 ) )
			{
				return;
			}


			gettext ( flights[ ftype ][ i ].day2 , 9 , 22 , 67 );
			if ( flights[ ftype ][ i ].day2[ 0 ] == 0 )
			{
				cle();
				return;
			}

			if ( spec_date ( &flights[ ftype ][ i ].per31 , 23 , 15 ) )
			{
				return;
			}

			if ( spec_date ( &flights[ ftype ][ i ].per32 , 23 , 21 ) )
			{
				return;
			}

			gettext ( flights[ ftype ][ i ].day3 , 9 , 23 , 27 );
			if ( flights[ ftype ][ i ].day3[ 0 ] == 0 )
			{
				cle();
				return;
			}
                        date_trans( &flights[ ftype ][ flight_index[ ftype ] ].per1 , &flights[ ftype ][ flight_index[ ftype ] ].per2 , ftype );
                        date_trans( &flights[ ftype ][ flight_index[ ftype ] ].per11 , &flights[ ftype ][ flight_index[ ftype ] ].per12 , ftype );
                        date_trans( &flights[ ftype ][ flight_index[ ftype ] ].per21 , &flights[ ftype ][ flight_index[ ftype ] ].per22 , ftype );
                        date_trans( &flights[ ftype ][ flight_index[ ftype ] ].per31 , &flights[ ftype ][ flight_index[ ftype ] ].per32 , ftype );


			cle();

		}


	}


}
void calendar( void )
{
	int y = 2 ;
	int i;
	int newdate;
	char  finished = FALSE;
	i = sort ( holly );
	drawcal ( holly );
	y = i + 2;
	while ( !finished )
	{
		int j;
		newdate = getdate( holly [ i ] , y , 9 );
		if ( newdate == F16 )
		{
			finished = TRUE ;
		}
		else if ( newdate == UP )
		{
			y--;
			i--;
		}
		else if ( newdate == DN )
		{
			y++;
			i++;
		}
		else
		{
			holly[ i ] = newdate;
			i ++;
			y ++;
		}
		if( i == 20 )
		{
			i = 0;
			y = 2;
		}
		if ( i == -1 )
		{
			i = 19;
			y = 21;
		}


		drawcal ( holly );
	}
}


void p_out( void )
{
	int i ;
	int row = 1;
	if ( not_selected() )
	{
		return;
	}

	clear();

	move ( 0 , 0 );
	printw ( "%s" , ftype_string[ ftype ] );
	for ( i = 0 ; i < flight_index[ ftype ] ; i++ )
	{

		move ( row , 5 );
		printw ( "flight . . . . . . .time . . . . . to . . . . . via . . . gate" );
		move ( row + 1 , 5 );
		printw ( "phr/v . . . . . . . . . . . . . . . . . . . " );
		move ( row + 2 , 5 );
		printw ( "periods . . . . . . . . . . . . . . . . . . . . . . . . " );
		move ( row + 3 , 5 );
		printw ( ". . . . . . . . . . . . . . . . " );
		move ( row , 15 );
		printw ( "%s" , flights[ ftype ][ i ].num );
		move ( row , 30 );
		printw ( "%s" , flights[ ftype ][ i ].time );
		move ( row , 43 );
		printw ( "%s" , flights[ ftype ][ i ].dest );
		move ( row , 57 );
		printw ( "%s" , flights[ ftype ][ i ].via );
		move ( row , 69 );
		printw ( "%s" , flights[ ftype ][ i ].gate );
		move ( row + 2 , 15 );
		printw ( "%.2d/%.2d" , flights[ ftype ][ i ].per1/100 , flights[ ftype ][ i ].per1 % 100 );
		move ( row + 2 , 21 );
		printw ( "%.2d/%.2d" , flights[ ftype ][ i ].per2/100 , flights[ ftype ][ i ].per2 % 100 );
		move ( row + 2 , 27 );
		printw ( "%s" , flights[ ftype ][ i ].day );
		move ( row + 2 , 35 );
		printw ( "%.2d/%.2d" , flights[ ftype ][ i ].per11/100 , flights[ ftype ][ i ].per11 % 100 );
		move ( row + 2 , 41 );
		printw ( "%.2d/%.2d" , flights[ ftype ][ i ].per12/100 , flights[ ftype ][ i ].per12 % 100 );
		move ( row + 2 , 47 );
		printw ( "%s" , flights[ ftype ][ i ].day1 );
		move ( row + 2 , 55 );
		printw ( "%.2d/%.2d" , flights[ ftype ][ i ].per21/100 , flights[ ftype ][ i ].per21 % 100 );
		move ( row + 2 , 61 );
		printw ( "%.2d/%.2d" , flights[ ftype ][ i ].per22/100 , flights[ ftype ][ i ].per22 % 100 );
		move ( row + 2 , 67 );
		printw ( "%s" , flights[ ftype ][ i ].day2 );
		move ( row + 3 , 15 );
		printw ( "%.2d/%.2d" , flights[ ftype ][ i ].per31/100 , flights[ ftype ][ i ].per31 % 100 );
		move ( row + 3 , 21 );
		printw ( "%.2d/%.2d" , flights[ ftype ][ i ].per32/100 , flights[ ftype ][ i ].per32 % 100 );
		move ( row + 3 , 27 );
		printw ( "%s" , flights[ ftype ][ i ].day3 );
		refresh ();
		row += 5;

		if ( row == 21 || i == flight_index[ ftype ] - 1 )
		{
			row = 1;
			printf( "%cP\n" , 27 );
			sleep ( 10 );
			clear();
		}
	}
}





