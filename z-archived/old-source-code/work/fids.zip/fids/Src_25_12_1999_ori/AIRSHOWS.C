/*------------------- Drawcal -----------------*/
void drawcal ( int a[20] )
{
	int i;
	clear();
	printw( "         ------------------ CALENDAR\n\n" );
	for ( i = 0 ; i < 20 ; i++ )
	{
		if ( a[ i ] == 0 )
			printw ( "         ../..\n" );
		else
			printw ( "         %.2d/%.2d\n" , a[ i ] / 100 , a[ i ] % 100 );
	}
	refresh ();
};





/*--------------- Show ----------------*/
void show ( char screen[ 24 ][ 81 ] )
{
	int i;
	clear();
	for ( i = 0 ; i <= 23 ; i++ )
	{
		printw ( "%s" , screen[ i ] );
		if ( i != 23 ) printw ( "\n" );
	}
	refresh();
};


/*------------------ Sort --------------------*/
int sort ( int a [ 20 ] )
{
	int i , j , temp;
	for ( i = 19 ; i >=0 ; i -- )
	{
		for ( j = 0 ; j < i ; j++ )
		{
			if ( a [ j ] < a [ j + 1 ] )
			{
				temp= a[ j ];
				a[ j ] = a[ j + 1 ];
				a[ j + 1 ] = temp;
			}
		}
	}
	for ( i = 0 ; i <= 19 ; i++ )
	{
		if ( !a[ i ] ) break;
	}
	return i;
};




void show_dexp ( int curr_pos )
{
	int row , last_date = 0;

	int lines = 0 , i;

	clear();

	for ( i = 0 ; i <= LINE_NO ; rows[ i ] = 0 , i++ );

	printw ( "F   Flight     Sche Actu    To    Via    Board   Type  Gate    Remark          V" );
	for ( row = 1 ; row <= LINE_NO ; row ++ )
	{
		if ( last_date != departure[ row - lines + curr_pos - 1 ].date )
		{
			rows[ row ] = 1;
			move ( row , 0 );
			printw ( "-----------------------------------------------------------------------%.2d/%.2d----" ,
			    departure[ row - lines + curr_pos - 1 ].date/100 , departure[ row - lines + curr_pos - 1 ].date%100);
			lines ++;
			row++;
			if ( row > LINE_NO )
				break;
			last_date = departure[ row - lines + curr_pos - 1 ].date;
		}
		move ( row , FLASH );
		printw ( "%c" , departure[ row - lines + curr_pos - 1 ].flash );
		move ( row , FLIGHT );
		printw ( "%s" , departure[ row - lines + curr_pos - 1 ].flight );
		move ( row , SCHE );
		printw ( "%s" , departure[ row - lines + curr_pos - 1 ].sche );
		move ( row , ACTU );
                printw ( "%s" , departure[ row - lines - curr_pos - 1 ].actu );
		move ( row , DEST );
		printw ( "%s" , departure[ row - lines + curr_pos - 1 ].dest );
		move ( row , VIA );
		printw ( "%s" , departure[ row - lines + curr_pos - 1 ].via );
		move ( row , BOARD );
		printw ( "%s" , departure[ row - lines - curr_pos - 1 ].board );
		move ( row , TYPE );
		printw ( "%s" , departure[ row - lines + curr_pos - 1 ].type );
		move ( row , GATE );
		printw ( "%s" , departure[ row - lines + curr_pos - 1 ].gate );
		move ( row , REMARK );
		printw( "%s" , departure[ row - lines + curr_pos - 1 ].remark );
		move ( row , MODN );
                printw ( "%c" , departure [ row - lines + curr_pos - 1 ].modn );

	}
	refresh();
}


void show_aexp ( int curr_pos )
{
	int row , last_date = 0;

	int lines = 0 , i;

	clear();

	for ( i = 0 ; i <= LINE_NO ; rows[ i ] = 0 , i++ );

	printw ( "F   Flight     Sche Actu    From  Via            Type  Conv    Remark          V" );
	for ( row = 1 ; row <= LINE_NO ; row ++ )
	{
		if ( last_date != arrival[ row - lines + curr_pos - 1 ].date )
		{
			rows[ row ] = 1;
			move ( row , 0 );
			printw ( "-----------------------------------------------------------------------%.2d/%.2d----" ,
			    arrival[ row - lines + curr_pos - 1 ].date/100 , arrival[ row - lines + curr_pos - 1 ].date%100);
			lines ++;
			row++;
			if ( row > LINE_NO )
				break;
			last_date = arrival[ row - lines + curr_pos - 1 ].date;
		}
		move ( row , FLASH );
		printw ( "%c" , arrival[ row - lines + curr_pos - 1 ].flash );
		move ( row , FLIGHT );
		printw ( "%s" , arrival[ row - lines + curr_pos - 1 ].flight );
		move ( row , SCHE );
		printw ( "%s" , arrival[ row - lines + curr_pos - 1 ].sche );
		move ( row , ACTU );
                printw ( "%s" , arrival[ row - lines - curr_pos - 1 ].actu );
		move ( row , DEST );
		printw ( "%s" , arrival[ row - lines + curr_pos - 1 ].dest );
		move ( row , VIA );
		printw ( "%s" , arrival[ row - lines + curr_pos - 1 ].via );
		move ( row , TYPE );
		printw ( "%s" , arrival[ row - lines + curr_pos - 1 ].type );
		move ( row , GATE );
		printw ( "%s" , arrival[ row - lines + curr_pos - 1 ].gate );
		move ( row , REMARK );
		printw( "%s" , arrival[ row - lines + curr_pos - 1 ].remark );
		move ( row , MODN );
                printw ( "%c" , arrival[ row - lines + curr_pos - 1 ].modn );

	}
	refresh();
}



void cle ( void )
{
	move ( 20 , 0 );
	printw( "                                                                            " );
	move ( 21 , 0 );
	printw( "                                                                            " );
	move ( 22 , 0 );
	printw( "                                                                            " );
	move ( 23 , 0 );
	printw( "                                                                            " );
}

