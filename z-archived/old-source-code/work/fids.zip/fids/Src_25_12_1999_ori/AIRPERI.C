void per_vis( void )
{
	int peri_no; 
	int i , j;

	clear();
	move ( 15 , 30 );
	printw( "Peripheral no. ? : " );
	refresh();
	peri_no = getchoice( 15 , 50 ) - '0';
	if ( peri_no > RW4 )
		peri_no = RW4;
	show( scrn_vis );
	move( 4 , 20 );
	printw( "%s" , cgen[ peri_no ].text );
	for ( i = 0 ; i < cgen[ peri_no ].num ; i++ )
	{
		move( 5 + i , 15 );
		for ( j = 0 ; j < strlen( cgen[ peri_no ].lines[ i ] ) ; j++ )
			if ( cgen[ peri_no ].lines[ i ][ j ] == CR )	
				cgen[ peri_no ].lines[ i ][ j ] = ' ';
		printw( "%s" , cgen[ peri_no ].lines[ i ] );
	}
	refresh();
	getch();
	flushinp();
}

void per_time( void )
{
	char y;
	struct TIMEST tim;
	int time , date;
	char command[ 30 ];
	char parameters[ 20 ];	

	airtime( &tim );
	show( scrn_vis );  
	move ( 8 , 25 );
	printw ( "Current time is : %.2d:%.2d" , tim.hs/100 , tim.hs%100 );
	move ( 9 , 25 );
	printw( "Current date is : %.2d:%.2d:%.4d" 
		, tim.md/100 , tim.md%100 , tim.year );
	refresh();
	time = tim.hs;
	date = tim.md;
	move( 7 , 17 );
	printw( "Change current system time and date ? ( y/n ) : " );
	y = getch();
	flushinp();
	if ( y == 'Y' || y == 'y' )
	{
		strcpy( command , "date " );
		printw( "%c" , y );
		move ( 8 , 43 );
		printw( "     " );
		refresh();
		time = gettime( time , 8 , 43 );
		move ( 9 , 43 );
		printw( "          " );
		refresh();
		date = getdate1( date , 9 , 43 );
		if ( time % 100 < 60 && time / 100 < 24 ) 
		{
			sprintf( parameters ,"%.4d%.4d >> log " , date , time );
			strcat ( command , parameters );
			system( command );
		}
	 }
}
void per_serv( void )
  {
	char choice[ 2 ];
	int peri_no;
	choice[ 0 ] = 0;
	clear();
	show ( scrn_vis );
	move( 10 , 30 );
	printw( "Peripheral no. ? : " );
	refresh();
	peri_no = getchoice( 10 , 50 );
	move ( 10 , 22 );
	if ( in_service[ peri_no ] )
	{
		printw( "The peripheral is currently in service." );
		move( 11 , 22 );
		printw( "Put it out of service ? ( y / n ) : " );
		refresh();
		gettext( choice , 1 , 11 , 63 );
		if ( choice[ 0 ] == 'Y' )
			in_service[ peri_no ] = FALSE;
	}
	else 
	{
		printw( "The peripheral is currently out of service. " );
		move( 11 , 22 );
		printw( "Put it in service ? ( y / n ) : " );
		gettext( choice , 1 , 11 , 60 );
		if ( choice[ 0 ] == 'y' || choice[ 0 ] == 'Y' )
			in_service[ peri_no ] = TRUE;
	} 

}
void brd_test( void )
  {
	int i;

	deptest( VP6 );
	arrtest( VQ7 );
	for( i = RP4 ; i <= RW4 ; i++ )
	{
		initdevice( i );
		testdevice( i );
		stopdevice( i );
	}
  }
