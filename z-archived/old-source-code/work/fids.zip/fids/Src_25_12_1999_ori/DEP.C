# include "dep.h"

/* This function gets acknowledgement from a device */

char   getacknow( void )
{
	long i;
	int  b;

	b = 0;
	for( i = 0 ; i < REQUEST ; i++ )
	{
		if( ( b = read( device_fd , ( char* )in_rep , 1 ) ) != 0 )
		{
			b = 1;
			break;
		}
	}
	if( b == 0 )
	{
		return NOREPLY;
	}
	tcflush( device_fd , TCIOFLUSH );
	return in_rep[ 0 ];
}

/* End of getacknow */

/* This function sends data to a device and gets status from it in selecting
   sequence */

void    senddat( int len )
{
	int  i;
	char s;

	for( i = 0 ; i < len ; i++ )
	{
		write( device_fd , out_dat + i , 1 );
	}
	s = getacknow();
	if( s == LCACK )
	{
		printf( "\nPeripheral acknowledges %4x\n" , s );
	}
	else if( s == NOREPLY )
	{
		printf( "\nPeripheral doesn't answere\n" );
	}
	else
	{
		printf( "\n Peripheral acknowledges wrong %2x\n" , s );
	}
}

/* End of senddat */

int initdevice( void )
{
	device_fd= open( device_file, O_NDELAY|O_RDWR );
	if( device_fd > 0 )
	{
		ioctl( device_fd, TCGETA , &device_old );
		ioctl( device_fd, TCGETA , &device_new );
		device_new.c_cflag = 2296;
		device_new.c_lflag = 0;
		device_new.c_iflag = 0;
		device_new.c_cc[ 4 ] = 1;
		ioctl( device_fd, TCSETA , &device_new);
		return OK;
	}
	else
	{
		return LINERR;
	}
}


void   testdevice( void )
{
	out_dat[ 0 ] = LCSTART;
	out_dat[ 1 ] = LCSTATUS;
	out_dat[ 2 ] = LCEND;
	senddat( 3 );
}

void   blank( int line )
{
	out_dat[ 0 ] = LCSTART;
	out_dat[ 1 ] = LCBLANK;
	out_dat[ 2 ] = 49 + line;
	out_dat[ 3 ] = LCEND;
	senddat( 4 );
}

int    makedat( int line )
{
	int i, len;

	out_dat[ 0 ] = LCSTART;
	out_dat[ 1 ] = LCNORM;
	out_dat[ 2 ] = 49 + line;
	out_dat[ 3 ] = 0;
	strcat( out_dat , linedat[ line ] );
	len = strlen( out_dat );
	out_dat[ len ] = LCEND;
	for( i = 0 ; i < len ; i++ )
	{
		if( out_dat[ i ] == ' ' )
		{
			out_dat[ i ] = CR ;
		}
	}
	return ( len + 1 );
}


void   talkdevice( int line )
{
	int len;

	blank( line );
	len = makedat( line);
	senddat( len );
}


void   stopdevice( void )
{
	ioctl( device_fd, TCSETA , &device_old);
	close( device_fd);
}

void   main( int argc , char* argv[] )
{
	int line;

	line = atoi( argv[ 1 ] );
	if( initdevice() == OK )
	{
		system( "stty -a</dev/tty1b" );
		testdevice();
		talkdevice( line );
		stopdevice();
	}
	else
	{
		printf( "\nPeripheral not open\n" );
	}
}
