int is_between( int date1 , int datemin , int date2 )
{
	int yes = FALSE;
	int i;
	
	for ( i = 0 ; i < 370 && date1 != date2 ; i++ )	
	{
		dateinc( &date1 );
		if ( date1 == datemin )
		{
			yes = TRUE;
			break;
		}
	}
	return yes;
}
int isholly ( int date )
{
	int i;
	
	for ( i = 0 ; i < 20 ; i++ )
	{
		if ( date == holly[ i ] )
			return TRUE;
	}
	return FALSE;
}


int datety ( int date )
{
	int out;
	if ( date / 100 < 11 )
	{
		out += 200;
	}
	else if ( date / 100 == 11 )
	{	
		out = date % 100 + 100;
	}
	else 
	{
		out = date % 100 + 200;
	}
	out = isdate ( out );
	return out;
}	


void dayinc ( int *day )
{
	*day = ( *day < 7 ) ? *day + 1 : 1;
} 


void dateinc ( int* date )
{
	if ( *date < 131 )
	{
		( *date )++;
	}
	else if ( *date == 131 )
	{
		*date = 201;
	}
	else if ( *date < 228 )
	{
		( *date ) ++;
	}
	else if ( *date == 228 )
	{
		if ( isleap () )
		{
			*date = 229;
		}
		else
		{
			*date = 301;
		}
	}
	else if ( *date == 229 )
	{
		*date = 301;
	} 
	else if ( *date < 331 )
	{
		( *date )++;
	}
	else if ( *date == 331 )
	{
		*date = 401;
	}
	else if ( *date < 430 )
	{
		( *date )++;
	}
	else if ( *date == 430 )
	{
		*date = 501;
	}
	else if ( *date < 531 )
	{
		( *date )++;
	}
	else if ( *date == 531 )
	{
		*date = 601;
	}
	else if ( *date < 630 )
	{
		( *date )++;
	}
	else if ( *date == 630 )
	{
		*date = 701;
	}
	else if ( *date < 731 )
	{
		( *date )++;
	}
	else if ( *date == 731 )
	{
		*date = 801;
	}
	else if ( *date < 831 )
	{
		( *date )++;
	}
	else if ( *date == 831 )
	{
		*date = 901;
	}
	else if ( *date < 930 )
	{
		( *date )++;
	}
	else if ( *date == 930 )
	{
		*date == 1001;
	}
	else if ( *date < 1031 )
	{
		( *date )++;
	}
	else if ( *date == 1031 )
	{
		*date = 1101;
	}
	else if ( *date < 1130 )
	{
		( *date ) ++;
	}
	else if ( *date == 1130 )
	{
		*date = 1201;
	}
	else if ( *date < 1231 )
	{
		( *date ) ++;
	}
	else 
	{
		*date = 101;
	}
}


dateless ( int date1 , int date2 )
{
	int i , found = FALSE;
	dateinc ( &date1 ); 
	for ( i = 0 ; i <= 70 ; i++ , dateinc ( &date1 ) )
	{
		if ( date1 == date2 )
		{
			found = TRUE;
			break;
		}
	}		 
	return found;
}


int isdate ( int date )
{
	if ( date < 101 )
	{
		date = 101;
	}
	else if ( date > 131 && date < 201 )
	{
		date = 131;
	}
	else if ( date > 229 && date < 301 )
	{
		date = 229;
	}
	else if ( date > 331 && date < 401 )
	{
		date = 331;
	}
	else if ( date > 430 && date < 501 )
	{
		date = 430;
	}
	else if ( date > 531 && date < 601 )
	{
		date = 531;
	}
	else if ( date > 630 && date < 701 )
	{
		date = 630;
	}
	else if ( date > 731 && date < 801 )
	{
		date = 731;
	}
	else if ( date > 831 && date < 901 )
	{
		date = 831;
	}
	else if ( date > 930 && date < 1001 )
	{
		date = 930;
	}
	else if ( date > 1031 && date < 1101 )
	{
		date = 1031;
	}
	else if ( date > 1130 && date < 1201 )
	{
		date = 1130;
	}
	else if ( date > 1231 )
	{
		date = 1231;
	}
	return date;
}



int isleap ( void )
{
	struct TIMEST tim;
	int year;

	airtime( &tim );
	if ( ( tim.year % 4 == 0 ) && ( tim.year % 100 != 0 ) )
	{
		return TRUE;
	}
	else
	{
		return FALSE;
	}
}	

void  airtime( struct TIMEST* TT )
{
	struct  tm   *tp;	
	time_t        t;

	t = time( 0 );
	tp = localtime( &t );
	TT->hs = tp->tm_hour * 100 + tp->tm_min; 
	TT->md = ( tp->tm_mon + 1 ) * 100 + tp->tm_mday; 
	TT->day = tp->tm_wday + 1; 
	TT->year = tp->tm_year + 1900; 
}		
