
/* -------------small functions called from main------------- */

/* ------------ Speech Synthesis --------------*/

void sp_syn( void )
{
	int a , escape = FALSE , ref = TRUE;
	while ( !escape )
	{
		if ( ref )
		{
			show ( scr4 );
			ref = FALSE;
		}
		a = getchoice ( 15 , 35 );
		switch ( a )
		{
		case '1':
		case '2':
		case '3':
		case '4':
		case '5':
			show ( scr_sp_err );
			sleep(2);
			ref = TRUE;
			break;
		case F16:
			escape = TRUE;
			break;
		}
	}
}

/* ----------------- Peripheral list ---------------*/

void per_list( void )
{
	int i;

	for ( i = VP6 ; i <= RW4 ; i++ )
	{
		test( i );
	}
	show ( scr_per_list );
	getch();
}

/*------------------ ONLY FUNCTION UNDER PER_LIST ----------------*/

void test ( int per_no )
{
	/*initdevice( per_no );
	     */strcpy ( &scr_per_list[ 6 + per_no ][ 47 ] , StatusText[ Status[ per_no ] ] );
}

/* --------------- Backup and restore ---------------- */

void bk_up( void )
{
	int   i, a, tempf;
	FILE* _file;
	char name[ 8 ];

	show( scr_bk_up );
	move( 20 , 30 );
	printw(" CHOICE  ? " );
	a = getchoice( 20 , 41 );
	if ( a >= '0' && a <= '5' )
	{
		move( 21 , 12 );
		printw( "Backup / Restore Proceeding on Winchester Disk. Please wait....." );
		refresh();
		sleep ( 2 );
	
		tempf = ftype;
		for ( ftype = 0 ; ftype < 4 ; ftype ++ )
		{
			strcpy ( name , ftype_string[ ftype ] );
			strcat ( name , ".DOC" );

			_file = fopen ( name , "wt" );
			fprintf( _file , "%d %d %d %d\n" , 
				flight[ ftype ].winter_from , 
				flight[ ftype ].winter_to , 
				flight[ ftype ].summer_from , 
				flight[ ftype ].summer_to );
			for ( i = 0 ; i < flight_index[ ftype ] ; i++ )
			{
				fprintf( _file , "%s %s %s %s %s\n"
				    , flights[ ftype ][ i ].num
				    , flights[ ftype ][ i ].time
				    , flights[ ftype ][ i ].dest
				    , flights[ ftype ][ i ].via
				    , ( flights[ ftype ][ i ].gate[ 0 ] ) ?
					 flights[ ftype ][ i ].gate : "|" );
	
				fprintf( _file , "%d %d %s\n"
				    , flights[ ftype ][ i ].per1
				    , flights[ ftype ][ i ].per2
				    , ( flights[ ftype ][ i ].day[ 0 ] )
				    ? flights[ ftype ][ i ].day : "|"  );

				fprintf( _file , "%d %d %s\n"
				    , flights[ ftype ][ i ].per11
				    , flights[ ftype ][ i ].per12
				    , ( flights[ ftype ][ i ].day1[ 0 ] )
				    ? flights[ ftype ][ i ].day1 : "|"  );
	
				fprintf( _file , "%d %d %s\n"
				    , flights[ ftype ][ i ].per21
				    , flights[ ftype ][ i ].per22
				    , ( flights[ ftype ][ i ].day2[ 0 ] )
				    ? flights[ ftype ][ i ].day2 : "|"  );
	
				fprintf( _file , "%d %d %s\n"
				    , flights[ ftype ][ i ].per31
				    , flights[ ftype ][ i ].per32
				    , ( flights[ ftype ][ i ].day3[ 0 ] )
				    ? flights[ ftype ][ i ].day3 : "|"  );
			}
			fclose ( _file );
		}
	}
	ftype = tempf;
	_file = fopen ( "IATA.DOC" , "wt" );
	for ( i = 0 ; i < code_index ; i++ )
	{
		fprintf ( _file , "%s %s\n" , IATA[ i ].code , IATA[ i ].town );
	}
	fclose ( _file );
}

/* ---------------- TEXT AND CYCLE FUNCTIONS --------------------- */
void tc_all( void )
{
     show ( scr_tc );
     sleep( 4 );
}

