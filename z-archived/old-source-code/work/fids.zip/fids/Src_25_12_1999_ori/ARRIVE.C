# include "arrive.h" 

void   talkdevice( void )
{
	char s[ 2 ];
	int  i, c;
	FILE *fil;

	fil = fopen ( "arrlog" , "rt" ); 
	initscr();
	s[ 0 ] = ARHOME; 
	initdevice();
	write( device_fd , s , 1 ); 
	stopdevice(); 
	while ( !feof( fil ) )
	{
		fscanf( fil , "%c" , &c );
		s[ 0 ] = c;
		initdevice();
		write( device_fd , s , 1 ); 
		stopdevice();
	}
	fclose ( fil );
	endwin(); 
} 	

void   initdevice( void )
{
	device_fd = open( device_file , O_WRONLY );
		ioctl( device_fd , TCGETA , &device_old );
		ioctl( device_fd , TCGETA , &device_new );

		device_new.c_iflag = 0;
		device_new.c_oflag = 0;
		device_new.c_lflag = 0;
		device_new.c_cflag = 
		B9600|CS7|CSTOPB|PARENB;

		ioctl( device_fd , TCSETAW , &device_new );
}


void   stopdevice( void )
{
	ioctl( device_fd , TCSETAW , &device_old );
	close( device_fd );
}


void main( void )
{
	talkdevice();
}

