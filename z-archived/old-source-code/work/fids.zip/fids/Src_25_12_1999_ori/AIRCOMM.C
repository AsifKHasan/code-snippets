char  complrc( char* buf1 , char* buf2 )
{
	char *s, c;

	c = buf1[ 0 ];
	for( s = buf1 + 1 ; s <= buf2 ; s++ )
	{
		c ^= (*s);
	}
	return  c;
}

int   checklrc( char* stx , char* etx , char lrc )
{
	char  clrc;

	clrc = complrc( stx + 1 , etx );
	if( clrc == CR )
	{
		clrc = DLE;
	}
	if( clrc == lrc )
	{
		return  1;
	}
	else
	{
		return  0;
	}
}

void  makepollstr( int  dtype )
{
	out_cmd[ 0 ] = SOH;
	out_cmd[ 1 ] = CharPgid[ dtype ];
	out_cmd[ 2 ] = CharPdid[ dtype ];
	out_cmd[ 3 ] = ENQ;
}

void  makeselstr( int  dtype )
{
	out_cmd[ 0 ] = SOH;
	out_cmd[ 1 ] = CharSgid[ dtype ];
	out_cmd[ 2 ] = CharSdid[ dtype ];
	out_cmd[ 3 ] = ENQ;
}

char   getreport( int dtype )
{
	char *stx, *etx, lrc;
	int  i , j, received;

	received = 0;
	for( i = 0 ; i < TIME ; i++ )
	{
		if( rdchk( device_fd[ dtype ] ) > 0 )
		{
			received = 1;
			break;
		}
	}
	if( received == 0 )
	{
		return NOREPLY;
	}
	received = read( device_fd[ dtype ] , in_rep , Binsize );
	tcflush( device_fd[ dtype ] , TCIFLUSH );
	stx = strchr( in_rep , STX );
	etx = strchr( in_rep , ETX );
	if( stx == NULL || etx == NULL )
	{
		return   LINEERR;
	}
	lrc = etx[ 1 ];
	if( checklrc( etx , stx , lrc ) )
	{
		if( ( int )( stx - etx ) == 4 )
		{
			return   NSPEC;
		}
		else
		{
			return stx[ 1 ];
		}
	}
	else
	{
		return   LINEERR;
	}
}

char   getstatus( int dtype )
{
	char s[2];
	int  i , received;

	received = 0;
	for( i = 0 ; i < TIME ; i++ )
	{
		if( rdchk( device_fd[ dtype ] ) > 0 )
		{
			received = 1;
			break;
		}
	}
	if( received == 0 )
	{
		return NOREPLY;
	}
	received = read( device_fd[ dtype ] , s , 2 );
	tcflush( device_fd[ dtype ] , TCIFLUSH );
	return   s[ 0 ];
}

char   getacknow( int dtype )
{
	char s[2];
	int  received;
	int  i;

	received = 0;
	for( i = 0 ; i < TIME ; i++ )
	{
		if( rdchk( device_fd[ dtype ] ) > 0 )
		{
			received = 1;
			break;
		}
	}
	if( received == 0 )
	{
		return NOREPLY;
	}
	received = read( device_fd[ dtype ] , s , 2 );
	tcflush( device_fd[ dtype ] , TCIFLUSH );
	return   s[ 0 ];
}

void   sendack( int dtype )
{
	char  s[2];
	int   txmitted;
	int   len;

	len = 1;
	s[ 0 ] = ACK1;
	tcflush( device_fd[ dtype ] , TCIOFLUSH );
	txmitted = write( device_fd[ dtype ] , s , len );
}

void   sendnack( int dtype )
{
	char  s[2];
	int   txmitted;
	int   len;

	len = 1;
	s[ 0 ] = NACK;
	tcflush( device_fd[ dtype ] , TCIOFLUSH );
	txmitted = write( device_fd[ dtype ] , s , len );
}

void   sendeot( int dtype )
{
	char  s[ 2 ];
	int   txmitted;
	int   len;

	len = 1;
	s[ 0 ] = EOT;
	tcflush( device_fd[ dtype ] , TCIOFLUSH );
	txmitted = write( device_fd[ dtype ] , s , len );
}

int    sendcmd( int dtype , char* buf , int len )
{
	int  txmitted;
	int  i;

	tcflush( device_fd[ dtype ] , TCIOFLUSH );
	txmitted = write( device_fd[ dtype ] , buf , len );
	if( txmitted == len )
	{
		return   _OK;
	}
	else if( txmitted == 0 )
	{
		return   MISSING;
	}
	else
	{
		return   MISSING;
	}
}

void    senddat( int dtype , int len )
{
	int  i;
	char s;

	for( i = 0 ; i < REQUEST ; i++ )
	{
		if( sendcmd( dtype , out_dat , len ) == MISSING )
		{
			Status[ dtype ] = MISSING;
			break;
		}
		s = getstatus( dtype );
		if( s == NOREPLY  )
		{
			if( i == ( REQUEST - 1 ) )
			{
				Status[ dtype ] = DEFAULT;
				break;
			}
			else
			{
				continue;
			}
		}
		else
		{
			break;
		}
	}

	if( s == NACK )
	{
		for( i = 0 ; i < REQUEST - 1 ; i++ )
		{
			sendcmd( dtype , out_dat , len );
			s = getstatus( dtype );
			if( s != NACK && s != NOREPLY )
			{
				break;
			}
		}
	}
	if( s == NOREPLY || s == NACK )
	{
		Status[ dtype ] = DEFAULT;
	}
	else if( s == ESC )
	{
		Status[ dtype ] = _OK;
	}
	else if( s == ACK0 )
	{
		Status[ dtype ] = _OK;
	}
}

void   actreport( char report, int dtype )
{
	switch( report )
	{
	case I_R:
		Status[ dtype ] = _OK;
		break;
	case C_R:
		Status[ dtype ] = _OK;
		break;
	case E_R:
		Status[ dtype ] = _OK;
		break;
	case N_R:
		Status[ dtype ] = _OK;
		break;
	case L_R:
		Status[ dtype ] = LOCAL;
		break;
	default :
		break;
	}
}

void   actstatus( char status , int dtype )
{

}

void   acknowrep( char report , int dtype )
{
	int i;
	int ack;

	actreport( report , dtype );
	for( i = 0 ; i < REQUEST ; i++ )
	{
		sendack( dtype );
		ack = getacknow( dtype );
		if( ack == EOT )
		{
			break;
		}
		else if( ack == NACK )
		{
			continue;
		}
		else if( ack == NOREPLY  && i == ( REQUEST - 1 ) )
		{
			sendeot( dtype );
			Status[ dtype ] = DEFAULT;
			continue;
		}
	}
}


void   initdevice( int dtype )
{
	if( dtype == VQ7 )
		device_fd[ dtype ] = open( device_file[ dtype ] , O_WRONLY );
	
	else
		device_fd[ dtype ] = open( device_file[ dtype ] , O_RDWR ); 
	if( device_fd[ dtype ] == -1 )
	{
		Status[ dtype ] = MISSING;
	}
	else
	{
		Status[ dtype ] = _OK;

		ioctl( device_fd[ dtype ] , TCGETA , &device_old[ dtype ] );
		ioctl( device_fd[ dtype ] , TCGETA , &device_new[ dtype ] );

		if( dtype == VP6 )
		{
			device_new[ dtype ].c_iflag = DOSMODE; 
			device_new[ dtype ].c_oflag = 0; 
			device_new[ dtype ].c_lflag = 0; 
			device_new[ dtype ].c_cflag = B600|CS8|CSTOPB|CREAD|CLOCAL;
		}
		else if( dtype == VQ7 )
		{
			device_new[ dtype ].c_iflag = 0; 
			device_new[ dtype ].c_oflag = 0; 
			device_new[ dtype ].c_lflag = 0; 
			device_new[ dtype ].c_cflag = 
			B9600|CS7|CSTOPB|PARENB|LOBLK; 
		}
		else
		{
			device_new[ dtype ].c_iflag = IGNPAR|INPCK|ICRNL; 
			device_new[ dtype ].c_oflag  = 0;
			device_new[ dtype ].c_lflag = ICANON; 
			device_new[ dtype ].c_cflag = B4800|CS7|PARENB|CSTOPB|CREAD|CLOCAL;
		}
		ioctl( device_fd[ dtype ] , TCSETAW , &device_new[ dtype ] );
	}
}


void   testdevice( int dtype )
{
	int  i;
	char report;

	makepollstr( dtype );
	for( i = 0 ; i < REQUEST ; i++ )
	{
		sendeot( dtype );
		if( sendcmd( dtype , out_cmd , 4 ) == MISSING )
		{
			Status[ dtype ] = MISSING;
			break;
		}
		report = getreport( dtype );
		if( report == NOREPLY  )
		{
			if( i == ( REQUEST - 1 ) )
			{
				Status[ dtype ] = DEFAULT;
				break;
			}
			else
			{
				continue;
			}
		}
		else
		{
			break;
		}
	}

	if( report == LINEERR )
	{
		for( i = 0 ; i < REQUEST ; i++ )
		{
			sendnack( dtype );
			report = getreport( dtype );
			if( report != LINEERR && report != NOREPLY )
			{
				break;
			}
		}
	}
	if( report == NOREPLY || report == LINEERR )
	{
		Status[ dtype ] = DEFAULT;
	}
	else
	{
		acknowrep( report , dtype );
	}
	sendeot( dtype );
}



void   talkdevice( int dtype , int len )
{
	int  i;
	char s;

	makeselstr( dtype );
	for( i = 0 ; i < REQUEST ; i++ )
	{
		sendeot( dtype );
		if( sendcmd( dtype , out_cmd , 4 ) == MISSING )
		{
			Status[ dtype ] = MISSING;
			break;
		}
		s = getacknow( dtype );
		if( s == NOREPLY  )
		{
			if( i == ( REQUEST - 1 ) )
			{
				Status[ dtype ] = DEFAULT;
				break;
			}
			else
			{
				continue;
			}
		}
		else
		{
			break;
		}
	}
	if( s == ACK0 )
	{
		senddat( dtype , len );
	}
	sendeot( dtype );
}


void   stopdevice( int dtype )
{
	tcflush( device_fd[ dtype ] , TCIOFLUSH );
	ioctl( device_fd[ dtype ] , TCSETA , &device_old[ dtype ] );
	close( device_fd[ dtype ] );
}


void make_dep_output( struct exploitation*  depart )
{
	int  i, j, add, len, lenb;
	char merged[ SIZE ];
	char board[ SIZE ];  
	char *tname;
	char *vname; 
	int  count[ LINKS ];

	count[ VP6 ] = count[ RP4 ] = count[ RR4 ] = count[ RS4 ] = 0;
	for( i = 0 ; i < numdexp ; i++ )
	{
		tname = town( depart[ i ].dest );
		vname = town( depart[ i ].via ); 
		if( ( tname[ 0 ] == NUL ) || ( vname[ 0 ] == NUL ) )
		{
			move( 23 , 0 );
			printw( "Unknown IATA code %s. Validation aborted." , depart[ i ].dest );
			refresh();
			sleep( 5 );
			return;
		}

		board[ 0 ] = ' '; 
		board[ 1 ] = ' '; 
		board[ 2 ] = ' '; 
		board[ 3 ] = NUL; 

		if( depart[ i ].flash == 'F' )
		{
			strcpy( merged , "*" );
			strcat( board , "*" );
		}
		else
		{
			strcpy( merged , " " );
			strcat( board , "" );
		}

		lenb = strlen( board ); 
		board[ lenb ] = 'c'; 
		board[ lenb + 1 ] = NUL; 

		strcat( merged , depart[ i ].sche );

		strcat( board , depart[ i ].sche ); 
		lenb = strlen( board ); 
		board[ lenb ] = 'c'; 
		board[ lenb + 1 ] = NUL; 

		len = strlen( merged );
		add = FLIGHTPOS - len;
		for( j = 0 ; j < add ; j++ )
		{
			strcat( merged , " " );
		}
		strcat( merged , depart[ i ].flight );

		strcat( board , depart[ i ].flight ); 
		lenb = strlen( board ); 
		board[ lenb ] = 'c'; 
		board[ lenb + 1 ] = NUL; 

		len = strlen( merged );
		add = TOWNPOS - len;
		for( j = 0 ; j < add ; j++ )
		{
			strcat( merged , " " );
		}
		strcat( merged , tname );

		strcat( board , tname ); 
		lenb = strlen( board ); 
		board[ lenb ] = 'c'; 
		board[ lenb + 1 ] = NUL; 

		strcat( board , vname );
		lenb = strlen( board ); 
		board[ lenb ] = 'c'; 
		board[ lenb + 1 ] = NUL;
		
		strcat( board , depart[ i ].gate ); 
		lenb = strlen( board ); 
		board[ lenb ] = 'c'; 
		board[ lenb + 1 ] = NUL; 

		len = strlen( merged );
		add = REMARKPOS - len;
		for( j = 0 ; j < add ; j++ )
		{
			strcat( merged , " " );
		}
		strcat( merged , depart[ i ].remark );

		strcat( board , depart[ i ].remark ); 
		lenb = strlen( board ); 
		board[ lenb ] = 'c'; 
		board[ lenb + 1 ] = 'd'; 
		board[ lenb + 2 ] = NUL; 

		if( depart[ i ].type[ 0 ] == 'I' )
		{
			if( count[ VP6 ] < MAXADENT )
			{
				board[ 2 ] = 49 + count[ VP6 ]; 
				strcpy( cgen[ VP6 ].lines[ count[ VP6 ] ] , board ); 
				count[ VP6 ]++; 
				depart[ i ].modn = '*'; 
			}

			if( count[ RP4 ] < MAXENTRY )
			{
				strcpy( cgen[ RP4 ].lines[ count[ RP4 ] ] , merged );
				count[ RP4 ]++;
				depart[ i ].modn = '*';
			}
			if( count[ RS4 ] < MAXENTRY )
			{
				strcpy( cgen[ RS4 ].lines[ count[ RS4 ] ] , merged );
				count[ RS4 ]++;
				depart[ i ].modn = '*';
			}
		}
		else if( depart[ i ].type[ 0 ] == 'D' )
		{
			if( count[ RR4 ] < MAXENTRY )
			{
				strcpy( cgen[ RR4 ].lines[ count[ RR4 ] ] , merged );
				count[ RR4 ]++;
				depart[ i ].modn = '*';
			}
			if( count[ RS4 ] < MAXENTRY )
			{
				strcpy( cgen[ RS4 ].lines[ count[ RS4 ] ] , merged );
				count[ RS4 ]++;
				depart[ i ].modn = '*';
			}
		}
	}
	cgen[ VP6 ].num = count[ VP6 ];
	cgen[ RP4 ].num = count[ RP4 ];
	cgen[ RR4 ].num = count[ RR4 ];
	cgen[ RS4 ].num = count[ RS4 ];
	if( in_service[ RP4 ] )
	{
		expchgen( RP4 );
	}
	if( in_service[ RR4 ] )
	{
		expchgen( RR4 );
	}
	if( in_service[ RS4 ] )
	{
		expchgen( RS4 );
	}
	if( in_service[ VP6 ] )
	{
		depexploit( VP6 );
	}
}

void make_arr_output( struct exploitation*  arrive )
{
	int  i, j, add, len;
	char merged[ SIZE ];
	char board[ SIZE ]; 
	char *tname, *vname;
	int  count[ LINKS ];

	count[ VQ7 ] = count[ RQ4 ] = count[ RT4 ] = count[ RU4 ] = count[ RV4 ] = count[ RW4 ] = 0;
	for( i = 0 ; i < numaexp ; i++ )
	{
		tname = town( arrive[ i ].dest );
		vname = town( arrive[ i ].via ); 
		if( ( tname[ 0 ] == NUL ) || ( vname[ 0 ] == NUL ) )
		{
			move( 23 , 0 );
			printw( "Unknown IATA code %s. Validation aborted." , arrive[ i ].dest );
			sleep( 2 );
			return;
		}

		if( arrive[ i ].flash == 'F' )
		{
			strcpy( merged , "*" );
			strcpy( board , "*" );
		}
		else
		{
			strcpy( merged , " " );
			strcpy( board , " " ); 
		}

		strcat( merged , arrive[ i ].sche );
		strcat( board , arrive[ i ].sche ); 

		len = strlen( merged );
		add = FLIGHTPOS - len;
		for( j = 0 ; j < add ; j++ )
		{
			strcat( merged , " " );
		}

		len = strlen( board ); 
		add = ARRFLIGHT - len; 
		for( j = 0 ; j < add ; j++ )
		{
			strcat( board , " " );
		}

		strcat( merged , arrive[ i ].flight );
		strcat( board , arrive[ i ].flight );

		len = strlen( merged );
		add = TOWNPOS - len;
		for( j = 0 ; j < add ; j++ )
		{
			strcat( merged , " " );
		}

		len = strlen( board ); 
		add = ARRTOWN - len; 
		for( j = 0 ; j < add ; j++ )
		{
			strcat( board , " " ); 
		}

		strcat( merged , tname );
		strcat( board , tname ); 

		len = strlen( board );
		add = ARRVIA - len; 
		for( j = 0 ; j < add ; j++ )
		{
			strcat( board , " " );
		}
		strcat( board , vname ); 

		len = strlen( merged ); 
		add = REMARKPOS - len; 
		for( j = 0 ; j < add ; j++ )
		{
			strcat( merged , " " );
		}

		len = strlen( board );
		add = ARRREMARK - len; 
		for( j = 0 ; j < add ; j++ )
		{
			strcat( board , " " );
		}
		strcat( board , arrive[ i ].remark ); 
		strcat( merged , arrive[ i ].remark ); 

		len = strlen( board ); 
		add = ARREND - len; 
		for( j = 0 ; j < add ; j++ )
		{
			strcat( board , " " );
		}

		if( arrive[ i ].type[ 0 ] == 'D' )
		{
			if( count[ RT4 ] < MAXENTRY )
			{
				strcpy( cgen[ RT4 ].lines[ count[ RT4 ] ] , merged );
				count[ RT4 ]++;
				arrive[ i ].modn = '*';
			}
		}
		else if( arrive[ i ].type[ 0 ] == 'I' )
		{
			if( count[ VQ7 ] < MAXADENT )
			{
				strcpy( cgen[ VQ7 ].lines[ count[ VQ7 ] ] , board ); 
				count[ VQ7 ]++;
				arrive[ i ].modn = '*'; 
			}
			if( count[ RQ4 ] < MAXENTRY )
			{
				strcpy( cgen[ RQ4 ].lines[ count[ RQ4 ] ] , merged );
				count[ RQ4 ]++;
				arrive[ i ].modn = '*';
			}
			if( count[ RT4 ] < MAXENTRY )
			{
				strcpy( cgen[ RT4 ].lines[ count[ RT4 ] ] , merged );
				count[ RT4 ]++;
				arrive[ i ].modn = '*';
			}
		}
		if( ( arrive[ i ].gate[ 0 ] == '1' ) && ( arrive[ i ].type[ 0 ] == 'I' ) )
		{
			if( count[ RU4 ] < MAXENTRY )
			{
				strcpy( cgen[ RU4 ].lines[ count[ RU4 ] ] , merged );
				count[ RU4 ]++;
				arrive[ i ].modn = '*';
			}
		}
		else if( ( arrive[ i ].gate[ 0 ] == '2' ) && ( arrive[ i ].type[ 0 ] == 'I' ) )
		{
			if( count[ RV4 ] < MAXENTRY )
			{
				strcpy( cgen[ RV4 ].lines[ count[ RV4 ] ] , merged );
				count[ RV4 ]++;
				arrive[ i ].modn = '*';
			}
		}
		else if( ( arrive[ i ].gate[ 0 ] == '3' ) && ( arrive[ i ].type[ 0 ] == 'I' ) )
		{
			if( count[ RW4 ] < MAXENTRY )
			{
				strcpy( cgen[ RW4 ].lines[ count[ RW4 ] ] , merged );
				count[ RW4 ]++;
				arrive[ i ].modn = '*';
			}
		}

	}
	cgen[ VQ7 ].num = count[ VQ7 ];
	cgen[ RQ4 ].num = count[ RQ4 ];
	cgen[ RT4 ].num = count[ RT4 ];
	cgen[ RU4 ].num = count[ RU4 ];
	cgen[ RV4 ].num = count[ RV4 ];
	cgen[ RW4 ].num = count[ RW4 ];
	if( in_service[ RQ4 ] )
	{
		expchgen( RQ4 );
	}
	if( in_service[ RT4 ] )
	{
		expchgen( RT4 );
	}	
	if( in_service[ RU4 ] )
	{
		expchgen( RU4 );
	}	
	if( in_service[ RV4 ] )
	{
		expchgen( RV4 );
	}	
	if( in_service[ RW4 ] )
	{
		expchgen( RW4 );
	}
	if( in_service[ VQ7 ] )
	{
		arrexploit( VQ7 ); 
	}
}

void expchgen( int dtype )
{
	int  i, len;

	out_dat[ 0 ] = STX;
	out_dat[ 1 ] = DECMODE;
	out_dat[ 2 ] = CCLS;
	out_dat[ 3 ] = CHOME;
	out_dat[ 4 ] = ESC;
	out_dat[ 5 ] = 'P';
	out_dat[ 6 ] =  PAGE1;
	out_dat[ 7 ] =  INITZ;
	out_dat[ 8 ] =  MEDIUM; 
	out_dat[ 9 ] =  NUL;
	strcat( out_dat , cgen[ dtype ].text );
	len = strlen( out_dat );
	out_dat[ len ] = CR;  
	out_dat[ len + 1 ] = LF;
	out_dat[ len + 2 ] = INITZ;
	out_dat[ len + 3 ] = UNDLINE;
	out_dat[ len + 4 ] = NUL;

	strcat( out_dat , cgen[ dtype ].format );
	len = strlen( out_dat );
	out_dat[ len ] = CR;
	out_dat[ len + 1 ] = LF;
	out_dat[ len + 2 ] = INITZ;
	out_dat[ len + 3 ] = MEDIUM;
	out_dat[ len + 4 ] = NUL;

	for( i = 0 ; i < cgen[ dtype ].num ; i++ )
	{
		strcat( out_dat , cgen[ dtype ].lines[ i ] );
		len = strlen( out_dat );
		out_dat[ len ] = CR; 
		out_dat[ len + 1 ] = NUL;
	}
	if( i == MAXENTRY )
	{
		len = len - 1;
	}
	out_dat[ len + 1 ] = ETX;
	out_dat[ len + 2 ] = complrc( out_dat + 1 , out_dat + len + 1 );
        initdevice( dtype );
	talkdevice( dtype , len + 3 );
        stopdevice( dtype );
}


void    depsenddat( int dtype , int len )
{
	int  i, j;
	FILE *f; 
	
	f = fopen( "deplog" , "wt" ); 
	fprintf( f , "%s" , out_dat ); 	
	fclose( f );
	system( "airdepart" ); 
}

void   deptest( int dtype )
{

}

void   arrtest( int dtype )
{
	
}

void   depexploit( int dtype )
{
	int i, len;

	out_dat[ 0 ] = NUL; 
	for( i = 0 ; i < cgen[ dtype ].num ; i++ )
	{
		strcat( out_dat , cgen[ dtype ].lines[ i ] ); 
	}
	len = strlen( out_dat ); 
	depsenddat( dtype , len ); 
} 

void   arrexploit( int dtype )
{
	int i, len;

	out_dat[ 0 ] = NUL; 
	for( i = 0 ; i < cgen[ dtype ].num ; i++ )
	{
		strcat( out_dat , cgen[ dtype ].lines[ i ] ); 
	}
	len = strlen( out_dat ); 
	arrsenddat( dtype , len );
}

void   arrsenddat( int dtype , int len )
{
	int  i,j;
	FILE* f;

	f = fopen( "arrlog" , "wt" ); 
	fprintf( f , "%s" , out_dat ); 
	fclose( f ); 
	system( "airarrive" ); 
} 	

