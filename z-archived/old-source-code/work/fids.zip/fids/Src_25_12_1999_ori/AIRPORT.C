# include "airdefs.h"
# include "airstruc.h"
# include "airenums.h"
# include "airglobe.h"
# include "airfuncs.h"

# include "airscrn.h"

# include "airutils.c"
# include "airshows.c"
# include "airgets.c"
# include "airdates.c"
# include "aircomm.c"


# include "aircode.c"       /* Coding Composition */
# include "airfile1.c"      /* Flight Composition */
# include "airfile2.c"      /* Flight Composition */
# include "airaexp.c"       /* Arrival Exploitation */
# include "airdexp.c"       /* Departure Exploitation */
# include "airperi.c"       /* Peripheral Functions */
# include "airsmall.c"      /* Backup and Speech Synthesis */

void main ( void )
{
	int  a , going = TRUE , ref = TRUE;
	char temp[ 3 ];
	readfiles();
	initscr();
	noecho();
	while ( going )
	{

		if ( ref )
		{
			show ( scr1 );
			ref = FALSE;
		}
		move( 2 , 44 );
		a = getkey ();
		switch ( a )
		{
		case '0':
			coding_comp();
			ref = TRUE;
			break;
		case '1':
			flight_comp();
			ref = TRUE;
			break;
		case '3':
			arriv_exp();
			ref = TRUE;
			break;
		case '4':
			depart_exp();
			ref = TRUE;
			break;
		case '5':
		case '6':
		case '7':
			tc_all();
			ref = TRUE;
			break;
		case '8':
			sp_syn();
			ref = TRUE;
			break;
		case '9':
			per_list();
			ref = TRUE;
			break;
		case 'A':
		case 'a':
			per_vis();
			ref = TRUE;
			break;
		case 'B':
		case 'b':
			per_time();
			ref = TRUE;
			break;
		case 'C':
		case 'c':
			per_serv();
			ref = TRUE;
			break;
		case 'D':
		case 'd':
			ref = TRUE;
			break;
		case 'E':
		case 'e':
			brd_test();
			ref = TRUE;
			break;
		case 'G':
		case 'g':
			bk_up();
			ref = TRUE;
			break;
		case F1:
			going = FALSE;
			break;
		}

	}
	echo();
	endwin ();
}



void readfiles ( void )
{
	FILE* _file;
	/* READING THE CODING COMPOSITION FILE */
	_file = fopen ("IATA.DOC" , "rt" );
	for ( code_index= 0 ; !feof ( _file ) ; code_index++ )
	{
		fscanf( _file , "%s %s\n" , IATA[ code_index ].code , IATA[ code_index ].town );
	}
	fclose ( _file );
	/* READING THE INTERNATIONAL ARRIVALS FILE */
	_file = fopen ("IA.DOC" , "rt" );
	scanfile( _file , _IA );

	/* READING THE INTERNATIONAL DEPARTURES FILE */
	_file = fopen ("ID.DOC" , "rt" );
	scanfile( _file , _ID );

	/* READING THE DOMESTIC DEPARTURES FILE */
	_file = fopen ("DD.DOC" , "rt" );
	scanfile( _file , _DD );

	/* READING THE DOMESTIC ARRIVALS FILE */
	_file = fopen ("DA.DOC" , "rt" );
	scanfile( _file , _DA );
}

void scanfile( FILE* file , int d )
{
	fscanf( file , "%d %d %d %d" , 
		&flight[ d ].winter_from , &flight[ d ].winter_to , 
		&flight[ d ].summer_from , &flight[ d ].summer_to );
	for ( flight_index[ d ] = 0 ; !feof ( file ) ; flight_index[ d ]++ )
	{
		fscanf( file , "%s %s %s %s %s\n"
		    , flights[ d ][ flight_index[ d ] ].num
		    , flights[ d ][ flight_index[ d ] ].time
		    , flights[ d ][ flight_index[ d ] ].dest
		    , flights[ d ][ flight_index[ d ] ].via
		    , flights[ d ][ flight_index[ d ] ].gate );
		if ( flights[ d ][ flight_index[ d ] ].gate[ 0 ] == '|' )
		{
			flights[ d ][ flight_index[ d ] ].gate[ 0 ] = 0;
		}
		fscanf ( file , " %d %d %s\n"
		    , &flights[ d ][ flight_index[ d ] ].per1
		    , &flights[ d ][ flight_index[ d ] ].per2
		    , flights[ d ][ flight_index[ d ] ].day );
		if ( flights[ d ][ flight_index[ d ] ].day[ 0 ] == '|' )
			strcpy ( flights[ d ][ flight_index[ d ] ].day , "" );

		fscanf ( file , " %d %d %s\n"
		    , &flights[ d ][ flight_index[ d ] ].per11
		    , &flights[ d ][ flight_index[ d ] ].per12
		    , flights[ d ][ flight_index[ d ] ].day1 );
		if ( flights[ d ][ flight_index[ d ] ].day1[ 0 ] == '|')
			strcpy ( flights[ d ][ flight_index[ d ] ].day1 , "" );

		fscanf ( file , " %d %d %s\n"
		    , &flights[ d ][ flight_index[ d ] ].per21
		    , &flights[ d ][ flight_index[ d ] ].per22
		    , flights[ d ][ flight_index[ d ] ].day2 );
		if ( flights[ d ][ flight_index[ d ] ].day2[ 0 ] == '|' )
			strcpy ( flights[ d ][ flight_index[ d ] ].day2 , "" );

		fscanf ( file , " %d %d %s\n"
		    , &flights[ d ][ flight_index[ d ] ].per31
		    , &flights[ d ][ flight_index[ d ] ].per32
		    , flights[ d ][ flight_index[ d ] ].day3  );
		if ( flights[ d ][ flight_index[ d ] ].day3[ 0 ] == '|' )
			strcpy ( flights[ d ][ flight_index[ d ] ].day3 , "" );
		if ( flights[ d ][ flight_index[ d ] ].num[ 0 ] == 0 )
			break;
	}
	fclose ( file );

}
